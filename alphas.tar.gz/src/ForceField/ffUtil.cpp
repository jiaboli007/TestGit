#include <algorithm>
#include <iostream>
#include <vector>

#include <math.h>

#include "ffUtil.h"

#include "Misc/fragment2D.h"
#include "MolStructure/canonUtil.h"
#include "Singleton/params.h"

namespace MISS {

FFRecord::FFRecord() {
    frequency = 0;
    parameter = 0;
}

FFRecord::~FFRecord() {}

FFRecord* findRecord(std::map<std::string, FFRecord*>& records, double rvalue) {
    char bufx[40];
    char buf0[40];
    char buf1[40];
    double rankvalue = rvalue;
    sprintf(bufx, "%15.13f", rankvalue);
    sprintf(buf0, "%15.13f", rankvalue - 9E-14);
    sprintf(buf1, "%15.13f", rankvalue + 9E-14);
    if (std::string(bufx) == std::string(buf0)) sprintf(buf0, "%15.13f", rankvalue - 11E-14);
    if (std::string(bufx) == std::string(buf1)) sprintf(buf1, "%15.13f", rankvalue + 11E-14);
    //
    // Check FragConfLib first.
    //
    if (records.find(std::string(buf0)) != records.end()) {
        return records[std::string(buf0)];
    } else if (records.find(std::string(buf1)) != records.end()) {
        return records[std::string(buf1)];
    } else if (records.find(std::string(bufx)) != records.end()) {
        return records[std::string(bufx)];
    }
    return 0;
}

// Scane FF elements
void FFScan(MFCFrag* Frag, std::map<std::string, FFRecord*>& Elements,
            std::map<std::string, FFRecord*>& Bonds, std::map<std::string, FFRecord*>& Angles,
            std::map<std::string, FFRecord*>& Torsions) {
    double rankValue = 0;
    CodingProfile* xfile = CodingProfile::Instance();
    PeriodicTable* xTable = PeriodicTable::Instance();
    double initRValue;
    double eps = xfile->eps;
    char buf[100];
    MFCAtom* Atom;
    MFCAtom* Atom1;
    MFCBond* Bond;
    FFRecord* record = 0;
    int hybtype = 0;
    for (int i = 0; i < Frag->numAtoms; i++) {
        hybtype = 0;
        Atom = Frag->atomList[i];
        if (Atom->hybride == MFC_SP_HYBRID) hybtype = 1;
        if (Atom->hybride == MFC_SP2_HYBRID) hybtype = 2;
        if (Atom->hybride == MFC_SP3_HYBRID) hybtype = 3;
        int nBonds = Atom->nBonds;
        double bb = 0;
        for (int j = 0; j < nBonds; j++) {
            Bond = Frag->bondList[Atom->bondList[j]];
            if (Bond->bondType == 1)
                bb = bb + xfile->bFactors[1];
            else if (Bond->bondType == 2)
                bb = bb + xfile->bFactors[2];
            else if (Bond->bondType == 3)
                bb = bb + xfile->bFactors[3];
            else if (Bond->bondType == 4)
                bb = bb + xfile->bFactors[4];
            else if (Bond->bondType == 5)  // 1.5
                bb = bb + xfile->bFactors[5];
            else if (Bond->bondType == 6)  // 2.5
                bb = bb + xfile->bFactors[6];
            else
                bb = bb + xfile->bFactors[7];  // Any
        }

        initRValue = xfile->aFactors[Atom->atomicNumber] + xfile->cFactor * hybtype +
                     xfile->bFactors[7] * nBonds + xfile->cFactor * Atom->FormalCharge;
        //                 xfile->cFactor*hybtype + bb +

        Atom->RankValue = xscale(initRValue);

        record = findRecord(Elements, Atom->RankValue);
        if (record) {
            record->frequency++;
        } else {
            record = new FFRecord();
            record->frequency++;
            int ii = Atom->atomicNumber;
            sprintf(buf, "%s_SP%d_%d_%lf", xTable->AtomicSymbolNoSpace(ii).c_str(), hybtype, nBonds,
                    Atom->FormalCharge);
            record->label = std::string(buf);
            sprintf(buf, "%15.13f", Atom->RankValue);
            record->recordID = std::string(buf);
            Elements[std::string(buf)] = record;
            if (xTable->AtomicSymbolNoSpace(ii) == std::string("F")) {
                std::cout << "Atomic Number =" << Atom->atomicNumber << "\n";
                std::cout << "FragName = " << Frag->fragname << "\n";
                std::cout << "hybtype  = " << hybtype << "\n";
                std::cout << "nBonds   = " << nBonds << "\n";
                std::cout << "bb       = " << bb << "\n";
                std::cout << "Charge   = " << Atom->FormalCharge << "\n";
                std::cout << "recordID = " << record->recordID << "\n";
            }
        }
    }

    MFCBond* Bond1;
    for (int i = 0; i < Frag->numBonds; i++) {
        Bond = Frag->bondList[i];
        Atom = Frag->atomList[Bond->atom1];
        Atom1 = Frag->atomList[Bond->atom2];
        std::string label = "";
        double bb;
        int jj;

        jj = Atom->atomicNumber;
        sprintf(buf, "%s", xTable->AtomicSymbolNoSpace(jj).c_str());
        label = label + std::string(buf);

        if (Bond->bondType == 1) {
            bb = xfile->bFactors[1];
            label = label + std::string("--");
        } else if (Bond->bondType == 2) {
            bb = xfile->bFactors[2];
            label = label + std::string("==");
        } else if (Bond->bondType == 3) {
            bb = xfile->bFactors[3];
            label = label + std::string("##");
        } else if (Bond->bondType == 4) {
            bb = xfile->bFactors[4];
            label = label + std::string("~~");  // Aromatic
        } else if (Bond->bondType == 5) {
            bb = xfile->bFactors[5];
            label = label + std::string("-=");
        } else {
            bb = xfile->bFactors[6];
            label = label + std::string("xx");
        }

        jj = Atom1->atomicNumber;
        sprintf(buf, "%s", xTable->AtomicSymbolNoSpace(jj).c_str());
        label = label + std::string(buf);

        // double tvalue = Atom->RankValue + Atom1->RankValue
        double tvalue = xfile->aFactors[Atom->atomicNumber] + xfile->aFactors[Atom1->atomicNumber];
        //                  + bb;
        tvalue = xscale(tvalue);
        record = findRecord(Bonds, tvalue);
        if (record) {
            record->frequency++;
        } else {
            record = new FFRecord();
            record->frequency = 1;
            record->label = label;
            sprintf(buf, "%15.13f", tvalue);
            record->recordID = std::string(buf);
            Bonds[std::string(buf)] = record;
        }
    }

    std::string tmpstr;
    for (int i = 0; i < Frag->numAtoms; i++) {
        Atom = Frag->atomList[i];
        int nBonds = Atom->nBonds;
        if (nBonds < 2) continue;
        double bb = 0;
        Atom1 = 0;
        std::string label = "";
        for (int j = 0; j < nBonds; j++) {
            Bond = Frag->bondList[Atom->bondList[j]];
            Atom1 = Frag->atomList[Atom->atomList[j]];
            int jj = Atom1->atomicNumber;
            if (Bond->bondType == 1) tmpstr = "";
            if (Bond->bondType == 2) tmpstr = "=";
            if (Bond->bondType == 3) tmpstr = "#";
            if (Bond->bondType == 4) tmpstr = "~";   // Aromatic bond
            if (Bond->bondType == 5) tmpstr = "-.";  // Aromatic bond
            sprintf(buf, "(%s%s)", tmpstr.c_str(), xTable->AtomicSymbolNoSpace(jj).c_str());
            label = label + std::string(buf);
        }

        Atom->RankValue = xscale(Atom->RankValue);
        record = findRecord(Angles, Atom->RankValue);
        if (record) {
            record->frequency++;
        } else {
            record = new FFRecord();
            record->frequency++;
            int ii = Atom->atomicNumber;
            sprintf(buf, "%s:", xTable->AtomicSymbolNoSpace(ii).c_str());
            record->label = std::string(buf) + label;
            sprintf(buf, "%15.13f", Atom->RankValue);
            record->recordID = std::string(buf);
            Angles[std::string(buf)] = record;
        }
    }

    for (int i = 0; i < Frag->numBonds; i++) {
        Bond = Frag->bondList[i];
        Atom = Frag->atomList[Bond->atom1];
        Atom1 = Frag->atomList[Bond->atom2];
        int nBond1 = Atom->nBonds;
        int nBond2 = Atom1->nBonds;
        if (nBond1 < 2 || nBond2 < 2) continue;
        MFCAtom* Atom3 = 0;
        std::string label = "";
        int jj;
        int count = 0;
        for (int j = 0; j < nBond1; j++) {
            Bond1 = Frag->bondList[Atom->bondList[j]];
            Atom3 = Frag->atomList[Atom->atomList[j]];
            if (Atom3 == Atom1) continue;
            jj = Atom3->atomicNumber;
            tmpstr = "xx";
            if (Bond1->bondType == 1) tmpstr = "";
            if (Bond1->bondType == 2) tmpstr = "=";
            if (Bond1->bondType == 3) tmpstr = "#";
            if (Bond1->bondType == 4) tmpstr = "~";   // Aromatic bond
            if (Bond1->bondType == 5) tmpstr = "-.";  // Aromatic bond
            sprintf(buf, "(%s%s)", xTable->AtomicSymbolNoSpace(jj).c_str(), tmpstr.c_str());
            label = label + std::string(buf);
        }
        jj = Atom->atomicNumber;
        sprintf(buf, "%s", xTable->AtomicSymbolNoSpace(jj).c_str());
        label = label + std::string(buf);
        double bb;
        if (Bond->bondType == 1) {
            bb = xfile->bFactors[1];
            label = label + std::string("--");
        } else if (Bond->bondType == 2) {
            bb = xfile->bFactors[2];
            label = label + std::string("==");
        } else if (Bond->bondType == 3) {
            bb = xfile->bFactors[3];
            label = label + std::string("##");
        } else if (Bond->bondType == 4) {
            bb = xfile->bFactors[4];
            label = label + std::string("~~");  // Aromatic
        } else if (Bond->bondType == 5) {
            bb = xfile->bFactors[5];
            label = label + std::string("-=");
        } else {
            bb = xfile->bFactors[6];
            label = label + std::string("xx");
        }
        jj = Atom1->atomicNumber;
        sprintf(buf, "%s", xTable->AtomicSymbolNoSpace(jj).c_str());
        label = label + std::string(buf);
        count = 0;
        for (int j = 0; j < nBond2; j++) {
            Bond1 = Frag->bondList[Atom1->bondList[j]];
            Atom3 = Frag->atomList[Atom1->atomList[j]];
            if (Atom3 == Atom) continue;
            jj = Atom3->atomicNumber;
            tmpstr = "xx";
            if (Bond1->bondType == 1) tmpstr = "";
            if (Bond1->bondType == 2) tmpstr = "=";
            if (Bond1->bondType == 3) tmpstr = "#";
            if (Bond1->bondType == 4) tmpstr = "~";   // Aromatic bond
            if (Bond1->bondType == 5) tmpstr = "-.";  // Aromatic bond
            sprintf(buf, "(%s%s)", tmpstr.c_str(), xTable->AtomicSymbolNoSpace(jj).c_str());
            label = label + std::string(buf);
        }
        double tvalue = Atom->RankValue + Atom1->RankValue + bb;
        tvalue = xscale(tvalue);
        record = findRecord(Torsions, tvalue);
        if (record) {
            record->frequency++;
        } else {
            record = new FFRecord();
            record->frequency = 1;
            record->label = label;
            sprintf(buf, "%15.13f", tvalue);
            record->recordID = std::string(buf);
            Torsions[std::string(buf)] = record;
        }
    }
}

//
// Distance unit: Angstrom
// Energy unit: kcal
//

VdwTerm::VdwTerm(int i, int j, int topdis, double r, double e) {
    IA = i;
    IB = j;
    topDistance = topdis;
    vdwR = r / 100.0;
    vdwE = e / 4184.0;
    vdwR2 = vdwR * vdwR;
    vdwScale = 1.0;
}

void SetBondLength(MFCFrag* Frag) {
    PeriodicTable* xTable = PeriodicTable::Instance();
    for (int i = 0; i < Frag->numBonds; i++) {
        auto Bond = Frag->bondList[i];
        auto AtomA = Frag->atomList[Bond->atom1];
        auto AtomB = Frag->atomList[Bond->atom2];
        auto ra1 = xTable->AtomicCovalentR2(AtomA->atomicNumber);
        auto rb1 = xTable->AtomicCovalentR2(AtomB->atomicNumber);
        auto ra3 = xTable->AtomicCovalentR3(AtomA->atomicNumber);
        auto rb3 = xTable->AtomicCovalentR3(AtomB->atomicNumber);
        switch (Bond->bondType) {
            case 1:
                Bond->idealBondLength = ra1 + rb1;
                break;
            case 2:
                Bond->idealBondLength = (ra1 + rb1 + ra3 + rb3) / 2.0;
                break;
            case 3:
                Bond->idealBondLength = ra3 + rb3;
                break;
            case 4:
            case 5:
                Bond->idealBondLength = ((ra1 + rb1) * 3.0 + ra3 + rb3) / 4.0;
                break;
            default:
                Bond->idealBondLength = ra1 + rb1;
        }
    }
}

void setMFCAtomVDW(MFCFrag* Frag) {
    PeriodicTable* xTable = PeriodicTable::Instance();
    int nAtoms = Frag->numAtoms;
    MFCAtom* Atom;
    for (int i = 0; i < nAtoms; i++) {
        Atom = Frag->atomList[i];
        if (Atom->atomicNumber == 1) {
            Atom->vdwR = 120;
            Atom->vdwE = -175.728;
        } else if (Atom->atomicNumber == 6) {
            Atom->vdwR = 180;
            Atom->vdwE = -377.815;
        } else if (Atom->atomicNumber == 7) {
            Atom->vdwR = 183;
            Atom->vdwE = -376.56;
        } else if (Atom->atomicNumber == 8) {
            Atom->vdwR = 160;
            Atom->vdwE = -665.67;
        } else if (Atom->atomicNumber == 9) {
            Atom->vdwR = 165;
            Atom->vdwE = -326.35;
        } else if (Atom->atomicNumber == 16) {
            Atom->vdwR = 169;
            Atom->vdwE = -179.90;
        } else if (Atom->atomicNumber == 17) {
            Atom->vdwR = 203;
            Atom->vdwE = -1004.16;
        } else if (Atom->atomicNumber == 35) {
            Atom->vdwR = 218;
            Atom->vdwE = -1338.88;
        } else if (Atom->atomicNumber == 53) {
            Atom->vdwR = 215;
            Atom->vdwE = -3347.20;
        } else {
            // std::cout << "Unknown Atom type \n";
            Atom->vdwR = xTable->AtomicVDWR(Atom->atomicNumber) * 100;
            Atom->vdwE = -377.815;
        }
    }
}

}  // namespace MISS
