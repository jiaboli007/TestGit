#ifndef ffutil_h
#define ffutil_h
/******************************************************************************
 *                                                                             *
 *    Category:   Molecule Foundation Classes (MFC)                            *
 *    Function:   Implementation of force field utilities.                     *
 *    Author:     James Li                                                     *
 *    Date:       March 2011                                                   *
 *                                                                             *
 ******************************************************************************/

#include <string>

#include "MolStructure/mfcMolecule.h"

namespace MISS {

// Force field term frequency
class FFRecord {
public:
    FFRecord();
    ~FFRecord();
    std::string recordID;
    std::string label;
    int frequency;
    double parameter;
};

class VdwTerm {
public:
    VdwTerm(int i, int j, int topdis, double r, double e);
    int IA, IB, topDistance;
    double vdwR, vdwE, vdwR2;
    double vdwScale;
};

// SetFF
void SetBondLength(MFCFrag* Frag);
void setMFCAtomVDW(MFCFrag* Frag);

// decendent order
struct compRecord : public std::binary_function<FFRecord*, FFRecord*, bool> {
    bool operator()(FFRecord* A, FFRecord* B) { return (A->frequency > B->frequency); }
};

}  // namespace MISS
#endif /* ffutil_h */
