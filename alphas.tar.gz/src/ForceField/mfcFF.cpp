/******************************************************************************
 * Principal function:                                                         *
 *    A General Force Field Engine: Energy and Gradient Evaluation
 *                                                                             *
 * Usage:
 *
 * Authors:                                                                    *
 *    James Li, SciNet Technologies, June 2011
 *    Mouse, SYSU, July 2011
 *
 *                                                                             *
 * Key words: Force Field, Minimization
 *                                                                             *
 ******************************************************************************/
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>

#include <math.h>
#include <time.h>

#include "mfcFF.h"

#include "Topology/topology.h"

// Units in this code: Angstrom, kcal/mol
// Implementation

// Some Math Utils
// Compute Angle of two vectors

namespace MISS {

double VecAngle(double ux, double uy, double uz, double vx, double vy, double vz) {
    double ulen, vlen, inv, dot;
    double diff, dx, dy, dz;
    double angle;
    double pi = 3.14159265358979;

    ulen = ux * ux + uy * uy + uz * uz;
    if (ulen == 0.0) return 0.0;
    if (ulen != 1.0) {
        inv = 1.0 / sqrt(ulen);
        ux *= inv;
        uy *= inv;
        uz *= inv;
    }

    vlen = vx * vx + vy * vy + vz * vz;
    if (vlen == 0.0) return 0.0;
    if (vlen != 1.0) {
        inv = 1.0 / sqrt(vlen);
        vx *= inv;
        vy *= inv;
        vz *= inv;
    }

    dot = ux * vx + uy * vy + uz * vz;

    if (dot < 0.0) {
        dx = -vx - ux;
        dy = -vy - uy;
        dz = -vz - uz;
        diff = sqrt(dx * dx + dy * dy + dz * dz) / 2.0;
        angle = pi - 2.0 * asin(diff);
    } else {
        dx = vx - ux;
        dy = vy - uy;
        dz = vz - uz;
        diff = sqrt(dx * dx + dy * dy + dz * dz) / 2.0;
        angle = 2.0 * asin(diff);
    }

    return angle;
}

double CosVecAngle(double ux, double uy, double uz, double vx, double vy, double vz) {
    // c^2 = a^2 + b^2 - 2ab*cos(angle)
    // cos(angle) = (a^2 + b^2 - c^2 )/(2ab)

    double wx, wy, wz, u, v, u2, v2, w2;
    wx = vx - ux;
    wy = vy - uy;
    wz = vz - uz;
    u2 = ux * ux + uy * uy + uz * uz;
    v2 = vx * vx + vy * vy + vz * vz;
    w2 = wx * wx + wy * wy + wz * wz;
    u = sqrt(u2);
    v = sqrt(v2);

    double cosAngle = (u2 + v2 - w2) / (2.0 * u * v);
    return cosAngle;
}

// v3 = v1xv2
void CrossProduct(double v1[3], double v2[3], double v[3]) {
    // v3 = v1xv2 (cross product)
    v[0] = v1[1] * v2[2] - v2[1] * v1[2];
    v[1] = v2[0] * v1[2] - v1[0] * v2[2];
    v[2] = v1[0] * v2[1] - v2[0] * v1[1];

    // std::cout << "V1 = " << v1[0] << " " << v1[1] << " " << v1[2] << "\n";
    // std::cout << "V2 = " << v2[0] << " " << v2[1] << " " << v2[2] << "\n";
    // std::cout << "V=V1xV2 = " << v[0] << " " << v[1] << " " << v[2] << "\n";
}

double DotProduct(double v1[3], double v2[3]) {
    double dot;
    dot = v1[0] * v2[0] + v1[1] * v2[1] + v1[2] * v2[2];
    return dot;
}

// 1<-2->3->4
//  v1 v2 v3
double TorAngle(double v1[3], double v2[3], double v3[3]) {
    double tor;
    double pi = 3.14159265358979;
    double v12[3], v32[3];
    CrossProduct(v1, v2, v12);
    CrossProduct(v3, v2, v32);
    tor = VecAngle(v12[0], v12[1], v12[2], v32[0], v32[1], v32[2]);
    if (DotProduct(v1, v32) < 0.0) {
        tor = pi + pi - tor;
    }
    return tor;
}

//
// Compute partial derivative d(cos(period*tor)) / d(cos(tor))
//
void computeDCosNTor(int period, double cosTor, double &cosNTor, double &dCosNTor) {
    double cos2Tor, cos3Tor;

    switch (period) {
        case 1:
            cosNTor = cosTor;
            dCosNTor = 1.0;
            break;
        case 2:
            cosNTor = 2.0 * cosTor * cosTor - 1.0;
            dCosNTor = 4.0 * cosTor;
            break;
        case 3:
            cos2Tor = cosTor * cosTor;
            cosNTor = 4.0 * cos2Tor * cosTor - 3.0 * cosTor;
            dCosNTor = 12.0 * cos2Tor - 3.0;
            break;
        case 4:
            cos2Tor = cosTor * cosTor;
            cosNTor = 8.0 * cos2Tor * (cos2Tor - 1.0) + 1.0;
            dCosNTor = 16.0 * cosTor * (2.0 * cos2Tor - 1.0);
            break;
        case 5:
            cos2Tor = cosTor * cosTor;
            cos3Tor = cos2Tor * cosTor;
            cosNTor = 4.0 * cos3Tor * (4.0 * cos2Tor - 5.0) + 5.0 * cosTor;
            dCosNTor = 2.0 * cos2Tor * (40.0 * cos2Tor - 30.0) + 5.0;
            break;
        case 6:
            cos2Tor = cosTor * cosTor;
            cos3Tor = cos2Tor * cosTor;
            cosNTor = 2.0 * cos2Tor * (cos2Tor * (16.0 * cos2Tor - 24.0) + 9.0) - 1.0;
            dCosNTor = 192.0 * cos3Tor * (cos2Tor - 1.0) + 36.0 * cosTor;
            break;
        default:
            std::cout << "Period > 6, exit\n";
            exit(0);
    }
}
//
// Compute partial derivative d(cos(period*(tor-phase))) / d(cos(tor))
//

double computeDCosNTorPhase(int periodx, double tor, double phase) {
    //  d(cos(N(A-B)/d(cos(A)
    //
    //  = d(cos(N(A-B))/d(cos(A-B)) . d(cos(A-B)/d(cos(A)
    //  d(cos(A-B))/d(cosA) = d(cosA.cosB + sinA.sinB)/d(cosA)
    //  = cosB - sinB.cosA/sinA
    double dCosNTorPhase, cosNTorPhase;
    double cosTorPhase = cos(tor - phase);
    double sinTor = sin(tor);
    if (cosTorPhase > 0.999999999) cosTorPhase = 0.999999999;
    if (cosTorPhase < -0.999999999) cosTorPhase = -0.999999999;
    if (fabs(sinTor) < 0.000000001) {
        if (sinTor > 0)
            sinTor = 0.000000001;
        else
            sinTor = -0.000000001;
    }
    computeDCosNTor(periodx, cosTorPhase, cosNTorPhase, dCosNTorPhase);
    double factor = cos(phase) - sin(phase) * cos(tor) / sinTor;
    double dr = dCosNTorPhase * factor;
    return dr;
}

MFCFFTerm::MFCFFTerm() {
    // Empty
}

double MFCFFTerm::ComputeEnergy(double *crds) {
    // Just an interface
    return 0;
}

double MFCFFTerm::ComputeEnergyGrads(double *crds, double *crdGrads) {
    // Just an interface
    return 0;
}

void MFCFFTerm::printFFTerms() {
    // Just an interface
}

MFCFFTerm::MFCFFTerm(int ntype, int natoms, int nparams, int *atoms, double *params) {
    nType = ntype;
    nAtoms = natoms;
    nParams = nparams;
    if (nparams > 6) {
        std::cout << "Maximum 6 parameters\n";
        exit(1);
    }
    for (int i = 0; i < nAtoms; i++) {
        atomList[i] = atoms[i];
    }
    for (int i = 0; i < nParams; i++) {
        paramList[i] = params[i];
    }
}

MFCFFTerm::~MFCFFTerm() {
    // std::cout << "Destructor of MFCFFTerm done!\n";
}

MFCFFBondTerm::MFCFFBondTerm() {}

MFCFFBondTerm::MFCFFBondTerm(int atom1, int atom2, double f, double blen) {
    nType = 1;
    nAtoms = 2;
    nParams = 2;
    if (atom1 < atom2) {
        atomList[0] = atom1;
        atomList[1] = atom2;
    } else {
        atomList[1] = atom1;
        atomList[0] = atom2;
    }
    paramList[0] = f;
    paramList[1] = blen;
}

void MFCFFBondTerm::printFFTerms() {
    std::cout << "\n\nType = Bond Term\n";
    std::cout << "Atom1 =" << atomList[0] + 1 << ", Atom2 = " << atomList[1] + 1 << "\n";
    std::cout << "FConst=" << paramList[0] << ", STDBondLength = " << paramList[1] << "\n";
}

MFCFFBondTerm::~MFCFFBondTerm() {}

double MFCFFBondTerm::ComputeEnergy(double *crds) {
    // Compute Bond Energy, implementation here
    double energy = 0;
    // return 0;
    // TODO: implementation
    int na1 = atomList[0] * 3;
    int na2 = atomList[1] * 3;
    double dx = crds[na1] - crds[na2];
    double dy = crds[na1 + 1] - crds[na2 + 1];
    double dz = crds[na1 + 2] - crds[na2 + 2];
    double dr = sqrt(dx * dx + dy * dy + dz * dz) - paramList[1];
    energy = dr * dr * paramList[0] / 4.184;
    return energy;
}

double MFCFFBondTerm::ComputeEnergyGrads(double *crds, double *crdGrads) {
    // Compute Bond Energy and its contribution to gradients
    double energy = 0;
    //
    int na1 = atomList[0] * 3;
    int na2 = atomList[1] * 3;
    double dx = crds[na2] - crds[na1];
    double dy = crds[na2 + 1] - crds[na1 + 1];
    double dz = crds[na2 + 2] - crds[na1 + 2];
    double r = sqrt(dx * dx + dy * dy + dz * dz);
    double dr = r - paramList[1];
    energy = dr * dr * paramList[0] / 4.184;
    double force = 2.0 * dr * paramList[0];
    double factor = force / r;
    crdGrads[na2] += dx * factor;
    crdGrads[na2 + 1] += dy * factor;
    crdGrads[na2 + 2] += dz * factor;
    // Newton's rule of force
    crdGrads[na1] -= dx * factor;
    crdGrads[na1 + 1] -= dy * factor;
    crdGrads[na1 + 2] -= dz * factor;

    return energy;
}

MFCFFAngleTerm::MFCFFAngleTerm(int atom0, int atom1, int atom2, double f, double angle0) {
    nType = 2;
    nAtoms = 3;
    nParams = 2;
    // atom1 = center atom
    atomList[1] = atom1;
    if (atom0 < atom2) {
        atomList[0] = atom0;
        atomList[2] = atom2;
    } else {
        atomList[2] = atom0;
        atomList[0] = atom2;
    }
    paramList[0] = f;
    paramList[1] = angle0;
}
void MFCFFAngleTerm::printFFTerms() {
    std::cout << "\n\nType = Angle Term\n";
    std::cout << "Left Atom1 =" << atomList[0] + 1 << ", Center Atom2 = " << atomList[1] + 1
              << ",Right Atom3 = " << atomList[2] + 1 << "\n";
    std::cout << "FConst=" << paramList[0] << ", STDBondAngle = " << paramList[1] << "\n";
}

MFCFFAngleTerm::~MFCFFAngleTerm() {}

double MFCFFAngleTerm::ComputeEnergy(double *crds) {
    // Compute Bond Energy, implementation here
    double energy = 0;
    // return energy;
    // TODO: implementation
    int na0 = atomList[0] * 3;
    int na1 = atomList[1] * 3;
    int na2 = atomList[2] * 3;
    double ux = crds[na0] - crds[na1];
    double uy = crds[na0 + 1] - crds[na1 + 1];
    double uz = crds[na0 + 2] - crds[na1 + 2];
    double vx = crds[na2] - crds[na1];
    double vy = crds[na2 + 1] - crds[na1 + 1];
    double vz = crds[na2 + 2] - crds[na1 + 2];
    double angle = VecAngle(ux, uy, uz, vx, vy, vz);
    double dr = angle - paramList[1];
    energy = dr * dr * paramList[0] / 4.184;
    // std::cout << "energy =" << energy << "\n";

    return energy;
}

double MFCFFAngleTerm::ComputeEnergyGrads(double *crds, double *crdGrads) {
    // Compute Bond Energy and its contribution to gradients
    double energy = 0;
    int na0 = atomList[0] * 3;
    int na1 = atomList[1] * 3;
    int na2 = atomList[2] * 3;
    double ux = crds[na0] - crds[na1];
    double uy = crds[na0 + 1] - crds[na1 + 1];
    double uz = crds[na0 + 2] - crds[na1 + 2];
    double vx = crds[na2] - crds[na1];
    double vy = crds[na2 + 1] - crds[na1 + 1];
    double vz = crds[na2 + 2] - crds[na1 + 2];
    double angle = VecAngle(ux, uy, uz, vx, vy, vz);
    double ra = sqrt(ux * ux + uy * uy + uz * uz);
    double rb = sqrt(vx * vx + vy * vy + vz * vz);
    double recipab = 1.0 / (ra * rb);
    double cosAngle = CosVecAngle(ux, uy, uz, vx, vy, vz);
    if (cosAngle > 0.9999) cosAngle = 0.9999;
    if (cosAngle < -0.9999) cosAngle = -0.9999;
    double dr = angle - paramList[1];
    energy = dr * dr * paramList[0] / 4.184;
    double lx, ly, lz, rx, ry, rz;

    double force = 2.0 * dr * paramList[0];
    double factor = force * recipab / sqrt(1.0 - cosAngle * cosAngle);
    double crbovra = cosAngle * rb / ra;
    double craovrb = cosAngle * ra / rb;

    lx = factor * (vx - ux * crbovra);
    ly = factor * (vy - uy * crbovra);
    lz = factor * (vz - uz * crbovra);
    rx = factor * (ux - vx * craovrb);
    ry = factor * (uy - vy * craovrb);
    rz = factor * (uz - vz * craovrb);

    crdGrads[na0] -= lx;
    crdGrads[na0 + 1] -= ly;
    crdGrads[na0 + 2] -= lz;

    crdGrads[na1] += (lx + rx);
    crdGrads[na1 + 1] += (ly + ry);
    crdGrads[na1 + 2] += (lz + rz);

    crdGrads[na2] -= rx;
    crdGrads[na2 + 1] -= ry;
    crdGrads[na2 + 2] -= rz;

    // std::cout << "energy =" << energy << "\n";
    return energy;
}

MFCFFDihedTerm::MFCFFDihedTerm(int atom1, int atom2, int atom3, int atom4, double f, double phase0,
                               int Period) {
    nType = 3;
    nAtoms = 4;
    nParams = 2;
    nTerms = 1;
    period[0] = Period;
    atomList[0] = atom1;
    atomList[1] = atom2;
    atomList[2] = atom3;
    atomList[3] = atom4;
    // 1-2-3-4
    // atom2-3 = center bond atoms
    if (atom2 < atom3) {
        atomList[0] = atom1;
        atomList[1] = atom2;
        atomList[2] = atom3;
        atomList[3] = atom4;
    } else {
        atomList[3] = atom1;
        atomList[2] = atom2;
        atomList[1] = atom3;
        atomList[0] = atom4;
    }
    paramList[0] = f;
    paramList[1] = phase0;
}

void MFCFFDihedTerm::printFFTerms() {
    std::cout << "\n\nType = Dihedral Term\n";
    std::cout << "Dihedral Atoms =" << atomList[0] + 1 << "," << atomList[1] + 1 << ","
              << atomList[2] + 1 << "," << atomList[3] + 1 << "\n";
    for (int i = 0; i < nTerms; i++) {
        std::cout << "Term " << i + 1 << ":\n";
        std::cout << "FConst=" << paramList[i * 2] << ", Phase = " << paramList[i * 2 + 1] << " "
                  << "Period=" << period[i] << "\n";
    }
}

MFCFFDihedTerm::~MFCFFDihedTerm() {}

double MFCFFDihedTerm::ComputeEnergy(double *crds) {
    // Compute Bond Energy, implementation here
    double energy = 0;
    // return 0;
    // TODO: implementation
    // 1<-2->3->4
    //  v1 v2 v3
    double v1[3], v2[3], v3[3];
    int na1 = atomList[0] * 3;
    int na2 = atomList[1] * 3;
    int na3 = atomList[2] * 3;
    int na4 = atomList[3] * 3;
    v1[0] = crds[na1] - crds[na2];
    v1[1] = crds[na1 + 1] - crds[na2 + 1];
    v1[2] = crds[na1 + 2] - crds[na2 + 2];

    v2[0] = crds[na3] - crds[na2];
    v2[1] = crds[na3 + 1] - crds[na2 + 1];
    v2[2] = crds[na3 + 2] - crds[na2 + 2];

    v3[0] = crds[na4] - crds[na3];
    v3[1] = crds[na4 + 1] - crds[na3 + 1];
    v3[2] = crds[na4 + 2] - crds[na3 + 2];
    //
    // TODO: Add a test for colinear case
    //
    double tor = TorAngle(v1, v2, v3);

    double cosTor = cos(tor);

    double torE = 0;
    for (int idx = 0; idx < nTerms; idx++) {
        double fConst = paramList[idx * 2];
        double phase = paramList[idx * 2 + 1];
        int periodx = period[idx];
        // std::cout << "periodx, phase = " << periodx << " " << phase << "\n";
        if (periodx == 3 || periodx == 1 || periodx == 5) {
            // torE = fConst * (1.0 + cos (periodx * (tor - phase)));
            // energy += fConst * (1.0 + cos (periodx * (tor - phase)));
            // The following expression is from Dreiding paper, page 8898,
            // Eq. 13.
            torE = fConst * (1.0 - cos(periodx * (tor - phase)));
            energy += fConst * (1.0 - cos(periodx * (tor - phase)));
        } else {
            torE = fConst * (1.0 - cos(periodx * (tor - phase)));
            // std::cout << "torE = fConst*(1.0 - cos(n*(tor-phase)) ...." << torE << " " << fConst
            // << " " << tor << "\n";
            energy += fConst * (1.0 - cos(periodx * (tor - phase)));
        }
    }
    // kj to kcal
    energy = energy / 4.184;
    return energy;
}

double MFCFFDihedTerm::ComputeEnergyGrads(double *crds, double *crdGrads) {
    // Compute Bond Energy and its contribution to gradients
    double energy = 0;
    // 1<-2->3->4
    //  v1 v2 v3
    double v1[3], v2[3], v3[3];
    double v[3], w[3], vw[3];
    int na1 = atomList[0] * 3;
    int na2 = atomList[1] * 3;
    int na3 = atomList[2] * 3;
    int na4 = atomList[3] * 3;
    v1[0] = crds[na1] - crds[na2];
    v1[1] = crds[na1 + 1] - crds[na2 + 1];
    v1[2] = crds[na1 + 2] - crds[na2 + 2];

    v2[0] = crds[na3] - crds[na2];
    v2[1] = crds[na3 + 1] - crds[na2 + 1];
    v2[2] = crds[na3 + 2] - crds[na2 + 2];

    v3[0] = crds[na4] - crds[na3];
    v3[1] = crds[na4 + 1] - crds[na3 + 1];
    v3[2] = crds[na4 + 2] - crds[na3 + 2];

    CrossProduct(v1, v2, v);
    CrossProduct(v3, v2, w);

    // The drivative expression breaks down for torsion angle = 180 degree,
    // and we need a special treatment: add a small distorsion and
    // using the same expression to get the gradient
    //
    CrossProduct(v, w, vw);
    double testvw = sqrt(vw[0] * vw[0] + vw[1] * vw[1] + vw[2] * vw[2]);
    // Test show that the following distorsion gives the best accuracy
    // This optimal value is determined by the accuracy of cos(a) cutoff
    //
    double disteps = 0.000001;
    if (testvw < 0.00001) {
        v1[0] += disteps * v[0];
        v1[1] += disteps * v[1];
        v1[2] += disteps * v[2];
        CrossProduct(v1, v2, v);
    }

    double ax = v1[0];
    double ay = v1[1];
    double az = v1[2];

    double bx = v2[0];
    double by = v2[1];
    double bz = v2[2];

    double cx = v3[0];
    double cy = v3[1];
    double cz = v3[2];

    double vx = v[0];
    double vy = v[1];
    double vz = v[2];

    double wx = w[0];
    double wy = w[1];
    double wz = w[2];

    double rv = sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
    double rw = sqrt(w[0] * w[0] + w[1] * w[1] + w[2] * w[2]);

    double rv2 = rv * rv;
    double rw2 = rw * rw;

    double cosTor, cosNTor, dCosNTor, cosPTor;
    cosTor = CosVecAngle(v[0], v[1], v[2], w[0], w[1], w[2]);
    // std::cout << "cosTor = " << cosTor << "\n";
    // The drivative expression breaks down for torsion angle = 180 degree,
    // and we need a special treatment: add a small distorsion and
    // using the same expression to get the gradient
    //
    CrossProduct(v, w, vw);

    if (cosTor > 0.999999999999) cosTor = 0.999999999999;
    if (cosTor < -0.999999999999) cosTor = -0.999999999999;
    //
    // TODO: Add a test for colinear case
    //
    double tor = TorAngle(v1, v2, v3);
    // std::cout << " tor Angle = " << tor << "\n";
    double gradFactor = 0;
    for (int idx = 0; idx < nTerms; idx++) {
        double fConst = paramList[idx * 2];
        double phase = paramList[idx * 2 + 1];
        int periodx = period[idx];
        // cosPTor       = cos(tor-phase);
        // std::cout << "periodx, phase = " << periodx << " " << phase << "\n";
        // computeDCosNTor(periodx,cosTor,cosNTor,dCosNTor);
        // computeDCosNTor(periodx,cosPTor,cosNTor,dCosNTor);
        double dCosNTorPhase = computeDCosNTorPhase(periodx, tor, phase);

        if (periodx == 3 || periodx == 1 || periodx == 5) {
            // energy += fConst * (1.0 + cos (periodx * (tor - phase)));
            // gradFactor += fConst * dCosNTorPhase;
            // The following equation is from Dreiding paper.
            energy += fConst * (1.0 - cos(periodx * (tor - phase)));
            gradFactor -= fConst * dCosNTorPhase;
        } else {
            energy += fConst * (1.0 - cos(periodx * (tor - phase)));
            // gradFactor += fConst*dCosNTor;
            gradFactor -= fConst * dCosNTorPhase;
        }
    }
    double recipq = 1.0 / (rv * rw);
    double gradScaledRecipq = gradFactor * recipq;
    double factor = rw2 * cosTor * recipq;
    double dtdvx = gradScaledRecipq * (wx - vx * factor);
    double dtdvy = gradScaledRecipq * (wy - vy * factor);
    double dtdvz = gradScaledRecipq * (wz - vz * factor);
    factor = rv2 * cosTor * recipq;
    double dtdwx = gradScaledRecipq * (vx - wx * factor);
    double dtdwy = gradScaledRecipq * (vy - wy * factor);
    double dtdwz = gradScaledRecipq * (vz - wz * factor);

    double dtdX0 = (-dtdvy * bz + dtdvz * by);
    double f = (dtdvy * az - dtdvz * ay + dtdwy * cz - dtdwz * cy);
    double g = (-dtdwy * bz + dtdwz * by);
    double h, q;
    crdGrads[na1] += (dtdX0);
    crdGrads[na2] -= (f + dtdX0);
    crdGrads[na3] += (f - g);
    crdGrads[na4] += g;

    double dtdY0 = (dtdvx * bz - dtdvz * bx);
    g = (-dtdvx * az + dtdvz * ax - dtdwx * cz + dtdwz * cx);
    h = (dtdwx * bz - dtdwz * bx);

    crdGrads[na1 + 1] += (dtdY0);
    crdGrads[na2 + 1] -= (g + dtdY0);
    crdGrads[na3 + 1] += (g - h);
    crdGrads[na4 + 1] += h;

    double dtdZ0 = (-dtdvx * by + dtdvy * bx);
    h = (dtdvx * ay - dtdvy * ax + dtdwx * cy - dtdwy * cx);
    q = (-dtdwx * by + dtdwy * bx);

    crdGrads[na1 + 2] += (dtdZ0);
    crdGrads[na2 + 2] -= (h + dtdZ0);
    crdGrads[na3 + 2] += (h - q);
    crdGrads[na4 + 2] += q;

    // kj to kcal
    energy = energy / 4.184;
    return energy;
}

MFCFFOoplTerm::MFCFFOoplTerm(int atom1, int atom2, int atom3, int atom4, double f) {
    nType = 4;
    nAtoms = 4;
    nParams = 1;
    int tmp;
    // Center atom
    atomList[0] = atom1;
    // 2<3<4
    atomList[1] = atom2;
    atomList[2] = atom3;
    atomList[3] = atom4;
    // sort
    if (atomList[2] > atomList[3]) {
        tmp = atomList[2];
        atomList[2] = atomList[3];
        atomList[3] = tmp;
    }
    if (atomList[1] > atomList[2]) {
        tmp = atomList[1];
        atomList[1] = atomList[2];
        atomList[2] = tmp;
    }
    if (atomList[2] > atomList[3]) {
        tmp = atomList[2];
        atomList[2] = atomList[3];
        atomList[3] = tmp;
    }
    paramList[0] = f;
}

void MFCFFOoplTerm::printFFTerms() {
    std::cout << "\n\nType = Oopl Term\n";
    std::cout << "Center-Three Atoms =" << atomList[0] + 1 << "," << atomList[1] + 1 << ","
              << atomList[2] + 1 << "," << atomList[3] + 1 << "\n";
    std::cout << "FConst=" << paramList[0] << "\n";
}

MFCFFOoplTerm::~MFCFFOoplTerm() {}

double MFCFFOoplTerm::ComputeEnergy(double *crds) {
    // Compute Bond Energy, implementation here
    double energy = 0;
    // TODO: implementation
    double HalfPi = 3.14159265358979 / 2.0;

    double v1[3];
    double v2[3];
    double v3[3];
    double v[3];
    double angle;
    double fConst = paramList[0];

    int na0 = atomList[0] * 3;
    int na1 = atomList[1] * 3;
    int na2 = atomList[2] * 3;
    int na3 = atomList[3] * 3;

    for (int i = 0; i < 3; i++) {
        v1[i] = crds[na1 + i] - crds[na0 + i];
        v2[i] = crds[na2 + i] - crds[na0 + i];
        v3[i] = crds[na3 + i] - crds[na0 + i];
    }

    CrossProduct(v1, v2, v);
    angle = VecAngle(v[0], v[1], v[2], v3[0], v3[1], v3[2]) - HalfPi;
    energy += angle * angle * fConst;

    CrossProduct(v2, v3, v);
    angle = VecAngle(v[0], v[1], v[2], v1[0], v1[1], v1[2]) - HalfPi;
    energy += angle * angle * fConst;

    CrossProduct(v1, v3, v);
    angle = VecAngle(v[0], v[1], v[2], v2[0], v2[1], v2[2]) - HalfPi;
    energy += angle * angle * fConst;

    // kj to kcal, and take average of three values
    energy = energy / (3.0 * 4.184);
    return energy;
}

void computeOoplGrads(double *v1, double *v2, double *v3, double *crds, double *crdGrads,
                      double fConst, int na0, int na1, int na2, int na3) {
    // TODO: implementation
    double HalfPi = 3.14159265358979 / 2.0;

    double v[3];
    double ooplAngle;
    double ax, ay, az, bx, by, bz, cx, cy, cz, vx, vy, vz, ra, rv;
    /*
       for (int i=0; i< 3; i++) {
       v1[i] = crds[na1+i] - crds[na0+i];
       v2[i] = crds[na2+i] - crds[na0+i];
       v3[i] = crds[na3+i] - crds[na0+i];
       }
     */
    CrossProduct(v2, v3, v);
    ooplAngle = VecAngle(v[0], v[1], v[2], v1[0], v1[1], v1[2]) - HalfPi;
    double u, un, unsq, factor;
    double da, kda, temp, rara, rarv, rvrv, ra2u, rv2u;
    ax = v1[0];
    ay = v1[1];
    az = v1[2];
    bx = v2[0];
    by = v2[1];
    bz = v2[2];
    cx = v3[0];
    cy = v3[1];
    cz = v3[2];
    vx = v[0];
    vy = v[1];
    vz = v[2];

    ra = sqrt(ax * ax + ay * ay + az * az);
    rv = sqrt(vx * vx + vy * vy + vz * vz);

    if (ra < 0.000001) ra = 0.000001;
    if (rv < 0.000001) rv = 0.000001;

    rara = ra * ra;
    rvrv = rv * rv;
    rarv = ra * rv;

    // Compute Oopl terms
    // u = ku_dotProduct(ax, ay, az, vx, vy, vz);
    u = DotProduct(v1, v);
    un = u / rarv;
    if (un > 0.99999) un = 0.99999;
    if (un < -0.99999) un = -0.99999;

    // Compute function value
    da = ooplAngle;
    kda = fConst * da / 3.0;
    unsq = un * un;
    factor = 2.0 * kda / sqrt(1 - unsq);

    // Compute derivative

    ra2u = u / rara;
    rv2u = u / rvrv;

    rarv = factor / rarv;

    temp = (rarv * (vx - ra2u * ax));
    crdGrads[na1] -= (temp = (rarv * (vx - ra2u * ax)));
    crdGrads[na0] += temp;
    crdGrads[na1 + 1] -= (temp = (rarv * (vy - ra2u * ay)));
    crdGrads[na0 + 1] += temp;
    crdGrads[na1 + 2] -= (temp = (rarv * (vz - ra2u * az)));
    crdGrads[na0 + 2] += temp;

    crdGrads[na2] -= (temp = rarv * ((vy * cz - vz * cy) * rv2u + az * cy - ay * cz));
    crdGrads[na0] += temp;
    crdGrads[na2 + 1] -= (temp = rarv * (ax * cz - az * cx - (vx * cz - vz * cx) * rv2u));
    crdGrads[na0 + 1] += temp;
    crdGrads[na2 + 2] -= (temp = rarv * ((vx * cy - vy * cx) * rv2u + ay * cx - ax * cy));
    crdGrads[na0 + 2] += temp;

    crdGrads[na3] -= (temp = rarv * (ay * bz - az * by - (vy * bz - vz * by) * rv2u));
    crdGrads[na0] += temp;
    crdGrads[na3 + 1] -= (temp = rarv * ((vx * bz - vz * bx) * rv2u + az * bx - ax * bz));
    crdGrads[na0 + 1] += temp;
    crdGrads[na3 + 2] -= (temp = rarv * (ax * by - ay * bx - (vx * by - vy * bx) * rv2u));
    crdGrads[na0 + 2] += temp;
}
double MFCFFOoplTerm::ComputeEnergyGrads(double *crds, double *crdGrads) {
    // Compute Bond Energy and its contribution to gradients
    double energy = 0;
    // TODO: implementation
    double HalfPi = 3.14159265358979 / 2.0;
    double v1[3];
    double v2[3];
    double v3[3];
    double v[3];
    double angle;
    double fConst = paramList[0];

    int na0 = atomList[0] * 3;
    int na1 = atomList[1] * 3;
    int na2 = atomList[2] * 3;
    int na3 = atomList[3] * 3;

    for (int i = 0; i < 3; i++) {
        v1[i] = crds[na1 + i] - crds[na0 + i];
        v2[i] = crds[na2 + i] - crds[na0 + i];
        v3[i] = crds[na3 + i] - crds[na0 + i];
    }

    CrossProduct(v1, v2, v);
    angle = VecAngle(v[0], v[1], v[2], v3[0], v3[1], v3[2]) - HalfPi;
    energy += angle * angle * fConst;
    computeOoplGrads(v1, v2, v3, crds, crdGrads, fConst, na0, na1, na2, na3);

    CrossProduct(v2, v3, v);
    angle = VecAngle(v[0], v[1], v[2], v1[0], v1[1], v1[2]) - HalfPi;
    energy += angle * angle * fConst;
    computeOoplGrads(v2, v3, v1, crds, crdGrads, fConst, na0, na2, na3, na1);

    CrossProduct(v1, v3, v);
    angle = VecAngle(v[0], v[1], v[2], v2[0], v2[1], v2[2]) - HalfPi;
    energy += angle * angle * fConst;
    computeOoplGrads(v3, v1, v2, crds, crdGrads, fConst, na0, na3, na1, na2);

    // kj to kcal, and take average of three values
    energy = energy / (3.0 * 4.184);
    return energy;
}

MFCFFLineBendTerm::MFCFFLineBendTerm(int atom0, int atom1, int atom2, double f) {
    nType = 5;
    nAtoms = 3;
    nParams = 1;
    atomList[1] = atom1;
    if (atom0 < atom2) {
        atomList[0] = atom0;
        atomList[2] = atom2;
    } else {
        atomList[2] = atom0;
        atomList[0] = atom2;
    }
    paramList[0] = f;
}

void MFCFFLineBendTerm::printFFTerms() {
    std::cout << "\n\nType = Line Bend Term\n";
    std::cout << "Left, Center and Right Atoms =" << atomList[0] + 1 << "," << atomList[1] + 1
              << "," << atomList[2] + 1 << "\n";
    std::cout << "FConst=" << paramList[0] << "\n";
}

MFCFFLineBendTerm::~MFCFFLineBendTerm() {}

double MFCFFLineBendTerm::ComputeEnergy(double *crds) {
    // Compute Bond Energy, implementation here
    double energy = 0;
    //
    // Note: Similar to Dreiding force field, the line bend energy
    // is expressed as f*(cosAngle+1). When the angle is close to 180,
    // the energy is quadratic function of distorsion angle.
    // The obvious advantage of using cosAngle is the simple expression
    // for energy drivative.
    //
    double v1[3];
    double v2[3];
    double angle;
    double fConst = paramList[0];

    int na0 = atomList[0] * 3;
    int na1 = atomList[1] * 3;
    int na2 = atomList[2] * 3;

    for (int i = 0; i < 3; i++) {
        v1[i] = crds[na0 + i] - crds[na1 + i];
        v2[i] = crds[na2 + i] - crds[na1 + i];
    }
    double cosAngle = CosVecAngle(v1[0], v1[1], v1[2], v2[0], v2[1], v2[2]);
    energy = fConst * (cosAngle + 1.0) / 4.184;
    return energy;
}

double MFCFFLineBendTerm::ComputeEnergyGrads(double *crds, double *crdGrads) {
    // Compute Bond Energy and its contribution to gradients
    double energy = 0;
    double v1[3];
    double v2[3];
    double angle;
    double r1, r2, temp;
    double fConst = paramList[0];

    int na0 = atomList[0] * 3;
    int na1 = atomList[1] * 3;
    int na2 = atomList[2] * 3;

    r1 = 0;
    r2 = 0;
    for (int i = 0; i < 3; i++) {
        v1[i] = crds[na0 + i] - crds[na1 + i];
        v2[i] = crds[na2 + i] - crds[na1 + i];
        r1 = r1 + v1[i] * v1[i];
        r2 = r2 + v2[i] * v2[i];
    }

    r1 = sqrt(r1);
    r2 = sqrt(r2);

    double cosAngle = CosVecAngle(v1[0], v1[1], v1[2], v2[0], v2[1], v2[2]);
    energy = fConst * (cosAngle + 1.0) / 4.184;
    // Compute Grads
    double da = cosAngle + 1.0;
    double da2 = cosAngle * cosAngle;
    if (da2 > 1.0) da2 = 1.0;
    double sinda = sqrt(1.0 - da2);
    double kda = fConst * sinda;
    double factor = kda / (r1 * r2);
    double r2dr1 = cosAngle * r2 / r1;
    double r1dr2 = cosAngle * r1 / r2;
    double vt[3];
    vt[0] = (v2[0] - r2dr1 * v1[0]) / r2;
    vt[1] = (v2[1] - r2dr1 * v1[1]) / r2;
    vt[2] = (v2[2] - r2dr1 * v1[2]) / r2;
    double f1 = factor / sqrt(vt[0] * vt[0] + vt[1] * vt[1] + vt[2] * vt[2]);
    vt[0] = (v1[0] - r1dr2 * v2[0]) / r1;
    vt[1] = (v1[1] - r1dr2 * v2[1]) / r1;
    vt[2] = (v1[2] - r1dr2 * v2[2]) / r1;
    double f2 = factor / sqrt(vt[0] * vt[0] + vt[1] * vt[1] + vt[2] * vt[2]);
    temp = f1 * (v2[0] - r2dr1 * v1[0]);
    crdGrads[na0] += temp;
    crdGrads[na1] -= temp;
    temp = f1 * (v2[1] - r2dr1 * v1[1]);
    crdGrads[na0 + 1] += temp;
    crdGrads[na1 + 1] -= temp;
    temp = f1 * (v2[2] - r2dr1 * v1[2]);
    crdGrads[na0 + 2] += temp;
    crdGrads[na1 + 2] -= temp;

    temp = f2 * (v1[0] - r1dr2 * v2[0]);
    crdGrads[na2] += temp;
    crdGrads[na1] -= temp;
    temp = f2 * (v1[1] - r1dr2 * v2[1]);
    crdGrads[na2 + 1] += temp;
    crdGrads[na1 + 1] -= temp;
    temp = f2 * (v1[2] - r1dr2 * v2[2]);
    crdGrads[na2 + 2] += temp;
    crdGrads[na1 + 2] -= temp;

    return energy;
}

MFCFFEspTerm::MFCFFEspTerm(int natoms, double *acharges) {
    nType = 6;
    nAtoms = natoms;
    nParams = natoms;
    charges = new double[nAtoms];
    for (int i = 0; i < nAtoms; i++) {
        charges[i] = acharges[i];
    }
    nEspPairs = 0;
}

void MFCFFEspTerm::printFFTerms() { std::cout << "\n\nType = ESP Term\n"; }

MFCFFEspTerm::MFCFFEspTerm(int natoms) {
    nType = 7;
    nAtoms = natoms;
    nParams = natoms;
    charges = new double[nAtoms];
    for (int i = 0; i < nAtoms; i++) {
        charges[i] = 0.0;
    }
    nEspPairs = 0;
}

MFCFFEspTerm::MFCFFEspTerm(MFCFrag *mfcFrag) {
    nType = 7;
    nAtoms = mfcFrag->numAtoms;
    nParams = nAtoms;
    charges = new double[nAtoms];
    double *crd = new double[nAtoms * 3];
    for (int i = 0; i < nAtoms; i++) {
        MFCAtom *mfcAtom = mfcFrag->atomList[i];
        charges[i] = mfcAtom->charge;

        int i3 = i * 3;
        crd[i3] = mfcAtom->x;
        crd[i3 + 1] = mfcAtom->y;
        crd[i3 + 2] = mfcAtom->z;
    }
    // TODO: sign charges from topology
    double cutR = 10.0;
    nEspPairs = findNeighborPairs(mfcFrag, cutR, crd, EspPairs);
    std::cout << "nEspPairs = " << nEspPairs << "\n";
    delete[] crd;
}

MFCFFEspTerm::~MFCFFEspTerm() { delete[] charges; }

double MFCFFEspTerm::ComputeEnergy(double *crds) {
    // Compute Bond Energy, implementation here
    double energy = 0;
    double r2 = 0;
    // the energy unit is j/mol
    // e = 1.602189E-19
    // k = 8.98755E+9 (Coulomb constant)
    // convert all constants into one constant
    // so the constant is k * e * e * 6.022141E+23 * 1.0E+10
    // =1.38938E+6 j/mol for two electron charges at one angstrom distance
    // (since e, k are based on meter/kg/second, we must use the distance
    // of one Angstrom in meter, which is 1.0E-10).
    double K = 1.38938E+6;
    int i3 = 0;
    int j3 = 0;

    for (int ip = 0; ip < nEspPairs; ip++) {
        i3 = EspPairs[ip * 2] * 3;
        j3 = EspPairs[ip * 2 + 1] * 3;
        r2 = (crds[i3] - crds[j3]) * (crds[i3] - crds[j3]) +
             (crds[i3 + 1] - crds[j3 + 1]) * (crds[i3 + 1] - crds[j3 + 1]) +
             (crds[i3 + 2] - crds[j3 + 2]) * (crds[i3 + 2] - crds[j3 + 2]);
        energy += K * charges[EspPairs[ip * 2]] * charges[EspPairs[ip * 2 + 1]] / sqrt(r2);
    }
    energy = energy / 4184.0;
    return energy;
}

double MFCFFEspTerm::ComputeEnergyGrads(double *crds, double *crdGrads) {
    // Compute Bond Energy and its contribution to gradients
    double energy = 0;
    double r2 = 0;
    double dx, dy, dz, gx, gy, gz;
    double factor, f;
    // the energy unit is j/mol
    // e = 1.602189E-19
    // k = 8.98755E+9 (Coulomb constant)
    // convert all constants into one constant
    // so the constant is k * e * e * 6.022141E+23 * 1.0E+10
    // =1.38938E+6 j/mol for two electron charges at one angstrom distance
    // (since e, k are based on meter/kg/second, we must use the distance
    // of one Angstrom in meter, which is 1.0E-10).
    //
    // For force, the internal unit is j/(mol.angstrom), and the length
    // is also in angstrom, so we do not need additional factor).
    //
    double K = 1.38938E+6;
    int i3 = 0;
    int j3 = 0;

    for (int ip = 0; ip < nEspPairs; ip++) {
        i3 = EspPairs[ip * 2] * 3;
        j3 = EspPairs[ip * 2 + 1] * 3;
        dx = crds[i3] - crds[j3];
        dy = crds[i3 + 1] - crds[j3 + 1];
        dz = crds[i3 + 2] - crds[j3 + 2];
        r2 = (dx * dx + dy * dy + dz * dz);
        f = K * charges[EspPairs[ip * 2]] * charges[EspPairs[ip * 2 + 1]] / r2;
        factor = f / sqrt(r2);
        gx = factor * dx;
        crdGrads[i3] += gx;
        crdGrads[j3] -= gx;
        gy = factor * dy;
        crdGrads[i3 + 1] += gy;
        crdGrads[j3 + 1] -= gy;
        gz = factor * dz;
        crdGrads[i3 + 2] += gz;
        crdGrads[j3 + 2] -= gz;
        energy += f * sqrt(r2);
    }
    energy = energy / 4184.0;
    return energy;
}

MFCFFVDWTerm::MFCFFVDWTerm(int natoms, double *r, double *wd) {
    nType = 6;
    nAtoms = natoms;
    nParams = natoms;
    radius = new double[nAtoms];
    wellDepth = new double[nAtoms];
    for (int i = 0; i < nAtoms; i++) {
        radius[i] = r[i];
        wellDepth[i] = wd[i];
    }
    ResetVDWTerms();
}

void MFCFFVDWTerm::ResetVDWTerms() {
    for (int i = 0; i < nVDWPairs; i++) {
        int i2 = i + i;
        int na1 = vdwPairs[i2];
        int na2 = vdwPairs[i2 + 1];
        rMin[i] = radius[na1] + radius[na2];
        eMin[i] = sqrt(wellDepth[na1] * wellDepth[na2]);
    }
}

MFCFFVDWTerm::MFCFFVDWTerm(MFCFrag *mfcFrag) {
    nType = 6;
    nAtoms = mfcFrag->numAtoms;
    nParams = nAtoms;
    radius = new double[nAtoms];
    wellDepth = new double[nAtoms];
    MFCAtom *mfcAtom = 0;
    // MFCAtom* mfcAtom1;
    // MFCAtom* mfcAtom2;
    double cutR = 10.0;
    for (int i = 0; i < nAtoms; i++) {
        mfcAtom = mfcFrag->atomList[i];
        radius[i] = mfcAtom->vdwR;
        wellDepth[i] = mfcAtom->vdwE;
    }

    double *crd = new double[nAtoms * 3];
    for (int i = 0; i < nAtoms; i++) {
        int i3 = i * 3;
        mfcAtom = mfcFrag->atomList[i];
        crd[i3] = mfcAtom->x;
        crd[i3 + 1] = mfcAtom->y;
        crd[i3 + 2] = mfcAtom->z;
    }

    nVDWPairs = findNeighborPairs(mfcFrag, cutR, crd, vdwPairs);
    rMin = new double[nVDWPairs];
    eMin = new double[nVDWPairs];
    for (int i = 0; i < nVDWPairs; i++) {
        int i2 = i + i;
        int na1 = vdwPairs[i2];
        int na2 = vdwPairs[i2 + 1];
        rMin[i] = radius[na1] + radius[na2];
        eMin[i] = sqrt(wellDepth[na1] * wellDepth[na2]);
    }

    delete[] crd;
}

int MFCFFVDWTerm::updateVDWPairs(MFCFrag *mfcFrag, double *crd) {
    nType = 6;
    nAtoms = mfcFrag->numAtoms;
    nParams = nAtoms;
    MFCAtom *mfcAtom = 0;
    for (int i = 0; i < nAtoms; i++) {
        mfcAtom = mfcFrag->atomList[i];
        radius[i] = mfcAtom->vdwR;
        wellDepth[i] = mfcAtom->vdwE;
    }

    delete[] rMin;
    delete[] eMin;
    double cutR = 10.0;

    vdwPairs.resize(0);
    nVDWPairs = findNeighborPairs(mfcFrag, cutR, crd, vdwPairs);
    rMin = new double[nVDWPairs];
    eMin = new double[nVDWPairs];
    for (int i = 0; i < nVDWPairs; i++) {
        int i2 = i + i;
        int na1 = vdwPairs[i2];
        int na2 = vdwPairs[i2 + 1];
        rMin[i] = radius[na1] + radius[na2];
        eMin[i] = sqrt(wellDepth[na1] * wellDepth[na2]);
    }
    return nVDWPairs;
}

void MFCFFVDWTerm::printFFTerms() {
    std::cout << "\n\nType = VDW Terms\n";
    for (int i = 0; i < nAtoms; i++) {
        std::cout << "Atom " << i + 1 << "VDW Radius = " << radius[i]
                  << ", WellDepth = " << wellDepth[i] << "\n";
    }
}

MFCFFVDWTerm::~MFCFFVDWTerm() {
    delete[] radius;
    delete[] wellDepth;
    delete[] rMin;
    delete[] eMin;
}

double MFCFFVDWTerm::ComputeEnergyGrads(double *crds, double *crdGrads) {
    // To do: for large proteins, a better and linear scaling algorithm
    // will be using neighbor list. i.e. each atom, has a neighbor list within
    // a cutoff distance. To build the neighbor list in a linear scaling way,
    // one can put all atoms into multiple boxes, and then for each atom in
    // a box, only atoms in the neighbor boxes will be considered for neibors.
    //
    double energy = 0;
    double r2 = 0;
    double R2;
    double R6;
    double ER;
    double dx, dy, dz, gx, gy, gz;
    double f;
    double factor;
    int ij = 0;
    int i3 = 0;
    int j3 = 0;
    // TODO: implementation
    for (int ip = 0; ip < nVDWPairs; ip++) {
        i3 = vdwPairs[ip * 2] * 3;
        j3 = vdwPairs[ip * 2 + 1] * 3;
        dx = crds[i3] - crds[j3];
        dy = crds[i3 + 1] - crds[j3 + 1];
        dz = crds[i3 + 2] - crds[j3 + 2];
        r2 = (dx * dx + dy * dy + dz * dz);
        R2 = 0.0001 * rMin[ip] * rMin[ip] / r2;
        R6 = R2 * R2 * R2;
        ER = R6 * eMin[ip];
        f = ER * (R6 - 2.0);
        factor = -0.012 * (f + ER) / r2;
        gx = factor * dx;
        crdGrads[i3] += gx;
        crdGrads[j3] -= gx;
        gy = factor * dy;
        crdGrads[i3 + 1] += gy;
        crdGrads[j3 + 1] -= gy;
        gz = factor * dz;
        crdGrads[i3 + 2] += gz;
        crdGrads[j3 + 2] -= gz;

        energy += ER * (R6 - 2.0);
    }
    energy = energy / 4184.0;
    return energy;
}

double MFCFFVDWTerm::ComputeEnergy(double *crds) {
    // Compute Bond Energy and its contribution to gradients
    double energy = 0;
    double r2 = 0;
    double R2;
    double R6;
    double ER;
    int ij = 0;
    int i3 = 0;
    int j3 = 0;

    for (int ip = 0; ip < nVDWPairs; ip++) {
        i3 = vdwPairs[ip * 2] * 3;
        j3 = vdwPairs[ip * 2 + 1] * 3;
        r2 = (crds[i3] - crds[j3]) * (crds[i3] - crds[j3]) +
             (crds[i3 + 1] - crds[j3 + 1]) * (crds[i3 + 1] - crds[j3 + 1]) +
             (crds[i3 + 2] - crds[j3 + 2]) * (crds[i3 + 2] - crds[j3 + 2]);
        R2 = 0.0001 * rMin[ip] * rMin[ip] / r2;
        R6 = R2 * R2 * R2;
        ER = R6 * eMin[ip];
        energy += ER * (R6 - 2.0);
    }
    energy = energy / 4184.0;
    return energy;
}

MFCFFFrag::MFCFFFrag() {
    // TODO
}

MFCFFFrag::MFCFFFrag(MFCFrag *mfcFrag) {
    // Implementation to convert a MFCFrag to MFCFFFrag
    nAtoms = mfcFrag->numAtoms;
    crds = new double[nAtoms * 3];
    crdGrads = new double[nAtoms * 3];
    MFCAtom *mfcAtom;
    MFCAtom *mfcAtom1;
    MFCAtom *mfcAtom2;
    ownerFrag = mfcFrag;

    int i3;
    for (int i = 0; i < nAtoms; i++) {
        i3 = i * 3;
        mfcAtom = mfcFrag->atomList[i];
        crds[i3] = mfcAtom->x;
        crds[i3 + 1] = mfcAtom->y;
        crds[i3 + 2] = mfcAtom->z;
        crdGrads[i3] = 0;
        crdGrads[i3 + 1] = 0;
        crdGrads[i3 + 2] = 0;
    }
    // Create FFTerms
    // Bond terms
    MFCFFTerm *ffTerm;
    int nBonds = mfcFrag->numBonds;
    int nBond1;
    int nBond2;
    int atom0;
    int atom1;
    int atom2;
    int atom3;
    MFCBond *mfcBond;
    MFCBond *mfcBond1;
    MFCBond *mfcBond2;
    MFCBond *mfcBond3;
    for (int i = 0; i < nBonds; i++) {
        mfcBond = mfcFrag->bondList[i];
        ffTerm = new MFCFFBondTerm(mfcBond->atom1, mfcBond->atom2, 0.0, 0.0);
        mfcFFTerms.push_back(ffTerm);
    }

    // Angle terms
    for (int i = 0; i < nAtoms; i++) {
        mfcAtom = mfcFrag->atomList[i];
        int nABonds = mfcAtom->nBonds;
        if (mfcAtom->hybride != MFC_SP_HYBRID && nABonds > 1) {
            atom0 = mfcAtom->AIdx;
            for (int j = 0; j < nABonds; j++) {
                mfcBond1 = mfcFrag->bondList[mfcAtom->bondList[j]];
                atom1 = findOtherBondAtom(mfcBond1, atom0);
                for (int k = 0; k < j; k++) {
                    mfcBond2 = mfcFrag->bondList[mfcAtom->bondList[k]];
                    atom2 = findOtherBondAtom(mfcBond2, atom0);
                    ffTerm = new MFCFFAngleTerm(atom1, atom0, atom2, 0.0, 0.0);
                    mfcFFTerms.push_back(ffTerm);
                }
            }
        }
    }
    // Dihedral terms
    for (int i = 0; i < nBonds; i++) {
        mfcBond = mfcFrag->bondList[i];
        atom1 = mfcBond->atom1;
        atom2 = mfcBond->atom2;
        mfcAtom1 = mfcFrag->atomList[atom1];
        mfcAtom2 = mfcFrag->atomList[atom2];
        nBond1 = mfcAtom1->nBonds;
        nBond2 = mfcAtom2->nBonds;
        if (mfcAtom1->hybride != MFC_SP_HYBRID && mfcAtom2->hybride != MFC_SP_HYBRID &&
            nBond1 > 1 && nBond2 > 1) {
            for (int j = 0; j < nBond1; j++) {
                mfcBond1 = mfcFrag->bondList[mfcAtom1->bondList[j]];
                atom0 = findOtherBondAtom(mfcBond1, atom1);
                for (int k = 0; k < nBond2; k++) {
                    mfcBond2 = mfcFrag->bondList[mfcAtom2->bondList[k]];
                    atom3 = findOtherBondAtom(mfcBond2, atom2);
                    if (atom3 != atom1 && atom0 != atom2) {
                        ffTerm = new MFCFFDihedTerm(atom0, atom1, atom2, atom3, 0.0, 0.0, 3);
                        mfcFFTerms.push_back(ffTerm);
                    }
                }
            }
        }
    }
    // Line bend terms
    // Check for SP centers and nBonds = 2
    for (int i = 0; i < nAtoms; i++) {
        mfcAtom = mfcFrag->atomList[i];
        int nABonds = mfcAtom->nBonds;
        if (mfcAtom->hybride == MFC_SP_HYBRID && nABonds == 2) {
            atom0 = mfcAtom->AIdx;
            mfcBond1 = mfcFrag->bondList[mfcAtom->bondList[0]];
            atom1 = findOtherBondAtom(mfcBond1, atom0);
            mfcBond2 = mfcFrag->bondList[mfcAtom->bondList[1]];
            atom2 = findOtherBondAtom(mfcBond2, atom0);
            // std::cout << "Line Bend Term created \n";
            // std::cout <<  atom1 << " " << atom0 << " " << atom2 << "\n";
            ffTerm = new MFCFFLineBendTerm(atom1, atom0, atom2, 0.0);
            mfcFFTerms.push_back(ffTerm);
        }
    }

    // Oopl terms
    // Check for SP2 centers, nBonds >= 3
    for (int i = 0; i < nAtoms; i++) {
        mfcAtom = mfcFrag->atomList[i];
        int nABonds = mfcAtom->nBonds;
        if (mfcAtom->hybride == MFC_SP2_HYBRID && nABonds == 3) {
            atom0 = mfcAtom->AIdx;
            mfcBond1 = mfcFrag->bondList[mfcAtom->bondList[0]];
            atom1 = findOtherBondAtom(mfcBond1, atom0);
            mfcBond2 = mfcFrag->bondList[mfcAtom->bondList[1]];
            atom2 = findOtherBondAtom(mfcBond2, atom0);
            mfcBond3 = mfcFrag->bondList[mfcAtom->bondList[2]];
            atom3 = findOtherBondAtom(mfcBond3, atom0);
            ffTerm = new MFCFFOoplTerm(atom0, atom1, atom2, atom3, 0.0);
            mfcFFTerms.push_back(ffTerm);
        }
    }
    // ESP terms
    // Charges are zeros
    ffTerm = new MFCFFEspTerm(nAtoms);
    mfcFFTerms.push_back(ffTerm);
    // VDW terms
    // Charges are zeros
    ffTerm = new MFCFFVDWTerm(mfcFrag);
    mfcFFTerms.push_back(ffTerm);
}

void MFCFFFrag::updateCoordinates(int natoms, double *crd) {
    if (natoms <= nAtoms) {
        for (int i = 0; i < natoms * 3; i++) {
            crds[i] = crd[i];
        }
    }
}
void MFCFFFrag::initFF(char *fflibname) {
    int atom0;
    int atom1;
    int atom2;
    int atom3;
    char buf[80];
    char str[80];
    double fconst;
    double phase[10];
    double tconst[10];
    double blen0;
    double angle0;
    int period[10];
    int nTerms;
    int intx;
    double phase0;
    MFCFFBondTerm *ffBTerm;
    MFCFFAngleTerm *ffATerm;
    MFCFFDihedTerm *ffDTerm;
    MFCFFOoplTerm *ffOTerm;
    MFCFFLineBendTerm *ffLTerm;

    FILE *pFile;
    pFile = fopen(fflibname, "r+");

    fgets(str, 80, pFile);
    while (fgets(str, 80, pFile) != NULL) {
        std::string stdstr(str);
        if (stdstr.substr(0, 17) == "Bond Energy Term:") {
            // std::cout << "Bond Term\n";
            fgets(str, 80, pFile);
            sscanf(str, "%s %d,%d", buf, &atom1, &atom2);
            // std::cout << "Atom1, Atom2 = " << atom1 << " " << atom2 << "\n";
            fgets(str, 80, pFile);
            sscanf(str, "%s %lf", buf, &blen0);
            fgets(str, 80, pFile);
            sscanf(str, "%s %lf", buf, &fconst);
            ffBTerm = (MFCFFBondTerm *)findFFTerm(1, atom1 - 1, atom2 - 1, 0, 0);
            ffBTerm->paramList[0] = fconst;
            ffBTerm->paramList[1] = blen0;
        }
        if (stdstr.substr(0, 18) == "Angle Energy Term:") {
            // std::cout << "Angle Term\n";
            fgets(str, 80, pFile);
            sscanf(str, "%s %d,%d,%d", buf, &atom1, &atom2, &atom3);
            // std::cout << "Atom1-3 = " << atom1 << " " << atom3 << "\n";
            fgets(str, 80, pFile);
            sscanf(str, "%s %lf", buf, &angle0);
            fgets(str, 80, pFile);
            sscanf(str, "%s %lf", buf, &fconst);
            ffATerm = (MFCFFAngleTerm *)findFFTerm(2, atom1 - 1, atom2 - 1, atom3 - 1, 0);
            ffATerm->paramList[0] = fconst;
            ffATerm->paramList[1] = angle0;
        }
        if (stdstr.substr(0, 21) == "Dihedral Energy Term:") {
            // std::cout << "Dihedral Term\n";
            fgets(str, 80, pFile);
            sscanf(str, "%s %d,%d,%d,%d", buf, &atom0, &atom1, &atom2, &atom3);
            std::cout << "Atom1-3 = " << atom1 << " " << atom3 << "\n";
            fgets(str, 80, pFile);
            sscanf(str, "%s %d", buf, &nTerms);
            ffDTerm = (MFCFFDihedTerm *)findFFTerm(3, atom0 - 1, atom1 - 1, atom2 - 1, atom3 - 1);
            if (ffDTerm) {
                ffDTerm->nTerms = nTerms;
                ffDTerm->nParams = nTerms * 2;
                for (int i = 0; i < nTerms; i++) {
                    fgets(str, 80, pFile);
                    sscanf(str, "%s %d", buf, &intx);
                    fgets(str, 80, pFile);
                    sscanf(str, "%s %lf", buf, &phase0);
                    fgets(str, 80, pFile);
                    sscanf(str, "%s %lf", buf, &fconst);
                    period[i] = intx;
                    phase[i] = phase0;
                    tconst[i] = fconst;
                    ffDTerm->paramList[i + i] = fconst;
                    ffDTerm->paramList[i + i + 1] = phase0;
                    ffDTerm->period[i] = intx;
                }
            }
        }
        if (stdstr.substr(0, 17) == "Oopl Energy Term:") {
            // std::cout << "Oopl Term\n";
            fgets(str, 80, pFile);
            sscanf(str, "%s %d,%d,%d,%d", buf, &atom0, &atom1, &atom2, &atom3);
            // std::cout << "Atom1-3 = " << atom1 << " " << atom3 << "\n";
            fgets(str, 80, pFile);
            sscanf(str, "%s %lf", buf, &fconst);
            ffOTerm = (MFCFFOoplTerm *)findFFTerm(4, atom0 - 1, atom1 - 1, atom2 - 1, atom3 - 1);
            if (ffOTerm) ffOTerm->paramList[0] = fconst;
        }
        if (stdstr.substr(0, 9) == "Line Bend") {
            // std::cout << "Line Bend Term\n";
            fgets(str, 80, pFile);
            sscanf(str, "%s %d,%d,%d", buf, &atom1, &atom2, &atom3);
            fgets(str, 80, pFile);
            sscanf(str, "%s %lf", buf, &fconst);
            // std::cout << "Line Bend FConst = " << fconst << "\n";
            ffLTerm = (MFCFFLineBendTerm *)findFFTerm(5, atom1 - 1, atom2 - 1, atom3 - 1, 0);
            if (ffLTerm) {
                // std::cout << "Find Line Bend FConst = " << fconst << "\n";
                ffLTerm->paramList[0] = fconst;
            }
        }
    }

    fclose(pFile);
}

//
// FF Types:
// 1: Bond
// 2: Angle
// 3: Torsion
// 4: Oopl
// 5: Line-Bend
// 6: VDW
// 7: ESP
//

template <typename iFileLikeSteam>
void MFCFFFrag::initFF(iFileLikeSteam &fin) {
    int atom0;
    int atom1;
    int atom2;
    int atom3;
    char buf[80];
    char str[80];
    double fconst;
    double phase[10];
    double tconst[10];
    double blen0;
    double angle0;
    double rMin;
    double eMin;

    int period[10];
    int nTerms;
    int intx;
    double phase0;
    MFCFFBondTerm *ffBTerm;
    MFCFFAngleTerm *ffATerm;
    MFCFFDihedTerm *ffDTerm;
    MFCFFOoplTerm *ffOTerm;
    MFCFFLineBendTerm *ffLTerm;
    MFCFFVDWTerm *ffVDWTerm;

    MFCAtom *mfcAtom;
    MFCFrag *mfcFrag = ownerFrag;

    ffVDWTerm = (MFCFFVDWTerm *)findFFTerm(6, 0, 0, 0, 0);

    // setMFCAtomVDW(mfcFrag);

    std::string tmpstr;

    int found = 0;
    int endMol = 0;
    // Skip to FFTERM
    do {
        std::getline(fin, tmpstr);
        if (fin.fail()) fin.clear();
        if (tmpstr.substr(0, 12) == std::string(">  <FFTerms>")) found = 1;
        if (tmpstr.substr(0, 12) == std::string("$$$$")) endMol = 1;
    } while (found != 1 && endMol != 1);

    if (endMol == 1) return;

    tmpstr.c_str();

    do {
        std::getline(fin, tmpstr);
        if (fin.fail()) fin.clear();
        // std::cout << tmpstr << "\n";

        if (tmpstr.substr(0, 16) == "BondAtom1-Atom2=") {
            // std::cout << "Bond Term\n";
            sscanf(tmpstr.c_str(), "%s %d,%d", buf, &atom1, &atom2);
            // std::cout << "Atom1, Atom2 = " << atom1 << " " << atom2 << "\n";
            std::getline(fin, tmpstr);
            sscanf(tmpstr.c_str(), "%s %lf", buf, &blen0);
            std::getline(fin, tmpstr);
            sscanf(tmpstr.c_str(), "%s %lf", buf, &fconst);
            ffBTerm = (MFCFFBondTerm *)findFFTerm(1, atom1 - 1, atom2 - 1, 0, 0);
            if (ffBTerm) {
                ffBTerm->paramList[0] = fconst;
                ffBTerm->paramList[1] = blen0;
            } else {
                std::cout << "Something wrong with Bond \n";
                throw("LBend error");
            }
        }
        if (tmpstr.substr(0, 17) == "AngleAtom1-Atom3=") {
            // std::cout << "Angle Term\n";
            sscanf(tmpstr.c_str(), "%s %d,%d,%d", buf, &atom1, &atom2, &atom3);
            // std::cout << "Atom1-3 = " << atom1 << " " << atom3 << "\n";
            std::getline(fin, tmpstr);
            sscanf(tmpstr.c_str(), "%s %lf", buf, &angle0);
            std::getline(fin, tmpstr);
            sscanf(tmpstr.c_str(), "%s %lf", buf, &fconst);
            ffATerm = (MFCFFAngleTerm *)findFFTerm(2, atom1 - 1, atom2 - 1, atom3 - 1, 0);
            if (ffATerm) {
                ffATerm->paramList[0] = fconst;
                ffATerm->paramList[1] = angle0;
            } else {
                std::cout << "Something wrong with Angle!\n";
            }
        }
        if (tmpstr.substr(0, 17) == "DihedAtom1-Atom4=") {
            // std::cout << "Dihedral Term\n";
            sscanf(tmpstr.c_str(), "%s %d,%d,%d,%d", buf, &atom0, &atom1, &atom2, &atom3);
            // std::cout << "Atom1-3 = " << atom1 << " " << atom3 << "\n";
            std::getline(fin, tmpstr);
            sscanf(tmpstr.c_str(), "%s %d", buf, &nTerms);
            ffDTerm = (MFCFFDihedTerm *)findFFTerm(3, atom0 - 1, atom1 - 1, atom2 - 1, atom3 - 1);
            if (ffDTerm) {
                ffDTerm->nTerms = nTerms;
                ffDTerm->nParams = 2 * nTerms;
                for (int i = 0; i < nTerms; i++) {
                    std::getline(fin, tmpstr);
                    sscanf(tmpstr.c_str(), "%s %d", buf, &intx);
                    std::getline(fin, tmpstr);
                    sscanf(tmpstr.c_str(), "%s %lf", buf, &phase0);
                    std::getline(fin, tmpstr);
                    sscanf(tmpstr.c_str(), "%s %lf", buf, &fconst);
                    period[i] = intx;
                    phase[i] = phase0;
                    tconst[i] = fconst;
                    ffDTerm->paramList[i + i] = fconst;
                    ffDTerm->paramList[i + i + 1] = phase0;
                    ffDTerm->period[i] = intx;
                }
            } else {
                std::cout << "Something wrong torsion\n";
            }
        }
        if (tmpstr.substr(0, 20) == "OoplAtomAtom0-Atom2=") {
            // std::cout << "Oopl Term\n";
            sscanf(tmpstr.c_str(), "%s %d,%d,%d,%d", buf, &atom0, &atom1, &atom2, &atom3);
            // std::cout << "Atom1-3 = " << atom1 << " " << atom3 << "\n";
            std::getline(fin, tmpstr);
            sscanf(tmpstr.c_str(), "%s %lf", buf, &fconst);
            ffOTerm = (MFCFFOoplTerm *)findFFTerm(4, atom0 - 1, atom1 - 1, atom2 - 1, atom3 - 1);
            if (ffOTerm)
                ffOTerm->paramList[0] = fconst;
            else
                std::cout << "Something wrong with OOLP\n";
        }
        if (tmpstr.substr(0, 20) == "LineBendAtom1-Atom3=") {
            // std::cout << "Line Bend Term\n";
            sscanf(tmpstr.c_str(), "%s %d,%d,%d", buf, &atom1, &atom2, &atom3);
            std::getline(fin, tmpstr);
            sscanf(tmpstr.c_str(), "%s %lf", buf, &fconst);
            // std::cout << "Line Bend FConst = " << fconst << "\n";
            ffLTerm = (MFCFFLineBendTerm *)findFFTerm(5, atom1 - 1, atom2 - 1, atom3 - 1, 0);
            if (ffLTerm) {
                // std::cout << "Find Line Bend FConst = " << fconst << "\n";
                ffLTerm->paramList[0] = fconst;
            } else {
                std::cout << "Something wrong with LBend\n";
                // throw("LBend error");
            }
        }
        if (tmpstr.substr(0, 8) == "VDWAtom=") {
            // std::cout << "VDW Term\n";
            sscanf(tmpstr.c_str(), "%s %d,%d", buf, &atom1);
            std::getline(fin, tmpstr);
            sscanf(tmpstr.c_str(), "%s %lf", buf, &rMin);
            std::getline(fin, tmpstr);
            sscanf(tmpstr.c_str(), "%s %lf", buf, &eMin);
            mfcAtom = mfcFrag->atomList[atom1 - 1];
            mfcAtom->vdwR = rMin;
            mfcAtom->vdwE = eMin;
            ffVDWTerm->radius[atom1 - 1] = rMin;
            ffVDWTerm->wellDepth[atom1 - 1] = eMin;
        }
    } while (tmpstr != std::string("") && !fin.eof());

    //
    // Reset FFVDWTerms
    //
    ffVDWTerm->ResetVDWTerms();
}

template void MFCFFFrag::initFF(std::istream &fin);
template void MFCFFFrag::initFF(std::ifstream &fin);
template void MFCFFFrag::initFF(iStringFileStream &fin);
template void MFCFFFrag::initFF(MMapStream &fin);

MFCFFTerm *MFCFFFrag::findFFTerm(int nType, int atom1, int atom2, int atom3, int atom4) {
    MFCFFTerm *ffTerm;
    std::vector<MFCFFTerm *>::iterator iter = mfcFFTerms.begin();
    std::vector<MFCFFTerm *>::iterator iter_end = mfcFFTerms.end();
    int atoms[4];
    int tmp;
    atoms[0] = atom1;
    atoms[1] = atom2;
    atoms[2] = atom3;
    atoms[3] = atom4;
    if (nType == 1) {
        if (atoms[0] > atoms[1]) {
            tmp = atoms[0];
            atoms[0] = atoms[1];
            atoms[1] = tmp;
        }
    }
    if (nType == 2 || nType == 5) {
        if (atoms[0] > atoms[2]) {
            tmp = atoms[0];
            atoms[0] = atoms[2];
            atoms[2] = tmp;
        }
    }
    if (nType == 3) {
        if (atoms[1] > atoms[2]) {
            tmp = atoms[1];
            atoms[1] = atoms[2];
            atoms[2] = tmp;
            tmp = atoms[0];
            atoms[0] = atoms[3];
            atoms[3] = tmp;
        }
    }
    if (nType == 4) {
        // sort
        if (atoms[2] > atoms[3]) {
            tmp = atoms[2];
            atoms[2] = atoms[3];
            atoms[3] = tmp;
        }
        if (atoms[1] > atoms[2]) {
            tmp = atoms[1];
            atoms[1] = atoms[2];
            atoms[2] = tmp;
        }
        if (atoms[2] > atoms[3]) {
            tmp = atoms[2];
            atoms[2] = atoms[3];
            atoms[3] = tmp;
        }
    }
    //
    //
    for (; iter != iter_end; ++iter) {
        if (*iter != 0) {
            ffTerm = *iter;
            if (ffTerm->nType == nType && nType == 1) {
                if (atoms[0] == ffTerm->atomList[0] && atoms[1] == ffTerm->atomList[1])
                    return ffTerm;
            }
            if (ffTerm->nType == nType && nType == 2) {
                if (atoms[0] == ffTerm->atomList[0] && atoms[1] == ffTerm->atomList[1] &&
                    atoms[2] == ffTerm->atomList[2])
                    return ffTerm;
            }
            if (ffTerm->nType == nType && nType == 3) {
                if (atoms[0] == ffTerm->atomList[0] && atoms[1] == ffTerm->atomList[1] &&
                    atoms[2] == ffTerm->atomList[2] && atoms[3] == ffTerm->atomList[3])
                    return ffTerm;
            }
            if (ffTerm->nType == nType && nType == 4) {
                if (atoms[0] == ffTerm->atomList[0] && atoms[1] == ffTerm->atomList[1] &&
                    atoms[2] == ffTerm->atomList[2] && atoms[3] == ffTerm->atomList[3])
                    return ffTerm;
            }
            if (ffTerm->nType == nType && nType == 5) {
                if (atoms[0] == ffTerm->atomList[0] && atoms[1] == ffTerm->atomList[1] &&
                    atoms[2] == ffTerm->atomList[2])
                    return ffTerm;
            }
            if (ffTerm->nType == nType && nType == 6) return ffTerm;
            if (ffTerm->nType == nType && nType == 7) return ffTerm;
        }
    }
    return 0;
}

double MFCFFFrag::optimizeGeom(int maxiter) {
    bool steepest = false;
    int nAtom3 = nAtoms * 3;
    int maxIter = 500;
    if (maxiter != 0) {
        maxIter = maxiter;
    }
    double *gradient = new double[nAtom3];
    double *gradOld = new double[nAtom3];
    double *direction = new double[nAtom3];
    double *direOld = new double[nAtom3];
    double beta = 0.0;
    double gN0 = 0;
    double gN1 = 0;
    double step = 0.05;
    double delta = 0.00001;
    double sfactor = 0.00001;
    double minStep = 0;
    // Compute initial energy and gradient
    double eStart = computeEnergyGrads();
    for (int i = 0; i < nAtom3; i++) {
        direction[i] = -crdGrads[i];
        direOld[i] = -crdGrads[i];
        gN0 += direOld[i] * direOld[i];
    }
    for (int iter = 0; iter < maxIter; iter++) {
        step = sqrt(gN0) * sfactor;
        // Line Search and update crds in the direction
        minStep = lineMinimizer(step, eStart, direction);
        double exx = computeEnergyGrads();
        // std::cout << "Ratio = " << sqrt(gN0)/minStep << "\n";
        gN1 = 0;
        for (int i = 0; i < nAtom3; i++) {
            gN1 += crdGrads[i] * crdGrads[i];
        }
        // Compute beta according to Fletcher-Reeves (FR) formula
        beta = gN1 / gN0;
        gN0 = 0;
        if (exx > eStart) beta = 0;
        if (steepest) beta = 0;
        int iter50 = iter / 50;
        if (iter50 * 50 == iter) beta = 0;
        for (int i = 0; i < nAtom3; i++) {
            direction[i] = -crdGrads[i] + beta * direOld[i];
            // gradOld[i] = crdGrads[i];
            direOld[i] = direction[i];
            // gN0 += direction[i]*direction[i];
            gN0 += crdGrads[i] * crdGrads[i];
        }
        eStart = exx;
        std::cout << "Energy of Iteration = " << iter << " " << exx << "\n";
        // std::cout << "gN1 = " << gN1 << "\n";
        if (minStep < delta) break;
    }

    delete gradient;
    delete gradOld;
    delete direOld;
    delete direction;
}

double MFCFFFrag::lineMinimizer(double step, double eOld, double *direction) {
    int maxSteps = 100;
    double bestStep = step;
    double minEnergy = 0;
    double factor = 0;
    double gg = 0;
    double bigger = 2.0;
    double escan[50];
    double steps[50];
    double energy = 0;
    double delta = 0.00000001;

    double *crdOld = new double[nAtoms * 3];
    for (int i = 0; i < nAtoms * 3; i++) {
        crdOld[i] = crds[i];
        gg += direction[i] * direction[i];
    }
    factor = 1.0 / sqrt(gg);
    // printf("sqrt(gg) = %15.13f\n",sqrt(gg));

    for (int i = 0; i < nAtoms * 3; i++) {
        direction[i] = direction[i] * factor;
    }
    // Find turn point
    escan[0] = eOld;
    steps[0] = 0;
    for (int j = 0; j < nAtoms * 3; j++) {
        crds[j] = crdOld[j] + step * direction[j];
    }
    escan[1] = computeEnergy();
    steps[1] = step;
    int iscan;
    if (escan[1] < escan[0]) {
        // Continue in this direction with bigger step, till energy increases
        for (int i = 0; i < 25; i++) {
            step = step * bigger;
            for (int j = 0; j < nAtoms * 3; j++) {
                crds[j] = crdOld[j] + step * direction[j];
            }
            energy = computeEnergy();
            if (energy < escan[1]) {
                escan[0] = escan[1];
                steps[0] = steps[1];
                escan[1] = energy;
                steps[1] = step;
            } else {
                escan[2] = energy;
                steps[2] = step;
                iscan = i + 1;
                break;
            }
        }
    } else {
        // Continue in this direction with smaller step, till energy below start
        for (int i = 0; i < 25; i++) {
            step = step / bigger;
            for (int j = 0; j < nAtoms * 3; j++) {
                crds[j] = crdOld[j] + step * direction[j];
            }
            energy = computeEnergy();
            printf("B step = %lf, energy = %15.13f\n", step, energy);
            if (energy < escan[0]) {
                escan[2] = escan[1];
                steps[2] = steps[1];
                escan[1] = energy;
                steps[1] = step;
                iscan = i + 1;
                break;
            } else {
                escan[1] = energy;
                steps[1] = step;
            }
        }
    }
    // std::cout << "Bracket scan = " << iscan << "\n";
    // Now, quadratic interplolation
    // First, compute numerical gradient for x0 and x2
    // Using  the gradient to comput xx, which has the lowest energy on the line
    //
    for (int j = 0; j < nAtoms * 3; j++) {
        crds[j] = crdOld[j] + (steps[0] + delta) * direction[j];
    }
    energy = computeEnergy();
    double dx0 = (energy - escan[0]) / delta;
    for (int j = 0; j < nAtoms * 3; j++) {
        crds[j] = crdOld[j] + (steps[2] + delta) * direction[j];
    }
    energy = computeEnergy();
    double dx2 = (energy - escan[2]) / delta;
    double xx = (dx0 * steps[2] - dx2 * steps[0]) / (dx0 - dx2);
    // std::cout << "xx from quadratic interplolation = " << xx << "\n";
    // if(steps[0] < xx && xx < steps[2]) return xx;
    // Set the new coords
    for (int j = 0; j < nAtoms * 3; j++) {
        crds[j] = crdOld[j] + xx * direction[j];
    }
    return xx;

    // If quadratic interpolation failed, do the following:
    // Now, binary search
    // E0 > E1 < E2
    double e01, e12;
    double s01, s12;
    for (int i = 0; i < 30; i++) {
        step = (steps[0] + steps[1]) * 0.5;
        s01 = step;
        for (int j = 0; j < nAtoms * 3; j++) {
            crds[j] = crdOld[j] + step * direction[j];
        }
        e01 = computeEnergy();
        step = (steps[1] + steps[2]) * 0.5;
        s12 = step;
        for (int j = 0; j < nAtoms * 3; j++) {
            crds[j] = crdOld[j] + step * direction[j];
        }
        e12 = computeEnergy();
        if (escan[1] < e01 && escan[1] < e12) {
            escan[0] = e01;
            steps[0] = s01;
            escan[2] = e12;
            steps[2] = s12;
        } else if (e01 < escan[1]) {
            escan[2] = escan[1];
            steps[2] = steps[1];
            escan[1] = e01;
            steps[1] = s01;
        } else {
            escan[0] = escan[1];
            steps[0] = steps[1];
            escan[1] = e12;
            steps[1] = s12;
        }
        iscan = i + 1;
        if ((steps[2] - steps[0]) < delta) break;
    }
    // std::cout << "refine scan = " << iscan << "\n";
    bestStep = steps[1];
    std::cout << "bestStep from binary search = " << bestStep << "\n";
    std::cout << "Ratio = " << bestStep / xx << "\n";
    return xx;
    return bestStep;
}

void MFCFFFrag::printFFTerms() {
    // Clean FFTerms
    MFCFFTerm *ffTerm;
    std::vector<MFCFFTerm *>::iterator iter = mfcFFTerms.begin();
    std::vector<MFCFFTerm *>::iterator iter_end = mfcFFTerms.end();
    int nFTerms = 0;
    for (; iter != iter_end; ++iter) {
        if (*iter != 0) {
            ffTerm = *iter;
            std::cout << "nFTerm = " << nFTerms + 1 << "\n";
            nFTerms++;
            ffTerm->printFFTerms();
        }
    }
}

MFCFFFrag::~MFCFFFrag() {
    // Clean FFTerms
    std::vector<MFCFFTerm *>::iterator iter = mfcFFTerms.begin();
    std::vector<MFCFFTerm *>::iterator iter_end = mfcFFTerms.end();
    for (; iter != iter_end; ++iter) {
        if (*iter != 0) {
            delete *iter;
        }
    }
    delete[] crds;
    delete[] crdGrads;
    if (ownerFrag != 0) delete ownerFrag;
}

// Find neighbor atom pairs with a distance cutoff R
// The neighbor pairs  are returned in a std vector, and the return value
// is the total number of atom pairs.
//
// For VDW calculations, the atom pairs of bonding atoms and bond angle atom
// pairs should be removed.
//
//
int findNeighborPairs(MFCFrag *mfcFrag, double R, std::vector<int> &neigborPairs) {
    // Loop over MFCAtoms,
    // MFCAtom mfcAtom = mfcFrag->atomList[i];
    // XYZ: mfcAtom->x ...

    return 0;
}

bool notBondingAngleAtoms(MFCFrag *mfcFrag, int na1, int na2) {
    int setA[10];
    int setB[10];
    setA[0] = na1;
    setB[0] = na2;
    MFCAtom *atomA = mfcFrag->atomList[na1];
    MFCAtom *atomB = mfcFrag->atomList[na2];
    MFCBond *bond;
    int AIdxA = atomA->AIdx;
    int AIdxB = atomB->AIdx;

    int nBA = atomA->nBonds;
    for (int i = 0; i < nBA; i++) {
        bond = mfcFrag->bondList[atomA->bondList[i]];
        int idxA = findOtherBondAtom(bond, AIdxA);
        setA[i + 1] = idxA;
    }
    int nBB = atomB->nBonds;
    for (int i = 0; i < nBB; i++) {
        bond = mfcFrag->bondList[atomB->bondList[i]];
        int idxB = findOtherBondAtom(bond, AIdxB);
        setB[i + 1] = idxB;
    }
    for (int i = 0; i < nBA + 1; i++) {
        for (int j = 0; j < nBB + 1; j++) {
            if (setA[i] == setB[j]) return false;
        }
    }
    return true;
}

int findNeighborPairs(MFCFrag *mfcFrag, double R, double *crd, std::vector<int> &neighborPairs) {
    // Loop over MFCAtoms,
    // MFCAtom mfcAtom = mfcFrag->atomList[i];
    // XYZ: mfcAtom->x ...
    neighborPairs.resize(0);
    int i3, j3;
    double maxX, maxY, maxZ, minX, minY, minZ, lx, ly, lz, temp;
    maxX = maxY = maxZ = -1.0 * 10E+20;
    minX = minY = minZ = 1.0 * 10E+20;
    int numX, numY, numZ;
    int nvdwPairs = 0;
    int nAtoms = mfcFrag->numAtoms;
    // step1:
    double R2 = R * R;
    double boxSize = 5.0;
    int layer = 2;
    for (int i = 0; i < nAtoms; i++) {
        i3 = i * 3;
        temp = crd[i3];
        if (temp > maxX) maxX = temp;
        if (temp < minX) minX = temp;

        temp = crd[i3 + 1];
        if (temp > maxY) maxY = temp;
        if (temp < minY) minY = temp;

        temp = crd[i3 + 2];
        if (temp > maxZ) maxZ = temp;
        if (temp < minZ) minZ = temp;
    }
    // printf("maxX=%f,maxY=%f,maxZ=%f,minX=%f,minY=%f,minZ=%f\n",maxX,maxY,maxZ,minX,minY,minZ);
    lx = maxX - minX;
    ly = maxY - minY;
    lz = maxZ - minZ;
    numX = (int)((lx + boxSize + 0.000000001) / boxSize);
    numY = (int)((ly + boxSize + 0.000000001) / boxSize);
    numZ = (int)((lz + boxSize + 0.000000001) / boxSize);
    int numBoxs = numX * numY * numZ;
    // printf("numX=%d,numY=%d,numZ=%d\n",numX,numY,numZ);
    // step3: group atoms in boxes
    std::vector<std::vector<int> > atomBoxs;
    for (int i = 0; i < numBoxs; i++) {
        std::vector<int> tempV;
        atomBoxs.push_back(tempV);
    }
    // loop over atoms to find atoms in this box

    for (int m = 0; m < nAtoms; m++) {
        int m3 = m * 3;
        temp = crd[m3] - minX;
        int i = (int)(temp / boxSize);
        temp = crd[m3 + 1] - minY;
        int j = (int)(temp / boxSize);
        temp = crd[m3 + 2] - minZ;
        int k = (int)(temp / boxSize);
        int ijk = k * numY * numX + j * numX + i;
        atomBoxs[ijk].push_back(m);
    }
    // int sumAtoms=0;
    /**  for(int i=0;i<numBoxs;i++){
            sumAtoms += atomBoxs[i].size();
            printf("number of atoms in box[%d]=%d\n",i,atomBoxs[i].size());
      }
    **/
    // printf("sum of atoms: %d\n",sumAtoms);
    std::vector<int> currAtomG;
    std::vector<int> atomG;
    std::vector<int>::iterator it1;
    std::vector<int>::iterator it2;
    for (int i = 0; i < numZ; i++) {
        for (int j = 0; j < numY; j++) {
            for (int k = 0; k < numX; k++) {
                atomG = atomBoxs[i * numY * numX + j * numX + k];
                for (it1 = atomG.begin(); it1 != atomG.end(); it1++) {
                    int atom1 = *it1;
                    int atom13 = atom1 * 3;
                    // loop over current boxes
                    int cimin = i - layer;
                    if (cimin < 0) cimin = 0;
                    int cimax = i + layer;
                    if (cimax > numZ - 1) cimax = numZ - 1;

                    int cjmin = j - layer;
                    if (cjmin < 0) cjmin = 0;
                    int cjmax = j + layer;
                    if (cjmax > numY - 1) cjmax = numY - 1;

                    int ckmin = k - layer;
                    if (ckmin < 0) ckmin = 0;
                    int ckmax = k + layer;
                    if (ckmax > numX - 1) ckmax = numX - 1;

                    for (int ci = cimin; ci <= cimax; ci++) {
                        for (int cj = cjmin; cj <= cjmax; cj++) {
                            for (int ck = ckmin; ck <= ckmax; ck++) {
                                currAtomG = atomBoxs.at(ci * numY * numX + cj * numX + ck);
                                for (it2 = currAtomG.begin(); it2 != currAtomG.end(); it2++) {
                                    int atom2 = *it2;
                                    if (atom2 > atom1) continue;
                                    int atom23 = atom2 * 3;
                                    double dx = crd[atom13] - crd[atom23];
                                    double dy = crd[atom13 + 1] - crd[atom23 + 1];
                                    double dz = crd[atom13 + 2] - crd[atom23 + 2];
                                    double dist2 = dx * dx + dy * dy + dz * dz;
                                    if (dist2 < R2) {
                                        if (notBondingAngleAtoms(mfcFrag, atom1, atom2)) {
                                            neighborPairs.push_back(atom1);
                                            neighborPairs.push_back(atom2);
                                            nvdwPairs++;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return nvdwPairs;
}

double MFCFFFrag::computeEnergy() {
    // Calculation energy from crds
    double energy = 0;
    MFCFFTerm *ffTerm;
    std::vector<MFCFFTerm *>::iterator iter = mfcFFTerms.begin();
    std::vector<MFCFFTerm *>::iterator iter_end = mfcFFTerms.end();
    int nFTerms = 0;
    double eBond = 0;
    double eAngle = 0;
    double eTorsion = 0;
    double eOopl = 0;
    double eLinBend = 0;
    double eVDW = 0;
    double eESP = 0;
    double eTemp = 0;
    for (; iter != iter_end; ++iter) {
        if (*iter != 0) {
            ffTerm = *iter;
            // ffTerm->printFFTerms();
            // std::cout << "nFTerm in Comput Energy = " << nFTerms+1 << "\n";
            // nFTerms++;
            eTemp = ffTerm->ComputeEnergy(crds);
            energy += eTemp;
            if (ffTerm->nType == 1) eBond += eTemp;
            if (ffTerm->nType == 2) eAngle += eTemp;
            if (ffTerm->nType == 3) eTorsion += eTemp;
            if (ffTerm->nType == 4) eOopl += eTemp;
            if (ffTerm->nType == 5) eLinBend += eTemp;
            if (ffTerm->nType == 6) eVDW += eTemp;
            if (ffTerm->nType == 7) eESP += eTemp;
        }
    }
    std::cout << "Energy from Bond = " << eBond << "\n";
    std::cout << "Energy from Angle = " << eAngle << "\n";
    std::cout << "Energy from Torsion = " << eTorsion << "\n";
    std::cout << "Energy from Oopl = " << eOopl << "\n";
    std::cout << "Energy from Lin-Bend = " << eLinBend << "\n";
    std::cout << "Energy from VDW = " << eVDW << "\n";
    std::cout << "Energy from ESP = " << eESP << "\n";
    std::cout << "Energy from MFCFFFrag = " << energy << "\n";

    return energy;
}

double MFCFFFrag::computeEnergy(double *crdx) {
    // Calculation energy from crds
    updateCoordinates(nAtoms, crdx);
    double energy = 0;
    MFCFFTerm *ffTerm;
    std::vector<MFCFFTerm *>::iterator iter = mfcFFTerms.begin();
    std::vector<MFCFFTerm *>::iterator iter_end = mfcFFTerms.end();
    int nFTerms = 0;
    for (; iter != iter_end; ++iter) {
        if (*iter != 0) {
            ffTerm = *iter;
            // ffTerm->printFFTerms();
            nFTerms++;
            energy += ffTerm->ComputeEnergy(crds);
        }
    }
    std::cout << "Energy from MFCFFFrag = " << energy << "\n";
    return energy;
}

double MFCFFFrag::computeEnergyGrads(double *crdx, double *crdGradx) {
    // Calculate energy from crds, and return grads in crdGrads
    updateCoordinates(nAtoms, crdx);
    // Zero Grads
    for (int i = 0; i < 3 * nAtoms; i++) {
        crdGrads[i] = 0;
    }
    double energy = 0;
    MFCFFTerm *ffTerm;
    std::vector<MFCFFTerm *>::iterator iter = mfcFFTerms.begin();
    std::vector<MFCFFTerm *>::iterator iter_end = mfcFFTerms.end();
    int nFTerms = 0;
    for (; iter != iter_end; ++iter) {
        if (*iter != 0) {
            ffTerm = *iter;
            // ffTerm->printFFTerms();
            energy += ffTerm->ComputeEnergyGrads(crds, crdGradx);
        }
    }
    return energy;
}

MFCFrag *MFCFFFrag::getMFCFrag() { return ownerFrag; }

double *MFCFFFrag::getCrds() { return crds; }

double MFCFFFrag::computeEnergyGrads() {
    // Calculate energy from crds, and return grads in crdGrads
    double energy = computeEnergyGrads(crds, crdGrads);
    return energy;
}

void MFCFFFrag::printCrdsAndGrads() {
    // Calculate energy from crds, and return grads in crdGrads
    double energy = computeEnergyGrads(crds, crdGrads);
    for (int i = 0; i < nAtoms; i++) {
        int i3 = i * 3;
        printf("Crd[%d]=%10.6f %10.6f %10.6f\n", i + 1, crds[i3], crds[i3 + 1], crds[i3 + 2]);
    }
    printf(" .......\n");
    for (int i = 0; i < nAtoms; i++) {
        int i3 = i * 3;
        printf("Grd[%d]=%10.6f %10.6f %10.6f\n", i + 1, crdGrads[i3], crdGrads[i3 + 1],
               crdGrads[i3 + 2]);
    }
}

MFCFFFrag *MFCFragToMFCFFFrag(MFCFrag *mfcFrag) {
    MFCFFFrag *mfcFFFrag = new MFCFFFrag(mfcFrag);
    return mfcFFFrag;
}

void writeFFParamsMapToFile(char *fn, std::map<std::string, MFCFFParams *> &ffParams) {
    FILE *f = fopen(fn, "w");
    if (!f) {
        std::cout << "unable to read %s" << fn;
        exit(0);
    }
    std::map<std::string, MFCFFParams *>::iterator it;
    for (it = ffParams.begin(); it != ffParams.end(); it++) {
        fprintf(f, "%s %d %d %d", (it->first).c_str(), it->second->nType, it->second->nParams,
                it->second->nTerms);
        for (int i = 0; i < it->second->nParams; i++) {
            fprintf(f, " %f", it->second->paramList[i]);
        }
        if (it->second->nType == 3) {
            for (int i = 0; i < it->second->nTerms; i++) {
                fprintf(f, " %d", it->second->period[i]);
            }
        }
        fprintf(f, "\n");
    }
    fclose(f);
}

void readFFParamsMapFromFile(char *fn, std::map<std::string, MFCFFParams *> &ffParams) {
    // char s[250];
    FILE *f = fopen(fn, "r");
    if (!f) {
        std::cout << "unable to read %s" << fn;
        exit(0);
    }
    char buf[40];
    char param[40];
    /*
       while(fgets(s,250,f)!=NULL){
       MFCFFParams* temp = new MFCFFParams();
       sscanf(s,"%s %d %d %d",buf,&(temp->nType),&(temp->nParams),&(temp->nTerms));
       for(int i=0;i<temp->nParams;i++){
       sscanf(s," %s",param);
       printf("parameters: %s\n",param);
       temp->paramList[i] = stringToDouble(std::string(param));
       }
       if(temp->nType==3){
       for(int i=0;i<temp->nTerms;i++){
       sscanf(s," %d",&(temp->period[i]));
       }
       }
       ffParams[std::string(buf)] = temp;
       }
       fclose(f);
     */
    while (fscanf(f, "%s ", buf) != EOF) {
        MFCFFParams *temp = new MFCFFParams();
        fscanf(f, "%d %d %d ", &(temp->nType), &(temp->nParams), &(temp->nTerms));
        for (int i = 0; i < temp->nParams; i++) {
            fscanf(f, "%lf ", &(temp->paramList[i]));
            // fscanf(s," %s",param);
            // printf("parameters: %s\n",param);
            // temp->paramList[i] = stringToDouble(std::string(param));
        }
        if (temp->nType == 3) {
            for (int i = 0; i < temp->nTerms; i++) {
                fscanf(f, "%d", &(temp->period[i]));
            }
        }
        ffParams[std::string(buf)] = temp;
    }
    fclose(f);
}

void collectVDWParams(MFCFFFrag *mfcFFFrag, std::map<std::string, vdwParams *> &vdwP,
                      std::map<std::string, int> &vdwFreqs, int rankedLevel) {
    char buf0[40], bufx[40], buf1[40];
    std::map<std::string, vdwParams *>::iterator it;
    MFCFrag *mfcFrag = mfcFFFrag->getMFCFrag();
    // std::map < std::string, int >vdwFreqs;
    for (int k = 0; k < mfcFrag->numAtoms; k++) {
        MFCAtom *mfcAtom = mfcFrag->atomList[k];
        for (int i = 0; i < rankedLevel; i++) {
            vdwParams *temp = new vdwParams();
            temp->vdwR = mfcAtom->vdwR;
            temp->vdwE = mfcAtom->vdwE;
            char iden = (char)(i + 97);
            sprintf(buf0, "%c%15.13f", iden, mfcAtom->RankedValues[i]);
            sprintf(bufx, "%c%15.13f", iden, mfcAtom->RankedValues[i] - 9E-14);
            sprintf(buf1, "%c%15.13f", iden, mfcAtom->RankedValues[i] + 9E-14);
            if (std::string(buf0) == std::string(bufx)) {
                sprintf(bufx, "%c%15.13f", iden, mfcAtom->RankedValues[i] - 11E-14);
            }
            if (std::string(buf0) == std::string(buf1)) {
                sprintf(buf1, "%c%15.13f", iden, mfcAtom->RankedValues[i] + 11E-14);
            }
            it = vdwP.find(std::string(buf0));
            if (it != vdwP.end()) {
                int freq = vdwFreqs.find(std::string(buf0))->second;
                double preVDWE = it->second->vdwE;
                double preVDWR = it->second->vdwR;
                double newVDWE = (preVDWE * freq + temp->vdwE) / (freq + 1);
                double newVDWR = (preVDWR * freq + temp->vdwR) / (freq + 1);
                it->second->vdwE = newVDWE;
                it->second->vdwR = newVDWR;
                vdwFreqs.find(std::string(buf0))->second = freq + 1;
                delete temp;
            } else {
                it = vdwP.find(std::string(bufx));
                if (it != vdwP.end()) {
                    int freq = vdwFreqs.find(std::string(bufx))->second;
                    double preVDWE = it->second->vdwE;
                    double preVDWR = it->second->vdwR;
                    double newVDWE = (preVDWE * freq + temp->vdwE) / (freq + 1);
                    double newVDWR = (preVDWR * freq + temp->vdwR) / (freq + 1);
                    it->second->vdwE = newVDWE;
                    it->second->vdwR = newVDWR;
                    vdwFreqs.find(std::string(bufx))->second = freq + 1;
                    delete temp;
                } else {
                    it = vdwP.find(std::string(buf1));
                    if (it != vdwP.end()) {
                        int freq = vdwFreqs.find(std::string(buf1))->second;
                        double preVDWE = it->second->vdwE;
                        double preVDWR = it->second->vdwR;
                        double newVDWE = (preVDWE * freq + temp->vdwE) / (freq + 1);
                        double newVDWR = (preVDWR * freq + temp->vdwR) / (freq + 1);
                        it->second->vdwE = newVDWE;
                        it->second->vdwR = newVDWR;
                        vdwFreqs.find(std::string(buf1))->second = freq + 1;
                        delete temp;
                    } else {
                        vdwP[std::string(buf0)] = temp;
                        vdwFreqs[std::string(buf0)] = 1;
                    }
                }
            }  // end if else
        }      // end loop over Ranked lever
    }          // end loop atoms in MFCFrag
}

void writeVDWParamsMapToFile(char *fn, std::map<std::string, vdwParams *> &vdwP) {
    FILE *f = fopen(fn, "w");
    if (!f) {
        std::cout << "unable to read %s" << fn;
        exit(0);
    }
    std::map<std::string, vdwParams *>::iterator it;
    for (it = vdwP.begin(); it != vdwP.end(); it++) {
        fprintf(f, "%s %f %f\n", (it->first).c_str(), it->second->vdwR, it->second->vdwE);
    }
    fclose(f);
}

void readVDWParamsMapFromFile(char *fn, std::map<std::string, vdwParams *> &vdwP) {
    char s[100];
    FILE *f = fopen(fn, "r");
    if (!f) {
        std::cout << "unable to read %s" << fn;
        exit(0);
    }
    char buf[40];
    char buf1[40];
    char buf2[40];
    while (fgets(s, 100, f) != NULL) {
        sscanf(s, "%s %s %s", buf, buf1, buf2);
        vdwParams *temp = new vdwParams();
        const string &ss = std::string(buf1);
        temp->vdwR = stod(ss);
        const string &ss1 = std::string(buf2);
        temp->vdwE = stod(ss1);
        vdwP[std::string(buf)] = temp;
    }
    fclose(f);
}

vdwParams *findVDWParams(std::string s, std::map<std::string, vdwParams *> &vdwP) {
    char buf[40];
    char pre = s.c_str()[0];
    const string &ss = s.substr(1);
    double lable = stod(ss);
    // std::cout << pre << "\n";
    // printf("%15.13f\n",lable);
    std::map<std::string, vdwParams *>::iterator it;
    it = vdwP.find(s);
    if (it != vdwP.end()) {
        return it->second;
    } else {
        sprintf(buf, "%c%15.13f", pre, lable - 9E-14);
        if (s == buf) sprintf(buf, "%c%15.13f", pre, lable - 11E-14);
        it = vdwP.find(std::string(buf));
        if (it != vdwP.end()) {
            return it->second;
        } else {
            sprintf(buf, "%c%15.13f", pre, lable + 9E-14);
            if (s == buf) sprintf(buf, "%c%15.13f", pre, lable + 11E-14);
            it = vdwP.find(std::string(buf));
            if (it != vdwP.end()) {
                return it->second;
            } else
                return NULL;
        }
    }
}

void setVDWParamsForAtom(MFCAtom *mfcAtom, std::map<std::string, vdwParams *> &vdwP,
                         int rankedLevel) {
    int flag = -1;
    for (int i = rankedLevel - 1; i > -1; i--) {
        char pre = (char)(i + 97);
        double lable = mfcAtom->RankedValues[i];
        char buf[40];
        sprintf(buf, "%c%15.13f", pre, lable);
        vdwParams *p = findVDWParams(std::string(buf), vdwP);
        if (p != NULL) {
            mfcAtom->vdwR = p->vdwR;
            mfcAtom->vdwE = p->vdwE;
            flag = i;
            break;
        }
    }
    if (flag == -1) printf("no parameters for atom: %d\n", mfcAtom->AIdx);
}

// It is assumed that the topological ranking has been done for mfcFrag
// up to level 4.
//
void collectFFParams(MFCFFFrag *FFFrag, std::map<std::string, MFCFFParams *> &ffParams,
                     std::map<std::string, int> &Freqs, int rankedLevel) {
    MFCFrag *mfcFrag = FFFrag->getMFCFrag();
    if (mfcFrag == 0) return;
    // check for highest ranking level
    int nAtoms = mfcFrag->numAtoms;
    MFCAtom *mfcAtom;
    mfcAtom = mfcFrag->atomList[0];
    if (mfcAtom->RankedValues.size() < 4) {
        std::cout << "Ranking level less than 4, stop\n";
        exit(0);
    }
    CodingProfile *xfile = CodingProfile::Instance();
    double eps = xfile->eps;
    MFCAtom *AtomA;
    MFCAtom *AtomB;
    MFCAtom *AtomC;
    MFCAtom *AtomD;
    MFCBond *Bond0;
    MFCBond *Bond1;
    MFCBond *Bond2;
    MFCBond *Bond3;
    // double *bFactors = new double[mfcFrag->numBonds];
    std::vector<MFCAtom *> atomVec(mfcFrag->numAtoms);

    for (int j = 0; j < mfcFrag->numBonds; j++) {
        Bond0 = mfcFrag->bondList[j];
        // bFactors[j] = xfile->bFactors[Bond0->bondType];
    }
    MFCFFTerm *ffTerm;
    std::vector<MFCFFTerm *>::iterator iter = FFFrag->mfcFFTerms.begin();
    std::vector<MFCFFTerm *>::iterator iter_end = FFFrag->mfcFFTerms.end();
    // std::map < std::string, int >Freqs;
    int FFType = 0;
    double FFRV[4];
    char buf0[40], bufx[40], buf1[40];
    for (; iter != iter_end; ++iter) {
        if (*iter != 0) {
            ffTerm = *iter;
            FFType = ffTerm->nType;
            switch (FFType) {
                case 1:  // Bond
                    AtomA = mfcFrag->atomList[ffTerm->atomList[0]];
                    AtomB = mfcFrag->atomList[ffTerm->atomList[1]];
                    Bond0 = findBondByAtomPair(AtomA, AtomB);

                    for (int i = 0; i < rankedLevel; i++) {
                        FFRV[i] = AtomA->RankedValues[i] + AtomB->RankedValues[i] +
                                  xfile->bFactors[Bond0->bondType];
                        char iden = (char)(i + 97);
                        sprintf(buf0, "%c%15.13f", iden, FFRV[i]);
                        sprintf(bufx, "%c%15.13f", iden, FFRV[i] - 9E-14);
                        sprintf(buf1, "%c%15.13f", iden, FFRV[i] + 9E-14);
                        if (std::string(buf0) == std::string(bufx)) {
                            sprintf(bufx, "%c%15.13f", iden, FFRV[i] - 11E-14);
                        }
                        if (std::string(buf0) == std::string(buf1)) {
                            sprintf(buf1, "%c%15.13f", iden, FFRV[i] + 11E-14);
                        }
                        std::map<std::string, MFCFFParams *>::iterator it;
                        it = ffParams.find(std::string(buf0));
                        if (it != ffParams.end()) {
                            int freq = Freqs.find(std::string(buf0))->second;
                            int nParams = it->second->nParams;
                            for (int i = 0; i < nParams; i++) {
                                double preParam = it->second->paramList[i];
                                double newParam =
                                    (preParam * freq + ffTerm->paramList[i]) / (freq + 1);
                                it->second->paramList[i] = newParam;
                            }
                            Freqs[std::string(buf0)] = freq + 1;
                        } else {
                            it = ffParams.find(std::string(bufx));
                            if (it != ffParams.end()) {
                                int freq = Freqs.find(std::string(bufx))->second;
                                int nParams = it->second->nParams;
                                for (int i = 0; i < nParams; i++) {
                                    double preParam = it->second->paramList[i];
                                    double newParam =
                                        (preParam * freq + ffTerm->paramList[i]) / (freq + 1);
                                    it->second->paramList[i] = newParam;
                                }
                                Freqs[std::string(bufx)] = freq + 1;
                            } else {
                                it = ffParams.find(std::string(buf1));
                                if (it != ffParams.end()) {
                                    int freq = Freqs.find(std::string(buf1))->second;
                                    int nParams = it->second->nParams;
                                    for (int i = 0; i < nParams; i++) {
                                        double preParam = it->second->paramList[i];
                                        double newParam =
                                            (preParam * freq + ffTerm->paramList[i]) / (freq + 1);
                                        it->second->paramList[i] = newParam;
                                    }
                                    Freqs[std::string(buf1)] = freq + 1;
                                } else {
                                    MFCFFParams *temp = new MFCFFParams();
                                    temp->nType = 1;
                                    temp->nTerms = 0;
                                    temp->nParams = ffTerm->nParams;
                                    for (int i = 0; i < ffTerm->nParams; i++) {
                                        temp->paramList[i] = ffTerm->paramList[i];
                                    }
                                    ffParams[std::string(buf0)] = temp;
                                    Freqs[std::string(buf0)] = 1;
                                }
                            }
                        }
                    }
                    break;
                case 2:                                              // Angle
                    AtomA = mfcFrag->atomList[ffTerm->atomList[0]];  // Left atom0
                    AtomB = mfcFrag->atomList[ffTerm->atomList[1]];  // Center atom1
                    AtomC = mfcFrag->atomList[ffTerm->atomList[2]];  // Right atom2
                    Bond0 = findBondByAtomPair(AtomA, AtomB);
                    Bond1 = findBondByAtomPair(AtomB, AtomC);
                    FFRV[0] = AtomB->RankedValues[0] + xfile->bFactors[Bond0->bondType] +
                              xfile->bFactors[Bond1->bondType];

                    for (int i = 1; i < 4; i++) {
                        FFRV[i] = AtomB->RankedValues[i] +
                                  xfile->bFactors[Bond0->bondType] * AtomA->RankedValues[i - 1] +
                                  xfile->bFactors[Bond1->bondType] * AtomC->RankedValues[i - 1];
                    }
                    // For each FFRV, check FF record. If not in the collection, create
                    // one, and add it to the collection

                    for (int i = 0; i < 4; i++) {
                        char iden = (char)(i + 97);
                        sprintf(buf0, "%c%15.13f", iden, FFRV[i]);
                        sprintf(bufx, "%c%15.13f", iden, FFRV[i] - 9E-14);
                        sprintf(buf1, "%c%15.13f", iden, FFRV[i] + 9E-14);
                        if (std::string(buf0) == std::string(bufx)) {
                            sprintf(bufx, "%c%15.13f", iden, FFRV[i] - 11E-14);
                        }
                        if (std::string(buf0) == std::string(buf1)) {
                            sprintf(buf1, "%c%15.13f", iden, FFRV[i] + 11E-14);
                        }
                        std::map<std::string, MFCFFParams *>::iterator it;
                        it = ffParams.find(std::string(buf0));
                        if (it != ffParams.end()) {
                            int freq = Freqs.find(std::string(buf0))->second;
                            int nParams = it->second->nParams;
                            for (int i = 0; i < nParams; i++) {
                                double preParam = it->second->paramList[i];
                                double newParam =
                                    (preParam * freq + ffTerm->paramList[i]) / (freq + 1);
                                it->second->paramList[i] = newParam;
                            }
                            Freqs[std::string(buf0)] = freq + 1;
                        } else {
                            it = ffParams.find(std::string(bufx));
                            if (it != ffParams.end()) {
                                int freq = Freqs.find(std::string(bufx))->second;
                                int nParams = it->second->nParams;
                                for (int i = 0; i < nParams; i++) {
                                    double preParam = it->second->paramList[i];
                                    double newParam =
                                        (preParam * freq + ffTerm->paramList[i]) / (freq + 1);
                                    it->second->paramList[i] = newParam;
                                }
                                Freqs[std::string(bufx)] = freq + 1;
                            } else {
                                it = ffParams.find(std::string(buf1));
                                if (it != ffParams.end()) {
                                    int freq = Freqs.find(std::string(buf1))->second;
                                    int nParams = it->second->nParams;
                                    for (int i = 0; i < nParams; i++) {
                                        double preParam = it->second->paramList[i];
                                        double newParam =
                                            (preParam * freq + ffTerm->paramList[i]) / (freq + 1);
                                        it->second->paramList[i] = newParam;
                                    }
                                    Freqs[std::string(buf1)] = freq + 1;
                                } else {
                                    MFCFFParams *temp = new MFCFFParams();
                                    temp->nType = 2;
                                    temp->nTerms = 0;
                                    temp->nParams = ffTerm->nParams;
                                    for (int i = 0; i < ffTerm->nParams; i++) {
                                        temp->paramList[i] = ffTerm->paramList[i];
                                    }
                                    ffParams[std::string(buf0)] = temp;
                                    Freqs[std::string(buf0)] = 1;
                                }
                            }
                        }
                    }

                    break;
                case 3:  // Torsion
                    // Atom list: A-B-C-D, i.e. atom B and C are center atoms
                    /*
                       std::cout <<"Atom List 1: = " << ffTerm->atomList[0] <<"\n";
                       std::cout <<"Atom List 2: = " << ffTerm->atomList[1] <<"\n";
                       std::cout <<"Atom List 3: = " << ffTerm->atomList[2] <<"\n";
                       std::cout <<"Atom List 4: = " << ffTerm->atomList[3] <<"\n";
                     */
                    AtomA = mfcFrag->atomList[ffTerm->atomList[0]];  // Left side atom
                    AtomB = mfcFrag->atomList[ffTerm->atomList[1]];  // Left atom
                    AtomC = mfcFrag->atomList[ffTerm->atomList[2]];  // Right atom
                    AtomD = mfcFrag->atomList[ffTerm->atomList[3]];  // Right side atom
                    Bond0 = findBondByAtomPair(AtomA, AtomB);        // Left bond
                    Bond1 = findBondByAtomPair(AtomB, AtomC);        // Center bond
                    Bond2 = findBondByAtomPair(AtomC, AtomD);        // Right bond
                    FFRV[0] = AtomB->RankedValues[0] * AtomC->RankedValues[0] *
                                  xfile->bFactors[Bond1->bondType] +
                              xfile->bFactors[Bond0->bondType] + xfile->bFactors[Bond1->bondType];
                    for (int i = 1; i < 4; i++) {
                        FFRV[i] = AtomB->RankedValues[i] * AtomC->RankedValues[i] *
                                      xfile->bFactors[Bond1->bondType] +
                                  xfile->bFactors[Bond0->bondType] * AtomA->RankedValues[i - 1] +
                                  xfile->bFactors[Bond2->bondType] * AtomD->RankedValues[i - 1];
                    }

                    for (int i = 0; i < 4; i++) {
                        // Create a FF record ID from FFRV(i), and check it in the
                        // collection, if not exist, create one and add it to the collec.
                        char iden = (char)(i + 97);
                        sprintf(buf0, "%c%15.13f", iden, FFRV[i]);
                        sprintf(bufx, "%c%15.13f", iden, FFRV[i] - 9E-14);
                        sprintf(buf1, "%c%15.13f", iden, FFRV[i] + 9E-14);
                        if (std::string(buf0) == std::string(bufx)) {
                            sprintf(bufx, "%c%15.13f", iden, FFRV[i] - 11E-14);
                        }
                        if (std::string(buf0) == std::string(buf1)) {
                            sprintf(buf1, "%c%15.13f", iden, FFRV[i] + 11E-14);
                        }
                        std::map<std::string, MFCFFParams *>::iterator it;
                        it = ffParams.find(std::string(buf0));
                        if (it != ffParams.end()) {
                            int freq = Freqs.find(std::string(buf0))->second;
                            /*int nParams = it->second->nParams;
                               for(int i=0;i<nParams;i++){
                               double preParam = it->second->paramList[i];
                               double newParam = (preParam * freq + ffTerm->paramList[i])/(freq +
                               1); it->second->paramList[i] = newParam;
                               } */
                            Freqs[std::string(buf0)] = freq + 1;
                        } else {
                            it = ffParams.find(std::string(bufx));
                            if (it != ffParams.end()) {
                                int freq = Freqs.find(std::string(bufx))->second;
                                /*
                                   int nParams = it->second->nParams;
                                   for(int i=0;i<nParams;i++){
                                   double preParam = it->second->paramList[i];
                                   double newParam = (preParam * freq + ffTerm->paramList[i])/(freq
                                   + 1); it->second->paramList[i] = newParam;
                                   }
                                 */
                                Freqs[std::string(bufx)] = freq + 1;
                            } else {
                                it = ffParams.find(std::string(buf1));
                                if (it != ffParams.end()) {
                                    int freq = Freqs.find(std::string(buf1))->second;
                                    /*
                                       int nParams = it->second->nParams;
                                       for(int i=0;i<nParams;i++){
                                       double preParam = it->second->paramList[i];
                                       double newParam = (preParam * freq +
                                       ffTerm->paramList[i])/(freq + 1); it->second->paramList[i] =
                                       newParam;
                                       }
                                     */
                                    Freqs[std::string(buf1)] = freq + 1;
                                } else {
                                    // convert MFCFFTerm* to MFCFFDihedTerm*
                                    MFCFFDihedTerm *ffDTerm = (MFCFFDihedTerm *)ffTerm;
                                    MFCFFParams *temp = new MFCFFParams();
                                    temp->nType = 3;
                                    temp->nTerms = ffDTerm->nTerms;
                                    temp->nParams = ffDTerm->nParams;
                                    // nParams == 2*nTerms , otherwise , wrong!
                                    if (ffDTerm->nParams > 6) {
                                        std::cout << "Out of range in parameter list for torsion\n";
                                    }
                                    for (int i = 0; i < ffDTerm->nTerms; i++) {
                                        temp->paramList[i + i] = ffDTerm->paramList[i + i];
                                        temp->paramList[i + i + 1] = ffDTerm->paramList[i + i + 1];
                                        temp->period[i] = ffDTerm->period[i];
                                    }
                                    ffParams[std::string(buf0)] = temp;
                                    Freqs[std::string(buf0)] = 1;
                                }
                            }
                        }
                    }
                    break;
                case 4:  // Oopl
                    // Atom list: B
                    //            |
                    //            A
                    //          /   \
          //        C       D
                    // i.e. Atom A is the center
                    AtomA = mfcFrag->atomList[ffTerm->atomList[0]];  // Center
                    AtomB = mfcFrag->atomList[ffTerm->atomList[1]];  // Side atom
                    AtomC = mfcFrag->atomList[ffTerm->atomList[2]];  // Side atom
                    AtomD = mfcFrag->atomList[ffTerm->atomList[3]];  // Side atom
                    Bond0 = findBondByAtomPair(AtomA, AtomB);
                    Bond1 = findBondByAtomPair(AtomA, AtomC);
                    Bond2 = findBondByAtomPair(AtomA, AtomD);
                    FFRV[0] = AtomA->RankedValues[0] + xfile->bFactors[Bond0->bondType] +
                              xfile->bFactors[Bond1->bondType] + xfile->bFactors[Bond2->bondType];
                    for (int i = 1; i < 4; i++) {
                        FFRV[i] = AtomA->RankedValues[i] +
                                  xfile->bFactors[Bond0->bondType] * AtomB->RankedValues[i - 1] +
                                  xfile->bFactors[Bond1->bondType] * AtomC->RankedValues[i - 1] +
                                  xfile->bFactors[Bond2->bondType] * AtomD->RankedValues[i - 1];
                    }

                    for (int i = 0; i < 4; i++) {
                        char iden = (char)(i + 97);
                        sprintf(buf0, "%c%15.13f", iden, FFRV[i]);
                        sprintf(bufx, "%c%15.13f", iden, FFRV[i] - 9E-14);
                        sprintf(buf1, "%c%15.13f", iden, FFRV[i] + 9E-14);
                        if (std::string(buf0) == std::string(bufx)) {
                            sprintf(bufx, "%c%15.13f", iden, FFRV[i] - 11E-14);
                        }
                        if (std::string(buf0) == std::string(buf1)) {
                            sprintf(buf1, "%c%15.13f", iden, FFRV[i] + 11E-14);
                        }
                        std::map<std::string, MFCFFParams *>::iterator it;
                        it = ffParams.find(std::string(buf0));
                        if (it != ffParams.end()) {
                            int freq = Freqs.find(std::string(buf0))->second;
                            int nParams = it->second->nParams;
                            double preParam = it->second->paramList[0];
                            double newParam = (preParam * freq + ffTerm->paramList[0]) / (freq + 1);
                            it->second->paramList[0] = newParam;
                            Freqs[std::string(buf0)] = freq + 1;
                        } else {
                            it = ffParams.find(std::string(bufx));
                            if (it != ffParams.end()) {
                                int freq = Freqs.find(std::string(bufx))->second;
                                int nParams = it->second->nParams;
                                double preParam = it->second->paramList[0];
                                double newParam =
                                    (preParam * freq + ffTerm->paramList[0]) / (freq + 1);
                                it->second->paramList[0] = newParam;
                                Freqs[std::string(bufx)] = freq + 1;
                            } else {
                                it = ffParams.find(std::string(buf1));
                                if (it != ffParams.end()) {
                                    int freq = Freqs.find(std::string(buf1))->second;
                                    int nParams = it->second->nParams;
                                    double preParam = it->second->paramList[0];
                                    double newParam =
                                        (preParam * freq + ffTerm->paramList[0]) / (freq + 1);
                                    it->second->paramList[0] = newParam;
                                    Freqs[std::string(buf1)] = freq + 1;
                                } else {
                                    MFCFFParams *temp = new MFCFFParams();
                                    temp->nType = 4;
                                    temp->nTerms = 0;
                                    temp->nParams = 1;
                                    temp->paramList[0] = ffTerm->paramList[0];
                                    ffParams[std::string(buf0)] = temp;
                                    Freqs[std::string(buf0)] = 1;
                                }
                            }
                        }
                    }
                    break;
                case 5:  // Line Bend
                    // Atom list: A-B-C
                    AtomA = mfcFrag->atomList[ffTerm->atomList[0]];  // Left atom
                    AtomB = mfcFrag->atomList[ffTerm->atomList[1]];  // Center atom
                    AtomC = mfcFrag->atomList[ffTerm->atomList[2]];  // Right atom
                    Bond0 = findBondByAtomPair(AtomA, AtomB);        // Left bond
                    Bond1 = findBondByAtomPair(AtomB, AtomC);        // Right bond
                    FFRV[0] = AtomB->RankedValues[0] + xfile->bFactors[Bond0->bondType] +
                              xfile->bFactors[Bond1->bondType];
                    for (int i = 1; i < 4; i++) {
                        FFRV[i] = AtomB->RankedValues[i] +
                                  xfile->bFactors[Bond0->bondType] * AtomA->RankedValues[i - 1] +
                                  xfile->bFactors[Bond1->bondType] * AtomC->RankedValues[i - 1];
                    }

                    for (int i = 0; i < 4; i++) {
                        char iden = (char)(i + 97);
                        sprintf(buf0, "%c%15.13f", iden, FFRV[i]);
                        sprintf(bufx, "%c%15.13f", iden, FFRV[i] - 9E-14);
                        sprintf(buf1, "%c%15.13f", iden, FFRV[i] + 9E-14);
                        if (std::string(buf0) == std::string(bufx)) {
                            sprintf(bufx, "%c%15.13f", iden, FFRV[i] - 11E-14);
                        }
                        if (std::string(buf0) == std::string(buf1)) {
                            sprintf(buf1, "%c%15.13f", iden, FFRV[i] + 11E-14);
                        }
                        std::map<std::string, MFCFFParams *>::iterator it;
                        it = ffParams.find(std::string(buf0));
                        if (it != ffParams.end()) {
                            int freq = Freqs.find(std::string(buf0))->second;
                            int nParams = it->second->nParams;
                            double preParam = it->second->paramList[0];
                            double newParam = (preParam * freq + ffTerm->paramList[0]) / (freq + 1);
                            it->second->paramList[0] = newParam;
                            Freqs[std::string(buf0)] = freq + 1;
                        } else {
                            it = ffParams.find(std::string(bufx));
                            if (it != ffParams.end()) {
                                int freq = Freqs.find(std::string(bufx))->second;
                                int nParams = it->second->nParams;
                                double preParam = it->second->paramList[0];
                                double newParam =
                                    (preParam * freq + ffTerm->paramList[0]) / (freq + 1);
                                it->second->paramList[0] = newParam;
                                Freqs[std::string(bufx)] = freq + 1;
                            } else {
                                it = ffParams.find(std::string(buf1));
                                if (it != ffParams.end()) {
                                    int freq = Freqs.find(std::string(buf1))->second;
                                    int nParams = it->second->nParams;
                                    double preParam = it->second->paramList[0];
                                    double newParam =
                                        (preParam * freq + ffTerm->paramList[0]) / (freq + 1);
                                    it->second->paramList[0] = newParam;
                                    Freqs[std::string(buf1)] = freq + 1;
                                } else {
                                    MFCFFParams *temp = new MFCFFParams();
                                    temp->nType = 5;
                                    temp->nTerms = 0;
                                    temp->nParams = 1;
                                    temp->paramList[0] = ffTerm->paramList[0];
                                    ffParams[std::string(buf0)] = temp;
                                    Freqs[std::string(buf0)] = 1;
                                }
                            }
                        }
                    }
                    break;
                default:
                    // case 6:  VDW, doing nothing, skip
                    // case 7:  ESP, doing nothing, skip
                    // ffTerm->printFFTerms();
                    continue;
            }
        }
    }
    // delete [] bFactors;
}

void setFFByLib(std::map<std::string, MFCFFParams *> &ffParams,
                std::map<std::string, vdwParams *> &vdwP, MFCFFFrag *mfcFFFrag, int rankedLevel) {
    MFCFrag *mfcFrag = mfcFFFrag->getMFCFrag();
    if (mfcFrag == 0) return;
    // check for highest ranking level
    int nAtoms = mfcFrag->numAtoms;
    MFCAtom *mfcAtom;
    mfcAtom = mfcFrag->atomList[0];
    if (mfcAtom->RankedValues.size() < 4) {
        std::cout << "Ranking level less than 4, stop\n";
        exit(0);
    }

    // loop over mfcffterms in MFCFFFrag
    MFCFFTerm *ffTerm;
    std::vector<MFCFFTerm *>::iterator iter = mfcFFFrag->mfcFFTerms.begin();
    std::vector<MFCFFTerm *>::iterator iter_end = mfcFFFrag->mfcFFTerms.end();
    CodingProfile *xfile = CodingProfile::Instance();
    // double eps = xfile->eps;
    MFCAtom *AtomA;
    MFCAtom *AtomB;
    MFCAtom *AtomC;
    MFCAtom *AtomD;
    MFCBond *Bond0;
    MFCBond *Bond1;
    MFCBond *Bond2;
    MFCBond *Bond3;
    int FFType = 0;
    double FFRV[4];
    char buf0[40], bufx[40], buf1[40];
    for (; iter != iter_end; ++iter) {
        if (*iter != 0) {
            ffTerm = *iter;
            FFType = ffTerm->nType;
            switch (FFType) {
                case 1:  // Bond
                    AtomA = mfcFrag->atomList[ffTerm->atomList[0]];
                    AtomB = mfcFrag->atomList[ffTerm->atomList[1]];
                    Bond0 = findBondByAtomPair(AtomA, AtomB);
                    for (int i = rankedLevel - 1; i > -1; i--) {
                        FFRV[i] = AtomA->RankedValues[i] + AtomB->RankedValues[i] +
                                  xfile->bFactors[Bond0->bondType];
                        char iden = (char)(i + 97);
                        sprintf(buf0, "%c%15.13f", iden, FFRV[i]);
                        sprintf(bufx, "%c%15.13f", iden, FFRV[i] - 9E-14);
                        sprintf(buf1, "%c%15.13f", iden, FFRV[i] + 9E-14);
                        if (std::string(buf0) == std::string(bufx)) {
                            sprintf(bufx, "%c%15.13f", iden, FFRV[i] - 11E-14);
                        }
                        if (std::string(buf0) == std::string(buf1)) {
                            sprintf(buf1, "%c%15.13f", iden, FFRV[i] + 11E-14);
                        }
                        std::map<std::string, MFCFFParams *>::iterator it;
                        it = ffParams.find(std::string(buf0));
                        if (it != ffParams.end()) {
                            int nParams1 = it->second->nParams;
                            int nParams2 = ffTerm->nParams;
                            if (nParams1 != nParams2) {
                                std::cout << "read BondTerm Params error, nParams are not equal\n";
                                exit(0);
                            }
                            for (int i = 0; i < nParams1; i++) {
                                ffTerm->paramList[i] = it->second->paramList[i];
                            }
                            break;
                        } else {
                            it = ffParams.find(std::string(bufx));
                            if (it != ffParams.end()) {
                                int nParams1 = it->second->nParams;
                                int nParams2 = ffTerm->nParams;
                                if (nParams1 != nParams2) {
                                    std::cout
                                        << "read BondTerm Params error, nParams are not equal\n";
                                    exit(0);
                                }
                                for (int i = 0; i < nParams1; i++) {
                                    ffTerm->paramList[i] = it->second->paramList[i];
                                }
                                break;
                            } else {
                                it = ffParams.find(std::string(buf1));
                                if (it != ffParams.end()) {
                                    int nParams1 = it->second->nParams;
                                    int nParams2 = ffTerm->nParams;
                                    if (nParams1 != nParams2) {
                                        std::cout << "read BondTerm Params error, nParams are not "
                                                     "equal\n";
                                        exit(0);
                                    }
                                    for (int i = 0; i < nParams1; i++) {
                                        ffTerm->paramList[i] = it->second->paramList[i];
                                    }
                                    break;
                                }
                            }
                        }
                    }
                    break;
                case 2:                                              // Angel
                    AtomA = mfcFrag->atomList[ffTerm->atomList[0]];  // Left atom0
                    AtomB = mfcFrag->atomList[ffTerm->atomList[1]];  // Cent atom1
                    AtomC = mfcFrag->atomList[ffTerm->atomList[2]];  // Rigt atom2
                    Bond0 = findBondByAtomPair(AtomA, AtomB);
                    Bond1 = findBondByAtomPair(AtomB, AtomC);
                    FFRV[0] = AtomB->RankedValues[0] + xfile->bFactors[Bond0->bondType] +
                              xfile->bFactors[Bond1->bondType];

                    for (int i = 1; i < 4; i++) {
                        FFRV[i] = AtomB->RankedValues[i] +
                                  xfile->bFactors[Bond0->bondType] * AtomA->RankedValues[i - 1] +
                                  xfile->bFactors[Bond1->bondType] * AtomC->RankedValues[i - 1];
                    }

                    for (int i = rankedLevel - 1; i > -1; i--) {
                        char iden = (char)(i + 97);
                        sprintf(buf0, "%c%15.13f", iden, FFRV[i]);
                        sprintf(bufx, "%c%15.13f", iden, FFRV[i] - 9E-14);
                        sprintf(buf1, "%c%15.13f", iden, FFRV[i] + 9E-14);
                        if (std::string(buf0) == std::string(bufx)) {
                            sprintf(bufx, "%c%15.13f", iden, FFRV[i] - 11E-14);
                        }
                        if (std::string(buf0) == std::string(buf1)) {
                            sprintf(buf1, "%c%15.13f", iden, FFRV[i] + 11E-14);
                        }
                        std::map<std::string, MFCFFParams *>::iterator it;
                        it = ffParams.find(std::string(buf0));
                        if (it != ffParams.end()) {
                            int nParams1 = it->second->nParams;
                            int nParams2 = ffTerm->nParams;
                            if (nParams1 != nParams2) {
                                std::cout << "read AngelTerm Params error, nParams are not equal\n";
                                exit(0);
                            }
                            for (int i = 0; i < nParams1; i++) {
                                ffTerm->paramList[i] = it->second->paramList[i];
                            }
                            break;
                        } else {
                            it = ffParams.find(std::string(bufx));
                            if (it != ffParams.end()) {
                                int nParams1 = it->second->nParams;
                                int nParams2 = ffTerm->nParams;
                                if (nParams1 != nParams2) {
                                    std::cout
                                        << "read AngelTerm Params error, nParams are not equal\n";
                                    exit(0);
                                }
                                for (int i = 0; i < nParams1; i++) {
                                    ffTerm->paramList[i] = it->second->paramList[i];
                                }
                                break;
                            } else {
                                it = ffParams.find(std::string(buf1));
                                if (it != ffParams.end()) {
                                    int nParams1 = it->second->nParams;
                                    int nParams2 = ffTerm->nParams;
                                    if (nParams1 != nParams2) {
                                        std::cout << "read AngelTerm Params error, nParams are not "
                                                     "equal\n";
                                        exit(0);
                                    }
                                    for (int i = 0; i < nParams1; i++) {
                                        ffTerm->paramList[i] = it->second->paramList[i];
                                    }
                                    break;
                                }
                            }
                        }
                    }
                    break;
                case 3:  // torsion
                {
                    MFCFFDihedTerm *ffDihedTerm = (MFCFFDihedTerm *)ffTerm;
                    // Atom list: A-B-C-D, i.e. atom B and C are center atoms
                    AtomA = mfcFrag->atomList[ffTerm->atomList[0]];  // Left side atom
                    AtomB = mfcFrag->atomList[ffTerm->atomList[1]];  // Left atom
                    AtomC = mfcFrag->atomList[ffTerm->atomList[2]];  // Right atom
                    AtomD = mfcFrag->atomList[ffTerm->atomList[3]];  // Right side atom
                    Bond0 = findBondByAtomPair(AtomA, AtomB);        // Left bond
                    Bond1 = findBondByAtomPair(AtomB, AtomC);        // Center bond
                    Bond2 = findBondByAtomPair(AtomC, AtomD);        // Right bond
                    FFRV[0] = AtomB->RankedValues[0] * AtomC->RankedValues[0] *
                                  xfile->bFactors[Bond1->bondType] +
                              xfile->bFactors[Bond0->bondType] + xfile->bFactors[Bond1->bondType];
                    for (int i = 1; i < rankedLevel; i++) {
                        FFRV[i] = AtomB->RankedValues[i] * AtomC->RankedValues[i] *
                                      xfile->bFactors[Bond1->bondType] +
                                  xfile->bFactors[Bond0->bondType] * AtomA->RankedValues[i - 1] +
                                  xfile->bFactors[Bond2->bondType] * AtomD->RankedValues[i - 1];
                    }
                    for (int i = rankedLevel - 1; i > -1; i--) {
                        char iden = (char)(i + 97);
                        sprintf(buf0, "%c%15.13f", iden, FFRV[i]);
                        sprintf(bufx, "%c%15.13f", iden, FFRV[i] - 9E-14);
                        sprintf(buf1, "%c%15.13f", iden, FFRV[i] + 9E-14);
                        if (std::string(buf0) == std::string(bufx)) {
                            sprintf(bufx, "%c%15.13f", iden, FFRV[i] - 11E-14);
                        }
                        if (std::string(buf0) == std::string(buf1)) {
                            sprintf(buf1, "%c%15.13f", iden, FFRV[i] + 11E-14);
                        }
                        std::map<std::string, MFCFFParams *>::iterator it;
                        it = ffParams.find(std::string(buf0));
                        if (it != ffParams.end()) {
                            int nParams = it->second->nParams;
                            int nTerms = it->second->nTerms;
                            if (nParams != 2 * nTerms) {
                                std::cout << "read DihedTerm Params error, nParams != 2*nTerms"
                                          << nParams << " nTerms = " << nTerms << "\n";
                                exit(0);
                            }
                            if (nParams > 6) {
                                std::cout << "Out of range in parameter list for torsion\n";
                            }
                            ffDihedTerm->nParams = nParams;
                            ffDihedTerm->nTerms = nTerms;
                            for (int i = 0; i < nTerms; i++) {
                                ffDihedTerm->period[i] = it->second->period[i];
                                ffDihedTerm->paramList[i + i + 0] =
                                    it->second->paramList[i + i + 0];
                                ffDihedTerm->paramList[i + i + 1] =
                                    it->second->paramList[i + i + 1];
                            }
                            break;
                        } else {
                            it = ffParams.find(std::string(bufx));
                            if (it != ffParams.end()) {
                                int nParams = it->second->nParams;
                                int nTerms = it->second->nTerms;
                                if (nParams != 2 * nTerms) {
                                    std::cout
                                        << "B read DihedTerm Params error, nParams != 2*nTerms"
                                        << nParams << " nTerms = " << nTerms << "\n";
                                    exit(0);
                                }
                                if (nParams > 6) {
                                    std::cout << "Out of range in parameter list for torsion\n";
                                }
                                ffDihedTerm->nParams = nParams;
                                ffDihedTerm->nTerms = nTerms;
                                for (int i = 0; i < nTerms; i++) {
                                    ffDihedTerm->period[i] = it->second->period[i];
                                    ffDihedTerm->paramList[i + i + 0] =
                                        it->second->paramList[i + i + 0];
                                    ffDihedTerm->paramList[i + i + 1] =
                                        it->second->paramList[i + i + 1];
                                }
                                break;
                            } else {
                                it = ffParams.find(std::string(buf1));
                                if (it != ffParams.end()) {
                                    int nParams = it->second->nParams;
                                    int nTerms = it->second->nTerms;
                                    if (nParams != 2 * nTerms) {
                                        std::cout
                                            << "C read DihedTerm Params error, nParams != 2*nTerms "
                                            << nParams << " " << nTerms << "\n";
                                        exit(0);
                                    }
                                    if (nParams > 6) {
                                        std::cout << "Out of range in parameter list for torsion\n";
                                    }
                                    ffDihedTerm->nTerms = nTerms;
                                    ffDihedTerm->nParams = nTerms * 2;
                                    for (int i = 0; i < nTerms; i++) {
                                        ffDihedTerm->period[i] = it->second->period[i];
                                        ffDihedTerm->paramList[i + i + 0] =
                                            it->second->paramList[i + i + 0];
                                        ffDihedTerm->paramList[i + i + 1] =
                                            it->second->paramList[i + i + 1];
                                    }
                                    break;
                                }
                            }
                        }
                    }
                    break;
                }
                case 4:  // Oopl
                    // Atom list: B
                    //            |
                    //            A
                    //          /   \
          //        C       D
                    // i.e. Atom A is the center
                    AtomA = mfcFrag->atomList[ffTerm->atomList[0]];  // Center
                    AtomB = mfcFrag->atomList[ffTerm->atomList[1]];  // Side atom
                    AtomC = mfcFrag->atomList[ffTerm->atomList[2]];  // Side atom
                    AtomD = mfcFrag->atomList[ffTerm->atomList[3]];  // Side atom
                    Bond0 = findBondByAtomPair(AtomA, AtomB);
                    Bond1 = findBondByAtomPair(AtomA, AtomC);
                    Bond2 = findBondByAtomPair(AtomA, AtomD);
                    FFRV[0] = AtomA->RankedValues[0] + xfile->bFactors[Bond0->bondType] +
                              xfile->bFactors[Bond1->bondType] + xfile->bFactors[Bond2->bondType];
                    for (int i = 1; i < rankedLevel; i++) {
                        FFRV[i] = AtomA->RankedValues[i] +
                                  xfile->bFactors[Bond0->bondType] * AtomB->RankedValues[i - 1] +
                                  xfile->bFactors[Bond1->bondType] * AtomC->RankedValues[i - 1] +
                                  xfile->bFactors[Bond2->bondType] * AtomD->RankedValues[i - 1];
                    }
                    for (int i = rankedLevel - 1; i > -1; i--) {
                        char iden = (char)(i + 97);
                        sprintf(buf0, "%c%15.13f", iden, FFRV[i]);
                        sprintf(bufx, "%c%15.13f", iden, FFRV[i] - 9E-14);
                        sprintf(buf1, "%c%15.13f", iden, FFRV[i] + 9E-14);
                        if (std::string(buf0) == std::string(bufx)) {
                            sprintf(bufx, "%c%15.13f", iden, FFRV[i] - 11E-14);
                        }
                        if (std::string(buf0) == std::string(buf1)) {
                            sprintf(buf1, "%c%15.13f", iden, FFRV[i] + 11E-14);
                        }
                        std::map<std::string, MFCFFParams *>::iterator it;
                        it = ffParams.find(std::string(buf0));
                        if (it != ffParams.end()) {
                            int nParams1 = it->second->nParams;
                            int nParams2 = ffTerm->nParams;
                            if (nParams1 != nParams2) {
                                std::cout << "read OoplTerm Params error, nParams are not equal\n";
                                std::cout << "nType = " << it->second->nType << "\n";
                                std::cout << "nPA1, nPA2 = " << nParams1 << " " << nParams2 << "\n";
                                std::cout << "buf0 = " << buf0 << "\n";
                                std::cout << "i = " << i + 1 << "\n";
                                exit(0);
                            }
                            for (int i = 0; i < nParams1; i++) {
                                ffTerm->paramList[i] = it->second->paramList[i];
                            }
                            break;
                        } else {
                            it = ffParams.find(std::string(bufx));
                            if (it != ffParams.end()) {
                                int nParams1 = it->second->nParams;
                                int nParams2 = ffTerm->nParams;
                                if (nParams1 != nParams2) {
                                    std::cout
                                        << "read OoplTerm Params error, nParams are not equal\n";
                                    std::cout << "nType = " << it->second->nType << "\n";
                                    std::cout << "B nPA1, nPA2 = " << nParams1 << " " << nParams2
                                              << "\n";
                                    exit(0);
                                }
                                for (int i = 0; i < nParams1; i++) {
                                    ffTerm->paramList[i] = it->second->paramList[i];
                                }
                                break;
                            } else {
                                it = ffParams.find(std::string(buf1));
                                if (it != ffParams.end()) {
                                    int nParams1 = it->second->nParams;
                                    int nParams2 = ffTerm->nParams;
                                    if (nParams1 != nParams2) {
                                        std::cout << "read OoplTerm Params error, nParams are not "
                                                     "equal\n";
                                        std::cout << "nType = " << it->second->nType << "\n";
                                        std::cout << "C nPA1, nPA2 = " << nParams1 << " "
                                                  << nParams2 << "\n";
                                        exit(0);
                                    }
                                    for (int i = 0; i < nParams1; i++) {
                                        ffTerm->paramList[i] = it->second->paramList[i];
                                    }
                                    break;
                                }
                            }
                        }
                    }
                    break;
                case 5:  // Line bend
                    // Atom list: A-B-C
                    AtomA = mfcFrag->atomList[ffTerm->atomList[0]];  // Left atom
                    AtomB = mfcFrag->atomList[ffTerm->atomList[1]];  // Center atom
                    AtomC = mfcFrag->atomList[ffTerm->atomList[2]];  // Right atom
                    Bond0 = findBondByAtomPair(AtomA, AtomB);        // Left bond
                    Bond1 = findBondByAtomPair(AtomB, AtomC);        // Right bond
                    FFRV[0] = AtomB->RankedValues[0] + xfile->bFactors[Bond0->bondType] +
                              xfile->bFactors[Bond1->bondType];
                    for (int i = 1; i < rankedLevel; i++) {
                        FFRV[i] = AtomB->RankedValues[i] +
                                  xfile->bFactors[Bond0->bondType] * AtomA->RankedValues[i - 1] +
                                  xfile->bFactors[Bond1->bondType] * AtomC->RankedValues[i - 1];
                    }
                    for (int i = rankedLevel - 1; i > -1; i--) {
                        char iden = (char)(i + 97);
                        sprintf(buf0, "%c%15.13f", iden, FFRV[i]);
                        sprintf(bufx, "%c%15.13f", iden, FFRV[i] - 9E-14);
                        sprintf(buf1, "%c%15.13f", iden, FFRV[i] + 9E-14);
                        if (std::string(buf0) == std::string(bufx)) {
                            sprintf(bufx, "%c%15.13f", iden, FFRV[i] - 11E-14);
                        }
                        if (std::string(buf0) == std::string(buf1)) {
                            sprintf(buf1, "%c%15.13f", iden, FFRV[i] + 11E-14);
                        }
                        std::map<std::string, MFCFFParams *>::iterator it;
                        it = ffParams.find(std::string(buf0));
                        if (it != ffParams.end()) {
                            int nParams1 = it->second->nParams;
                            int nParams2 = ffTerm->nParams;
                            if (nParams1 != nParams2) {
                                std::cout
                                    << "read LindBendTerm Params error, nParams are not equal\n";
                                printf("nParams in map/ffTerm: %d/%d ID:%s\n", nParams1, nParams2,
                                       buf0);
                                printf("nType in map/ffTerm: %d/%d \n", it->second->nType,
                                       ffTerm->nType);
                                exit(0);
                            }
                            for (int i = 0; i < nParams1; i++) {
                                ffTerm->paramList[i] = it->second->paramList[i];
                            }
                            break;
                        } else {
                            it = ffParams.find(std::string(bufx));
                            if (it != ffParams.end()) {
                                int nParams1 = it->second->nParams;
                                int nParams2 = ffTerm->nParams;
                                if (nParams1 != nParams2) {
                                    std::cout << "read LindBendTerm Params error, nParams are not "
                                                 "equal\n";
                                    printf("nParams in map/ffTerm: %d/%d ID:%s\n", nParams1,
                                           nParams2, bufx);
                                    printf("nType in map/ffTerm: %d/%d \n", it->second->nType,
                                           ffTerm->nType);
                                    exit(0);
                                }
                                for (int i = 0; i < nParams1; i++) {
                                    ffTerm->paramList[i] = it->second->paramList[i];
                                }
                                break;
                            } else {
                                it = ffParams.find(std::string(buf1));
                                if (it != ffParams.end()) {
                                    int nParams1 = it->second->nParams;
                                    int nParams2 = ffTerm->nParams;
                                    if (nParams1 != nParams2) {
                                        std::cout << "read LindBendTerm Params error, nParams are "
                                                     "not equal\n";
                                        printf("nParams in map/ffTerm: %d/%d ID:%s\n", nParams1,
                                               nParams2, buf1);
                                        printf("nType in map/ffTerm: %d/%d \n", it->second->nType,
                                               ffTerm->nType);
                                        exit(0);
                                    }
                                    for (int i = 0; i < nParams1; i++) {
                                        ffTerm->paramList[i] = it->second->paramList[i];
                                    }
                                    break;
                                }
                            }
                        }
                    }
                    break;
                case 6:  // VDW
                {
                    MFCFFVDWTerm *vdwTerm = (MFCFFVDWTerm *)ffTerm;
                    for (int i = 0; i < nAtoms; i++) {
                        mfcAtom = mfcFrag->atomList[i];
                        // set VDW parameters(R,E) for each atom
                        setVDWParamsForAtom(mfcAtom, vdwP, rankedLevel);
                        // refresh radius and wellDepth of vdwTerm
                        vdwTerm->radius[i] = mfcAtom->vdwR;
                        vdwTerm->wellDepth[i] = mfcAtom->vdwE;
                    }
                    // use new radius and wellDepth to calculate eMin and rMin of each VDW pair
                    vdwTerm->ResetVDWTerms();
                    printf("ResetVDWTerms\n");
                    break;
                }
                default:

                    continue;
            }
        }
    }
}

}  // namespace MISS
