#ifndef mfcFF_h
#define mfcFF_h
/******************************************************************************
 * Principal function:                                                         *
 *    Force Field, Minimization
 *                                                                             *
 * Usage:                                                                      *
 *
 * Author:                                                                     *
 *    James Li     June 2011
 *                                                                             *
 *******************************************************************************
 *                                                                             *
 * Copyright (C) 2011 SciNet Technologies
 *                                                                             *
 ******************************************************************************/
#include <fstream>
#include <functional>
#include <string>
#include <vector>

#include "Misc/fragment2D.h"
#include "Misc/fragment3D.h"
#include "MolStructure/mfcAtom.h"
#include "MolStructure/mfcBond.h"
#include "Singleton/params.h"
#include "Topology/topology.h"
#include "Utils/mfcUtil.hpp"
#include "ffUtil.h"

namespace MISS {

class MFCFFTerm {
public:
    MFCFFTerm();
    MFCFFTerm(int type, int natoms, int nparams, int *atoms, double *params);
    virtual ~MFCFFTerm();
    virtual double ComputeEnergy(double *crds);
    virtual double ComputeEnergyGrads(double *crds, double *crdGrads);
    virtual void printFFTerms();

    int nType;
    int nAtoms;
    int nParams;
    int atomList[4];
    double paramList[6];
};

struct MFCFFParams {
    int nType;
    int nParams;
    int nTerms;  // Maximum 3 terms.
    int period[3];
    int Freqs;
    double paramList[6];
};

class MFCFFBondTerm : public MFCFFTerm {
public:
    MFCFFBondTerm();
    MFCFFBondTerm(int atom1, int atom2, double fconst, double length0);
    ~MFCFFBondTerm();
    double ComputeEnergy(double *crds);
    double ComputeEnergyGrads(double *crds, double *crdGrads);
    void printFFTerms();
};

class MFCFFAngleTerm : public MFCFFTerm {
public:
    MFCFFAngleTerm();
    MFCFFAngleTerm(int atom1, int atom2, int atom3, double fconst, double angle0);
    ~MFCFFAngleTerm();
    double ComputeEnergy(double *crds);
    double ComputeEnergyGrads(double *crds, double *crdGrads);
    void printFFTerms();
};

class MFCFFDihedTerm : public MFCFFTerm {
public:
    MFCFFDihedTerm();
    MFCFFDihedTerm(int atom1, int atom2, int atom3, int atom4, double fconst, double phase0,
                   int Period);
    ~MFCFFDihedTerm();
    double ComputeEnergy(double *crds);
    double ComputeEnergyGrads(double *crds, double *crdGrads);
    void printFFTerms();

    int nTerms;
    int period[3];
};

class MFCFFLineBendTerm : public MFCFFTerm {
public:
    MFCFFLineBendTerm();
    MFCFFLineBendTerm(int atom1, int atom2, int atom3, double fconst);
    ~MFCFFLineBendTerm();
    double ComputeEnergy(double *crds);
    double ComputeEnergyGrads(double *crds, double *crdGrads);
    void printFFTerms();
};

class MFCFFOoplTerm : public MFCFFTerm {
public:
    MFCFFOoplTerm();
    MFCFFOoplTerm(int atom1, int atom2, int atom3, int atom4, double fconst);
    ~MFCFFOoplTerm();
    double ComputeEnergy(double *crds);
    double ComputeEnergyGrads(double *crds, double *crdGrads);
    void printFFTerms();
};

class MFCFFEspTerm : public MFCFFTerm {
public:
    MFCFFEspTerm();
    MFCFFEspTerm(int natoms);
    MFCFFEspTerm(int natoms, double *chrges);
    MFCFFEspTerm(MFCFrag *mfcFrag);
    ~MFCFFEspTerm();
    double ComputeEnergy(double *crds);
    double ComputeEnergyGrads(double *crds, double *crdGrads);
    void printFFTerms();
    double *charges;
    int nEspPairs;
    std::vector<int> EspPairs;
};

class MFCFFVDWTerm : public MFCFFTerm {
public:
    MFCFFVDWTerm();
    MFCFFVDWTerm(int natoms, double *r, double *wd);
    MFCFFVDWTerm(MFCFrag *mfcFrag);
    ~MFCFFVDWTerm();
    double ComputeEnergy(double *crds);
    double ComputeEnergyGrads(double *crds, double *crdGrads);
    double ComputeEnergyGrads();
    void printFFTerms();
    void ResetVDWTerms();
    int updateVDWPairs(MFCFrag *mfcFrag, double *crds);
    int nVDWPairs;
    std::vector<int> vdwPairs;
    double *radius;
    double *wellDepth;
    double *rMin;
    double *eMin;
};

class MFCFFFrag {
public:
    MFCFFFrag();
    MFCFFFrag(MFCFrag *mfcFrag);
    ~MFCFFFrag();
    int nAtoms;
    std::vector<MFCFFTerm *> mfcFFTerms;
    double computeEnergy();
    double computeEnergy(double *crds);
    double computeEnergyGrads(double *crds, double *crdGrads);
    double computeEnergyGrads();
    double optimizeGeom(int maxIter = 0);
    double lineMinimizer(double step, double eStart, double *direction);

    void printFFTerms();
    void printCrdsAndGrads();
    void updateCoordinates(int natoms, double *crd);
    void initFF(char *fflibname);

    template<typename iFileLikeSteam>
    void initFF(iFileLikeSteam &fin);
    MFCFrag *getMFCFrag();
    double *getCrds();

    // Util for debug
    MFCFFTerm *findFFTerm(int nType, int atom1, int atom2, int atom3, int atom4);

private:
    // Active coordinates and associated gradients
    double *crds;
    double *crdGrads;
    MFCFrag *ownerFrag;
};

struct vdwParams {
    double vdwR;
    double vdwE;
};

void writeFFParamsMapToFile(char *fn, std::map<std::string, MFCFFParams *> &ffParams);

void readFFParamsMapFromFile(char *fn, std::map<std::string, MFCFFParams *> &ffParams);

void writeVDWParamsMapToFile(char *fn, std::map<std::string, vdwParams *> &vdmP);
void readVDWParamsMapFromFile(char *fn, std::map<std::string, vdwParams *> &vdwP);

int findNeighborPairs(MFCFrag *mfcFrag, double R, double *crd, std::vector<int> &Pairs);

int findNeighborPairs(MFCFrag *mfcFrag, double R, std::vector<int> &Pairs);

MFCFFFrag *MFCFragToMFCFFFrag(MFCFrag *mfcFrag);

vdwParams *findVDWParams(std::string s, std::map<std::string, vdwParams *> &vdwP);
void collectVDWParams(MFCFFFrag *mfcFFFrag, std::map<std::string, vdwParams *> &vdwP,
                      std::map<std::string, int> &vdwFreqs, int rankedLevel);
void setVDWParamsForAtom(MFCAtom *mfcAtom, std::map<std::string, vdwParams *> &vdwP,
                         int rankedLevel);
void collectFFParams(MFCFFFrag *mfcFFFrag, std::map<std::string, MFCFFParams *> &ffParams,
                     std::map<std::string, int> &Freqs, int rankedLevel);

void setFFByLib(std::map<std::string, MFCFFParams *> &ffParams,
                std::map<std::string, vdwParams *> &vdwP, MFCFFFrag *mfcFFFrag, int rankedLevel);
}  // namespace MISS

#endif /* mfcFF_h */
