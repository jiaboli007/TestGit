//
// Created by xiamr on 9/1/20.
//
#include "config.hpp"

#include <algorithm>
#include <cassert>
#include <iostream>

#include <boost/range/algorithm.hpp>
#include <boost/range/irange.hpp>
#include <boost/range/numeric.hpp>

#include "GPUEngine.hpp"

using namespace MISS;

void GPUEngineImpl::copy_query(const QueryInfo &q, const float *WF) {
    // max query atoms: 100
    float h_ux[4 * MAX_QUERY_ATOM_NUMBER];
    float h_uy[4 * MAX_QUERY_ATOM_NUMBER];
    float h_uz[4 * MAX_QUERY_ATOM_NUMBER];
    float h_ufeatx[4 * MAX_QUERY_FEATURE_NUMBER];
    float h_ufeaty[4 * MAX_QUERY_FEATURE_NUMBER];
    float h_ufeatz[4 * MAX_QUERY_FEATURE_NUMBER];

    auto totalqNumFAtoms = boost::accumulate(q.numFeat, 0, std::plus{});

    if (q.nAtoms > MAX_QUERY_ATOM_NUMBER) {
        std::cerr << "error! number of query atoms > " << MAX_QUERY_ATOM_NUMBER << " !\n";
        std::exit(EXIT_FAILURE);
    }

    if (totalqNumFAtoms > MAX_QUERY_FEATURE_NUMBER) {
        std::cerr << "error! number of query feature atoms > " << MAX_QUERY_FEATURE_NUMBER
                  << " !\n";
        std::exit(EXIT_FAILURE);
    }

    for (int i = 0; i < totalqNumFAtoms; i++) {
        h_ufeatx[i] = q.featXYZ[i][0];
        h_ufeaty[i] = q.featXYZ[i][1];
        h_ufeatz[i] = q.featXYZ[i][2];

        // -x -y
        auto j = totalqNumFAtoms + i;
        h_ufeatx[j] = -q.featXYZ[i][0];
        h_ufeaty[j] = -q.featXYZ[i][1];
        h_ufeatz[j] = q.featXYZ[i][2];

        // -x -z
        j += totalqNumFAtoms;
        h_ufeatx[j] = -q.featXYZ[i][0];
        h_ufeaty[j] = q.featXYZ[i][1];
        h_ufeatz[j] = -q.featXYZ[i][2];

        // -y -z
        j += totalqNumFAtoms;
        h_ufeatx[j] = q.featXYZ[i][0];
        h_ufeaty[j] = -q.featXYZ[i][1];
        h_ufeatz[j] = -q.featXYZ[i][2];
    }

    for (int i = 0; i < q.nAtoms; i++) {
        h_ux[i] = q.xyz[i][0];
        h_uy[i] = q.xyz[i][1];
        h_uz[i] = q.xyz[i][2];

        //-x,-y
        auto j = q.nAtoms + i;
        h_ux[j] = -q.xyz[i][0];
        h_uy[j] = -q.xyz[i][1];
        h_uz[j] = q.xyz[i][2];

        //-x,-z
        j += q.nAtoms;
        h_ux[j] = -q.xyz[i][0];
        h_uy[j] = q.xyz[i][1];
        h_uz[j] = -q.xyz[i][2];

        //-y,-z
        j += q.nAtoms;
        h_ux[j] = q.xyz[i][0];
        h_uy[j] = -q.xyz[i][1];
        h_uz[j] = -q.xyz[i][2];
    }

    int h_ii[10];
    h_ii[0] = 0;
    h_ii[1] = 6;
    h_ii[2] = 11;
    h_ii[3] = 15;
    h_ii[4] = 18;
    h_ii[5] = 20;
    h_ii[6] = q.nAtoms;
    h_ii[7] = nMol;
    h_ii[8] = totalqNumFAtoms;
    h_ii[9] = 0;

    //    float h_selfVol[nMol * 10];
    //    for (int i = 0; i < nMol; i++) {
    //        for (int j = 0; j < 10; j++) {
    //            h_selfVol[i * 10 + j] = db.selfVol[i * 10 + j] + [j];
    //        }
    //    }

    // query data to constant memory
    std::cout << "Copy query data to GPU constant memory\n";
    copy_query_to_device(h_ii, h_ux, h_uy, h_uz, q.weight.data(), h_ufeatx, h_ufeaty, h_ufeatz,
                         q.numFeat.data(), WF, q.selfVol.data());
}
