//
// Created by xiamr on 9/1/20.
//

#ifndef ALPHACS_GPUENGINE_HPP
#define ALPHACS_GPUENGINE_HPP

#include <vector>

#include "IO/Database.hpp"
#include "IO/QueryInfo.hpp"
#include "Utils/cuda_utility.hpp"

namespace MISS {
// wrapper_comb_outPharma

class GPUEngineImpl {
public:
    void query(const QueryInfo &q, const float *WF, float *simi) {
        copy_query(q, WF);
        run_one_batch(simi);
    }

    virtual ~GPUEngineImpl() = default;

    GPUEngineImpl(const GPUEngineImpl &) = delete;
    GPUEngineImpl &operator=(const GPUEngineImpl &) = delete;
    GPUEngineImpl(GPUEngineImpl &&) = delete;
    GPUEngineImpl &operator=(GPUEngineImpl &&) = delete;

    struct StreamData {
        int xyz_size;
        int w_size;
        int f_size;
        int fw_size;

        // page-locked host memory
        float *xyz{};
        float *w{};
        int *maxNAtomPGrp{};
        int *wStartIdxGrp{};
        float *fxyz{};
        float *wFAtom{};
        int *maxNAtomPerFGrp{};
        int *fwStartIdxGrp{};
        float *selfVol{};

        ~StreamData() {
            gpuErrChk(cudaFreeHost((void *)xyz));
            gpuErrChk(cudaFreeHost((void *)w));
            gpuErrChk(cudaFreeHost((void *)maxNAtomPGrp));
            gpuErrChk(cudaFreeHost((void *)wStartIdxGrp));
            gpuErrChk(cudaFreeHost((void *)fxyz));
            gpuErrChk(cudaFreeHost((void *)wFAtom));
            gpuErrChk(cudaFreeHost((void *)maxNAtomPerFGrp));
            gpuErrChk(cudaFreeHost((void *)fwStartIdxGrp));
            gpuErrChk(cudaFreeHost((void *)selfVol));
        }
    };

protected:
    friend class GPUEngine;
    GPUEngineImpl(const Database &db) : db(db) {}
    StreamData init_databases();

    void release_GPU_memory();

    void copy_query(const QueryInfo &q, const float *WF);

    virtual void copy_db_to_device(int xyz_size, int w_size, int f_size, int fw_size, float *xyz,
                                   float *w, int *maxNAtomPGrp, int *wStartIdxGrp, float *fxyz,
                                   float *wFAtom, int *maxNAtomPerFGrp, int *fwStartIdxGrp,
                                   const float *selfVol);

    virtual void copy_query_to_device(int *h_ii, float *h_ux, float *h_uy, float *h_uz,
                                      const float *qweight, float *h_ufeatx, float *h_ufeaty,
                                      float *h_ufeatz, const int *qnumFeat, const float *WF,
                                      const float *qselfVol);

    void copy_db_to_device(StreamData &stream_data) {
        copy_db_to_device(stream_data.xyz_size, stream_data.w_size, stream_data.f_size,
                          stream_data.fw_size, stream_data.xyz, stream_data.w,
                          stream_data.maxNAtomPGrp, stream_data.wStartIdxGrp, stream_data.fxyz,
                          stream_data.wFAtom, stream_data.maxNAtomPerFGrp,
                          stream_data.fwStartIdxGrp, stream_data.selfVol);
    };

    void run_one_batch(float *simi);

    const Database &db;

    float *d_simi;
    float *d_xyz;
    float *d_weight;
    float *d_selfVol;
    float *d_fxyz;
    float *d_wFAtom;
    int *d_maxAtomPerGrp;
    int *d_wStartIdxGrp;
    int *d_maxNAtomPerFGrp;
    int *d_fwStartIdxGrp;

    int nGrp;
    int nMol;

    int res_size;
};

class GPUEngine final {
public:
    GPUEngine(const Database &db) : gpu(db), stream_data(gpu.init_databases()) {}
    ~GPUEngine() { gpu.release_GPU_memory(); }

    void copy_db_to_device() { gpu.copy_db_to_device(stream_data); }

    void query(const QueryInfo &q, const float *WF, float *simi) {
        gpu.copy_query(q, WF);
        gpu.run_one_batch(simi);
    }

private:
    GPUEngineImpl gpu;

    GPUEngineImpl::StreamData stream_data;
};

}  // namespace MISS
#endif  // ALPHACS_GPUENGINE_HPP
