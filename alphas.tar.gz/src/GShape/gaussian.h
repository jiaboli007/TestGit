#ifndef gaussian_h
#define gaussian_h
#include "Misc/fragment2D.h"

namespace MISS {

void TransRot(double xyz0[3], double t[3], double r[3][3], double xyz1[3]);
void RotTrans(double xyz0[3], double t[3], double r[3][3], double xyz1[3]);
void Euler2Matrices(double alpha, double beta, double gama, double R[3][3], double DRA[3][3],
                    double DRB[3][3], double DRG[3][3], double DDRAB[3][3], double DDRAG[3][3],
                    double DDRBG[3][3], double DDRAA[3][3], double DDRBB[3][3], double DDRGG[3][3]);
//
// n: number of overlapping Guassian
// aList: indexes of the atom list of the Guassians
// xyz: coordinates of the whole molecule
// rn: coordiates of the coalesense center of the overlapping Guassians
// vn: overlapping volume
// vdwR: van der Waals radii
// pix: p(i)
// dltn: delta-n
// atomSA: return value
//
void calSA(int n, int* aList, double vn, double* xyz, double* rn, double* vdwR, double* pix,
           double dltn, double* atomSA);
void calDerivatives(int n, int* aList, double vn, double* xyz, double* rn, double* alpha,
                    double dltn, double* cderv, double* chess, int na1);
double calCrossVolume(int na1, int na2, double* xyz, double* vdwR, int grank);
double calMolVolume(int numAtoms, double* xyz, double* vdwR, int overlay, int na1, int grank,
                    double* cderv, double* chess);
double molVolume(MFCFrag* Frag, int grank);
double LSolver6(double hess[6][6], double der6[6], double dx[6]);
double SAA(MFCFrag* Frag1, int grank);
double overlayMol(MFCFrag* Frag1, MFCFrag* Frag2, int grank);

}  // namespace MISS

#endif /* shape_h */
