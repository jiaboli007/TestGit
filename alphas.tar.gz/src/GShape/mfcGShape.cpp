/******************************************************************************
 * Principal function:                                                         *
 *    Molecule shape overlay: Hard Sphere Model, Gaussian Sphere Model, flexible
 * 			     overlay
 *                                                                             *
 * Usage:
 *
 * Authors:                                                                    *
 *    James Li, SciNet Technologies, May 2012
 *    Xin Yan, May 2012
 *
 *                                                                             *
 ******************************************************************************/
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <sstream>

#include <math.h>
#include <time.h>

#include "mfcGShape.hpp"

#include "Misc/ssdUtil.h"
#include "MolStructure/mfcAtom.h"
#include "MolStructure/mfcMolecule.h"
#include "Singleton/params.h"
#include "Topology/chemgraph.h"
#include "Utils/mathUtil.hpp"
#include "Utils/mfcUtil.hpp"
namespace MISS {

static double gParam = 2.8284;

void test_overlay();
double overlay_hack(int NA1, double* xyz1, double* alpha1, double* w1, int NA2,
                                  double* xyz2, double* alpha2, double* w2, int nFeat1,
                                  int* FeatTypes1, double* featXYZ1, int nDirc1, int* dircTypes1,
                                  double* dircXYZ1, int nFeat2, int* FeatTypes2, double* featXYZ2,
                                  int nDirc2, int* dircTypes2, double* dircXYZ2, bool trans,
                                  bool equalR, double* W, double* cVol, double* diffVolume); 
double calHSVolumeMC(int nAtoms, double* xyz, double* vdwR);

//
//   Calculate the atomic surface of rank n contribution
//   n: number of overlapping Gaussian
//   aList: indexes of the atom list of the Guassians
//   xyz: coordinates of the whole molecule
//   rn: coordiates of the coalesense center of the overlapping Guassians
//   vn: overlapping volume
//   vdwR: van der Waals radii
//   pix: p(i)
//   dltn: delta-n (see total exponent of n Gaussian functions)
//   atomSA: return value
//
void calGSA(int n, int* aList, double vn, double* xyz, double* rn, double* vdwR, double* pix,
            double dltn, double* atomSA) {
    int i;
    int ia;
    int i3;
    double pi = 3.14159265358979;
    double factor = pow((-1.0), n + 1);
    double ki2;
    double dist2;
    for (i = 0; i < n; i++) {
        ia = aList[i];
        i3 = ia * 3;
        ki2 = (2 * pi / pow(4 * pi / (3 * pix[ia]), 2.0 / 3.0)) / (vdwR[ia] * vdwR[ia] * vdwR[ia]);
        dist2 = (xyz[i3] - rn[0]) * (xyz[i3] - rn[0]) +
                (xyz[i3 + 1] - rn[1]) * (xyz[i3 + 1] - rn[1]) +
                (xyz[i3 + 2] - rn[2]) * (xyz[i3 + 2] - rn[2]);
        atomSA[ia] += factor * ki2 * (1.5 / dltn + dist2) * vn;
    }
}

//
//  Calculation of overlap volume of Mol1 and Mol2
//
double calGCrossVolume(int na1, int na2, double* xyz1, double* vdwR1, double* xyz2, double* vdwR2,
                       double* w1, double* w2) {
    //
    // First, build neighbor list
    //
    int i3, j3;
    int numAtoms = na1 + na2;
    double dist;
    double dCutoff = 10;
    double mindist;
    double base;
    double pi = 3.14159265358979;
    double p2 = gParam * gParam;
    int* gPairs = new int[2 * na1 * na2];
    double* alpha1 = new double[na1];
    double* alpha2 = new double[na2];
    double* gDist = new double[na1 * na2];

    double rn[3];

    double gfactor = 4.0 * pi / (3.0 * gParam);       // gfactor = 1.48098
    gfactor = pi / (pow(gfactor, 0.66666666666667));  // gfactor = 2.41797
    for (int i = 0; i < na1; i++) {
        alpha1[i] = gfactor / (vdwR1[i] * vdwR1[i]);
        double testv = 4.0 * pi * pow(vdwR2[i], 3.0) / 3.0;
    }
    for (int i = 0; i < na2; i++) {
        alpha2[i] = gfactor / (vdwR2[i] * vdwR2[i]);
    }
    int ij = 0;
    int ij1 = 0;
    for (int i = 0; i < na1; i++) {
        i3 = i * 3;
        for (int j = 0; j < na2; j++) {
            j3 = j * 3;
            ij1 = ij * 2;
            gPairs[ij1] = i;
            gPairs[ij1 + 1] = j;
            dist = sqrt((xyz1[i3] - xyz2[j3]) * (xyz1[i3] - xyz2[j3]) +
                        (xyz1[i3 + 1] - xyz2[j3 + 1]) * (xyz1[i3 + 1] - xyz2[j3 + 1]) +
                        (xyz1[i3 + 2] - xyz2[j3 + 2]) * (xyz1[i3 + 2] - xyz2[j3 + 2]));
            gDist[ij] = dist;
            ij = ij + 1;
        }
    }

    int a, b, ab;
    double kn;
    double tmpd;
    double dltn = 0;
    double crossVol = 0;
    for (int i = 0; i < na1 * na2; i++) {
        a = gPairs[i * 2];
        b = gPairs[i * 2 + 1];
        i3 = a * 3;
        j3 = b * 3;
        ab = b * (b - 1) / 2 + a;
        tmpd = alpha1[a] + alpha2[b];
        dltn = tmpd;
        kn = exp(-alpha1[a] * alpha2[b] * gDist[i] * gDist[i] / tmpd);
        tmpd = p2 * kn * pow(pi / tmpd, 1.5);
        crossVol += tmpd * w1[a] * w2[b];
    }

    delete[] alpha1;
    delete[] alpha2;
    delete[] gPairs;
    delete[] gDist;
    return crossVol;
}

//
// for flexible overlap
//
double calGDCrossVolFB(double* v, int na1S, int* sAtomIdx, int na1F, int* fAtomIdx, double* xyz1,
                       double* alpha1, double* w1, int na2, double* xyz2, double* alpha2,
                       double* w2, bool equalR, double* wxpp, double* drt, double* hess) {
    int i3, j3, i6;
    int si, fi;
    double dist;

    double rn[3];

    double kn;
    double tmpd;
    double dltn = 0;
    double crossVol = 0;
    double tav, tavad, tavap;
    double cderv[3];
    double chess[6];
    for (int i = 0; i < 7; i++) {
        drt[i] = 0;
        for (int j = 0; j < 7; j++) {
            hess[i * 7 + j] = 0;
        }
    }

    // calculate derv of stable atoms
    for (int i = 0; i < na1S; i++) {
        i3 = sAtomIdx[i] * 3;
        si = sAtomIdx[i];
        i6 = i3 + i3;
        double w1p2 = w1[si] * 7.99984656;
        double pidltn;
        cderv[0] = 0;
        cderv[1] = 0;
        cderv[2] = 0;
        chess[0] = 0;
        chess[1] = 0;
        chess[2] = 0;
        chess[3] = 0;
        chess[4] = 0;
        chess[5] = 0;

        for (int j = 0; j < na2; j++) {
            j3 = j * 3;
            dist = (xyz1[i3] - xyz2[j3]) * (xyz1[i3] - xyz2[j3]) +
                   (xyz1[i3 + 1] - xyz2[j3 + 1]) * (xyz1[i3 + 1] - xyz2[j3 + 1]) +
                   (xyz1[i3 + 2] - xyz2[j3 + 2]) * (xyz1[i3 + 2] - xyz2[j3 + 2]);
            dltn = alpha1[si] + alpha2[j];
            rn[0] = (xyz1[i3] * alpha1[si] + xyz2[j3] * alpha2[j]) / dltn;
            rn[1] = (xyz1[i3 + 1] * alpha1[si] + xyz2[j3 + 1] * alpha2[j]) / dltn;
            rn[2] = (xyz1[i3 + 2] * alpha1[si] + xyz2[j3 + 2] * alpha2[j]) / dltn;
            kn = exp(-alpha1[si] * alpha2[j] * dist / dltn);
            // A: poor implementation
            // tmpd = w1p2*w2[j]*kn*pow(pi/dltn,1.5);
            //
            // B: maybe a good option for GPU implementation
            // pidltn = 3.14159265358979/dltn;
            // tmpd = w1p2*w2[j]*kn*pidltn*sqrt(pidltn);
            //
            // C: a slightly more efficient CPU implementation using
            //    pre-computed values stored in wxpp.
            tmpd = wxpp[si * na2 + j] * kn;
            crossVol += tmpd;
            // First derivatives
            tav = alpha1[si] * tmpd * 2;
            cderv[0] += tav * (xyz1[i3] - rn[0]);
            cderv[1] += tav * (xyz1[i3 + 1] - rn[1]);
            cderv[2] += tav * (xyz1[i3 + 2] - rn[2]);
            tavad = tav * (alpha1[si] / dltn - 1);
            tavap = (tav + tav) * alpha1[si];
            // Hessian
            chess[0] -= tavad + tavap * (xyz1[i3] - rn[0]) * (xyz1[i3] - rn[0]);
            chess[1] -= tavap * (xyz1[i3] - rn[0]) * (xyz1[i3 + 1] - rn[1]);
            chess[2] -= tavad + tavap * (xyz1[i3 + 1] - rn[1]) * (xyz1[i3 + 1] - rn[1]);
            chess[3] -= tavap * (xyz1[i3] - rn[0]) * (xyz1[i3 + 2] - rn[2]);
            chess[4] -= tavap * (xyz1[i3 + 1] - rn[1]) * (xyz1[i3 + 2] - rn[2]);
            chess[5] -= tavad + tavap * (xyz1[i3 + 2] - rn[2]) * (xyz1[i3 + 2] - rn[2]);
        }
        //
        // First derivatives
        //
        drt[3] += cderv[0];
        drt[4] += cderv[1];
        drt[5] += cderv[2];
        drt[0] += -cderv[0] * xyz1[i3 + 1] + cderv[1] * xyz1[i3];
        drt[1] += -cderv[1] * xyz1[i3 + 2] + cderv[2] * xyz1[i3 + 1];
        drt[2] += cderv[0] * xyz1[i3 + 2] - cderv[2] * xyz1[i3];
        //
        // Hessian. variables 0=alpha, 1=beta, 2=gamma, 3=tx, 4=ty, 5=tx
        //
        hess[3 * 7 + 3] += chess[0];
        hess[3 * 7 + 4] += chess[1];
        hess[4 * 7 + 4] += chess[2];
        hess[3 * 7 + 5] += chess[3];
        hess[4 * 7 + 5] += chess[4];
        hess[5 * 7 + 5] += chess[5];
        hess[0] += -cderv[0] * xyz1[i3] - cderv[1] * xyz1[i3 + 1] +
                   chess[0] * xyz1[i3 + 1] * xyz1[i3 + 1] -
                   chess[1] * xyz1[i3 + 1] * xyz1[i3] * 2.0 + chess[2] * xyz1[i3] * xyz1[i3];
        hess[1] += cderv[0] * xyz1[i3 + 2] + chess[1] * xyz1[i3 + 1] * xyz1[i3 + 2] -
                   chess[2] * xyz1[i3] * xyz1[i3 + 2] - chess[3] * xyz1[i3 + 1] * xyz1[i3 + 1] +
                   chess[4] * xyz1[i3] * xyz1[i3 + 1];
        hess[1 * 7 + 1] += -cderv[1] * xyz1[i3 + 1] - cderv[2] * xyz1[i3 + 2] +
                           chess[2] * xyz1[i3 + 2] * xyz1[i3 + 2] -
                           chess[4] * xyz1[i3 + 1] * xyz1[i3 + 2] * 2.0 +
                           chess[5] * xyz1[i3 + 1] * xyz1[i3 + 1];
        hess[2] += cderv[2] * xyz1[i3 + 1] - chess[0] * xyz1[i3 + 1] * xyz1[i3 + 2] +
                   chess[1] * xyz1[i3] * xyz1[i3 + 2] + chess[3] * xyz1[i3] * xyz1[i3 + 1] -
                   chess[4] * xyz1[i3] * xyz1[i3];
        hess[1 * 7 + 2] += cderv[0] * xyz1[i3 + 1] - chess[1] * xyz1[i3 + 2] * xyz1[i3 + 2] +
                           chess[3] * xyz1[i3 + 1] * xyz1[i3 + 2] +
                           chess[4] * xyz1[i3] * xyz1[i3 + 2] - chess[5] * xyz1[i3] * xyz1[i3 + 1];
        hess[2 * 7 + 2] += -cderv[0] * xyz1[i3] - cderv[2] * xyz1[i3 + 2] +
                           chess[0] * xyz1[i3 + 2] * xyz1[i3 + 2] -
                           chess[3] * xyz1[i3] * xyz1[i3 + 2] * 2.0 +
                           chess[5] * xyz1[i3] * xyz1[i3];
        hess[3] += -chess[0] * xyz1[i3 + 1] + chess[1] * xyz1[i3];
        hess[1 * 7 + 3] += -chess[1] * xyz1[i3 + 2] + chess[3] * xyz1[i3 + 1];
        hess[2 * 7 + 3] += chess[0] * xyz1[i3 + 2] - chess[3] * xyz1[i3];

        hess[4] += -chess[1] * xyz1[i3 + 1] + chess[2] * xyz1[i3];
        hess[1 * 7 + 4] += -chess[2] * xyz1[i3 + 2] + chess[4] * xyz1[i3 + 1];
        hess[2 * 7 + 4] += chess[1] * xyz1[i3 + 2] - chess[4] * xyz1[i3];

        hess[5] += -chess[3] * xyz1[i3 + 1] + chess[4] * xyz1[i3];
        hess[1 * 7 + 5] += -chess[4] * xyz1[i3 + 2] + chess[5] * xyz1[i3 + 1];
        hess[2 * 7 + 5] += chess[3] * xyz1[i3 + 2] - chess[5] * xyz1[i3];
    }

    // calculate derv of flexible atoms
    double vLen2 = v[0] * v[0] + v[1] * v[1] + v[2] * v[2];
    double vLen = sqrt(vLen2);
    for (int i = 0; i < na1F; i++) {
        i3 = fAtomIdx[i] * 3;
        fi = fAtomIdx[i];
        i6 = i3 + i3;
        double w1p2 = w1[fi] * 7.99984656;
        double pidltn;
        cderv[0] = 0;
        cderv[1] = 0;
        cderv[2] = 0;
        chess[0] = 0;
        chess[1] = 0;
        chess[2] = 0;
        chess[3] = 0;
        chess[4] = 0;
        chess[5] = 0;

        for (int j = 0; j < na2; j++) {
            j3 = j * 3;
            dist = (xyz1[i3] - xyz2[j3]) * (xyz1[i3] - xyz2[j3]) +
                   (xyz1[i3 + 1] - xyz2[j3 + 1]) * (xyz1[i3 + 1] - xyz2[j3 + 1]) +
                   (xyz1[i3 + 2] - xyz2[j3 + 2]) * (xyz1[i3 + 2] - xyz2[j3 + 2]);
            dltn = alpha1[fi] + alpha2[j];
            rn[0] = (xyz1[i3] * alpha1[fi] + xyz2[j3] * alpha2[j]) / dltn;
            rn[1] = (xyz1[i3 + 1] * alpha1[fi] + xyz2[j3 + 1] * alpha2[j]) / dltn;
            rn[2] = (xyz1[i3 + 2] * alpha1[fi] + xyz2[j3 + 2] * alpha2[j]) / dltn;
            kn = exp(-alpha1[fi] * alpha2[j] * dist / dltn);
            // A: poor implementation
            // tmpd = w1p2*w2[j]*kn*pow(pi/dltn,1.5);
            //
            // B: maybe a good option for GPU implementation
            // pidltn = 3.14159265358979/dltn;
            // tmpd = w1p2*w2[j]*kn*pidltn*sqrt(pidltn);
            //
            // C: a slightly more efficient CPU implementation using
            //    pre-computed values stored in wxpp.
            tmpd = wxpp[fi * na2 + j] * kn;
            crossVol += tmpd;
            // First derivatives
            tav = alpha1[fi] * tmpd * 2;
            cderv[0] += tav * (xyz1[i3] - rn[0]);
            cderv[1] += tav * (xyz1[i3 + 1] - rn[1]);
            cderv[2] += tav * (xyz1[i3 + 2] - rn[2]);
            tavad = tav * (alpha1[fi] / dltn - 1);
            tavap = (tav + tav) * alpha1[fi];
            // Hessian
            chess[0] -= tavad + tavap * (xyz1[i3] - rn[0]) * (xyz1[i3] - rn[0]);
            chess[1] -= tavap * (xyz1[i3] - rn[0]) * (xyz1[i3 + 1] - rn[1]);
            chess[2] -= tavad + tavap * (xyz1[i3 + 1] - rn[1]) * (xyz1[i3 + 1] - rn[1]);
            chess[3] -= tavap * (xyz1[i3] - rn[0]) * (xyz1[i3 + 2] - rn[2]);
            chess[4] -= tavap * (xyz1[i3 + 1] - rn[1]) * (xyz1[i3 + 2] - rn[2]);
            chess[5] -= tavad + tavap * (xyz1[i3 + 2] - rn[2]) * (xyz1[i3 + 2] - rn[2]);
        }
        //
        // First derivatives
        //
        drt[3] += cderv[0];
        drt[4] += cderv[1];
        drt[5] += cderv[2];
        drt[0] += -cderv[0] * xyz1[i3 + 1] + cderv[1] * xyz1[i3];
        drt[1] += -cderv[1] * xyz1[i3 + 2] + cderv[2] * xyz1[i3 + 1];
        drt[2] += cderv[0] * xyz1[i3 + 2] - cderv[2] * xyz1[i3];
        drt[6] += cderv[0] * xyz1[i3] * (v[2] - v[1]) / vLen +
                  cderv[1] * xyz1[i3 + 1] * (v[0] - v[2]) / vLen +
                  cderv[2] * xyz1[i3 + 2] * (v[1] - v[0]) / vLen;

        //
        // Hessian. variables 0=alpha, 1=beta, 2=gamma, 3=tx, 4=ty, 5=tx
        //
        hess[3 * 7 + 3] += chess[0];
        hess[3 * 7 + 4] += chess[1];
        hess[4 * 7 + 4] += chess[2];
        hess[3 * 7 + 5] += chess[3];
        hess[4 * 7 + 5] += chess[4];
        hess[5 * 7 + 5] += chess[5];
        hess[0] += -cderv[0] * xyz1[i3] - cderv[1] * xyz1[i3 + 1] +
                   chess[0] * xyz1[i3 + 1] * xyz1[i3 + 1] -
                   chess[1] * xyz1[i3 + 1] * xyz1[i3] * 2.0 + chess[2] * xyz1[i3] * xyz1[i3];
        hess[1] += cderv[0] * xyz1[i3 + 2] + chess[1] * xyz1[i3 + 1] * xyz1[i3 + 2] -
                   chess[2] * xyz1[i3] * xyz1[i3 + 2] - chess[3] * xyz1[i3 + 1] * xyz1[i3 + 1] +
                   chess[4] * xyz1[i3] * xyz1[i3 + 1];
        hess[1 * 7 + 1] += -cderv[1] * xyz1[i3 + 1] - cderv[2] * xyz1[i3 + 2] +
                           chess[2] * xyz1[i3 + 2] * xyz1[i3 + 2] -
                           chess[4] * xyz1[i3 + 1] * xyz1[i3 + 2] * 2.0 +
                           chess[5] * xyz1[i3 + 1] * xyz1[i3 + 1];
        hess[2] += cderv[2] * xyz1[i3 + 1] - chess[0] * xyz1[i3 + 1] * xyz1[i3 + 2] +
                   chess[1] * xyz1[i3] * xyz1[i3 + 2] + chess[3] * xyz1[i3] * xyz1[i3 + 1] -
                   chess[4] * xyz1[i3] * xyz1[i3];
        hess[1 * 7 + 2] += cderv[0] * xyz1[i3 + 1] - chess[1] * xyz1[i3 + 2] * xyz1[i3 + 2] +
                           chess[3] * xyz1[i3 + 1] * xyz1[i3 + 2] +
                           chess[4] * xyz1[i3] * xyz1[i3 + 2] - chess[5] * xyz1[i3] * xyz1[i3 + 1];
        hess[2 * 7 + 2] += -cderv[0] * xyz1[i3] - cderv[2] * xyz1[i3 + 2] +
                           chess[0] * xyz1[i3 + 2] * xyz1[i3 + 2] -
                           chess[3] * xyz1[i3] * xyz1[i3 + 2] * 2.0 +
                           chess[5] * xyz1[i3] * xyz1[i3];
        hess[3] += -chess[0] * xyz1[i3 + 1] + chess[1] * xyz1[i3];
        hess[1 * 7 + 3] += -chess[1] * xyz1[i3 + 2] + chess[3] * xyz1[i3 + 1];
        hess[2 * 7 + 3] += chess[0] * xyz1[i3 + 2] - chess[3] * xyz1[i3];

        hess[4] += -chess[1] * xyz1[i3 + 1] + chess[2] * xyz1[i3];
        hess[1 * 7 + 4] += -chess[2] * xyz1[i3 + 2] + chess[4] * xyz1[i3 + 1];
        hess[2 * 7 + 4] += chess[1] * xyz1[i3 + 2] - chess[4] * xyz1[i3];

        hess[5] += -chess[3] * xyz1[i3 + 1] + chess[4] * xyz1[i3];
        hess[1 * 7 + 5] += -chess[4] * xyz1[i3 + 2] + chess[5] * xyz1[i3 + 1];
        hess[2 * 7 + 5] += chess[3] * xyz1[i3 + 2] - chess[5] * xyz1[i3];
    }

    for (int i = 0; i < 7; i++) {
        for (int j = 0; j < i + 1; j++) {
            // printf("%15.10lf",hess6[j][i]);
            hess[i * 7 + j] = hess[j * 7 + i];
        }
        // printf("\n");
    }
    return crossVol;
}

//
// Add Feature overlay contribution
//
double calFGDCrossVol(int na1, double* xyz1, double* alpha1, double* w1, int na2, double* xyz2,
                      double* alpha2, double* w2, int nFA1, int* FATypes1, int* FAIdx1, int nFA2,
                      int* FATypes2, int* FAIdx2, double dtr0[6], double hess6[6][6], double* WF,
                      double* cVol) {
    int i3, j3, i6;
    double dist;

    double rn[3];
    double alpha[10];

    double VDWR = 2.0;
    double gFactor = 2.41797;
    double a = gFactor / (VDWR * VDWR);

    alpha[0] = 1.0;
    alpha[1] = a;
    alpha[2] = a;
    alpha[3] = a;
    alpha[4] = a;
    alpha[5] = a;
    alpha[6] = a;
    alpha[7] = a;
    alpha[8] = a;
    alpha[9] = a;

    double kn;
    double tmpd;
    double dltn = 0;
    double crossVol = 0;
    double tav, tavad, tavap;
    double derv[3];
    double hess[6];

    for (int i = 0; i < nFA1; i++) {
        i3 = FAIdx1[i] * 3;
        i6 = i3 + i3;
        double w1p2 = WF[FATypes1[i]] * 7.99984656;
        double pidltn;
        double AP = alpha[FATypes1[i]];
        derv[0] = 0;
        derv[1] = 0;
        derv[2] = 0;
        hess[0] = 0;
        hess[1] = 0;
        hess[2] = 0;
        hess[3] = 0;
        hess[4] = 0;
        hess[5] = 0;

        for (int j = 0; j < nFA2; j++) {
            if (FATypes1[i] != FATypes2[j]) continue;
            j3 = FAIdx2[j] * 3;
            dist = (xyz1[i3] - xyz2[j3]) * (xyz1[i3] - xyz2[j3]) +
                   (xyz1[i3 + 1] - xyz2[j3 + 1]) * (xyz1[i3 + 1] - xyz2[j3 + 1]) +
                   (xyz1[i3 + 2] - xyz2[j3 + 2]) * (xyz1[i3 + 2] - xyz2[j3 + 2]);
            dltn = AP + AP;
            rn[0] = (xyz1[i3] + xyz2[j3]) * 0.5;
            rn[1] = (xyz1[i3 + 1] + xyz2[j3 + 1]) * 0.5;
            rn[2] = (xyz1[i3 + 2] + xyz2[j3 + 2]) * 0.5;
            kn = exp(-AP * dist / 2.0);
            pidltn = 3.14159265358979 / dltn;
            tmpd = w1p2 * kn * pidltn * sqrt(pidltn);
            crossVol += tmpd;
            //
            // sum crossVol of each feature type
            //
            cVol[FATypes1[i]] += tmpd;

            // First derivatives
            tav = AP * tmpd * 2;
            derv[0] += tav * (xyz1[i3] - rn[0]);
            derv[1] += tav * (xyz1[i3 + 1] - rn[1]);
            derv[2] += tav * (xyz1[i3 + 2] - rn[2]);
            tavad = tav * (AP / dltn - 1);
            tavap = (tav + tav) * AP;
            // Hessian
            hess[0] -= tavad + tavap * (xyz1[i3] - rn[0]) * (xyz1[i3] - rn[0]);
            hess[1] -= tavap * (xyz1[i3] - rn[0]) * (xyz1[i3 + 1] - rn[1]);
            hess[2] -= tavad + tavap * (xyz1[i3 + 1] - rn[1]) * (xyz1[i3 + 1] - rn[1]);
            hess[3] -= tavap * (xyz1[i3] - rn[0]) * (xyz1[i3 + 2] - rn[2]);
            hess[4] -= tavap * (xyz1[i3 + 1] - rn[1]) * (xyz1[i3 + 2] - rn[2]);
            hess[5] -= tavad + tavap * (xyz1[i3 + 2] - rn[2]) * (xyz1[i3 + 2] - rn[2]);
        }
        //
        // First derivatives
        //
        dtr0[3] += derv[0];
        dtr0[4] += derv[1];
        dtr0[5] += derv[2];
        dtr0[0] += -derv[0] * xyz1[i3 + 1] + derv[1] * xyz1[i3];
        dtr0[1] += -derv[1] * xyz1[i3 + 2] + derv[2] * xyz1[i3 + 1];
        dtr0[2] += derv[0] * xyz1[i3 + 2] - derv[2] * xyz1[i3];
        //
        // Hessian. variables 0=alpha, 1=beta, 2=gamma, 3=tx, 4=ty, 5=tx
        //
        hess6[3][3] += hess[0];
        hess6[3][4] += hess[1];
        hess6[4][4] += hess[2];
        hess6[3][5] += hess[3];
        hess6[4][5] += hess[4];
        hess6[5][5] += hess[5];
        hess6[0][0] += -derv[0] * xyz1[i3] - derv[1] * xyz1[i3 + 1] +
                       hess[0] * xyz1[i3 + 1] * xyz1[i3 + 1] -
                       hess[1] * xyz1[i3 + 1] * xyz1[i3] * 2.0 + hess[2] * xyz1[i3] * xyz1[i3];
        hess6[0][1] += derv[0] * xyz1[i3 + 2] + hess[1] * xyz1[i3 + 1] * xyz1[i3 + 2] -
                       hess[2] * xyz1[i3] * xyz1[i3 + 2] - hess[3] * xyz1[i3 + 1] * xyz1[i3 + 1] +
                       hess[4] * xyz1[i3] * xyz1[i3 + 1];
        hess6[1][1] += -derv[1] * xyz1[i3 + 1] - derv[2] * xyz1[i3 + 2] +
                       hess[2] * xyz1[i3 + 2] * xyz1[i3 + 2] -
                       hess[4] * xyz1[i3 + 1] * xyz1[i3 + 2] * 2.0 +
                       hess[5] * xyz1[i3 + 1] * xyz1[i3 + 1];
        hess6[0][2] += derv[2] * xyz1[i3 + 1] - hess[0] * xyz1[i3 + 1] * xyz1[i3 + 2] +
                       hess[1] * xyz1[i3] * xyz1[i3 + 2] + hess[3] * xyz1[i3] * xyz1[i3 + 1] -
                       hess[4] * xyz1[i3] * xyz1[i3];
        hess6[1][2] += derv[0] * xyz1[i3 + 1] - hess[1] * xyz1[i3 + 2] * xyz1[i3 + 2] +
                       hess[3] * xyz1[i3 + 1] * xyz1[i3 + 2] + hess[4] * xyz1[i3] * xyz1[i3 + 2] -
                       hess[5] * xyz1[i3] * xyz1[i3 + 1];
        hess6[2][2] += -derv[0] * xyz1[i3] - derv[2] * xyz1[i3 + 2] +
                       hess[0] * xyz1[i3 + 2] * xyz1[i3 + 2] -
                       hess[3] * xyz1[i3] * xyz1[i3 + 2] * 2.0 + hess[5] * xyz1[i3] * xyz1[i3];
        hess6[0][3] += -hess[0] * xyz1[i3 + 1] + hess[1] * xyz1[i3];
        hess6[1][3] += -hess[1] * xyz1[i3 + 2] + hess[3] * xyz1[i3 + 1];
        hess6[2][3] += hess[0] * xyz1[i3 + 2] - hess[3] * xyz1[i3];

        hess6[0][4] += -hess[1] * xyz1[i3 + 1] + hess[2] * xyz1[i3];
        hess6[1][4] += -hess[2] * xyz1[i3 + 2] + hess[4] * xyz1[i3 + 1];
        hess6[2][4] += hess[1] * xyz1[i3 + 2] - hess[4] * xyz1[i3];

        hess6[0][5] += -hess[3] * xyz1[i3 + 1] + hess[4] * xyz1[i3];
        hess6[1][5] += -hess[4] * xyz1[i3 + 2] + hess[5] * xyz1[i3 + 1];
        hess6[2][5] += hess[3] * xyz1[i3 + 2] - hess[5] * xyz1[i3];
    }
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j < i + 1; j++) {
            // printf("%15.10lf",hess6[j][i]);
            hess6[i][j] = hess6[j][i];
        }
        // printf("\n");
    }
    return crossVol;
}

//
// Add Feature overlay contribution
//
double calFGDCrossVol_ourPharma(int nFeat1, int* FeatTypes1, double* featXYZ1, int nDirc1,
                                int* dircTypes1, double* dircXYZ1, int nFeat2, int* FeatTypes2,
                                double* featXYZ2, int nDirc2, int* dircTypes2, double* dircXYZ2,
                                double dtr0[6], double hess6[6][6], double* WF, double* cVol) {
    int i3, j3, i6;
    double dist;

    double rn[3];
    // double alpha[10];

    double VDWR = 1.8;  // vdw radius for feature sphere
    double gFactor = 2.41797;
    double alpha = 0.74628778;  // gFactor/(VDWR*VDWR);
    double alphaH = 0.37314390;
    double alpha2 = 1.49257558;
    double pidltn = 2.10481311;  // pi / dltn; dltn == alpha2;
    pidltn = 3.05365740;         // pidltn*sqrt(pidltn);

    double atomx1, atomy1, atomz1, dircx1, dircy1, dircz1;

    double kn;
    double tmpd;
    // double dltn = 0;
    double crossVol = 0;
    double tav, tavad, tavap;
    double derv[3];
    double hess[6];

    int type1;
    for (int i = 0; i < nFeat1; i++) {
        type1 = FeatTypes1[i];
        double w1p2 = WF[type1] * 7.99984656;  // P= 7.99984656
        // double pidltn;
        // double AP = alpha[type1];
        derv[0] = 0;
        derv[1] = 0;
        derv[2] = 0;
        hess[0] = 0;
        hess[1] = 0;
        hess[2] = 0;
        hess[3] = 0;
        hess[4] = 0;
        hess[5] = 0;

        i3 = i * 3;
        atomx1 = featXYZ1[i3];
        atomy1 = featXYZ1[i3 + 1];
        atomz1 = featXYZ1[i3 + 2];

        // std::cout << "type: " << type1 << ", "<< atomx1 << ", " <<atomy1 << ", "<< atomz1 <<
        // "\n";

        for (int j = 0; j < nFeat2; j++) {
            if (type1 != FeatTypes2[j]) continue;

            j3 = j * 3;

            // std::cout << "qtype: " << FeatTypes2[j] << ", "<<  featXYZ2[j3] << ", " <<
            // featXYZ2[j3+1] << ", "<< featXYZ2[j3+2] << "\n";

            dist = (atomx1 - featXYZ2[j3]) * (atomx1 - featXYZ2[j3]) +
                   (atomy1 - featXYZ2[j3 + 1]) * (atomy1 - featXYZ2[j3 + 1]) +
                   (atomz1 - featXYZ2[j3 + 2]) * (atomz1 - featXYZ2[j3 + 2]);
            // dltn = AP+AP;
            rn[0] = (atomx1 + featXYZ2[j3]) * 0.5;
            rn[1] = (atomy1 + featXYZ2[j3 + 1]) * 0.5;
            rn[2] = (atomz1 + featXYZ2[j3 + 2]) * 0.5;
            kn = exp(-alphaH * dist);
            // pidltn = 3.14159265358979/dltn;
            // tmpd = w1p2*kn*pidltn*sqrt(pidltn);
            tmpd = w1p2 * kn * pidltn;

            // std::cout << "vol: " << tmpd << "\n";
            crossVol += tmpd;
            //
            // sum crossVol of each feature type
            //
            cVol[type1] += tmpd;

            // First derivatives
            tav = alpha2 * tmpd;
            derv[0] += tav * (atomx1 - rn[0]);
            derv[1] += tav * (atomy1 - rn[1]);
            derv[2] += tav * (atomz1 - rn[2]);
            tavad = tav * (-0.5);
            tavap = (tav + tav) * alpha;
            // Hessian
            hess[0] -= tavad + tavap * (atomx1 - rn[0]) * (atomx1 - rn[0]);
            hess[1] -= tavap * (atomx1 - rn[0]) * (atomy1 - rn[1]);
            hess[2] -= tavad + tavap * (atomy1 - rn[1]) * (atomy1 - rn[1]);
            hess[3] -= tavap * (atomx1 - rn[0]) * (atomz1 - rn[2]);
            hess[4] -= tavap * (atomy1 - rn[1]) * (atomz1 - rn[2]);
            hess[5] -= tavad + tavap * (atomz1 - rn[2]) * (atomz1 - rn[2]);
        }
        //
        // First derivatives
        //
        dtr0[3] += derv[0];
        dtr0[4] += derv[1];
        dtr0[5] += derv[2];
        dtr0[0] += -derv[0] * atomy1 + derv[1] * atomx1;
        dtr0[1] += -derv[1] * atomz1 + derv[2] * atomy1;
        dtr0[2] += derv[0] * atomz1 - derv[2] * atomx1;
        //
        // Hessian. variables 0=alpha, 1=beta, 2=gamma, 3=tx, 4=ty, 5=tx
        //
        hess6[3][3] += hess[0];
        hess6[3][4] += hess[1];
        hess6[4][4] += hess[2];
        hess6[3][5] += hess[3];
        hess6[4][5] += hess[4];
        hess6[5][5] += hess[5];
        hess6[0][0] += -derv[0] * atomx1 - derv[1] * atomy1 + hess[0] * atomy1 * atomy1 -
                       hess[1] * atomy1 * atomx1 * 2.0 + hess[2] * atomx1 * atomx1;
        hess6[0][1] += derv[0] * atomz1 + hess[1] * atomy1 * atomz1 - hess[2] * atomx1 * atomz1 -
                       hess[3] * atomy1 * atomy1 + hess[4] * atomx1 * atomy1;
        hess6[1][1] += -derv[1] * atomy1 - derv[2] * atomz1 + hess[2] * atomz1 * atomz1 -
                       hess[4] * atomy1 * atomz1 * 2.0 + hess[5] * atomy1 * atomy1;
        hess6[0][2] += derv[2] * atomy1 - hess[0] * atomy1 * atomz1 + hess[1] * atomx1 * atomz1 +
                       hess[3] * atomx1 * atomy1 - hess[4] * atomx1 * atomx1;
        hess6[1][2] += derv[0] * atomy1 - hess[1] * atomz1 * atomz1 + hess[3] * atomy1 * atomz1 +
                       hess[4] * atomx1 * atomz1 - hess[5] * atomx1 * atomy1;
        hess6[2][2] += -derv[0] * atomx1 - derv[2] * atomz1 + hess[0] * atomz1 * atomz1 -
                       hess[3] * atomx1 * atomz1 * 2.0 + hess[5] * atomx1 * atomx1;
        hess6[0][3] += -hess[0] * atomy1 + hess[1] * atomx1;
        hess6[1][3] += -hess[1] * atomz1 + hess[3] * atomy1;
        hess6[2][3] += hess[0] * atomz1 - hess[3] * atomx1;

        hess6[0][4] += -hess[1] * atomy1 + hess[2] * atomx1;
        hess6[1][4] += -hess[2] * atomz1 + hess[4] * atomy1;
        hess6[2][4] += hess[1] * atomz1 - hess[4] * atomx1;

        hess6[0][5] += -hess[3] * atomy1 + hess[4] * atomx1;
        hess6[1][5] += -hess[4] * atomz1 + hess[5] * atomy1;
        hess6[2][5] += hess[3] * atomz1 - hess[5] * atomx1;
    }

    // overlay of direction points
    for (int i = 0; i < nDirc1; i++) {
        type1 = dircTypes1[i];
        double w1p2 = WF[6 + type1] * 7.99984656;
        // double pidltn;
        // double AP = alpha[6+type1];
        derv[0] = 0;
        derv[1] = 0;
        derv[2] = 0;
        hess[0] = 0;
        hess[1] = 0;
        hess[2] = 0;
        hess[3] = 0;
        hess[4] = 0;
        hess[5] = 0;

        i3 = i * 3;
        atomx1 = dircXYZ1[i3];
        atomy1 = dircXYZ1[i3 + 1];
        atomz1 = dircXYZ1[i3 + 2];
        // std::cout << "dirc type: " << type1 << ", "<< atomx1 << ", " <<atomy1 << ", "<< atomz1 <<
        // "\n";

        for (int j = 0; j < nDirc2; j++) {
            if (type1 != dircTypes2[j]) continue;
            j3 = j * 3;

            // std::cout << "q dirc type: " << dircTypes2[j] << ", "<<  dircXYZ2[j3] << ", " <<
            // dircXYZ2[j3+1] << ", "<< dircXYZ2[j3+2] << "\n";

            dist = (atomx1 - dircXYZ2[j3]) * (atomx1 - dircXYZ2[j3]) +
                   (atomy1 - dircXYZ2[j3 + 1]) * (atomy1 - dircXYZ2[j3 + 1]) +
                   (atomz1 - dircXYZ2[j3 + 2]) * (atomz1 - dircXYZ2[j3 + 2]);
            // dltn = AP+AP;
            rn[0] = (atomx1 + dircXYZ2[j3]) * 0.5;
            rn[1] = (atomy1 + dircXYZ2[j3 + 1]) * 0.5;
            rn[2] = (atomz1 + dircXYZ2[j3 + 2]) * 0.5;
            kn = exp(-alphaH * dist);
            // pidltn = 3.14159265358979/dltn;
            tmpd = w1p2 * kn * pidltn;

            // std::cout << "vol: " << tmpd << "\n";

            crossVol += tmpd;
            //
            // sum crossVol of each feature type
            //
            // std::cout << "tmpd: " << tmpd << "\n";
            cVol[6 + type1] += tmpd;

            // First derivatives
            tav = alpha2 * tmpd;
            derv[0] += tav * (atomx1 - rn[0]);
            derv[1] += tav * (atomy1 - rn[1]);
            derv[2] += tav * (atomz1 - rn[2]);
            tavad = tav * (-0.5);
            tavap = (tav + tav) * alpha;
            // Hessian
            hess[0] -= tavad + tavap * (atomx1 - rn[0]) * (atomx1 - rn[0]);
            hess[1] -= tavap * (atomx1 - rn[0]) * (atomy1 - rn[1]);
            hess[2] -= tavad + tavap * (atomy1 - rn[1]) * (atomy1 - rn[1]);
            hess[3] -= tavap * (atomx1 - rn[0]) * (atomz1 - rn[2]);
            hess[4] -= tavap * (atomy1 - rn[1]) * (atomz1 - rn[2]);
            hess[5] -= tavad + tavap * (atomz1 - rn[2]) * (atomz1 - rn[2]);
        }
        //
        // First derivatives
        //
        dtr0[3] += derv[0];
        dtr0[4] += derv[1];
        dtr0[5] += derv[2];
        dtr0[0] += -derv[0] * atomy1 + derv[1] * atomx1;
        dtr0[1] += -derv[1] * atomz1 + derv[2] * atomy1;
        dtr0[2] += derv[0] * atomz1 - derv[2] * atomx1;
        //
        // Hessian. variables 0=alpha, 1=beta, 2=gamma, 3=tx, 4=ty, 5=tx
        //
        hess6[3][3] += hess[0];
        hess6[3][4] += hess[1];
        hess6[4][4] += hess[2];
        hess6[3][5] += hess[3];
        hess6[4][5] += hess[4];
        hess6[5][5] += hess[5];
        hess6[0][0] += -derv[0] * atomx1 - derv[1] * atomy1 + hess[0] * atomy1 * atomy1 -
                       hess[1] * atomy1 * atomx1 * 2.0 + hess[2] * atomx1 * atomx1;
        hess6[0][1] += derv[0] * atomz1 + hess[1] * atomy1 * atomz1 - hess[2] * atomx1 * atomz1 -
                       hess[3] * atomy1 * atomy1 + hess[4] * atomx1 * atomy1;
        hess6[1][1] += -derv[1] * atomy1 - derv[2] * atomz1 + hess[2] * atomz1 * atomz1 -
                       hess[4] * atomy1 * atomz1 * 2.0 + hess[5] * atomy1 * atomy1;
        hess6[0][2] += derv[2] * atomy1 - hess[0] * atomy1 * atomz1 + hess[1] * atomx1 * atomz1 +
                       hess[3] * atomx1 * atomy1 - hess[4] * atomx1 * atomx1;
        hess6[1][2] += derv[0] * atomy1 - hess[1] * atomz1 * atomz1 + hess[3] * atomy1 * atomz1 +
                       hess[4] * atomx1 * atomz1 - hess[5] * atomx1 * atomy1;
        hess6[2][2] += -derv[0] * atomx1 - derv[2] * atomz1 + hess[0] * atomz1 * atomz1 -
                       hess[3] * atomx1 * atomz1 * 2.0 + hess[5] * atomx1 * atomx1;
        hess6[0][3] += -hess[0] * atomy1 + hess[1] * atomx1;
        hess6[1][3] += -hess[1] * atomz1 + hess[3] * atomy1;
        hess6[2][3] += hess[0] * atomz1 - hess[3] * atomx1;

        hess6[0][4] += -hess[1] * atomy1 + hess[2] * atomx1;
        hess6[1][4] += -hess[2] * atomz1 + hess[4] * atomy1;
        hess6[2][4] += hess[1] * atomz1 - hess[4] * atomx1;

        hess6[0][5] += -hess[3] * atomy1 + hess[4] * atomx1;
        hess6[1][5] += -hess[4] * atomz1 + hess[5] * atomy1;
        hess6[2][5] += hess[3] * atomz1 - hess[5] * atomx1;
    }

    for (int i = 0; i < 6; i++) {
        for (int j = 0; j < i + 1; j++) {
            // printf("%15.10lf",hess6[j][i]);
            hess6[i][j] = hess6[j][i];
        }
        // printf("\n");
    }
    return crossVol;
}

//
// Solve linear equation of dimension size 6
//
double LSolver6x(double hess[6][6], double der6[6], double dx[6]) {
    double vec[6][6], E[6], invhes[36], tempE, hessx[36], hessv[36];
    double eThresh = 0.5;
    double dmax = 0;
    int jk, ij;

    for (int i = 0; i < 36; i++) invhes[i] = 0;

    //
    // Compute invers hessian
    //
    // Eigen(hess, vec, E);
    for (int i = 0; i < 6; i++)
        for (int j = 0; j < 6; j++) hessx[j * 6 + i] = hess[i][j];

    Jacobi(hessx, hessv, E, 6, 6);

    /*
    // test float number version of Jacobi

    float hessxf[36],hessvf[36],Ef[6],vecf[6][6];
       for (int i=0; i < 6; i++)
         for (int j=0; j < 6; j++)
           hessxf[j*6+i] = (float)hess[i][j];

       Jacobi_f(hessxf, hessvf, Ef, 6, 6);
       for (int i=0; i < 6; i++)
       {
         for (int j=0; j < 6; j++)
         {
           vecf[i][j] = hessvf[j*6+i];
           printf("%f ",vecf[i][j]);
         }
         printf("\n");
       }
       for (int i=0; i<6; i++) {
         printf("i, Ef(i) = %d, %20.15f \n",i, Ef[i]);
       }
    */

    //   printf("vec:\n");
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j < 6; j++) {
            vec[i][j] = hessv[j * 6 + i];
            // printf("%f ",vec[i][j]);
        }
        // printf("\n");
    }

    for (int i = 0; i < 6; i++) {
        //   printf("i, E(i) = %d, %20.15f \n",i, E[i]);
        tempE = E[i];
        if (tempE < 0) tempE = -tempE;
        if (tempE < 4.0) tempE = 4.0;
        tempE = 1.0 / tempE;
        for (int j = 0; j < 6; j++) {
            for (int k = 0; k < 6; k++) {
                jk = j * 6 + k;
                invhes[jk] += vec[j][i] * vec[k][i] * tempE;
            }
        }
    }

    //
    // dx = invhes , der6
    //
    dmax = 0;
    for (int i = 0; i < 6; i++) {
        dx[i] = 0;
        for (int j = 0; j < 6; j++) {
            ij = i * 6 + j;
            dx[i] += invhes[ij] * der6[j];
        }
        // printf("i, dx[i] = %d, %20.15f \n",i, dx[i]);
        if (fabs(dx[i]) > dmax) dmax = fabs(dx[i]);
    }
    //
    // Test hess.dx = der6
    //
    for (int i = 0; i < 6; i++) {
        tempE = 0;
        for (int j = 0; j < 6; j++) {
            tempE += hess[i][j] * dx[j];
        }
    }
    return dmax;
}

//
// Solve linear equation of dimension size 6 using Gaussian Elimination method
//
// hess*dx = der6
//
double LSolver6(double hess[6][6], double der6[6], double dx[6]) {
    double a[21], derv[6];
    double dmax;
    double base = 5.0;
    int nfc;
    int loop = 0;
    int ii[6];
    ii[0] = 0;
    for (int i = 1; i < 6; i++) ii[i] = ii[i - 1] + 7 - i;

    do {
        for (int i = 0; i < 6; i++) {
            derv[i] = der6[i];
            for (int j = i; j < 6; j++) a[ii[i] + j - i] = hess[i][j];
            a[ii[i]] += loop * base;
        }
        nfc = 0;
        for (int i = 0; i < 5; i++) {
            if (a[ii[i]] < 0) nfc++;
            //
            //   Do elimination
            //
            for (int j = i + 1; j < 6; j++) {
                double ex = a[ii[i] + j - i] / a[ii[i]];
                derv[j] -= derv[i] * ex;
                for (int k = j; k < 6; k++) a[ii[j] + k - j] -= a[ii[i] + k - i] * ex;
            }
        }
        if (a[20] < 0) nfc++;
        if (nfc > 0) {
            //   printf("Nagative eigenvalues !\n");
            //   printf("base = %lf !\n", base);
        }
        loop = 1;
        base *= 2.0;
    } while (nfc > 0);
    dmax = 0;
    for (int j = 5; j > -1; j--) {
        double tmp = derv[j];
        for (int k = j + 1; k < 6; k++) {
            tmp -= a[ii[j] + k - j] * dx[k];
        }
        dx[j] = tmp / a[ii[j]];
        if (fabs(dx[j]) > dmax) dmax = fabs(dx[j]);
    }
    return dmax;
}

float LSolver6_float(float hess[6][6], float der6[6], float dx[6]) {
    float a[21], derv[6];
    float dmax;
    float base = 5.0;
    int nfc;
    int loop = 0;
    int ii[6];
    ii[0] = 0;
    for (int i = 1; i < 6; i++) ii[i] = ii[i - 1] + 7 - i;

    do {
        for (int i = 0; i < 6; i++) {
            derv[i] = der6[i];
            for (int j = i; j < 6; j++) a[ii[i] + j - i] = hess[i][j];
            a[ii[i]] += loop * base;
        }
        nfc = 0;
        for (int i = 0; i < 5; i++) {
            if (a[ii[i]] < 0) nfc++;
            //
            //   Do elimination
            //
            for (int j = i + 1; j < 6; j++) {
                float ex = a[ii[i] + j - i] / a[ii[i]];
                derv[j] -= derv[i] * ex;
                for (int k = j; k < 6; k++) a[ii[j] + k - j] -= a[ii[i] + k - i] * ex;
            }
        }
        if (a[20] < 0) nfc++;
        if (nfc > 0) {
            //   printf("Nagative eigenvalues !\n");
            //   printf("base = %lf !\n", base);
        }
        loop = 1;
        base *= 2.0;
    } while (nfc > 0);
    dmax = 0;
    for (int j = 5; j > -1; j--) {
        float tmp = derv[j];
        for (int k = j + 1; k < 6; k++) {
            tmp -= a[ii[j] + k - j] * dx[k];
        }
        dx[j] = tmp / a[ii[j]];
        if (fabs(dx[j]) > dmax) dmax = fabs(dx[j]);
    }
    return dmax;
}

//
//
// Find the best overlay of two molecules based on the maximization of
// their overlapping volume and pharmacophore features.
// On return, Frag1 has transformed coordinates.
//
double overlayFGMols(MFCFrag* Frag1, MFCFrag* Frag2, double a, double b, double g, double* t,
                     bool computeWeights, double* WF, double* WV) {
    int NA1 = Frag1->numAtoms;
    int NA2 = Frag2->numAtoms;
    std::vector<int> FAtomList1;
    std::vector<int> FANumList1;
    std::vector<int> FAtomList2;
    std::vector<int> FANumList2;
    std::map<std::string, int> fMaps;

    fMaps[std::string("HBondAcceptor")] = 1;
    fMaps[std::string("HBondDonor")] = 2;
    fMaps[std::string("Hydrophobic")] = 3;
    fMaps[std::string("AromaticRing")] = 4;
    fMaps[std::string("PositiveIonizable")] = 5;
    fMaps[std::string("NegativeIonizable")] = 6;

    std::cout << "fMaps = " << fMaps[std::string("HBondAcceptor")] << "\n";

    MolProperties* molPro1 = Frag1->getMolPro();
    int nFeatures1 = molPro1->getIntProperty("Num_MolFeatures");
    std::vector<std::string> FeatureList1;
    FeatureList1 = molPro1->getStringPropertyArray("<MolFeatures>");
    molPro1->getPropertyIntList("MolFeaturesAtoms", FANumList1, FAtomList1);
    int nFeat1 = FeatureList1.size();
    int nFeatAtoms1 = FAtomList1.size();
    int* FeatTypes1 = new int[nFeatAtoms1];
    int* FeatAtomIdx1 = new int[nFeatAtoms1];
    int nPos = 0;
    std::cout << "nFeat1 = " << nFeat1 << "\n";
    for (int i = 0; i < nFeat1; i++) {
        // std::cout << "Feature Name = " << FeatureList1[i] << "\n";
        // std::cout << "FANum = " << FANumList1[i] << "\n";
        for (int j = 0; j < FANumList1[i]; j++) {
            FeatTypes1[nPos] = fMaps[FeatureList1[i]];
            FeatAtomIdx1[nPos] = FAtomList1[nPos];
            // std::cout << "Feature Atom List " << nPos << ": " << FAtomList1[nPos] << "FeatType =
            // " << FeatTypes1[nPos] << " FeatAtomIdx1 = " << FeatAtomIdx1[nPos] << "\n";
            nPos++;
        }
    }
    if (nPos != nFeatAtoms1) {
        std::cout << "nPos = " << nPos << "\n";
        std::cout << "nFeatAtoms1 = " << nFeatAtoms1 << "\n";
        exit(0);
    }
    std::cout << "After inital : nFeatAtoms1, type = " << nFeatAtoms1 << FeatTypes1[nFeatAtoms1 - 1]
              << "\n";
    MolProperties* molPro2 = Frag2->getMolPro();
    int nFeatures2 = molPro2->getIntProperty("Num_MolFeatures");
    std::vector<std::string> FeatureList2;
    FeatureList2 = molPro2->getStringPropertyArray("<MolFeatures>");
    molPro2->getPropertyIntList("MolFeaturesAtoms", FANumList2, FAtomList2);
    int nFeat2 = FeatureList2.size();
    int nFeatAtoms2 = FAtomList2.size();
    int* FeatTypes2 = new int[nFeatAtoms2];
    int* FeatAtomIdx2 = new int[nFeatAtoms2];
    nPos = 0;
    for (int i = 0; i < nFeat2; i++) {
        std::cout << "Feature Name = " << FeatureList2[i] << "\n";
        std::cout << "FANum = " << FANumList2[i] << "\n";
        for (int j = 0; j < FANumList2[i]; j++) {
            FeatTypes2[nPos] = fMaps[FeatureList2[i]];
            FeatAtomIdx2[nPos] = FAtomList2[nPos];
            std::cout << "Feature Atom List " << nPos << ": " << FAtomList2[nPos]
                      << "FeatType = " << FeatTypes2[nPos]
                      << "FeatAtomIdx1 = " << FeatAtomIdx2[nPos] << "\n";
            nPos++;
        }
    }
    int i;
    int i3;
    double cvolume = 0;
    double mvol1 = 0;
    double mvol2 = 0;
    double* xyz1 = new double[NA1 * 3];
    double* xyz2 = new double[NA2 * 3];
    double* vdwR1 = new double[NA1];
    double* vdwR2 = new double[NA2];
    double* w1 = new double[NA1];
    double* w2 = new double[NA2];

    MFCAtom* Atom;
    for (i = 0; i < NA1; i++) {
        i3 = i * 3;
        Atom = Frag1->atomList[i];
        xyz1[i3] = Atom->x;
        xyz1[i3 + 1] = Atom->y;
        xyz1[i3 + 2] = Atom->z;
        vdwR1[i] = Atom->vdwR / 100.0;
        w1[i] = 1.0;
    }
    for (i = 0; i < NA2; i++) {
        i3 = i * 3;
        Atom = Frag2->atomList[i];
        xyz2[i3] = Atom->x;
        xyz2[i3 + 1] = Atom->y;
        xyz2[i3 + 2] = Atom->z;
        vdwR2[i] = Atom->vdwR / 100.0;
        w2[i] = 1.0;
    }

    mvol1 = calMolSelfVolGS(NA1, xyz1, vdwR1, w1, computeWeights, false);
    mvol2 = calMolSelfVolGS(NA2, xyz2, vdwR2, w2, computeWeights, false);
    std::cout << "Before call FGS2: nFeatAtoms1, type = " << nFeatAtoms1
              << FeatTypes1[nFeatAtoms1 - 1] << "\n";
    std::cout << "nFeatAtoms1, type = " << nFeatAtoms1 << FeatTypes1[nFeatAtoms1 - 1] << "\n";
    cvolume = overlayFGSpheres2(NA1, xyz1, vdwR1, w1, NA2, xyz2, vdwR2, w2, nFeatAtoms1, FeatTypes1,
                                FeatAtomIdx1, nFeatAtoms2, FeatTypes2, FeatAtomIdx2, a, b, g, t,
                                true, WF, WV);
    std::cout << "computeWeights= " << computeWeights << "\n";

    //
    // Update Frag1 coordinates according to xyz1
    //

    // to test results, make sure 0-1 === 1-0
    for (i = 0; i < NA1; i++) {
        i3 = i * 3;
        Atom = Frag1->atomList[i];
        Atom->x = xyz1[i3];
        Atom->y = xyz1[i3 + 1];
        Atom->z = xyz1[i3 + 2];
    }
    delete[] xyz1;
    delete[] xyz2;
    delete[] vdwR1;
    delete[] vdwR2;
    delete[] w1;
    delete[] w2;

    return cvolume;
}

//
//
// Find the best overlay of two molecules based on the maximization of
// their overlapping volume and pharmacophore features.
// On return, Frag1 has transformed coordinates.
//
double overlayFGMols_readSimpleSD(simpleMolData* molData1, simpleMolData* molData2, double a,
                                  double b, double g, double* t, bool computeWeights, double* WF,
                                  double* WV) {
    int NA1 = molData1->nAtoms;
    int NA2 = molData2->nAtoms;
    std::vector<int> FAtomList1;
    std::vector<int> FANumList1;
    std::vector<int> FAtomList2;
    std::vector<int> FANumList2;
    std::map<std::string, int> fMaps;

    fMaps[std::string("HBondAcceptor")] = 1;
    fMaps[std::string("HBondDonor")] = 2;
    fMaps[std::string("Hydrophobic")] = 3;
    fMaps[std::string("AromaticRing")] = 4;
    fMaps[std::string("PositiveIonizable")] = 5;
    fMaps[std::string("NegativeIonizable")] = 6;

    std::cout << "fMaps = " << fMaps[std::string("HBondAcceptor")] << "\n";

    //   MolProperties* molPro1 = molData1->getMolPro();
    int nFeatures1 = getIntProperty(molData1->PropertyDoc, "Num_MolFeatures");
    std::vector<std::string> FeatureList1;
    FeatureList1 = getStringPropertyArray(molData1->PropertyDoc, "<MolFeatures>");
    getPropertyIntList(molData1->PropertyDoc, "MolFeaturesAtoms", FANumList1, FAtomList1);
    int nFeat1 = FeatureList1.size();
    int nFeatAtoms1 = FAtomList1.size();
    int* FeatTypes1 = new int[nFeatAtoms1];
    int* FeatAtomIdx1 = new int[nFeatAtoms1];
    int nPos = 0;
    std::cout << "nFeat1 = " << nFeat1 << "\n";
    for (int i = 0; i < nFeat1; i++) {
        std::cout << "Feature Name = " << FeatureList1[i] << "\n";
        std::cout << "FANum = " << FANumList1[i] << "\n";
        for (int j = 0; j < FANumList1[i]; j++) {
            FeatTypes1[nPos] = fMaps[FeatureList1[i]];
            FeatAtomIdx1[nPos] = FAtomList1[nPos];
            std::cout << "Feature Atom List " << nPos << ": " << FAtomList1[nPos]
                      << "FeatType = " << FeatTypes1[nPos]
                      << " FeatAtomIdx1 = " << FeatAtomIdx1[nPos] << "\n";
            nPos++;
        }
    }
    if (nPos != nFeatAtoms1) {
        std::cout << "nPos = " << nPos << "\n";
        std::cout << "nFeatAtoms1 = " << nFeatAtoms1 << "\n";
        exit(0);
    }
    std::cout << "After inital : nFeatAtoms1, type = " << nFeatAtoms1 << FeatTypes1[nFeatAtoms1 - 1]
              << "\n";
    //   MolProperties* molPro2 = molData2->getMolPro();
    int nFeatures2 = getIntProperty(molData2->PropertyDoc, "Num_MolFeatures");
    std::vector<std::string> FeatureList2;
    FeatureList2 = getStringPropertyArray(molData2->PropertyDoc, "<MolFeatures>");
    getPropertyIntList(molData2->PropertyDoc, "MolFeaturesAtoms", FANumList2, FAtomList2);
    int nFeat2 = FeatureList2.size();
    int nFeatAtoms2 = FAtomList2.size();
    int* FeatTypes2 = new int[nFeatAtoms2];
    int* FeatAtomIdx2 = new int[nFeatAtoms2];
    nPos = 0;
    for (int i = 0; i < nFeat2; i++) {
        std::cout << "Feature Name = " << FeatureList2[i] << "\n";
        std::cout << "FANum = " << FANumList2[i] << "\n";
        for (int j = 0; j < FANumList2[i]; j++) {
            FeatTypes2[nPos] = fMaps[FeatureList2[i]];
            FeatAtomIdx2[nPos] = FAtomList2[nPos];
            std::cout << "Feature Atom List " << nPos << ": " << FAtomList2[nPos]
                      << "FeatType = " << FeatTypes2[nPos]
                      << "FeatAtomIdx1 = " << FeatAtomIdx2[nPos] << "\n";
            nPos++;
        }
    }
    int i;
    int i3;
    double cvolume = 0;
    double mvol1 = 0;
    double mvol2 = 0;
    double* xyz1 = new double[NA1 * 3];
    double* xyz2 = new double[NA2 * 3];
    double* vdwR1 = new double[NA1];
    double* vdwR2 = new double[NA2];
    double* w1 = new double[NA1];
    double* w2 = new double[NA2];

    for (i = 0; i < NA1; i++) {
        i3 = i * 3;
        xyz1[i3] = molData1->xyz[i3];
        xyz1[i3 + 1] = molData1->xyz[i3 + 1];
        xyz1[i3 + 2] = molData1->xyz[i3 + 2];
        vdwR1[i] = molData1->vdwR[i] / 100.0;
        w1[i] = 1.0;
    }
    for (i = 0; i < NA2; i++) {
        i3 = i * 3;
        xyz2[i3] = molData2->xyz[i3];
        xyz2[i3 + 1] = molData2->xyz[i3 + 1];
        xyz2[i3 + 2] = molData2->xyz[i3 + 2];
        vdwR2[i] = molData2->vdwR[i] / 100.0;
        w2[i] = 1.0;
    }

    mvol1 = calMolSelfVolGS(NA1, xyz1, vdwR1, w1, computeWeights, false);
    mvol2 = calMolSelfVolGS(NA2, xyz2, vdwR2, w2, computeWeights, false);

    std::cout << "Before call FGS2: nFeatAtoms1, type = " << nFeatAtoms1
              << FeatTypes1[nFeatAtoms1 - 1] << "\n";
    std::cout << "nFeatAtoms1, type = " << nFeatAtoms1 << FeatTypes1[nFeatAtoms1 - 1] << "\n";
    cvolume = overlayFGSpheres2(NA1, xyz1, vdwR1, w1, NA2, xyz2, vdwR2, w2, nFeatAtoms1, FeatTypes1,
                                FeatAtomIdx1, nFeatAtoms2, FeatTypes2, FeatAtomIdx2, a, b, g, t,
                                true, WF, WV);
    std::cout << "computeWeights= " << computeWeights << "\n";

    //
    // Update molData1 coordinates according to xyz1
    //

    // to test results, make sure 0-1 === 1-0
    /*
       for (i=0; i < NA1; i++) {
           i3 = i*3;
           Atom = molData1->atomList[i];
           Atom->x = xyz1[i3];
           Atom->y = xyz1[i3+1];
           Atom->z = xyz1[i3+2];
       }
    */
    delete[] xyz1;
    delete[] xyz2;
    delete[] vdwR1;
    delete[] vdwR2;
    delete[] w1;
    delete[] w2;

    return cvolume;
}

//
// Find the best overlay of two set of Gaussian spheres that the maximization of
// their overlapping can be achieved. Return rotation parameter a,b,g and
// translation vector t.
//
double overlayFGSpheres2(int NA1, double* xyz1, double* alpha1, double* w1, int NA2, double* xyz2,
                         double* alpha2, double* w2, int nFA1, int* FATypes1, int* FAIdx1, int nFA2,
                         int* FATypes2, int* FAIdx2, double a, double b, double g, double* t,
                         bool trans, double* WF, double* WV) {
    //
    // r' = R*r + T
    //
    // r': new position
    // r:  Original position of mol1
    // R:  Rotation matrix
    // T:  Translation
    //
    bool equalR = false;
    int numAtoms = NA1 + NA2;
    int ij;
    int i;
    int i3;
    double pi = 3.14159265358979;
    double p2 = gParam * gParam;
    double dltn;

    double molvol;
    double molvol2;
    double diffVol;
    double dtr[6];
    double da, db, dg;
    double xyz0[3], xyzr[3];
    double r[3][3];
    double xyz[3000];
    double T[3];
    //
    // a, b, g, x, y, z
    //
    double hess[6][6], dx[6];
    double Thresh = 0.01;
    int maxIter = 30;
    double dmax = 0;
    double hessOld[6][6];

    double* cderv = new double[NA1 * 3];
    double* chess = new double[NA1 * 6];
    // Save old coordinates
    for (i = 0; i < NA1; i++) {
        i3 = i * 3;
        xyz[i3] = xyz1[i3];
        xyz[i3 + 1] = xyz1[i3 + 1];
        xyz[i3 + 2] = xyz1[i3 + 2];
    }

    // Apply transformation
    // Initial guess

    T[0] = 0;
    T[1] = 0;
    T[2] = 0;
    a = 0;
    b = 0;
    g = 0;

    int iter = 0;
    molvol2 = 0;
    double damp = 0.5;

    do {
        iter++;
        molvol =
            calDervsCartesian(NA1, xyz1, alpha1, w1, NA2, xyz2, alpha2, w2, cderv, chess, true);

        dervsCartesian2RT(NA1, xyz1, cderv, chess, dtr, hess);

        molvol = molvol * WV[0];
        for (i = 0; i < 6; i++) {
            dtr[i] = dtr[i] * WV[0];
            for (int j = 0; j < 6; j++) {
                hess[i][j] = hess[i][j] * WV[0];
            }
        }

        double cVol[7];
        molvol += calFGDCrossVol(NA1, xyz1, alpha1, w1, NA2, xyz2, alpha2, w2, nFA1, FATypes1,
                                 FAIdx1, nFA2, FATypes2, FAIdx2, dtr, hess, WF, cVol);
        printf("molvol%d : %f\n", iter, molvol);

        double dmaxFactor = 1.0;
        diffVol = fabs(molvol - molvol2);
        dmax = LSolver6x(hess, dtr, dx);
        if (molvol < molvol2) {
            dmaxFactor = 0.5;
        }

        damp = 1.0;
        if (dmax > 0.5 * dmaxFactor) damp = 0.5 * dmaxFactor / dmax;
        molvol2 = molvol;
        a = -damp * dx[0];
        b = -damp * dx[1];
        g = -damp * dx[2];
        T[0] = -damp * dx[3];
        T[1] = -damp * dx[4];
        T[2] = -damp * dx[5];
        // Translation
        RotMat(a, b, g, r);
        for (i = 0; i < NA1; i++) {
            i3 = i * 3;
            Rotation(xyz1 + i3, r, xyzr);
            xyz1[i3] = xyzr[0] + T[0];
            xyz1[i3 + 1] = xyzr[1] + T[1];
            xyz1[i3 + 2] = xyzr[2] + T[2];
        }

    } while (diffVol > Thresh && iter < maxIter);
    printf("diffVol: %f\n", diffVol);

    if (diffVol > Thresh && iter == maxIter) {
        printf("iter: %d, NR method is not converged\n", iter);
    }
    printf("Iter = %d, molVol2 = %10.5f, dmax = %10.5f\n", iter, molvol2, dmax);
    // Copy xyz back to mol
    if (!trans) {
        for (i = 0; i < NA1; i++) {
            i3 = i * 3;
            xyz1[i3] = xyz[i3];
            xyz1[i3 + 1] = xyz[i3 + 1];
            xyz1[i3 + 2] = xyz[i3 + 2];
        }
    }
    return molvol;
}

//
// Find the best overlay of two set of Gaussian spheres that the maximization of
// their overlapping can be achieved. Return rotation parameter a,b,g and
// translation vector t.
//
double overlayFGSpheres(int NA1, double* xyz1, double* alpha1, double* w1, int NA2, double* xyz2,
                        double* alpha2, double* w2, int nFA1, int* FATypes1, int* FAIdx1, int nFA2,
                        int* FATypes2, int* FAIdx2, double a, double b, double g, double* t,
                        bool trans, double* W, double* cVol) {
    //
    // r' = R*r + T
    //
    // r': new position
    // r:  Original position of mol1
    // R:  Rotation matrix
    // T:  Translation
    //
    int ij;
    int i;
    int i3;
    double pi = 3.14159265358979;
    double p2 = gParam * gParam;
    double dltn;

    double molvol;
    double molvol2;
    double diffVol;
    double xyz0[3], xyzr[3];
    double r[3][3];
    double xyz[3000];
    double T[3];
    //
    // a, b, g, x, y, z
    //
    double hess[6][6], dtr[6], dx[6];
    double Thresh = 0.01;
    int maxIter = 30;
    double dmax = 0;
    double hessOld[6][6];

    double* cderv = new double[NA1 * 3];
    double* chess = new double[NA1 * 6];
    // Save old coordinates
    for (i = 0; i < NA1; i++) {
        i3 = i * 3;
        xyz[i3] = xyz1[i3];
        xyz[i3 + 1] = xyz1[i3 + 1];
        xyz[i3 + 2] = xyz1[i3 + 2];
    }

    // Apply transformation
    // Initial guess

    T[0] = 0;
    T[1] = 0;
    T[2] = 0;
    a = 0;
    b = 0;
    g = 0;

    int iter = 0;
    molvol2 = 0;
    double damp = 0.5;

    do {
        iter++;
        for (i = 0; i < 6; i++) {
            dtr[i] = 0;
            for (int j = 0; j < 6; j++) {
                hess[i][j] = 0;
            }
        }

        molvol =
            calDervsCartesian(NA1, xyz1, alpha1, w1, NA2, xyz2, alpha2, w2, cderv, chess, false);

        dervsCartesian2RT(NA1, xyz1, cderv, chess, dtr, hess);

        cVol[0] = molvol;
        molvol = molvol * W[0];

        /*
        // only consider feature overlay
           molvol = 0;
           for(i=0; i<6; i++)
           {
             dtr[i] = 0;
             for(int j=0; j<6; j++)
             {
               hess[i][j] = 0;
             }
           }
        */

        for (i = 0; i < 6; i++) {
            dtr[i] = dtr[i] * W[0];
            for (int j = 0; j < 6; j++) {
                hess[i][j] = hess[i][j] * W[0];
            }
        }

        for (i = 1; i < 7; i++) cVol[i] = 0;

        molvol += calFGDCrossVol(NA1, xyz1, alpha1, w1, NA2, xyz2, alpha2, w2, nFA1, FATypes1,
                                 FAIdx1, nFA2, FATypes2, FAIdx2, dtr, hess, W, cVol);
        // printf("molvol%d : %f\n",iter,molvol);

        double dmaxFactor = 1.0;
        diffVol = fabs(molvol - molvol2);
        dmax = LSolver6x(hess, dtr, dx);
        if (molvol < molvol2) {
            dmaxFactor = 0.5;
        }

        damp = 1.0;
        if (dmax > 0.5 * dmaxFactor) damp = 0.5 * dmaxFactor / dmax;
        molvol2 = molvol;
        a = -damp * dx[0];
        b = -damp * dx[1];
        g = -damp * dx[2];
        T[0] = -damp * dx[3];
        T[1] = -damp * dx[4];
        T[2] = -damp * dx[5];
        // Translation
        RotMat(a, b, g, r);
        for (i = 0; i < NA1; i++) {
            i3 = i * 3;
            Rotation(xyz1 + i3, r, xyzr);
            xyz1[i3] = xyzr[0] + T[0];
            xyz1[i3 + 1] = xyzr[1] + T[1];
            xyz1[i3 + 2] = xyzr[2] + T[2];
        }

    } while (diffVol > Thresh && iter < maxIter);
    // printf("diffVol: %f\n",diffVol);

    /*
       std::cout << "drt: ";
       for(i=0; i<6; i++)
         std::cout << dtr[i] << "\t";
       std::cout << "\n";
    */
    if (diffVol > Thresh && iter == maxIter) {
        // printf("iter: %d, NR method is not converged\n",iter);
    }
    // printf("Iter = %d, molVol2 = %10.5f, dmax = %10.5f\n",iter, molvol2,dmax);
    // Copy xyz back to mol
    if (!trans) {
        for (i = 0; i < NA1; i++) {
            i3 = i * 3;
            xyz1[i3] = xyz[i3];
            xyz1[i3 + 1] = xyz[i3 + 1];
            xyz1[i3 + 2] = xyz[i3 + 2];
        }
    }

    delete[] cderv;
    delete[] chess;
    return molvol;
}

//
// Find the best overlay of two set of Gaussian spheres that the maximization of
// their overlapping can be achieved. Return rotation parameter a,b,g and
// translation vector t.
//
double overlayFGSpheres_ourPharma(int NA1, double* xyz1, double* alpha1, double* w1, int NA2,
                                  double* xyz2, double* alpha2, double* w2, int nFeat1,
                                  int* FeatTypes1, double* featXYZ1, int nDirc1, int* dircTypes1,
                                  double* dircXYZ1, int nFeat2, int* FeatTypes2, double* featXYZ2,
                                  int nDirc2, int* dircTypes2, double* dircXYZ2, bool trans,
                                  bool equalR, double* W, double* cVol, double* diffVolume) 
{
	std::cout << "Trans = " << trans << " equalR = " << equalR << "\n"; 
	for (int i = 0; i < 10; i++) {
		std::cout << "i, W = " << i+1 << " " << W[i] << "\n";
	}
    std::ofstream fout;
    fout.open("test_data.txt");

    fout << NA1 << " ";
    for (int i=0; i < NA1; i++) {
	int i3 = i*3;
	fout << alpha1[i] << " " << w1[i] << " ";
	fout << xyz1[i3] << " ";
	fout << xyz1[i3+1] << " ";
	fout << xyz1[i3+2] << " ";
    }
    fout << NA2 << " ";
    for (int i=0; i < NA2; i++) {
	int i3 = i*3;
	fout << alpha2[i] << " " << w2[i] << " ";
	fout << xyz2[i3] << " ";
	fout << xyz2[i3+1] << " ";
	fout << xyz2[i3+2] << " ";
    }
    fout << nFeat1 << " ";
    for (int i=0; i < nFeat1; i++) {
	int i3 = i*3;
	fout << FeatTypes1[i] << " ";
	fout << featXYZ1[i3] << " ";
	fout << featXYZ1[i3+1] << " ";
	fout << featXYZ1[i3+2] << " ";
    }
    fout << nDirc1 << " ";
    for (int i=0; i < nDirc1; i++) {
	int i3 = i*3;
	fout << dircTypes1[i] << " ";
	fout << dircXYZ1[i3] << " ";
	fout << dircXYZ1[i3+1] << " ";
	fout << dircXYZ1[i3+2] << " ";
    }

    fout << nFeat2 << " ";
    for (int i=0; i < nFeat2; i++) {
	int i3 = i*3;
	fout << FeatTypes2[i] << " ";
	fout << featXYZ2[i3] << " ";
	fout << featXYZ2[i3+1] << " ";
	fout << featXYZ2[i3+2] << " ";
    }
    fout << nDirc2 << " ";
    for (int i=0; i < nDirc2; i++) {
	int i3 = i*3;
	fout << dircTypes2[i] << " ";
	fout << dircXYZ2[i3] << " ";
	fout << dircXYZ2[i3+1] << " ";
	fout << dircXYZ2[i3+2] << " ";
    }

    std::cout << "NA1 = " << NA1 << "\n";
    //
    // r' = R*r + T
    //
    // r': new position
    // r:  Original position of mol1
    // R:  Rotation matrix
    // T:  Translation
    //
    int ij;
    int i;
    int i3;
    double pi = 3.14159265358979;
    double p2 = gParam * gParam;
    double dltn;

    double molvol;
    double molvol2;
    double diffVol;
    double xyz0[3], xyzr[3];
    double r[3][3];
    double xyz[3000];
    double T[3];
    double a, b, g;
    //
    // a, b, g, x, y, z
    //
    double hess[6][6], dtr[6], dx[6];
    double Thresh = 0.01;
    int maxIter = 25;
    double dmax = 0;
    double hessOld[6][6];

    double* cderv = new double[NA1 * 3];
    double* chess = new double[NA1 * 6];
    // Save old coordinates
    for (i = 0; i < NA1; i++) {
        i3 = i * 3;
        xyz[i3] = xyz1[i3];
        xyz[i3 + 1] = xyz1[i3 + 1];
        xyz[i3 + 2] = xyz1[i3 + 2];
    }

    // Apply transformation
    // Initial guess

    T[0] = 0;
    T[1] = 0;
    T[2] = 0;
    a = 0;
    b = 0;
    g = 0;

    int iter = 0;
    molvol2 = 0;
    double damp = 0.5;

    do {
        iter++;
        for (i = 0; i < 6; i++) {
            dtr[i] = 0;
            for (int j = 0; j < 6; j++) {
                hess[i][j] = 0;
            }
        }

        molvol =
            calDervsCartesian(NA1, xyz1, alpha1, w1, NA2, xyz2, alpha2, w2, cderv, chess, equalR);

        dervsCartesian2RT(NA1, xyz1, cderv, chess, dtr, hess);

        cVol[0] = molvol;
        molvol = molvol * W[0];

        for (i = 0; i < 6; i++) {
            dtr[i] = dtr[i] * W[0];
            for (int j = 0; j < 6; j++) {
                hess[i][j] = hess[i][j] * W[0];
            }
        }

        // for test
        /*
           std::cout << "vol derv:\n";
           for(i=0; i<6; i++) std::cout << dtr[i] << "\t";
           std::cout << "\n";
           std::cout << "vol hess:\n";
           for(i=0; i<6; i++)
           {
             for(int j=i; j<6; j++)
             {
               std::cout << hess[i][j] << "\n";
             }
           }
        */

        for (i = 1; i < 10; i++) cVol[i] = 0;

        //printf("iter:%d, shapeCrossVol: %f\t",iter,cVol[0]);
        float tmpVol = molvol;
        molvol += calFGDCrossVol_ourPharma(nFeat1, FeatTypes1, featXYZ1, nDirc1, dircTypes1,
                                           dircXYZ1, nFeat2, FeatTypes2, featXYZ2, nDirc2,
                                           dircTypes2, dircXYZ2, dtr, hess, W, cVol);
        //printf("feature vol: %f\ttotal vol : %f\n",molvol-tmpVol,molvol);

        // for test
        /*
           double shapeSimi = cVol[0]/(240.767 + 243.819 - cVol[0]);
           for(i=1;i<10;i++){
             if(0.001 > W[i])
               continue;
             cVol[i] = cVol[i]/W[i];
           }
           double cVolFeats = 0;
           for(int j=1; j<10; j++){
               cVolFeats  += cVol[j]*W[j];
           }
           double featSimi = cVolFeats/(531.035 + 654.035 - cVolFeats);
           std::cout << "shapeSimi: " << shapeSimi << ", featSimi: " << featSimi << ", simi: " <<
           shapeSimi + featSimi << "\n";
        */

        /*
           // all as one score
           for(i=1;i<10;i++){
             if(0.001 > W[i])
               continue;
             cVol[i] = cVol[i]/W[i];
           }
           double crossVol = 0;
           for(int j=0; j<10; j++){
               crossVol  += cVol[j]*W[j];
           }
           double simi = crossVol/(771.802 + 1594.35 - crossVol);
           std::cout << "crossVol: " << crossVol << ", simi: " << simi << "\n";
        */

        // for test
        /*
           std::cout << "total derv:\n";
           for(i=0; i<6; i++) std::cout << dtr[i] << "\t";
           std::cout << "\n";
           std::cout << "total hess:\n";
           for(i=0; i<6; i++)
           {
             for(int j=i; j<6; j++)
             {
               std::cout << hess[i][j] << "\n";
             }
           }
        */

        double dmaxFactor = 1.0;
        diffVol = fabs(molvol - molvol2);
        // dmax = LSolver6x(hess, dtr, dx);
        dmax = LSolver6(hess, dtr, dx);

        // for test
        // for(i=0; i<6; i++) std::cout << dx[i] << "\n";

        damp = 1.0;
        if (molvol < molvol2) {
            dmaxFactor = 0.5;
        }

        if (dmax > 0.5 * dmaxFactor) damp = 0.5 * dmaxFactor / dmax;
        molvol2 = molvol;
        a = -damp * dx[0];
        b = -damp * dx[1];
        g = -damp * dx[2];
        T[0] = -damp * dx[3];
        T[1] = -damp * dx[4];
        T[2] = -damp * dx[5];
        // Translation
        RotMat(a, b, g, r);
        for (i = 0; i < NA1; i++) {
            i3 = i * 3;
            Rotation(xyz1 + i3, r, xyzr);
            xyz1[i3] = xyzr[0] + T[0];
            xyz1[i3 + 1] = xyzr[1] + T[1];
            xyz1[i3 + 2] = xyzr[2] + T[2];
        }

        for (i = 0; i < nFeat1; i++) {
            i3 = i * 3;
            Rotation(featXYZ1 + i3, r, xyzr);
            featXYZ1[i3] = xyzr[0] + T[0];
            featXYZ1[i3 + 1] = xyzr[1] + T[1];
            featXYZ1[i3 + 2] = xyzr[2] + T[2];
        }

        for (i = 0; i < nDirc1; i++) {
            i3 = i * 3;
            Rotation(dircXYZ1 + i3, r, xyzr);
            dircXYZ1[i3] = xyzr[0] + T[0];
            dircXYZ1[i3 + 1] = xyzr[1] + T[1];
            dircXYZ1[i3 + 2] = xyzr[2] + T[2];
        }

    } while (diffVol > Thresh && iter < maxIter);
    // printf("diffVol: %f; Iter: %d\n",diffVol,iter);
    if (0 != diffVolume) diffVolume[0] = diffVol;

    double molvx = cVol[0];
    for (i = 1; i < 10; i++) {
        if (0.001 > W[i]) continue;
	molvx += cVol[i];
        cVol[i] = cVol[i] / W[i];
    }

    // for test
    /*
       std::cout << "drt: ";
       for(i=0; i<6; i++)
         std::cout << dtr[i] << "\t";
       std::cout << "\n";
    */

    // for(i=1;i<10;i++)
    //  std::cout << cVol[i] << "\t";

    // printf("Iter = %d, molVol2 = %10.5f, dmax = %10.5f\n",iter, molvol2,dmax);
    // Copy xyz back to mol
    if (!trans) {
        for (i = 0; i < NA1; i++) {
            i3 = i * 3;
            xyz1[i3] = xyz[i3];
            xyz1[i3 + 1] = xyz[i3 + 1];
            xyz1[i3 + 2] = xyz[i3 + 2];
        }
    }

    delete[] cderv;
    delete[] chess;

    for (i = 0; i < 10; i++) {
	fout << cVol[i] << " ";
    }
    std::cout << "molvol, molvx = " << molvol << " " << molvx << "\n";
    fout.close();
    test_overlay();
    /*
    overlay_hack(NA1, xyz1, alpha1, w1, NA2, xyz2, alpha2, w2, nFeat1, FeatTypes1, featXYZ1, nDirc1,
		    dircTypes1, dircXYZ1, nFeat2, FeatTypes2, featXYZ2, nDirc2, dircTypes2, dircXYZ2,
		    trans, equalR, W, cVol, diffVolume);
		    */
    return molvol;
}

void test_overlay()
{
     int NA1;
     double* xyz1;
     double* alpha1;
     double* w1;
     int NA2;
     double* xyz2;
     double* alpha2;
     double* w2;
     int nFeat1;
     int* FeatTypes1;
     double* featXYZ1;
     int nDirc1;
     int* dircTypes1;
     double* dircXYZ1;
     int nFeat2;
     int* FeatTypes2;
     double* featXYZ2;
     int nDirc2;
     int* dircTypes2;
     double* dircXYZ2;
     bool trans;
     bool equalR;
     double cVol[10];
     double diffVolume[10];
     double W[10]{1.0,
                  1.0,   // HBA in ownPharma
                  1.0,   // HBD
                  0.5,   // ARO
                  2.0,   // POS
                  2.0,   // NEG
                  2.0,   // HYD
                  1.0,   // for direction of HBA in overlay
                  1.0,   // for direction of HBD
                  0.5};  // for direction of ARO

    std::ifstream fin;
    fin.open("test_data.txt");
    std::string data_str;

    getline(fin, data_str);
    std::cout << data_str << "\n";
    fin.close();
    std::istringstream fin0(data_str);

    fin0 >> NA1;
    alpha1 = new double[NA1];
    w1 = new double[NA1];
    xyz1 = new double[NA1*3];

    for (int i=0; i < NA1; i++) {
	int i3 = i*3;
	fin0 >> alpha1[i];
       	fin0 >> w1[i];
	fin0 >> xyz1[i3];
	fin0 >> xyz1[i3+1];
	fin0 >> xyz1[i3+2];
    }
    fin0 >> NA2;
    alpha2 = new double[NA2];
    w2 = new double[NA2];
    xyz2 = new double[NA2*3];
    for (int i=0; i < NA2; i++) {
	int i3 = i*3;
	fin0 >> alpha2[i];
       	fin0 >> w2[i];
	fin0 >> xyz2[i3];
	fin0 >> xyz2[i3+1];
	fin0 >> xyz2[i3+2];
    }
    fin0 >> nFeat1;
    FeatTypes1 = new int[nFeat1];
    featXYZ1 = new double[nFeat1*3];
    for (int i=0; i < nFeat1; i++) {
	int i3 = i*3;
	fin0 >> FeatTypes1[i];
	fin0 >> featXYZ1[i3];
	fin0 >> featXYZ1[i3+1];
	fin0 >> featXYZ1[i3+2];
    }
    fin0 >> nDirc1;
    dircTypes1 = new int[nDirc1];
    dircXYZ1 = new double[nDirc1*3];
    for (int i=0; i < nDirc1; i++) {
	int i3 = i*3;
	fin0 >> dircTypes1[i];
	fin0 >> dircXYZ1[i3];
	fin0 >> dircXYZ1[i3+1];
	fin0 >> dircXYZ1[i3+2];
    }
    fin0 >> nFeat2;
    FeatTypes2 = new int[nFeat2];
    featXYZ2 = new double[nFeat2*3];
    for (int i=0; i < nFeat2; i++) {
	int i3 = i*3;
	fin0 >> FeatTypes2[i];
	fin0 >> featXYZ2[i3];
	fin0 >> featXYZ2[i3+1];
	fin0 >> featXYZ2[i3+2];
    }
    fin0 >> nDirc2;
    dircTypes2 = new int[nDirc2];
    dircXYZ2 = new double[nDirc2*3];
    for (int i=0; i < nDirc2; i++) {
	int i3 = i*3;
	fin0 >> dircTypes2[i];
	fin0 >> dircXYZ2[i3];
	fin0 >> dircXYZ2[i3+1];
	fin0 >> dircXYZ2[i3+2];
    }
    trans = false;
    equalR = true;

    overlay_hack(NA1, xyz1, alpha1, w1, NA2, xyz2, alpha2, w2, nFeat1, FeatTypes1, featXYZ1, nDirc1,
		    dircTypes1, dircXYZ1, nFeat2, FeatTypes2, featXYZ2, nDirc2, dircTypes2, dircXYZ2,
		    trans, equalR, W, cVol, diffVolume);
    
}

double overlay_hack(int NA1, double* xyz1, double* alpha1, double* w1, int NA2,
                                  double* xyz2, double* alpha2, double* w2, int nFeat1,
                                  int* FeatTypes1, double* featXYZ1, int nDirc1, int* dircTypes1,
                                  double* dircXYZ1, int nFeat2, int* FeatTypes2, double* featXYZ2,
                                  int nDirc2, int* dircTypes2, double* dircXYZ2, bool trans,
                                  bool equalR, double* W, double* cVol, double* diffVolume) 
{
    std::ifstream fin;
    fin.open("test_data.txt");
    std::string data_str;

    getline(fin, data_str);
    std::cout << data_str << "\n";
    fin.close();
    std::istringstream fin0(data_str);

    fin0 >> NA1;
    for (int i=0; i < NA1; i++) {
	int i3 = i*3;
	fin0 >> alpha1[i];
       	fin0 >> w1[i];
	fin0 >> xyz1[i3];
	fin0 >> xyz1[i3+1];
	fin0 >> xyz1[i3+2];
    }
    fin0 >> NA2;
    for (int i=0; i < NA2; i++) {
	int i3 = i*3;
	fin0 >> alpha1[2];
       	fin0 >> w2[i];
	fin0 >> xyz2[i3];
	fin0 >> xyz2[i3+1];
	fin0 >> xyz2[i3+2];
    }
    fin0 >> nFeat1;
    for (int i=0; i < nFeat1; i++) {
	int i3 = i*3;
	fin0 >> FeatTypes1[i];
	fin0 >> featXYZ1[i3];
	fin0 >> featXYZ1[i3+1];
	fin0 >> featXYZ1[i3+2];
    }
    fin0 >> nDirc1;
    for (int i=0; i < nDirc1; i++) {
	int i3 = i*3;
	fin0 >> dircTypes1[i];
	fin0 >> dircXYZ1[i3];
	fin0 >> dircXYZ1[i3+1];
	fin0 >> dircXYZ1[i3+2];
    }
    fin0 >> nFeat2;
    for (int i=0; i < nFeat2; i++) {
	int i3 = i*3;
	fin0 >> FeatTypes2[i];
	fin0 >> featXYZ2[i3];
	fin0 >> featXYZ2[i3+1];
	fin0 >> featXYZ2[i3+2];
    }
    fin0 >> nDirc2;
    for (int i=0; i < nDirc2; i++) {
	int i3 = i*3;
	fin0 >> dircTypes2[i];
	fin0 >> dircXYZ2[i3];
	fin0 >> dircXYZ2[i3+1];
	fin0 >> dircXYZ2[i3+2];
    }

    std::cout << "NA1 = " << NA1 << "\n";
    //
    // r' = R*r + T
    //
    // r': new position
    // r:  Original position of mol1
    // R:  Rotation matrix
    // T:  Translation
    //
    int ij;
    int i;
    int i3;
    double pi = 3.14159265358979;
    double p2 = gParam * gParam;
    double dltn;

    double molvol;
    double molvol2;
    double diffVol;
    double xyz0[3], xyzr[3];
    double r[3][3];
    double xyz[3000];
    double T[3];
    double a, b, g;
    //
    // a, b, g, x, y, z
    //
    double hess[6][6], dtr[6], dx[6];
    double Thresh = 0.01;
    int maxIter = 25;
    double dmax = 0;
    double hessOld[6][6];

    double* cderv = new double[NA1 * 3];
    double* chess = new double[NA1 * 6];
    // Save old coordinates
    for (i = 0; i < NA1; i++) {
        i3 = i * 3;
        xyz[i3] = xyz1[i3];
        xyz[i3 + 1] = xyz1[i3 + 1];
        xyz[i3 + 2] = xyz1[i3 + 2];
    }

    // Apply transformation
    // Initial guess

    T[0] = 0;
    T[1] = 0;
    T[2] = 0;
    a = 0;
    b = 0;
    g = 0;

    int iter = 0;
    molvol2 = 0;
    double damp = 0.5;

    do {
        iter++;
        for (i = 0; i < 6; i++) {
            dtr[i] = 0;
            for (int j = 0; j < 6; j++) {
                hess[i][j] = 0;
            }
        }

        molvol =
            calDervsCartesian(NA1, xyz1, alpha1, w1, NA2, xyz2, alpha2, w2, cderv, chess, equalR);

        dervsCartesian2RT(NA1, xyz1, cderv, chess, dtr, hess);

        cVol[0] = molvol;
        molvol = molvol * W[0];

        for (i = 0; i < 6; i++) {
            dtr[i] = dtr[i] * W[0];
            for (int j = 0; j < 6; j++) {
                hess[i][j] = hess[i][j] * W[0];
            }
        }

        for (i = 1; i < 10; i++) cVol[i] = 0;

        //printf("iter:%d, shapeCrossVol: %f\t",iter,cVol[0]);
        float tmpVol = molvol;
        molvol += calFGDCrossVol_ourPharma(nFeat1, FeatTypes1, featXYZ1, nDirc1, dircTypes1,
                                           dircXYZ1, nFeat2, FeatTypes2, featXYZ2, nDirc2,
                                           dircTypes2, dircXYZ2, dtr, hess, W, cVol);
        //printf("feature vol: %f\ttotal vol : %f\n",molvol-tmpVol,molvol);

        double dmaxFactor = 1.0;
        diffVol = fabs(molvol - molvol2);
        // dmax = LSolver6x(hess, dtr, dx);
        dmax = LSolver6(hess, dtr, dx);

        damp = 1.0;
        if (molvol < molvol2) {
            dmaxFactor = 0.5;
        }

        if (dmax > 0.5 * dmaxFactor) damp = 0.5 * dmaxFactor / dmax;
        molvol2 = molvol;
        a = -damp * dx[0];
        b = -damp * dx[1];
        g = -damp * dx[2];
        T[0] = -damp * dx[3];
        T[1] = -damp * dx[4];
        T[2] = -damp * dx[5];
        // Translation
        RotMat(a, b, g, r);
        for (i = 0; i < NA1; i++) {
            i3 = i * 3;
            Rotation(xyz1 + i3, r, xyzr);
            xyz1[i3] = xyzr[0] + T[0];
            xyz1[i3 + 1] = xyzr[1] + T[1];
            xyz1[i3 + 2] = xyzr[2] + T[2];
        }

        for (i = 0; i < nFeat1; i++) {
            i3 = i * 3;
            Rotation(featXYZ1 + i3, r, xyzr);
            featXYZ1[i3] = xyzr[0] + T[0];
            featXYZ1[i3 + 1] = xyzr[1] + T[1];
            featXYZ1[i3 + 2] = xyzr[2] + T[2];
        }

        for (i = 0; i < nDirc1; i++) {
            i3 = i * 3;
            Rotation(dircXYZ1 + i3, r, xyzr);
            dircXYZ1[i3] = xyzr[0] + T[0];
            dircXYZ1[i3 + 1] = xyzr[1] + T[1];
            dircXYZ1[i3 + 2] = xyzr[2] + T[2];
        }

    } while (diffVol > Thresh && iter < maxIter);
    // printf("diffVol: %f; Iter: %d\n",diffVol,iter);
    if (0 != diffVolume) diffVolume[0] = diffVol;

    double molvx = cVol[0];
    for (i = 1; i < 10; i++) {
        if (0.001 > W[i]) continue;
	molvx += cVol[i];
        cVol[i] = cVol[i] / W[i];
    }

    // Copy xyz back to mol
    if (!trans) {
        for (i = 0; i < NA1; i++) {
            i3 = i * 3;
            xyz1[i3] = xyz[i3];
            xyz1[i3 + 1] = xyz[i3 + 1];
            xyz1[i3 + 2] = xyz[i3 + 2];
        }
    }

    delete[] cderv;
    delete[] chess;

    std::cout << "molvol, molvx = " << molvol << " " << molvx << "\n";
    fin.close();
    return molvol;
}

double calHSMolCrossVolumeMC(MFCFrag* Frag1, MFCFrag* Frag2) {
    int na1 = Frag1->numAtoms;
    int na2 = Frag2->numAtoms;
    int nAtoms = na1 + na2;
    double vol = 0;
    double* xyz = new double[nAtoms * 3];
    double* vdwR = new double[nAtoms];
    double volume;
    int i;
    setMFCAtomVDW(Frag1);
    setMFCAtomVDW(Frag2);
    MFCAtom* Atom;
    for (int i = 0; i < na1; i++) {
        Atom = Frag1->atomList[i];
        xyz[i * 3] = Atom->x;
        xyz[i * 3 + 1] = Atom->y;
        xyz[i * 3 + 2] = Atom->z;
        vdwR[i] = Atom->vdwR / 100.0;
    }
    for (int i = 0; i < na2; i++) {
        Atom = Frag2->atomList[i];
        xyz[(i + na1) * 3] = Atom->x;
        xyz[(i + na1) * 3 + 1] = Atom->y;
        xyz[(i + na1) * 3 + 2] = Atom->z;
        vdwR[i + na1] = Atom->vdwR / 100.0;
    }
    double VolA = calHSMolVolumeMC(Frag1);
    double VolB = calHSMolVolumeMC(Frag2);
    double VolC = calHSVolumeMC(nAtoms, xyz, vdwR);
    delete[] xyz;
    delete[] vdwR;
    volume = VolA + VolB - VolC;
    return volume;
}

struct cube {
    double x0;
    double y0;
    double z0;
    double length;
    int nAtoms;
    std::vector<int> atomList;
};

//
//  Calculate Hard Sphere molecular volume using multi-level cut algorithm
//
//  By JL
//
double calHSMolVolumeMC(MFCFrag* mfcFrag) {
    int nAtoms = mfcFrag->numAtoms;
    double* xyz = new double[nAtoms * 3];
    double* vdwR = new double[nAtoms];
    double volume = 0;

    setMFCAtomVDW(mfcFrag);
    MFCAtom* Atom;
    for (int i = 0; i < nAtoms; i++) {
        Atom = mfcFrag->atomList[i];
        xyz[i * 3] = Atom->x;
        xyz[i * 3 + 1] = Atom->y;
        xyz[i * 3 + 2] = Atom->z;
        vdwR[i] = Atom->vdwR / 100.0;
    }
    volume = calHSVolumeMC(nAtoms, xyz, vdwR);
    delete[] xyz;
    delete[] vdwR;
    return volume;
}

double calHSVolumeMC(int nAtoms, double* xyz, double* vdwR) {
    double minr = 0.03126 / 2;
    double x, y, z, x1, y1, z1;
    double volume = 0;
    double xmax = -10000000.0;
    double xmin = 10000000.0;
    double ymax = -10000000.0;
    double ymin = 10000000.0;
    double zmax = -10000000.0;
    double zmin = 10000000.0;
    double rmax = 0;
    int cutLevel = 20;
    int cutNumber = 2;
    std::vector<cube*> cubes;
    std::vector<cube*> cube2;
    // to do: create box
    for (int i = 0; i < nAtoms; i++) {
        if (rmax < vdwR[i]) rmax = vdwR[i];
        if (xmax < xyz[i * 3]) xmax = xyz[i * 3];
        if (ymax < xyz[i * 3 + 1]) ymax = xyz[i * 3 + 1];
        if (zmax < xyz[i * 3 + 2]) zmax = xyz[i * 3 + 2];
        if (xmin > xyz[i * 3]) xmin = xyz[i * 3];
        if (ymin > xyz[i * 3 + 1]) ymin = xyz[i * 3 + 1];
        if (zmin > xyz[i * 3 + 2]) zmin = xyz[i * 3 + 2];
    }
    xmax = xmax + rmax;
    xmin = xmin - rmax;
    ymax = ymax + rmax;
    ymin = ymin - rmax;
    zmax = zmax + rmax;
    zmin = zmin - rmax;
    double length = xmax - xmin;
    if (length < ymax - ymin) length = ymax - ymin;
    if (length < zmax - zmin) length = zmax - zmin;
    if (length < 32) length = 32;
    double hsqrt3 = sqrt(3.0) / 2.0;
    double r3;
    //
    // Now, create the initial cube
    //
    cube* box = new cube();
    box->x0 = xmin;
    box->y0 = ymin;
    box->z0 = zmin;
    box->length = length;
    box->nAtoms = nAtoms;
    for (int i = 0; i < nAtoms; i++) box->atomList.push_back(i);
    cubes.push_back(box);

    // Now, start multi-level box cuts, do until box size is smaller than minr

    int nBoxes = cubes.size();
    int sType;
    bool lastcut = false;
    int lastboxes = 0;
    do {
        length = length / cutNumber;
        if (length <= minr) lastcut = true;
        for (int i = 0; i < nBoxes; i++) {
            box = cubes[i];
            r3 = length * hsqrt3;
            int boxAtoms = box->atomList.size();
            // std::cout << "boxAtoms = " << boxAtoms << "\n";
            for (int j = 0; j < cutNumber; j++) {
                x = box->x0 + j * length;
                for (int k = 0; k < cutNumber; k++) {
                    y = box->y0 + k * length;
                    for (int m = 0; m < cutNumber; m++) {
                        z = box->z0 + m * length;
                        cube* box0 = 0;
                        if (!lastcut) {
                            box0 = new cube();
                            box0->x0 = x;
                            box0->y0 = y;
                            box0->z0 = z;
                            box0->length = length;
                        }
                        x1 = x + 0.5 * length;
                        y1 = y + 0.5 * length;
                        z1 = z + 0.5 * length;
                        //
                        // Check small box type by box-center-atom-center distances
                        //
                        sType = 0;
                        for (int l = 0; l < boxAtoms; l++) {
                            int la = box->atomList[l];
                            int la3 = la * 3;
                            double dist = sqrt((x1 - xyz[la3]) * (x1 - xyz[la3]) +
                                               (y1 - xyz[la3 + 1]) * (y1 - xyz[la3 + 1]) +
                                               (z1 - xyz[la3 + 2]) * (z1 - xyz[la3 + 2]));
                            if (dist + r3 <= vdwR[la]) {
                                // Type I, in sphere
                                volume += length * length * length;
                                sType = 1;
                                break;
                            } else if (dist - r3 < vdwR[la]) {
                                // Possible Type III, possible intersect with spheres
                                if (lastcut) {
                                    sType = 3;  // not break loop, it can be Type I
                                } else {
                                    box0->atomList.push_back(la);
                                }
                            }
                        }  // loop over neighbor atoms of the current box
                        if (!lastcut) {
                            if (box0->atomList.size() > 0 && sType != 1)
                                cube2.push_back(box0);
                            else
                                delete box0;

                        } else {
                            // Count Type III boxes for last cut
                            if (sType == 3) lastboxes++;
                        }
                    }  // cut x
                }      // cut y
            }          // cut z
            // Delete old box
            delete box;
        }  // loop over boxes
        //
        // clean up vectors
        //
        cubes.resize(0);
        nBoxes = cube2.size();
        for (int i = 0; i < nBoxes; i++) {
            cubes.push_back(cube2[i]);
        }
        cube2.resize(0);
        // std::cout << "volume = " << volume << "\n";
    } while (length > minr);
    volume = volume + lastboxes * length * length * length *
                          0.5;  // lastboxes is the number of box possible intersect with atoms
    // volume = volume+nBoxes*length*length*length*0.5;
    // std::cout << "length = " << length << "\n";
    // std::cout << "Final volume = " << volume << "\n";
    //
    return volume;
}

//
// Find neighbor atom list around boxes
//
NBAtomBoxes* findNeighborAtoms(MFCFrag* mfcFrag) {
    int nAtoms = mfcFrag->numAtoms;
    double* xyz = new double[nAtoms * 3];
    double xmax = -10000000.0;
    double xmin = 10000000.0;
    double ymax = -10000000.0;
    double ymin = 10000000.0;
    double zmax = -10000000.0;
    double zmin = 10000000.0;
    int tmpAtoms[2000][200];
    int nx, ny, nz;
    int L = 4;
    if (nAtoms > 200) {
        std::cout << "No more than 200 atoms \n";
        exit(0);
    }

    MFCAtom* Atom;
    for (int i = 0; i < nAtoms; i++) {
        Atom = mfcFrag->atomList[i];
        xyz[i * 3] = Atom->x;
        xyz[i * 3 + 1] = Atom->y;
        xyz[i * 3 + 2] = Atom->z;
    }
    // to do: create box
    for (int i = 0; i < nAtoms; i++) {
        if (xmax < xyz[i * 3]) xmax = xyz[i * 3];
        if (ymax < xyz[i * 3 + 1]) ymax = xyz[i * 3 + 1];
        if (zmax < xyz[i * 3 + 2]) zmax = xyz[i * 3 + 2];
        if (xmin > xyz[i * 3]) xmin = xyz[i * 3];
        if (ymin > xyz[i * 3 + 1]) ymin = xyz[i * 3 + 1];
        if (zmin > xyz[i * 3 + 2]) zmin = xyz[i * 3 + 2];
    }
    NBAtomBoxes* atomBoxes = new NBAtomBoxes();
    atomBoxes->x0 = xmin - 0.01;
    atomBoxes->y0 = ymin - 0.01;
    atomBoxes->z0 = zmin - 0.01;
    atomBoxes->nx = (int)(xmax - xmin + 1.01);
    atomBoxes->ny = (int)(ymax - ymin + 1.01);
    atomBoxes->nz = (int)(zmax - zmin + 1.01);
    nx = atomBoxes->nx;
    ny = atomBoxes->ny;
    nz = atomBoxes->nz;

    int nBoxes = atomBoxes->nx * atomBoxes->ny * atomBoxes->nz;

    if (nBoxes > 2000) {
        std::cout << "No more than 1000 boxes \n";
        exit(0);
    }
    atomBoxes->startIndexes = new int[nBoxes + 1];
    int* nboxAtoms = new int[nBoxes];
    for (int i = 0; i < nBoxes; i++) {
        nboxAtoms[i] = 0;
    }
    for (int i = 0; i < nAtoms; i++) {
        int nx0 = (int)(xyz[i * 3] - atomBoxes->x0);
        int ny0 = (int)(xyz[i * 3 + 1] - atomBoxes->y0);
        int nz0 = (int)(xyz[i * 3 + 2] - atomBoxes->z0);
        int nx00 = nx0 - L;
        int nx01 = nx0 + L;
        int ny00 = ny0 - L;
        int ny01 = ny0 + L;
        int nz00 = nz0 - L;
        int nz01 = nz0 + L;
        if (nx00 < 0) nx00 = 0;
        if (nx01 >= nx) nx01 = nx - 1;
        if (ny00 < 0) ny00 = 0;
        if (ny01 >= ny) ny01 = ny - 1;
        if (nz00 < 0) nz00 = 0;
        if (nz01 >= nz) nz01 = nz - 1;
        for (int j = nx00; j <= nx01; j++) {
            int jj = j * ny * nz;
            for (int k = ny00; k <= ny01; k++) {
                int kk = jj + k * nz;
                for (int m = nz00; m <= nz01; m++) {
                    int mm = kk + m;
                    tmpAtoms[mm][nboxAtoms[mm]] = i;
                    nboxAtoms[mm]++;
                }
            }
        }
    }
    int neAtoms = 0;
    for (int i = 0; i < nBoxes; i++) {
        atomBoxes->startIndexes[i] = neAtoms;
        neAtoms = neAtoms + nboxAtoms[i];
    }
    atomBoxes->startIndexes[nBoxes] = neAtoms;
    atomBoxes->nbAtomList = new int[neAtoms];

    for (int i = 0; i < nBoxes; i++) {
        for (int j = atomBoxes->startIndexes[i]; j < atomBoxes->startIndexes[i + 1]; j++) {
            int jj = j - atomBoxes->startIndexes[i];
            atomBoxes->nbAtomList[j] = tmpAtoms[i][jj];
        }
    }

    printf("neAtoms: %d\n", neAtoms);
    delete[] nboxAtoms;
    return atomBoxes;
}

// for the fitting of param K in GS Weight calculation
double calMolSelfVolGS_fitK(int nSpheres, double* xyz, double* vdwR, double* weights, double* gVols,
                            double* alpha, bool getW, bool equalR, double k) {
    bool noWeights = false;
    bool nogVols = false;
    bool noalpha = false;

    int i3, j3, ij;
    double sab = 0;
    double dist2 = 0;
    double kn;
    double tmpd;
    double factor1 = k;
    double pi = 3.14159265358979;
    // double p2 = gParam*gParam;
    // double gfactor = 4.0*pi/(3.0*gParam);
    // gfactor = pi/(pow(gfactor,0.66666666666667));
    double p2 = 7.99984656;
    double gfactor = 2.417972471923026;
    double VDWR = 1.8;

    double* selfv = new double[nSpheres];
    double* s1 = new double[nSpheres];
    for (int i = 0; i < nSpheres; i++) {
        selfv[i] = 0.0;
        s1[i] = 0.0;
    }

    if (weights == 0) {
        noWeights = true;
        weights = new double[nSpheres];
    }

    if (equalR) {
        if (0 == alpha) alpha = new double[nSpheres];

        double alphaAll = gfactor / (VDWR * VDWR);
        double alphaAllH = alphaAll / 2;
        double alphaAll2 = alphaAll * 2;
        if (0 == gVols) {
            gVols = new double[nSpheres * (nSpheres + 1) / 2];
            nogVols = true;
        }

        ij = 0;
        for (int i = 0; i < nSpheres; i++) {
            alpha[i] = alphaAll;
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                dist2 = (xyz[i3] - xyz[j3]) * (xyz[i3] - xyz[j3]) +
                        (xyz[i3 + 1] - xyz[j3 + 1]) * (xyz[i3 + 1] - xyz[j3 + 1]) +
                        (xyz[i3 + 2] - xyz[j3 + 2]) * (xyz[i3 + 2] - xyz[j3 + 2]);
                // if(dist2 > 16) continue;
                kn = exp(-alphaAllH * dist2);
                gVols[ij] = p2 * kn * pow(pi / alphaAll2, 1.5);
                if (i == j)
                    selfv[i] = gVols[ij];
                else {
                    s1[i] += gVols[ij];
                    s1[j] += gVols[ij];
                }
                ij = ij + 1;
            }
        }
    } else {
        if (0 == alpha) {
            alpha = new double[nSpheres];
            noalpha = true;
        }
        if (0 == gVols) {
            gVols = new double[nSpheres * (nSpheres + 1) / 2];
            nogVols = true;
        }

        for (int i = 0; i < nSpheres; i++) {
            alpha[i] = gfactor / (vdwR[i] * vdwR[i]);
        }

        ij = 0;
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                dist2 = (xyz[i3] - xyz[j3]) * (xyz[i3] - xyz[j3]) +
                        (xyz[i3 + 1] - xyz[j3 + 1]) * (xyz[i3 + 1] - xyz[j3 + 1]) +
                        (xyz[i3 + 2] - xyz[j3 + 2]) * (xyz[i3 + 2] - xyz[j3 + 2]);
                // if(dist2 > 16) continue;
                tmpd = alpha[i] + alpha[j];
                kn = exp(-alpha[i] * alpha[j] * dist2 / tmpd);
                gVols[ij] = p2 * kn * pow(pi / tmpd, 1.5);
                if (i == j)
                    selfv[i] = gVols[ij];
                else {
                    s1[i] += gVols[ij];
                    s1[j] += gVols[ij];
                }
                ij = ij + 1;
            }
        }
    }

    /*
       // addup atom volume
       double addup = 0;
       for(int i=0; i< nSpheres; i++)
         addup +=selfv[i];

       std::cout << "addup: " << addup << "\n";
    */

    //
    // Set up weights
    //
    if (getW) {
        for (int i = 0; i < nSpheres; i++) {
            s1[i] = s1[i] / selfv[i];
            weights[i] = 1.0 / (1.0 + factor1 * s1[i]);
            /*###############################################################
            # because weights < 1.0, so sqaure weights will decrease the small one
            # more than the big one
            # this will indirectly reflect the position of atom,
            # the surface atom will be enphasized(its weight is the big one)
            #################################################################*/
            // weights[i] = weights[i]*weights[i];

            // std::cout << "i = " << i+1 << " " << s1[i] << " " << weights[i] << "\n";
        }
    } else  // do not consider weights
    {
        for (int i = 0; i < nSpheres; i++) {
            weights[i] = 1.0;
        }
    }

    //
    // Recalculate weighted volume
    //
    ij = 0;
    sab = 0;
    for (int i = 0; i < nSpheres; i++) {
        for (int j = 0; j < i + 1; j++) {
            if (i == j)
                sab += gVols[ij] * weights[i] * weights[i];
            else
                sab += 2 * gVols[ij] * weights[i] * weights[j];
            ij = ij + 1;
        }
    }

    if (noalpha) delete[] alpha;

    if (nogVols) delete[] gVols;

    delete[] selfv;
    delete[] s1;
    if (noWeights) delete[] weights;
    return sab;
}

double calGDCrossVol(int na1, double* xyz1, double* vdwR1, double* w1, int na2, double* xyz2,
                     double* vdwR2, double* w2, double* cderv, bool computeCderv) {
    //
    // First, build neighbor list
    //
    int i3, j3;
    int numAtoms = na1 + na2;
    double dist;
    double dCutoff = 10;
    double mindist;
    double base;
    double pi = 3.14159265358979;
    int* gPairs = new int[2 * na1 * na2];
    double* alpha1 = new double[na1];
    double* alpha2 = new double[na2];
    double* gDist = new double[na1 * na2];

    double p2 = gParam * gParam;
    double gfactor = 4.0 * pi / (3.0 * gParam);
    gfactor = pi / (pow(gfactor, 0.66666666666667));
    double rn[3];

    // Set zero
    for (int i = 0; i < na1 * 3; i++) {
        cderv[i] = 0;
    }

    for (int i = 0; i < na1; i++) {
        alpha1[i] = gfactor / (vdwR1[i] * vdwR1[i]);
    }
    for (int i = 0; i < na2; i++) {
        alpha2[i] = gfactor / (vdwR2[i] * vdwR2[i]);
    }
    int ij = 0;
    int ij1 = 0;
    for (int i = 0; i < na1; i++) {
        i3 = i * 3;
        for (int j = 0; j < na2; j++) {
            j3 = j * 3;
            ij1 = ij * 2;
            gPairs[ij1] = i;
            gPairs[ij1 + 1] = j;
            dist = sqrt((xyz1[i3] - xyz2[j3]) * (xyz1[i3] - xyz2[j3]) +
                        (xyz1[i3 + 1] - xyz2[j3 + 1]) * (xyz1[i3 + 1] - xyz2[j3 + 1]) +
                        (xyz1[i3 + 2] - xyz2[j3 + 2]) * (xyz1[i3 + 2] - xyz2[j3 + 2]));
            gDist[ij] = dist;
            ij = ij + 1;
        }
    }
    int a, b, ab;
    double kn;
    double tmpd;
    double dltn = 0;
    double crossVol = 0;
    for (int i = 0; i < na1 * na2; i++) {
        a = gPairs[i * 2];
        b = gPairs[i * 2 + 1];
        i3 = a * 3;
        j3 = b * 3;
        ab = b * (b - 1) / 2 + a;
        tmpd = alpha1[a] + alpha2[b];
        rn[0] = (xyz1[i3] * alpha1[a] + xyz2[j3] * alpha2[b]) / tmpd;
        rn[1] = (xyz1[i3 + 1] * alpha1[a] + xyz2[j3 + 1] * alpha2[b]) / tmpd;
        rn[2] = (xyz1[i3 + 2] * alpha1[a] + xyz2[j3 + 2] * alpha2[b]) / tmpd;
        dltn = tmpd;
        kn = exp(-alpha1[a] * alpha2[b] * gDist[i] * gDist[i] / tmpd);
        tmpd = w1[a] * w2[b] * p2 * kn * pow(pi / tmpd, 1.5);

        crossVol += tmpd;
        /*
          printf("dist2: %f, kn: %f, alpha: %f, qalpha: %f, vol: %f, w1: %f, w2:
          %f\n",gDist[i]*gDist[i],kn,alpha1[a],alpha2[b],crossVol,w1[a],w2[b]);
        */
        if (computeCderv) {
            cderv[i3] += 2 * alpha1[a] * tmpd * (xyz1[i3] - rn[0]);
            cderv[i3 + 1] += 2 * alpha1[a] * tmpd * (xyz1[i3 + 1] - rn[1]);
            cderv[i3 + 2] += 2 * alpha1[a] * tmpd * (xyz1[i3 + 2] - rn[2]);
        }
    }

    delete[] alpha1;
    delete[] alpha2;
    delete[] gPairs;
    delete[] gDist;
    return crossVol;
}

double calGGradient(int NA1, double* xyz1, double* vdwR1, double* w1, int NA2, double* xyz2,
                    double* vdwR2, double* w2, double* dtr, double* rt, bool computeGrad) {
    int numAtoms = NA1 + NA2;
    int ij;
    int i;
    int i3;
    double molvol;
    double cx1, cy1, cz1;
    double cx2, cy2, cz2;
    double dxyza[3];
    double da, db, dg;
    double xyz0[3], xyzr[3];
    double r[3][3], dra[3][3], drb[3][3], drg[3][3], dr2ab[3][3];
    double dr2ag[3][3], dr2bg[3][3];
    double dr2aa[3][3], dr2bb[3][3], dr2gg[3][3];
    double* cderv = new double[NA1 * 3];
    double* xyz = new double[numAtoms * 3];
    double* vdwR = new double[numAtoms];

    // cx1=0;
    // cy1=0;
    // cz1=0;
    // cx2=0;
    // cy2=0;
    // cz2=0;
    for (i = 0; i < NA1; i++) {
        i3 = i * 3;
        xyz[i3] = xyz1[i3];
        xyz[i3 + 1] = xyz1[i3 + 1];
        xyz[i3 + 2] = xyz1[i3 + 2];
        vdwR[i] = vdwR1[i];
        //  cx1 += xyz[i3];
        //  cy1 += xyz[i3+1];
        //  cz1 += xyz[i3+2];
    }
    for (i = 0; i < NA2; i++) {
        int i23 = i * 3;
        i3 = (NA1 + i) * 3;
        xyz[i3] = xyz2[i23];
        xyz[i3 + 1] = xyz2[i23 + 1];
        xyz[i3 + 2] = xyz2[i23 + 2];
        vdwR[NA1 + i] = vdwR2[i];
        // cx2 += xyz[i3];
        // cy2 += xyz[i3+1];
        // cz2 += xyz[i3+2];
    }
    //   cx1 = cx1/NA1;
    //   cy1 = cy1/NA1;
    //   cz1 = cz1/NA1;
    //   cx2 = cx2/NA2;
    //   cy2 = cy2/NA2;
    //   cz2 = cz2/NA2;

    /*
       for (i=0; i < NA1; i++) {
           i3 = i*3;
    //       xyz1[i3]   -= cx1;
    //       xyz1[i3+1] -= cy1;
    //       xyz1[i3+2] -= cz1;
           xyz[i3]   = xyz1[i3];
           xyz[i3+1] = xyz1[i3+1];
           xyz[i3+2] = xyz1[i3+2];
          // printf("xyz1: %f, %f, %f\n",xyz[i3],xyz[i3+1],xyz[i3+2]);
       }

       for (i=0; i < NA2; i++) {
           int i23 = i*3;
           i3 = (NA1+i)*3;
    //       xyz2[i23]   -= cx2;
    //       xyz2[i23+1] -= cy2;
    //       xyz2[i23+2] -= cz2;
           xyz[i3]   = xyz2[i23];
           xyz[i3+1] = xyz2[i23+1];
           //xyz[i3+2] = xyz2[123+2]; !!!
           xyz[i3+2] = xyz2[i23+2];
         //  printf("xyz0: %f, %f, %f\n",xyz[i3],xyz[i3+1],xyz[i3+2]);
       }
    */
    /*
       for (i=0; i < NA2; i++) {
           printf("w0: %f\n",w2[i]);
       }
    */
    // Apply transformation
    // Initial guess

    Euler2Mat(rt[0], rt[1], rt[2], r, dra, drb, drg, dr2ab, dr2ag, dr2bg, dr2aa, dr2bb, dr2gg);

    for (i = 0; i < NA1; i++) {
        i3 = i * 3;
        xyz0[0] = xyz1[i3];
        xyz0[1] = xyz1[i3 + 1];
        xyz0[2] = xyz1[i3 + 2];
        Rotation(xyz0, r, xyzr);
        // printf("xyzr%d: %f, %f, %f\n",i,xyzr[0],xyzr[1],xyzr[2]);
        xyz[i3] = xyzr[0] + rt[3];
        xyz[i3 + 1] = xyzr[1] + rt[4];
        xyz[i3 + 2] = xyzr[2] + rt[5];
        //     printf("xyzt%d: %f, %f, %f\n",i,xyz[i3],xyz[i3+1],xyz[i3+2]);
    }
    molvol =
        calGDCrossVol(NA1, xyz, vdwR, w1, NA2, xyz + 3 * NA1, vdwR + NA1, w2, cderv, computeGrad);
    if (computeGrad) {
        // Compute dtr
        for (i = 0; i < 3; i++) {
            dtr[3 + i] = 0;
            for (int j = 0; j < NA1; j++) {
                dtr[3 + i] += cderv[j * 3 + i];
            }
        }

        da = 0.0;
        // Compute da
        for (i = 0; i < NA1; i++) {
            i3 = i * 3;
            xyz0[0] = xyz1[i3];
            xyz0[1] = xyz1[i3 + 1];
            xyz0[2] = xyz1[i3 + 2];
            Rotation(xyz0, dra, dxyza);
            for (int j = 0; j < 3; j++) {
                da = da + cderv[i3 + j] * dxyza[j];
            }
        }

        db = 0.0;
        for (i = 0; i < NA1; i++) {
            i3 = i * 3;
            xyz0[0] = xyz1[i3];
            xyz0[1] = xyz1[i3 + 1];
            xyz0[2] = xyz1[i3 + 2];
            Rotation(xyz0, drb, dxyza);
            for (int j = 0; j < 3; j++) {
                db = db + cderv[i3 + j] * dxyza[j];
            }
        }

        dg = 0.0;
        for (i = 0; i < NA1; i++) {
            i3 = i * 3;
            xyz0[0] = xyz1[i3];
            xyz0[1] = xyz1[i3 + 1];
            xyz0[2] = xyz1[i3 + 2];
            Rotation(xyz0, drg, dxyza);
            for (int j = 0; j < 3; j++) {
                dg = dg + cderv[i3 + j] * dxyza[j];
            }
        }

        dtr[0] = da;
        dtr[1] = db;
        dtr[2] = dg;
    }

    delete[] xyz;
    delete[] vdwR;
    delete[] cderv;
    // minus the gradient and volume, and the |minimum volume| will be the max volume
    for (int i = 0; i < 6; i++) {
        // dtr[i] = -dtr[i];
    }
    return -molvol;
}

// to do: CG method to optimize overlapping volume
double optimizeOverlapVol(MFCFrag* Frag1, MFCFrag* Frag2, bool onlyHeavyAtoms, double* selfVol) {
    int NA1 = getNSpheres(Frag1, onlyHeavyAtoms);
    int NA2 = getNSpheres(Frag2, onlyHeavyAtoms);

    int i;
    int i3;
    double* xyz1 = new double[NA1 * 3];
    double* xyz2 = new double[NA2 * 3];
    double* vdwR1 = new double[NA1];
    double* vdwR2 = new double[NA2];
    double* w1 = new double[NA1];
    double* w2 = new double[NA2];

    /*
    MFCAtom* Atom;
    for (i=0; i < NA1; i++) {
        i3 = i*3;
        Atom = Frag1->atomList[i];
        xyz1[i3]   = Atom->x;
        xyz1[i3+1] = Atom->y;
        xyz1[i3+2] = Atom->z;
        vdwR1[i]   = Atom->vdwR/100.0;
    }
    for (i=0; i < NA2; i++) {
        i3 = i*3;
        Atom = Frag2->atomList[i];
        xyz2[i3]   = Atom->x;
        xyz2[i3+1] = Atom->y;
        xyz2[i3+2] = Atom->z;
        vdwR2[i]  = Atom->vdwR/100.0;
    }
    */
    getFragXYZVDWR(Frag1, xyz1, vdwR1, onlyHeavyAtoms, true);
    getFragXYZVDWR(Frag2, xyz2, vdwR2, onlyHeavyAtoms, true);

    double mvol1 = calMolSelfVolGS(NA1, xyz1, vdwR1, w1, true, false);
    double mvol2 = calMolSelfVolGS(NA2, xyz2, vdwR2, w2, true, false);
    // std::cout<<"tvol = "<<mvol1<<"\tqvol = "<<mvol2<<"\n";
    selfVol[0] = mvol1;
    selfVol[1] = mvol2;

    bool steepest = true;
    int maxIter = 500;
    double rt[6];
    for (int i = 0; i < 6; i++) {
        rt[i] = 0;
    }
    double drt[6];
    double gradient[6];
    double gradOld[6];
    double direction[6];
    double direOld[6];
    double beta = 0.0;
    double gN0 = 0;
    double gN1 = 0;
    double step = 0.05;
    double delta = 0.001;
    double sfactor = 0.006;
    double DThreshold = 0.00001;
    double minStep = 0;
    int resetSteps = 10;
    // Compute initial vol and gradient
    double vStart = calGGradient(NA1, xyz1, vdwR1, w1, NA2, xyz2, vdwR2, w2, drt, rt, true);
    for (int i = 0; i < 6; i++) {
        // printf("drt: %f\n",drt[i]);
    }

    for (int i = 0; i < 6; i++) {
        direction[i] = -drt[i];
        direOld[i] = -drt[i];
        gN0 += direOld[i] * direOld[i];
    }
    if (gN0 < DThreshold) return -vStart;

    int iter;
    for (iter = 0; iter < maxIter; iter++) {
        step = sqrt(gN0) * sfactor;
        //   printf("initial step: %f\n",step);
        // Line Search and update crds in the direction
        minStep =
            lineMinimizer(NA1, xyz1, vdwR1, w1, NA2, xyz2, vdwR2, w2, rt, step, vStart, direction);
        //  printf("minStep: %f\n",minStep);
        //   printf("sfactor%d: %f\n",iter,minStep/sqrt(gN0));
        //   exit(0);
        double vxx = calGGradient(NA1, xyz1, vdwR1, w1, NA2, xyz2, vdwR2, w2, drt, rt, true);
        // std::cout << "Ratio = " << sqrt(gN0)/minStep << "\n";
        gN1 = 0;
        for (int i = 0; i < 6; i++) {
            gN1 += drt[i] * drt[i];
        }
        // Compute beta according to Fletcher-Reeves (FR) formula
        beta = gN1 / gN0;
        gN0 = 0;
        if (vxx > vStart) beta = 0;
        if (steepest) beta = 0;
        int iter50 = iter / resetSteps;
        if (iter50 * resetSteps == iter) beta = 0;
        for (int i = 0; i < 6; i++) {
            direction[i] = -drt[i] + beta * direOld[i];
            // gradOld[i] = crdGrads[i];
            direOld[i] = direction[i];
            // gN0 += direction[i]*direction[i];
            gN0 += drt[i] * drt[i];
        }
        vStart = vxx;
        // std::cout << "OverlapVolume of Iteration = " << iter << " " << -vxx << "\n";
        // std::cout << "gN1 = " << gN1 << "\n";
        if (minStep < delta) break;
    }
    //   printf("iter: %d\n",iter);
    //    if(minStep >= delta) printf("minStep: %d, CG method is not converged\n",minStep);

    double rotmat[3][3];
    double xyz0[3];
    double xyzr[3];
    RotMat(rt[0], rt[1], rt[2], rotmat);
    for (i = 0; i < NA1; i++) {
        i3 = i * 3;
        xyz0[0] = xyz1[i3];
        xyz0[1] = xyz1[i3 + 1];
        xyz0[2] = xyz1[i3 + 2];
        Rotation(xyz0, rotmat, xyzr);
        // printf("xyzr%d: %f, %f, %f\n",i,xyzr[0],xyzr[1],xyzr[2]);
        xyz1[i3] = xyzr[0] + rt[3];
        xyz1[i3 + 1] = xyzr[1] + rt[4];
        xyz1[i3 + 2] = xyzr[2] + rt[5];
        //     printf("xyzt%d: %f, %f, %f\n",i,xyz[i3],xyz[i3+1],xyz[i3+2]);
    }

    setFragXYZ(Frag1, xyz1, onlyHeavyAtoms);

    delete[] xyz1;
    delete[] xyz2;
    delete[] vdwR1;
    delete[] vdwR2;
    delete[] w1;
    delete[] w2;

    return -vStart;
}

// to do: CG method to optimize overlapping volume
double optimizeOverlapVol(int NA1, double* xyz1, double* vdwR1, double* w1, int NA2, double* xyz2,
                          double* vdwR2, double* w2, bool onlyHeavyAtoms) {
    int i;
    int i3;

    bool steepest = true;
    int maxIter = 500;
    double rt[6];
    for (int i = 0; i < 6; i++) {
        rt[i] = 0;
    }
    double drt[6];
    double gradient[6];
    double gradOld[6];
    double direction[6];
    double direOld[6];
    double beta = 0.0;
    double gN0 = 0;
    double gN1 = 0;
    double step = 0.05;
    double delta = 0.001;
    double sfactor = 0.006;
    double DThreshold = 0.00001;
    double minStep = 0;
    int resetSteps = 10;
    // Compute initial vol and gradient
    double vStart = calGGradient(NA1, xyz1, vdwR1, w1, NA2, xyz2, vdwR2, w2, drt, rt, true);
    for (int i = 0; i < 6; i++) {
        // printf("drt: %f\n",drt[i]);
    }

    for (int i = 0; i < 6; i++) {
        direction[i] = -drt[i];
        direOld[i] = -drt[i];
        gN0 += direOld[i] * direOld[i];
    }
    if (gN0 < DThreshold) return -vStart;

    int iter;
    for (iter = 0; iter < maxIter; iter++) {
        step = sqrt(gN0) * sfactor;
        //   printf("initial step: %f\n",step);
        // Line Search and update crds in the direction
        minStep =
            lineMinimizer(NA1, xyz1, vdwR1, w1, NA2, xyz2, vdwR2, w2, rt, step, vStart, direction);
        //  printf("minStep: %f\n",minStep);
        //   printf("sfactor%d: %f\n",iter,minStep/sqrt(gN0));
        //   exit(0);
        double vxx = calGGradient(NA1, xyz1, vdwR1, w1, NA2, xyz2, vdwR2, w2, drt, rt, true);
        // std::cout << "Ratio = " << sqrt(gN0)/minStep << "\n";
        gN1 = 0;
        for (int i = 0; i < 6; i++) {
            gN1 += drt[i] * drt[i];
        }
        // Compute beta according to Fletcher-Reeves (FR) formula
        beta = gN1 / gN0;
        gN0 = 0;
        if (vxx > vStart) beta = 0;
        if (steepest) beta = 0;
        int iter50 = iter / resetSteps;
        if (iter50 * resetSteps == iter) beta = 0;
        for (int i = 0; i < 6; i++) {
            direction[i] = -drt[i] + beta * direOld[i];
            // gradOld[i] = crdGrads[i];
            direOld[i] = direction[i];
            // gN0 += direction[i]*direction[i];
            gN0 += drt[i] * drt[i];
        }
        vStart = vxx;
        // std::cout << "OverlapVolume of Iteration = " << iter << " " << -vxx << "\n";
        // std::cout << "gN1 = " << gN1 << "\n";
        if (minStep < delta) break;
    }
    //   printf("iter: %d\n",iter);
    //    if(minStep >= delta) printf("minStep: %d, CG method is not converged\n",minStep);

    double rotmat[3][3];
    double xyz0[3];
    double xyzr[3];
    RotMat(rt[0], rt[1], rt[2], rotmat);
    for (i = 0; i < NA1; i++) {
        i3 = i * 3;
        xyz0[0] = xyz1[i3];
        xyz0[1] = xyz1[i3 + 1];
        xyz0[2] = xyz1[i3 + 2];
        Rotation(xyz0, rotmat, xyzr);
        // printf("xyzr%d: %f, %f, %f\n",i,xyzr[0],xyzr[1],xyzr[2]);
        xyz1[i3] = xyzr[0] + rt[3];
        xyz1[i3 + 1] = xyzr[1] + rt[4];
        xyz1[i3 + 2] = xyzr[2] + rt[5];
        //     printf("xyzt%d: %f, %f, %f\n",i,xyz[i3],xyz[i3+1],xyz[i3+2]);
    }

    return -vStart;
}

double lineMinimizer(int NA1, double* xyz1, double* vdwR1, double* w1, int NA2, double* xyz2,
                     double* vdwR2, double* w2, double* rt, double step, double vOld,
                     double* direction) {
    int maxSteps = 100;
    double bestStep = step;
    double minVol = 0;
    double factor = 0;
    double gg = 0;
    double bigger = 2.0;
    double vscan[50];
    double steps[50];
    double overlapVol = 0;
    double delta = 0.000001;
    double drt[6];
    double rtOld[6];
    for (int i = 0; i < 6; i++) {
        rtOld[i] = rt[i];
        gg += direction[i] * direction[i];
    }
    factor = 1.0 / sqrt(gg);
    // printf("sqrt(gg) = %15.13f\n",sqrt(gg));

    for (int i = 0; i < 6; i++) {
        direction[i] = direction[i] * factor;
    }
    // Find turn point
    vscan[0] = vOld;
    steps[0] = 0;
    for (int j = 0; j < 6; j++) {
        rt[j] = rtOld[j] + step * direction[j];
    }
    vscan[1] = calGGradient(NA1, xyz1, vdwR1, w1, NA2, xyz2, vdwR2, w2, drt, rt, false);
    //  printf("vscan0: %f\n",vscan[1]);
    steps[1] = step;
    //  printf("step0: %f\n",steps[1]);
    int iscan;
    if (vscan[1] < vscan[0]) {
        // Continue in this direction with bigger step, till overlapVol increases
        for (int i = 0; i < 25; i++) {
            step = step * bigger;
            //  printf("step%d: %f\n",i,step);
            for (int j = 0; j < 6; j++) {
                rt[j] = rtOld[j] + step * direction[j];
            }
            overlapVol = calGGradient(NA1, xyz1, vdwR1, w1, NA2, xyz2, vdwR2, w2, drt, rt, false);
            //   printf("vscan%d: %f\n",i,overlapVol);
            if (overlapVol < vscan[1]) {
                vscan[0] = vscan[1];
                steps[0] = steps[1];
                vscan[1] = overlapVol;
                steps[1] = step;
            } else {
                vscan[2] = overlapVol;
                steps[2] = step;
                iscan = i + 1;
                break;
            }
        }
        //   printf("Case A, line steps: %d\n",iscan);
        for (int i = 0; i < 3; i++) {
            //   printf("vscan[%d]: %f\n",i,vscan[i]);
            //   printf("step[%d]: %f\n",i,steps[i]);
        }
    } else {
        // Continue in this direction with smaller step, till overlapVol below start
        for (int i = 0; i < 25; i++) {
            step = step / bigger;
            for (int j = 0; j < 6; j++) {
                rt[j] = rtOld[j] + step * direction[j];
            }
            overlapVol = calGGradient(NA1, xyz1, vdwR1, w1, NA2, xyz2, vdwR2, w2, drt, rt, false);
            //   printf ("B step = %lf, overlapVol = %15.13f\n", step, overlapVol);
            if (overlapVol < vscan[0]) {
                vscan[2] = vscan[1];
                steps[2] = steps[1];
                vscan[1] = overlapVol;
                steps[1] = step;
                iscan = i + 1;
                break;
            } else {
                vscan[1] = overlapVol;
                steps[1] = step;
            }
        }
        //   printf("Case B, line steps: %d\n",iscan);
    }
    // further search
    double diffStep = steps[2] - steps[0];
    double step0, step1, step2;
    step0 = steps[0];
    step1 = steps[1];
    step2 = steps[2];
    minVol = vscan[0];
    if (diffStep > 0.2) {
        int nSteps = (int)(diffStep / 0.2);
        double miniStepSize = diffStep / nSteps;
        for (int i = 1; i < nSteps - 1; i++) {
            for (int j = 0; j < 6; j++) {
                rt[j] = rtOld[j] + (steps[0] + miniStepSize * i) * direction[j];
            }
            overlapVol = calGGradient(NA1, xyz1, vdwR1, w1, NA2, xyz2, vdwR2, w2, drt, rt, false);
            //   printf("step%d: %f, vscan%d: %f\n",i,steps[0] + miniStepSize*i,i,overlapVol);

            if (overlapVol < minVol) {
                vscan[0] = minVol;
                minVol = overlapVol;
                vscan[1] = overlapVol;

                step0 = steps[0] + miniStepSize * (i - 1);
                step1 = steps[0] + miniStepSize * i;
            } else {
                vscan[2] = overlapVol;
                step2 = steps[0] + miniStepSize * i;
                break;
            }
        }
        // printf("nSteps: %d\n",nSteps);
        //  printf("step0: %f, vscan0: %f\n",step0,vscan[0]);
        // 	printf("step1: %f, vscan1: %f\n",step1,vscan[1]);
        //      printf("step2: %f, vscan2: %f\n",step2,vscan[2]);
    }

    // std::cout << "Bracket scan = " << iscan << "\n";
    // Now, quadratic interplolation
    // First, compute numerical gradient for x0 and x2

    for (int j = 0; j < 6; j++) {
        rt[j] = rtOld[j] + (step0 + delta) * direction[j];
    }
    overlapVol = calGGradient(NA1, xyz1, vdwR1, w1, NA2, xyz2, vdwR2, w2, drt, rt, false);
    double dx0 = (overlapVol - vscan[0]) / delta;
    // printf("dx0: %f\n",dx0);
    for (int j = 0; j < 6; j++) {
        rt[j] = rtOld[j] + (step2 + delta) * direction[j];
    }
    overlapVol = calGGradient(NA1, xyz1, vdwR1, w1, NA2, xyz2, vdwR2, w2, drt, rt, false);
    double dx2 = (overlapVol - vscan[2]) / delta;
    // printf("dx2: %f\n",dx2);
    double xx = (dx0 * step2 - dx2 * step0) / (dx0 - dx2);
    //  printf("xx: %f\n",xx);
    // std::cout << "xx from quadratic interplolation = " << xx << "\n";
    // if(steps[0] < xx && xx < steps[2]) return xx;
    // Set the new coords
    for (int j = 0; j < 6; j++) {
        rt[j] = rtOld[j] + xx * direction[j];
    }
    return xx;
}

double calMolSelfVol_ASA(int nSpheres, double* xyz, double* vdwR, double P, double F) {
    int i, j, i3, j3, ij, ji;
    double dist2 = 0;
    double kn;
    double tmp, tmpd;
    double pi = 3.14159265358979;
    double p2 = P * P;
    double gfactor = 4.0 * pi / (3.0 * P);
    gfactor = pi / (pow(gfactor, 0.66666666666667));

    double* selfv = new double[nSpheres];
    double* s1 = new double[nSpheres];
    for (i = 0; i < nSpheres; i++) {
        selfv[i] = 0;
        s1[i] = 0;
    }

    double* weights = new double[nSpheres];
    double* alpha = new double[nSpheres];
    double* gVols = new double[nSpheres * nSpheres];

    for (i = 0; i < nSpheres; i++) {
        alpha[i] = gfactor / (vdwR[i] * vdwR[i]);
    }

    for (i = 0; i < nSpheres; i++) {
        i3 = i * 3;
        for (j = 0; j < i + 1; j++) {
            j3 = j * 3;
            dist2 = (xyz[i3] - xyz[j3]) * (xyz[i3] - xyz[j3]) +
                    (xyz[i3 + 1] - xyz[j3 + 1]) * (xyz[i3 + 1] - xyz[j3 + 1]) +
                    (xyz[i3 + 2] - xyz[j3 + 2]) * (xyz[i3 + 2] - xyz[j3 + 2]);

            ij = i * nSpheres + j;
            ji = j * nSpheres + i;
            tmpd = alpha[i] + alpha[j];
            if (i == j) {
                gVols[ij] = P * pow(pi / alpha[i], 1.5);
                selfv[i] = gVols[ij];
                // std::cout << "new selfv: " << selfv[i] << "\n";
                // std::cout << "gVols: " << gVols[ij] << "\n";
            } else {
                kn = exp(-alpha[i] * alpha[j] * dist2 / tmpd);
                gVols[ij] = p2 * kn * pow(pi / tmpd, 1.5);
                gVols[ji] = gVols[ij];
                // std::cout << "new crossVol: " << gVols[ij] << "\n";
                s1[i] += gVols[ij];
                s1[j] += gVols[ij];
            }
        }
    }

    // set up weights
    for (i = 0; i < nSpheres; i++) {
        // std::cout << "s1: " << s1[i] << "\n";
        tmp = s1[i] / selfv[i];
        weights[i] = 1.0 / (1.0 + F * tmp);
        // std::cout << "new weights: " <<  weights[i] << "\n";
    }

    //
    // Recalculate weighted volume
    //
    double vol = 0;
    for (i = 0; i < nSpheres; i++) {
        for (j = 0; j < i + 1; j++) {
            ij = i * nSpheres + j;
            if (i == j)
                vol += selfv[i] * weights[i];
            else {
                // tmp = 2*gVols[ij]*weights[i]*weights[j];
                // vol += tmp;
            }
        }
    }

    delete[] selfv;
    delete[] s1;
    delete[] weights;
    delete[] gVols;
    delete[] alpha;
    return vol;
}

void calGSASA(int nSpheres, double* xyz, double* vdwR, double* weights, double* sa, double* P,
              double* F, bool equalR) {
    int i, j, i3, j3, ij, ji;
    double dist2 = 0;
    double kn;
    double tmp, tmpc, tmpd;
    double factor1 = 0.8665;
    double pi = 3.14159265358979;
    double p2, gfactor;

    // double p2 = P*P;
    // double gfactor = 4.0*pi/(3.0*P);
    // gfactor = pi/(pow(gfactor,0.66666666666667));
    // double p2 = 7.99984656;
    // double gfactor = 2.417972471923026;

    double* selfv = new double[nSpheres];
    double* s1 = new double[nSpheres];
    for (i = 0; i < nSpheres; i++) {
        selfv[i] = 0;
        s1[i] = 0;
    }

    double* alpha = new double[nSpheres];
    double* gVols = new double[nSpheres * nSpheres];
    double* dist2s = new double[nSpheres * nSpheres];

    for (i = 0; i < nSpheres; i++) {
        gfactor = 4.0 * pi / (3.0 * P[i]);
        gfactor = pi / (pow(gfactor, 0.66666666666667));
        // std::cout << "vdwR: " << vdwR[i] << "\n";
        alpha[i] = gfactor / (vdwR[i] * vdwR[i]);
        // std::cout << "alpha: " << alpha[i] << "\n";
    }

    for (i = 0; i < nSpheres; i++) {
        i3 = i * 3;
        for (j = 0; j < i + 1; j++) {
            j3 = j * 3;
            dist2 = (xyz[i3] - xyz[j3]) * (xyz[i3] - xyz[j3]) +
                    (xyz[i3 + 1] - xyz[j3 + 1]) * (xyz[i3 + 1] - xyz[j3 + 1]) +
                    (xyz[i3 + 2] - xyz[j3 + 2]) * (xyz[i3 + 2] - xyz[j3 + 2]);

            ij = i * nSpheres + j;
            ji = j * nSpheres + i;
            dist2s[ij] = dist2;
            dist2s[ji] = dist2;

            tmpd = alpha[i] + alpha[j];
            kn = exp(-alpha[i] * alpha[j] * dist2 / tmpd);
            if (i == j) {
                gVols[ij] = P[i] * pow(pi / alpha[i], 1.5);
                selfv[i] = gVols[ij];
                // std::cout << "selfv: " << selfv[i] << "\n";
                // std::cout << "selfv-new: " << p2*kn*pow(pi/tmpd,1.5) << "\n";
                // std::cout << "gVols: " << gVols[ij] << "\n";
            } else {
                // std::cout << "1.5/dltn + dist2: " << 1.5/tmpd + dist2 << "\n";
                gVols[ij] = P[i] * P[j] * kn * pow(pi / tmpd, 1.5);
                gVols[ji] = gVols[ij];
                // std::cout << "crossVol: " << gVols[ij] << "\n";
                s1[i] += gVols[ij];
                s1[j] += gVols[ij];
            }
        }
    }

    // set up weights
    for (i = 0; i < nSpheres; i++) {
        // std::cout << "s1: " << s1[i] << "\n";
        tmp = s1[i] / selfv[i];
        weights[i] = 1.0 / (1.0 + F[i] * tmp);
        // weights[i] = sqrt(weights[i]);
        // weights[i] = weights[i] * weights[i];
        // std::cout << "old weights: " <<  weights[i] << "\n";
    }

    /*
       //
       // Recalculate weighted volume
       //
       double vol = 0;
       for(i=0; i< nSpheres; i++) {
           for(j=0; j< i+1; j++) {
             //ij = i*nSpheres + j;
             if(i == j)
                vol += selfv[i]*weights[i];
             else{
                //tmp = 2*gVols[ij]*weights[i]*weights[j];
                //vol += tmp;
             }
           }
       }
    */

    //
    // calculate surface area
    //
    double dervSelfVToR;
    double dervCrsVToR;
    for (i = 0; i < nSpheres; i++) {
        sa[i] = 0;
        tmpc = 2 * alpha[i] / vdwR[i];
        // dervSelfVToR = selfv[i] * tmpc * ( 1.5/alpha[i] );
        dervSelfVToR = 4 * pi * vdwR[i] * vdwR[i];
        // std::cout << "dervSelfVToR: " << dervSelfVToR << "\n";

        dervCrsVToR = 0;
        for (j = 0; j < nSpheres; j++) {
            if (j != i) {
                ij = i * nSpheres + j;
                tmpd = alpha[i] + alpha[j];
                dervCrsVToR += tmpc * gVols[ij] *
                               (1.5 / tmpd + dist2s[ij] * alpha[j] * alpha[j] / (tmpd * tmpd));
            }
        }
        // std::cout << "dervCrsVToR: " << dervCrsVToR << "\n";

        sa[i] += weights[i] * dervSelfVToR;
        for (j = 0; j < nSpheres; j++) {
            tmp = selfv[j] + F[j] * s1[j];
            tmp = tmp * tmp;
            if (i == j) {
                sa[i] += selfv[i] * F[i] * (dervSelfVToR * s1[i] - selfv[i] * dervCrsVToR) / tmp;
                // std::cout << "i==j dervWToR: " << F*(dervSelfVToR*s1[i]-selfv[i]*dervCrsVToR)/tmp
                // << "\n";
            } else {
                ij = i * nSpheres + j;
                tmpd = alpha[i] + alpha[j];
                sa[i] += selfv[j] * (-selfv[j]) * F[j] / tmp * tmpc * gVols[ij] *
                         (1.5 / tmpd + dist2s[ij] * alpha[j] * alpha[j] / (tmpd * tmpd));
                // std::cout << "i!=j dervWToR: " << (-selfv[j])*F/tmp * tmpc * gVols[ij] *
                // ( 1.5/tmpd + dist2s[ij]*alpha[j]*alpha[j]/(tmpd*tmpd)) << "\n";
            }
        }
    }

    /*
       //
       // calculate surface area by numerical method
       //
         std::cout << "atom\tanalytic method\tnumerical method\n";
         double saNM = 0;
         double vol2 = 0;
         double dR = 0.000001;
         for (i=0; i < nSpheres; i++) {
           vdwR[i] += dR;
           vol2 = calMolSelfVol_ASA(nSpheres, xyz, vdwR, P, F);
           saNM = (vol2-vol)/dR;
           vdwR[i] -= dR;

           std::cout << "sa-atom-" << i+1 << "\t" << sa[i] << "\t" << saNM << "\n";
         }
    */

    delete[] selfv;
    delete[] s1;
    delete[] gVols;
    delete[] alpha;
    delete[] dist2s;
}

// cleanup
double calMolSelfVolGS(int nSpheres, double* xyz, double* vdwR, double* weights, bool getW,
                       bool equalR) {
    double* alpha = 0;
    double* gVols = 0;
    return calMolSelfVolGS(nSpheres, xyz, vdwR, weights, gVols, alpha, getW, equalR);
}

double calMolSelfVolGS(int nSpheres, double* xyz, double* vdwR, double* weights, double* gVols,
                       double* alpha, bool getW, bool equalR) {
    bool noWeights = false;
    bool nogVols = false;
    bool noalpha = false;

    int i3, j3, ij;
    double sab = 0;
    double dist2 = 0;
    double kn;
    double tmpd;
    double factor1 = 0.8665;
    double pi = 3.14159265358979;
    // double p2 = gParam*gParam;
    // double gfactor = 4.0*pi/(3.0*gParam);
    // gfactor = pi/(pow(gfactor,0.66666666666667));
    double p2 = 7.99984656;
    double gfactor = 2.417972471923026;
    double VDWR = 1.8;

    double* selfv = new double[nSpheres];
    double* s1 = new double[nSpheres];
    for (int i = 0; i < nSpheres; i++) {
        selfv[i] = 0.0;
        s1[i] = 0.0;
    }

    if (weights == 0) {
        noWeights = true;
        weights = new double[nSpheres];
    }

    if (equalR) {
        if (0 == alpha) alpha = new double[nSpheres];

        double alphaAll = gfactor / (VDWR * VDWR);
        double alphaAllH = alphaAll / 2;
        double alphaAll2 = alphaAll * 2;
        if (0 == gVols) {
            gVols = new double[nSpheres * (nSpheres + 1) / 2];
            nogVols = true;
        }

        ij = 0;
        for (int i = 0; i < nSpheres; i++) {
            alpha[i] = alphaAll;
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                dist2 = (xyz[i3] - xyz[j3]) * (xyz[i3] - xyz[j3]) +
                        (xyz[i3 + 1] - xyz[j3 + 1]) * (xyz[i3 + 1] - xyz[j3 + 1]) +
                        (xyz[i3 + 2] - xyz[j3 + 2]) * (xyz[i3 + 2] - xyz[j3 + 2]);
                // if(dist2 > 16) continue;
                kn = exp(-alphaAllH * dist2);
                gVols[ij] = p2 * kn * pow(pi / alphaAll2, 1.5);
                if (i == j)
                    selfv[i] = gVols[ij];
                else {
                    s1[i] += gVols[ij];
                    s1[j] += gVols[ij];
                }
                ij = ij + 1;
            }
        }
    } else {
        if (0 == alpha) {
            alpha = new double[nSpheres];
            noalpha = true;
        }
        if (0 == gVols) {
            gVols = new double[nSpheres * (nSpheres + 1) / 2];
            nogVols = true;
        }

        for (int i = 0; i < nSpheres; i++) {
            alpha[i] = gfactor / (vdwR[i] * vdwR[i]);
        }

        ij = 0;
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                dist2 = (xyz[i3] - xyz[j3]) * (xyz[i3] - xyz[j3]) +
                        (xyz[i3 + 1] - xyz[j3 + 1]) * (xyz[i3 + 1] - xyz[j3 + 1]) +
                        (xyz[i3 + 2] - xyz[j3 + 2]) * (xyz[i3 + 2] - xyz[j3 + 2]);
                // if(dist2 > 16) continue;
                tmpd = alpha[i] + alpha[j];
                kn = exp(-alpha[i] * alpha[j] * dist2 / tmpd);
                gVols[ij] = p2 * kn * pow(pi / tmpd, 1.5);
                if (i == j)
                    selfv[i] = gVols[ij];
                else {
                    s1[i] += gVols[ij];
                    s1[j] += gVols[ij];
                }
                ij = ij + 1;
            }
        }
    }

    /*
       // addup atom volume
       double addup = 0;
       for(int i=0; i< nSpheres; i++)
         addup +=selfv[i];

       std::cout << "addup: " << addup << "\n";
    */

    //
    // Set up weights
    //
    if (getW) {
        for (int i = 0; i < nSpheres; i++) {
            s1[i] = s1[i] / selfv[i];
            weights[i] = 1.0 / (1.0 + factor1 * s1[i]);
            /*###############################################################
            # because weights < 1.0, so sqaure weights will decrease the small one
            # more than the big one
            # this will indirectly reflect the position of atom,
            # the surface atom will be enphasized(its weight is the big one)
            #################################################################*/
            // weights[i] = weights[i]*weights[i];

            // std::cout << "i = " << i+1 << " " << s1[i] << " " << weights[i] << "\n";
        }
    } else  // do not consider weights
    {
        for (int i = 0; i < nSpheres; i++) {
            weights[i] = 1.0;
        }
    }

    //
    // Recalculate weighted volume
    //
    ij = 0;
    sab = 0;
    for (int i = 0; i < nSpheres; i++) {
        for (int j = 0; j < i + 1; j++) {
            if (i == j)
                sab += gVols[ij] * weights[i] * weights[i];
            else
                sab += 2 * gVols[ij] * weights[i] * weights[j];
            ij = ij + 1;
        }
    }

    if (noalpha) delete[] alpha;

    if (nogVols) delete[] gVols;

    delete[] selfv;
    delete[] s1;
    if (noWeights) delete[] weights;
    return sab;
}

double calMolSelfVolGS_SS(int nSpheres, double* xyz, double* vdwR, double* weights, double* gVols,
                          double* alpha, bool getW, bool equalR, double* vol, int* mtype,
                          double* mwt) {
    bool noWeights = false;
    bool nogVols = false;
    bool noalpha = false;

    int i3, j3, ij;
    double sab = 0;
    double dist2 = 0;
    double kn;
    double tmpd;
    double factor1 = 0.8665;
    double pi = 3.14159265358979;
    // double p2 = gParam*gParam;
    // double gfactor = 4.0*pi/(3.0*gParam);
    // gfactor = pi/(pow(gfactor,0.66666666666667));
    double p2 = 7.99984656;
    double gfactor = 2.417972471923026;
    double VDWR = 1.8;

    double* selfv = new double[nSpheres];
    double* s1 = new double[nSpheres];
    for (int i = 0; i < nSpheres; i++) {
        selfv[i] = 0.0;
        s1[i] = 0.0;
    }

    if (weights == 0) {
        noWeights = true;
        weights = new double[nSpheres];
    }

    if (equalR) {
        if (0 == alpha) alpha = new double[nSpheres];

        double alphaAll = gfactor / (VDWR * VDWR);
        double alphaAllH = alphaAll / 2;
        double alphaAll2 = alphaAll * 2;
        if (0 == gVols) {
            gVols = new double[nSpheres * (nSpheres + 1) / 2];
            nogVols = true;
        }

        ij = 0;
        for (int i = 0; i < nSpheres; i++) {
            alpha[i] = alphaAll;
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                dist2 = (xyz[i3] - xyz[j3]) * (xyz[i3] - xyz[j3]) +
                        (xyz[i3 + 1] - xyz[j3 + 1]) * (xyz[i3 + 1] - xyz[j3 + 1]) +
                        (xyz[i3 + 2] - xyz[j3 + 2]) * (xyz[i3 + 2] - xyz[j3 + 2]);
                // if(dist2 > 16) continue;
                kn = exp(-alphaAllH * dist2);
                gVols[ij] = p2 * kn * pow(pi / alphaAll2, 1.5);
                if (i == j)
                    selfv[i] = gVols[ij];
                else {
                    s1[i] += gVols[ij];
                    s1[j] += gVols[ij];
                }
                ij = ij + 1;
            }
        }
    } else {
        if (0 == alpha) {
            alpha = new double[nSpheres];
            noalpha = true;
        }
        if (0 == gVols) {
            gVols = new double[nSpheres * (nSpheres + 1) / 2];
            nogVols = true;
        }

        for (int i = 0; i < nSpheres; i++) {
            alpha[i] = gfactor / (vdwR[i] * vdwR[i]);
        }

        ij = 0;
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                dist2 = (xyz[i3] - xyz[j3]) * (xyz[i3] - xyz[j3]) +
                        (xyz[i3 + 1] - xyz[j3 + 1]) * (xyz[i3 + 1] - xyz[j3 + 1]) +
                        (xyz[i3 + 2] - xyz[j3 + 2]) * (xyz[i3 + 2] - xyz[j3 + 2]);
                // if(dist2 > 16) continue;
                tmpd = alpha[i] + alpha[j];
                kn = exp(-alpha[i] * alpha[j] * dist2 / tmpd);
                gVols[ij] = p2 * kn * pow(pi / tmpd, 1.5);
                if (i == j)
                    selfv[i] = gVols[ij];
                else {
                    s1[i] += gVols[ij];
                    s1[j] += gVols[ij];
                }
                ij = ij + 1;
            }
        }
    }

    /*
       // addup atom volume
       double addup = 0;
       for(int i=0; i< nSpheres; i++)
         addup +=selfv[i];

       std::cout << "addup: " << addup << "\n";
    */

    //
    // Set up weights
    //
    if (getW) {
        for (int i = 0; i < nSpheres; i++) {
            s1[i] = s1[i] / selfv[i];
            weights[i] = 1.0 / (1.0 + factor1 * s1[i]);
            /*###############################################################
            # because weights < 1.0, so sqaure weights will decrease the small one
            # more than the big one
            # this will indirectly reflect the position of atom,
            # the surface atom will be enphasized(its weight is the big one)
            #################################################################*/
            // weights[i] = weights[i]*weights[i];

            // std::cout << "i = " << i+1 << " " << s1[i] << " " << weights[i] << "\n";
        }
    } else  // do not consider weights
    {
        for (int i = 0; i < nSpheres; i++) {
            weights[i] = 1.0;
        }
    }

    //
    // Recalculate weighted volume
    //
    /**
    ij = 0;
    sab = 0;
    for(int i=0; i< nSpheres; i++) {
        for(int j=0; j< i+1; j++) {
          if(i == j)
             sab += gVols[ij]*weights[i]*weights[i];
          else
             sab += 2*gVols[ij]*weights[i]*weights[j];
          ij = ij+1;
        }

    }
    **/
    // lixm:calculate the core and side volume.begin.
    ij = 0;
    sab = 0;
    for (int i = 0; i < nSpheres; i++) {
        for (int j = 0; j < i + 1; j++) {
            if (i == j) {
                if (mtype[i] == mtype[j]) {
                    vol[mtype[i]] += gVols[ij] * weights[i] * weights[i] * mwt[i] * mwt[i];
                }
                // sab += gVols[ij]*weights[i]*weights[i];
            } else {
                if (mtype[i] == mtype[j]) {
                    vol[mtype[i]] += 2 * gVols[ij] * weights[i] * weights[j] * mwt[i] * mwt[j];
                }
                // sab += 2*gVols[ij]*weights[i]*weights[j];
            }
            ij = ij + 1;
        }
    }
    /**
    for(int i=0;i<nSpheres;i++)
    {
      std::cout << mtype[i] << " ";
    }
    std::cout << "\n";
    for(int i=0;i<nSpheres;i++)
    {
      std::cout << mwt[i] << " ";
    }
    std::cout << "\n";
    for(int i=0;i<3;i++)
    {
      std::cout << vol[i] << " ";
    }
    std::cout << sab << "\n";
    **/
    // lixm:calcuate the core and side volume.end
    sab = vol[0] + vol[1];

    if (noalpha) delete[] alpha;

    if (nogVols) delete[] gVols;

    delete[] selfv;
    delete[] s1;
    if (noWeights) delete[] weights;
    return sab;
}

//
// feature atoms are all considered as carbon
//
void calSelfVolFeature(double* xyz, int nFAtoms, int* atomsFType, int* fAtoms, double* selfVol) {
    int i, i3, j, j3;
    double dist2, kn, tmp;

    double pi = 3.14159265358979;
    // double p2 = gParam*gParam;
    // double gfactor = 4.0*pi/(3.0*gParam);
    // gfactor = pi/(pow(gfactor,0.66666666666667));
    double p2 = 7.99984656;
    double gfactor = 2.417972471923026;
    double VDWR = 2.0;  // vdwR of carbon

    double alphaAll = gfactor / (VDWR * VDWR);
    double alphaAllH = alphaAll / 2;
    double alphaAll2 = alphaAll * 2;

    for (i = 0; i < nFAtoms; i++) {
        i3 = fAtoms[i] * 3;
        for (j = 0; j < i + 1; j++) {
            if (atomsFType[i] != atomsFType[j]) continue;

            j3 = fAtoms[j] * 3;
            dist2 = (xyz[i3] - xyz[j3]) * (xyz[i3] - xyz[j3]) +
                    (xyz[i3 + 1] - xyz[j3 + 1]) * (xyz[i3 + 1] - xyz[j3 + 1]) +
                    (xyz[i3 + 2] - xyz[j3 + 2]) * (xyz[i3 + 2] - xyz[j3 + 2]);
            kn = exp(-alphaAllH * dist2);
            tmp = p2 * kn * pow(pi / alphaAll2, 1.5);
            if (i3 == j3)
                selfVol[atomsFType[i]] += tmp;
            else
                selfVol[atomsFType[i]] += 2 * tmp;
        }
    }
}

//
// feature atoms are all considered as carbon
//
void calSelfVolFeature_ownPharma(int nFeat, int* featTypes, double* featXYZ, int nDirc,
                                 int* dircTypes, double* dircXYZ, double* selfVol) {
    int i, i3, j, j3, type;
    double dist2, kn, tmp;

    double pi = 3.14159265358979;
    // double p2 = gParam*gParam;
    // double gfactor = 4.0*pi/(3.0*gParam);
    // gfactor = pi/(pow(gfactor,0.66666666666667));
    double p2 = 7.99984656;
    double gfactor = 2.417972471923026;
    double VDWR = 1.8;  // vdwR of carbon

    double alphaAll = gfactor / (VDWR * VDWR);
    double alphaAllH = alphaAll / 2;
    double alphaAll2 = alphaAll * 2;

    //
    for (i = 0; i < nFeat; i++) {
        i3 = i * 3;
        type = featTypes[i];
        for (j = 0; j < i + 1; j++) {
            if (type != featTypes[j]) continue;

            j3 = j * 3;
            dist2 = (featXYZ[i3] - featXYZ[j3]) * (featXYZ[i3] - featXYZ[j3]) +
                    (featXYZ[i3 + 1] - featXYZ[j3 + 1]) * (featXYZ[i3 + 1] - featXYZ[j3 + 1]) +
                    (featXYZ[i3 + 2] - featXYZ[j3 + 2]) * (featXYZ[i3 + 2] - featXYZ[j3 + 2]);
            kn = exp(-alphaAllH * dist2);
            tmp = p2 * kn * pow(pi / alphaAll2, 1.5);
            if (i3 == j3)
                selfVol[type] += tmp;
            else
                selfVol[type] += 2 * tmp;
        }
    }

    for (i = 0; i < nDirc; i++) {
        i3 = i * 3;
        type = dircTypes[i];
        for (j = 0; j < i + 1; j++) {
            if (type != dircTypes[j]) continue;

            j3 = j * 3;
            dist2 = (dircXYZ[i3] - dircXYZ[j3]) * (dircXYZ[i3] - dircXYZ[j3]) +
                    (dircXYZ[i3 + 1] - dircXYZ[j3 + 1]) * (dircXYZ[i3 + 1] - dircXYZ[j3 + 1]) +
                    (dircXYZ[i3 + 2] - dircXYZ[j3 + 2]) * (dircXYZ[i3 + 2] - dircXYZ[j3 + 2]);
            kn = exp(-alphaAllH * dist2);
            tmp = p2 * kn * pow(pi / alphaAll2, 1.5);
            if (i3 == j3)
                selfVol[type + 6] += tmp;
            else
                selfVol[type + 6] += 2 * tmp;
        }
    }
}

void calSelfVolFeature_ownPharma(std::vector<PharmaFeature*>& allFeatures, double* selfVol) {
    int i, i3;
    int numFeats = allFeatures.size();
    // std::cout << numFeats << "\n";
    int* featTypes = new int[numFeats];
    int* dircTypes = new int[numFeats];

    int numDircPoints = 0;
    for (i = 0; i < numFeats; i++) {
        featTypes[i] = allFeatures[i]->fType;
        if (4 > featTypes[i]) {
            dircTypes[numDircPoints] = featTypes[i];
            numDircPoints++;
        }
    }

    double* featxyz = new double[numFeats * 3];
    double* dircxyz = new double[numDircPoints * 3];
    PharmaFeature* tmpFeat;

    numDircPoints = 0;
    for (i = 0; i < numFeats; i++) {
        tmpFeat = allFeatures[i];
        i3 = i * 3;
        featxyz[i3] = tmpFeat->x1;
        featxyz[i3 + 1] = tmpFeat->y1;
        featxyz[i3 + 2] = tmpFeat->z1;

        if (4 > featTypes[i]) {
            i3 = numDircPoints * 3;
            dircxyz[i3] = tmpFeat->x2;
            dircxyz[i3 + 1] = tmpFeat->y2;
            dircxyz[i3 + 2] = tmpFeat->z2;
            numDircPoints++;
        }
    }

    calSelfVolFeature_ownPharma(numFeats, featTypes, featxyz, numDircPoints, dircTypes, dircxyz,
                                selfVol);

    delete[] featTypes;
    delete[] dircTypes;
    delete[] featxyz;
    delete[] dircxyz;
}

//
// feature atoms are all considered as carbon
//
double calSelfVolPerF(double* xyz, int nFAtoms, std::vector<int>& fAtoms) {
    if (0 == nFAtoms) return 0.0;

    int i, i3, j, j3;
    double dist2, kn, tmp;
    double selfVol = 0;

    double pi = 3.14159265358979;
    // double p2 = gParam*gParam;
    // double gfactor = 4.0*pi/(3.0*gParam);
    // gfactor = pi/(pow(gfactor,0.66666666666667));
    double p2 = 7.99984656;
    double gfactor = 2.417972471923026;
    double VDWR = 2.0;  // vdwR of carbon

    double alphaAll = gfactor / (VDWR * VDWR);
    double alphaAllH = alphaAll / 2;
    double alphaAll2 = alphaAll * 2;

    for (i = 0; i < nFAtoms; i++) {
        i3 = fAtoms[i] * 3;
        for (j = 0; j < i + 1; j++) {
            j3 = fAtoms[j] * 3;
            dist2 = (xyz[i3] - xyz[j3]) * (xyz[i3] - xyz[j3]) +
                    (xyz[i3 + 1] - xyz[j3 + 1]) * (xyz[i3 + 1] - xyz[j3 + 1]) +
                    (xyz[i3 + 2] - xyz[j3 + 2]) * (xyz[i3 + 2] - xyz[j3 + 2]);
            kn = exp(-alphaAllH * dist2);
            tmp = p2 * kn * pow(pi / alphaAll2, 1.5);
            if (i3 == j3)  // atom index are equal
                selfVol += tmp;
            else
                selfVol += 2 * tmp;
        }
    }
    return selfVol;
}

void Set_StdOrientation(int nSpheres, double* xyz, double* alpha, double* weights, double* gVols,
                        double* Eout, bool onlyHeavyAtoms) {
    int i3, j3, ij, ij3;
    double tmp;
    double centX, centY, centZ;

    if (nSpheres > 1000) {
        std::cout << "More than 1000 atoms, stop\n";
        exit(0);
    }
    /*
    // print data
       double avgW = 0;
       for(int i=0; i<nSpheres; i++)
       {
         //std::cout << i+1 << ": " << weights[i] << "\n";
         avgW += weights[i];
       }
       //std::cout << avgW/nSpheres << "\n";

       //std::cout << "gVols\n";
       ij = 0;
       for(int i=0; i<nSpheres; i++)
       {
          i3 = i*3;
          for(int j=0; j<i+1; j++)
          {
            j3 = j*3;
            //if(i == j)
            //{
            //  std::cout << i+1 << ": " << gVols[ij] << "\n";
            //}
            ij++;
          }
       }
    */

    double cx = 0;
    double cy = 0;
    double cz = 0;
    double totalw = 0;
    double a1a2 = 0;

    ij = 0;

    // save the xyz of each part of volume, totally nSpheres*nSpheres parts
    //   int size = nSpheres*(nSpheres+1)/2;
    //   double* xyzVol = new double[size*3];

    if (onlyHeavyAtoms) {
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                if (i == j) {
                    tmp = weights[i] * weights[i] * gVols[ij];
                    // ij3 = ij*3;
                    // xyzVol[ij3]   = xyz[i3];
                    // xyzVol[ij3+1] = xyz[i3+1];
                    // xyzVol[ij3+2] = xyz[i3+2];
                    cx += tmp * xyz[i3];
                    cy += tmp * xyz[i3 + 1];
                    cz += tmp * xyz[i3 + 2];
                    totalw += tmp;
                } else {
                    tmp = 2 * weights[i] * weights[j] * gVols[ij];

                    //          ij3 = ij * 3;
                    /*
                              xyzVol[ij3]   = (xyz[i3]   + xyz[j3])/2;
                              xyzVol[ij3+1] = (xyz[i3+1] + xyz[j3+1])/2;
                              xyzVol[ij3+2] = (xyz[i3+2] + xyz[j3+2])/2;
                              cx += tmp*xyzVol[ij3];
                              cy += tmp*xyzVol[ij3+1];
                              cz += tmp*xyzVol[ij3+2];
                    */

                    cx += tmp * (xyz[i3] + xyz[j3]) / 2;
                    cy += tmp * (xyz[i3 + 1] + xyz[j3 + 1]) / 2;
                    cz += tmp * (xyz[i3 + 2] + xyz[j3 + 2]) / 2;

                    totalw += tmp;
                }
                ij++;
            }
        }
    } else {
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                if (i == j) {
                    tmp = weights[i] * weights[i] * gVols[ij];
                    //          ij3 = ij*3;
                    //          xyzVol[ij3]   = xyz[i3];
                    //          xyzVol[ij3+1] = xyz[i3+1];
                    //          xyzVol[ij3+2] = xyz[i3+2];

                    cx += tmp * xyz[i3];
                    cy += tmp * xyz[i3 + 1];
                    cz += tmp * xyz[i3 + 2];
                    totalw += tmp;
                } else {
                    tmp = 2 * weights[i] * weights[j] * gVols[ij];
                    a1a2 = alpha[i] + alpha[j];
                    //          ij3 = ij * 3;
                    /*
                              xyzVol[ij3]     = (xyz[i3]*alpha[i] + xyz[j3]*alpha[j])/a1a2;
                              xyzVol[ij3 + 1] = (xyz[i3+1]*alpha[i] + xyz[j3+1]*alpha[j])/a1a2;
                              xyzVol[ij3 + 2] = (xyz[i3+2]*alpha[i] + xyz[j3+2]*alpha[j])/a1a2;
                              cx += tmp*xyzVol[ij3];
                              cy += tmp*xyzVol[ij3+1];
                              cz += tmp*xyzVol[ij3+2];
                    */
                    cx += tmp * (xyz[i3] * alpha[i] + xyz[j3] * alpha[j]) / a1a2;
                    cy += tmp * (xyz[i3 + 1] * alpha[i] + xyz[j3 + 1] * alpha[j]) / a1a2;
                    cz += tmp * (xyz[i3 + 2] * alpha[i] + xyz[j3 + 2] * alpha[j]) / a1a2;

                    totalw += tmp;
                }
                ij++;
            }
        }
    }
    cx = cx / totalw;
    cy = cy / totalw;
    cz = cz / totalw;

    /*
       for(int i=0; i<nSpheres; i++)
       {
          i3 = i*3;
          xyz[i3]   = xyz[i3]-cx;
          xyz[i3+1] = xyz[i3+1]-cy;
          xyz[i3+2] = xyz[i3+2]-cz;
          //print data
          //std::cout << xyz[i3] << "\t" << xyz[i3+1] << "\t" << xyz[i3+2] << "\n";
       }
    */

    /*
       for(int i=0; i<size; i++)
       {
          i3 = i*3;
          xyzVol[i3]   -= cx;
          xyzVol[i3+1] -= cy;
          xyzVol[i3+2] -= cz;
          //print data
          //std::cout << xyz[i3] << "\t" << xyz[i3+1] << "\t" << xyz[i3+2] << "\n";
       }
    */

    // calculate the second molecule moment(3*3 matrix)
    double M[9];
    for (int i = 0; i < 9; i++) M[i] = 0;

    ij = 0;
    if (onlyHeavyAtoms) {
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                if (i == j) {
                    tmp = weights[i] * weights[i] * gVols[ij];
                    M[0] += tmp * xyz[i3] * xyz[i3];
                    M[1] += tmp * xyz[i3] * xyz[i3 + 1];
                    M[2] += tmp * xyz[i3] * xyz[i3 + 2];
                    M[4] += tmp * xyz[i3 + 1] * xyz[i3 + 1];
                    M[5] += tmp * xyz[i3 + 1] * xyz[i3 + 2];
                    M[8] += tmp * xyz[i3 + 2] * xyz[i3 + 2];
                } else {
                    tmp = 2 * weights[i] * weights[j] * gVols[ij];

                    /*
                             ij3 = ij * 3;
                             M[0] += tmp*xyzVol[ij3]*xyzVol[ij3];
                             M[1] += tmp*xyzVol[ij3]*xyzVol[ij3+1];
                             M[2] += tmp*xyzVol[ij3]*xyzVol[ij3+2];
                             M[4] += tmp*xyzVol[ij3+1]*xyzVol[ij3+1];
                             M[5] += tmp*xyzVol[ij3+1]*xyzVol[ij3+2];
                             M[8] += tmp*xyzVol[ij3+2]*xyzVol[ij3+2];
                    */

                    centX = (xyz[i3] + xyz[j3]) / 2;
                    centY = (xyz[i3 + 1] + xyz[j3 + 1]) / 2;
                    centZ = (xyz[i3 + 2] + xyz[j3 + 2]) / 2;

                    M[0] += tmp * centX * centX;
                    M[1] += tmp * centX * centY;
                    M[2] += tmp * centX * centZ;
                    M[4] += tmp * centY * centY;
                    M[5] += tmp * centY * centZ;
                    M[8] += tmp * centZ * centZ;
                }
                ij++;
            }
        }
    } else {
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                if (i == j) {
                    tmp = weights[i] * weights[i] * gVols[ij];
                    M[0] += tmp * xyz[i3] * xyz[i3];
                    M[1] += tmp * xyz[i3] * xyz[i3 + 1];
                    M[2] += tmp * xyz[i3] * xyz[i3 + 2];
                    M[4] += tmp * xyz[i3 + 1] * xyz[i3 + 1];
                    M[5] += tmp * xyz[i3 + 1] * xyz[i3 + 2];
                    M[8] += tmp * xyz[i3 + 2] * xyz[i3 + 2];
                } else {
                    tmp = 2 * weights[i] * weights[j] * gVols[ij];
                    a1a2 = alpha[i] + alpha[j];
                    /*
                             ij3 = ij * 3;
                             M[0] += tmp*xyzVol[ij3]*xyzVol[ij3];
                             M[1] += tmp*xyzVol[ij3]*xyzVol[ij3+1];
                             M[2] += tmp*xyzVol[ij3]*xyzVol[ij3+2];
                             M[4] += tmp*xyzVol[ij3+1]*xyzVol[ij3+1];
                             M[5] += tmp*xyzVol[ij3+1]*xyzVol[ij3+2];
                             M[8] += tmp*xyzVol[ij3+2]*xyzVol[ij3+2];
                    */
                    centX = (xyz[i3] * alpha[i] + xyz[j3] * alpha[j]) / a1a2;
                    centY = (xyz[i3 + 1] * alpha[i] + xyz[j3 + 1] * alpha[j]) / a1a2;
                    centZ = (xyz[i3 + 2] * alpha[i] + xyz[j3 + 2] * alpha[j]) / a1a2;

                    M[0] += tmp * centX * centX;
                    M[1] += tmp * centX * centY;
                    M[2] += tmp * centX * centZ;
                    M[4] += tmp * centY * centY;
                    M[5] += tmp * centY * centZ;
                    M[8] += tmp * centZ * centZ;
                }
                ij++;
            }
        }
    }

    for (int i = 0; i < nSpheres; i++) {
        i3 = i * 3;
        xyz[i3] = xyz[i3] - cx;
        xyz[i3 + 1] = xyz[i3 + 1] - cy;
        xyz[i3 + 2] = xyz[i3 + 2] - cz;
        // print data
        // std::cout << xyz[i3] << "\t" << xyz[i3+1] << "\t" << xyz[i3+2] << "\n";
    }

    return;

    //  delete [] xyzVol;

    M[3] = M[1];
    M[6] = M[2];
    M[7] = M[5];

    /*
       //print data
       for(int i=0; i<3; i++)
       {
         for(int j=0; j<3; j++)
         {
           ij = i*3+j;
           //std::cout << M[ij] << "\t";
         }
         //std::cout << "\n";
       }
    */

    double VEC[9], E[3];
    //  diagnoselization and get eigenvalue and eigenvector
    Jacobi(M, VEC, E, 3, 3);
    double A[3][3];
    for (int J = 0; J < 3; J++) {
        for (int K = 0; K < 3; K++) {
            A[J][K] = VEC[K * 3 + J];
        }
    }
    /*
     *   Sort the three eigen values and the corresponding eigenvectors
     *
     *     i.e. E(0) <= E(1) <= E(2)
     */
    double TEMP;
    if (E[1] > E[0]) {
        TEMP = E[0];
        E[0] = E[1];
        E[1] = TEMP;
        for (int I = 0; I < 3; I++) {
            TEMP = A[I][0];
            A[I][0] = A[I][1];
            A[I][1] = TEMP;
        }
    }
    if (E[2] > E[1]) {
        TEMP = E[1];
        E[1] = E[2];
        E[2] = TEMP;
        for (int I = 0; I < 3; I++) {
            TEMP = A[I][1];
            A[I][1] = A[I][2];
            A[I][2] = TEMP;
        }
    }
    if (E[1] > E[0]) {
        TEMP = E[0];
        E[0] = E[1];
        E[1] = TEMP;
        for (int I = 0; I < 3; I++) {
            TEMP = A[I][0];
            A[I][0] = A[I][1];
            A[I][1] = TEMP;
        }
    }

    E[0] += 100;
    E[1] += 100;
    E[2] += 100;

    if (0 != Eout) {
        Eout[0] = sqrt(E[0]);
        Eout[1] = sqrt(E[1]);
        Eout[2] = sqrt(E[2]);
    }
    // print data
    // std::cout << E[0] << "\t" << E[1] << "\t" << E[2] << "\t";

    double crossprod[3];
    for (int i = 0; i < 3; i++) crossprod[i] = 0;
    crossprod[0] = A[1][0] * A[2][1] - A[1][1] * A[2][0];
    crossprod[1] = A[0][1] * A[2][0] - A[0][0] * A[2][1];
    crossprod[2] = A[0][0] * A[1][1] - A[0][1] * A[1][0];
    double dotprod;
    dotprod = 0.0;
    for (int i = 0; i < 3; i++) {
        dotprod += crossprod[i] * A[i][2];
    }
    if (dotprod < 0) {
        A[0][2] = -A[0][2];
        A[1][2] = -A[1][2];
        A[2][2] = -A[2][2];
    }

    //      find rotation matrix by Kabsch Alg
    double Y[12];
    for (int i = 0; i < 12; i++) Y[i] = 0;
    Y[0] = 1;
    Y[4] = 1;
    Y[8] = 1;
    double rot[3][3];
    double X[12];
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            X[i * 3 + j] = A[j][i];
        }
    }
    X[9] = 0;
    X[10] = 0;
    X[11] = 0;
    superpose(Y, X, 4, rot);
    //      apply rotation to molecule
    double* rotresult = new double[nSpheres * 3];
    for (int i = 0; i < nSpheres * 3; i++) rotresult[i] = 0;
    for (int i = 0; i < nSpheres; i++) {
        i3 = i * 3;
        rotresult[i3] = xyz[i3] * rot[0][0] + xyz[i3 + 1] * rot[0][1] + xyz[i3 + 2] * rot[0][2];
        rotresult[i3 + 1] = xyz[i3] * rot[1][0] + xyz[i3 + 1] * rot[1][1] + xyz[i3 + 2] * rot[1][2];
        rotresult[i3 + 2] = xyz[i3] * rot[2][0] + xyz[i3 + 1] * rot[2][1] + xyz[i3 + 2] * rot[2][2];
    }
    //      export reoriented xyz back to sdfile

    for (int i = 0; i < nSpheres; i++) {
        i3 = i * 3;
        xyz[i3] = rotresult[i3];
        xyz[i3 + 1] = rotresult[i3 + 1];
        xyz[i3 + 2] = rotresult[i3 + 2];
    }

    delete[] rotresult;
}

void initTransAndRotation(int nSpheres, double* xyz, double* alpha, double* weights, double* gVols,
                          double* Eout, bool equalR, bool useR) {
    int i3, j3, ij, ij3;
    double tmp;
    double centX, centY, centZ;

    if (nSpheres > 1000) {
        std::cout << "More than 1000 atoms, stop\n";
        exit(0);
    }

    double cx = 0;
    double cy = 0;
    double cz = 0;
    double totalw = 0;
    double a1a2 = 0;

    ij = 0;

    if (equalR) {
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                if (i == j) {
                    tmp = weights[i] * weights[i] * gVols[ij];
                    cx += tmp * xyz[i3];
                    cy += tmp * xyz[i3 + 1];
                    cz += tmp * xyz[i3 + 2];
                    totalw += tmp;
                } else {
                    tmp = 2 * weights[i] * weights[j] * gVols[ij];
                    cx += tmp * (xyz[i3] + xyz[j3]) / 2;
                    cy += tmp * (xyz[i3 + 1] + xyz[j3 + 1]) / 2;
                    cz += tmp * (xyz[i3 + 2] + xyz[j3 + 2]) / 2;

                    totalw += tmp;
                }
                ij++;
            }
        }
    } else {
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                if (i == j) {
                    tmp = weights[i] * weights[i] * gVols[ij];
                    cx += tmp * xyz[i3];
                    cy += tmp * xyz[i3 + 1];
                    cz += tmp * xyz[i3 + 2];
                    totalw += tmp;
                } else {
                    tmp = 2 * weights[i] * weights[j] * gVols[ij];
                    a1a2 = alpha[i] + alpha[j];
                    cx += tmp * (xyz[i3] * alpha[i] + xyz[j3] * alpha[j]) / a1a2;
                    cy += tmp * (xyz[i3 + 1] * alpha[i] + xyz[j3 + 1] * alpha[j]) / a1a2;
                    cz += tmp * (xyz[i3 + 2] * alpha[i] + xyz[j3 + 2] * alpha[j]) / a1a2;

                    totalw += tmp;
                }
                ij++;
            }
        }
    }
    cx = cx / totalw;
    cy = cy / totalw;
    cz = cz / totalw;

    for (int i = 0; i < nSpheres; i++) {
        i3 = i * 3;
        xyz[i3] = xyz[i3] - cx;
        xyz[i3 + 1] = xyz[i3 + 1] - cy;
        xyz[i3 + 2] = xyz[i3 + 2] - cz;
        // print data
        // std::cout << xyz[i3] << "\t" << xyz[i3+1] << "\t" << xyz[i3+2] << "\n";
    }

    if (!useR) return;

    // calculate the second molecule moment(3*3 matrix)
    double M[9];
    for (int i = 0; i < 9; i++) M[i] = 0;

    ij = 0;
    if (equalR) {
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                if (i == j) {
                    tmp = weights[i] * weights[i] * gVols[ij];
                    M[0] += tmp * xyz[i3] * xyz[i3];
                    M[1] += tmp * xyz[i3] * xyz[i3 + 1];
                    M[2] += tmp * xyz[i3] * xyz[i3 + 2];
                    M[4] += tmp * xyz[i3 + 1] * xyz[i3 + 1];
                    M[5] += tmp * xyz[i3 + 1] * xyz[i3 + 2];
                    M[8] += tmp * xyz[i3 + 2] * xyz[i3 + 2];
                } else {
                    tmp = 2 * weights[i] * weights[j] * gVols[ij];

                    centX = (xyz[i3] + xyz[j3]) / 2;
                    centY = (xyz[i3 + 1] + xyz[j3 + 1]) / 2;
                    centZ = (xyz[i3 + 2] + xyz[j3 + 2]) / 2;

                    M[0] += tmp * centX * centX;
                    M[1] += tmp * centX * centY;
                    M[2] += tmp * centX * centZ;
                    M[4] += tmp * centY * centY;
                    M[5] += tmp * centY * centZ;
                    M[8] += tmp * centZ * centZ;
                }
                ij++;
            }
        }
    } else {
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                if (i == j) {
                    tmp = weights[i] * weights[i] * gVols[ij];
                    M[0] += tmp * xyz[i3] * xyz[i3];
                    M[1] += tmp * xyz[i3] * xyz[i3 + 1];
                    M[2] += tmp * xyz[i3] * xyz[i3 + 2];
                    M[4] += tmp * xyz[i3 + 1] * xyz[i3 + 1];
                    M[5] += tmp * xyz[i3 + 1] * xyz[i3 + 2];
                    M[8] += tmp * xyz[i3 + 2] * xyz[i3 + 2];
                } else {
                    tmp = 2 * weights[i] * weights[j] * gVols[ij];
                    a1a2 = alpha[i] + alpha[j];
                    centX = (xyz[i3] * alpha[i] + xyz[j3] * alpha[j]) / a1a2;
                    centY = (xyz[i3 + 1] * alpha[i] + xyz[j3 + 1] * alpha[j]) / a1a2;
                    centZ = (xyz[i3 + 2] * alpha[i] + xyz[j3 + 2] * alpha[j]) / a1a2;

                    M[0] += tmp * centX * centX;
                    M[1] += tmp * centX * centY;
                    M[2] += tmp * centX * centZ;
                    M[4] += tmp * centY * centY;
                    M[5] += tmp * centY * centZ;
                    M[8] += tmp * centZ * centZ;
                }
                ij++;
            }
        }
    }

    M[3] = M[1];
    M[6] = M[2];
    M[7] = M[5];

    /*
       //print data
       for(int i=0; i<3; i++)
       {
         for(int j=0; j<3; j++)
         {
           ij = i*3+j;
           //std::cout << M[ij] << "\t";
         }
         //std::cout << "\n";
       }
    */

    double VEC[9], E[3];
    //  diagnoselization and get eigenvalue and eigenvector
    Jacobi(M, VEC, E, 3, 3);
    double A[3][3];
    for (int J = 0; J < 3; J++) {
        for (int K = 0; K < 3; K++) {
            A[J][K] = VEC[K * 3 + J];
        }
    }
    /*
     *   Sort the three eigen values and the corresponding eigenvectors
     *
     *     i.e. E(0) <= E(1) <= E(2)
     */
    double TEMP;
    if (E[1] > E[0]) {
        TEMP = E[0];
        E[0] = E[1];
        E[1] = TEMP;
        for (int I = 0; I < 3; I++) {
            TEMP = A[I][0];
            A[I][0] = A[I][1];
            A[I][1] = TEMP;
        }
    }
    if (E[2] > E[1]) {
        TEMP = E[1];
        E[1] = E[2];
        E[2] = TEMP;
        for (int I = 0; I < 3; I++) {
            TEMP = A[I][1];
            A[I][1] = A[I][2];
            A[I][2] = TEMP;
        }
    }
    if (E[1] > E[0]) {
        TEMP = E[0];
        E[0] = E[1];
        E[1] = TEMP;
        for (int I = 0; I < 3; I++) {
            TEMP = A[I][0];
            A[I][0] = A[I][1];
            A[I][1] = TEMP;
        }
    }

    E[0] += 100;
    E[1] += 100;
    E[2] += 100;

    if (0 != Eout) {
        Eout[0] = sqrt(E[0]);
        Eout[1] = sqrt(E[1]);
        Eout[2] = sqrt(E[2]);
    }
    // print data
    // std::cout << E[0] << "\t" << E[1] << "\t" << E[2] << "\t";

    double crossprod[3];
    for (int i = 0; i < 3; i++) crossprod[i] = 0;
    crossprod[0] = A[1][0] * A[2][1] - A[1][1] * A[2][0];
    crossprod[1] = A[0][1] * A[2][0] - A[0][0] * A[2][1];
    crossprod[2] = A[0][0] * A[1][1] - A[0][1] * A[1][0];
    double dotprod;
    dotprod = 0.0;
    for (int i = 0; i < 3; i++) {
        dotprod += crossprod[i] * A[i][2];
    }
    if (dotprod < 0) {
        A[0][2] = -A[0][2];
        A[1][2] = -A[1][2];
        A[2][2] = -A[2][2];
    }

    //      find rotation matrix by Kabsch Alg
    double Y[12];
    for (int i = 0; i < 12; i++) Y[i] = 0;
    Y[0] = 1;
    Y[4] = 1;
    Y[8] = 1;
    double rot[3][3];
    double X[12];
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            X[i * 3 + j] = A[j][i];
        }
    }
    X[9] = 0;
    X[10] = 0;
    X[11] = 0;
    superpose(Y, X, 4, rot);
    //      apply rotation to molecule
    double* rotresult = new double[nSpheres * 3];
    for (int i = 0; i < nSpheres * 3; i++) rotresult[i] = 0;
    for (int i = 0; i < nSpheres; i++) {
        i3 = i * 3;
        rotresult[i3] = xyz[i3] * rot[0][0] + xyz[i3 + 1] * rot[0][1] + xyz[i3 + 2] * rot[0][2];
        rotresult[i3 + 1] = xyz[i3] * rot[1][0] + xyz[i3 + 1] * rot[1][1] + xyz[i3 + 2] * rot[1][2];
        rotresult[i3 + 2] = xyz[i3] * rot[2][0] + xyz[i3 + 1] * rot[2][1] + xyz[i3 + 2] * rot[2][2];
    }
    //      export reoriented xyz back to sdfile

    for (int i = 0; i < nSpheres; i++) {
        i3 = i * 3;
        xyz[i3] = rotresult[i3];
        xyz[i3 + 1] = rotresult[i3 + 1];
        xyz[i3 + 2] = rotresult[i3 + 2];
    }

    delete[] rotresult;
}

// lixm.move the core center as the origin.
void initTransAndRotation_SS(int nSpheres, double* xyz, double* alpha, double* weights,
                             double* gVols, double* Eout, bool equalR, bool useR, int* mtype) {
    int i3, j3, ij, ij3;
    double tmp;
    double centX, centY, centZ;

    if (nSpheres > 1000) {
        std::cout << "More than 1000 atoms, stop\n";
        exit(0);
    }

    double cx = 0;
    double cy = 0;
    double cz = 0;
    double totalw = 0;
    double a1a2 = 0;

    ij = 0;

    if (equalR) {
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                if (i == j) {
                    if (mtype[i] == 1 && mtype[j] == 1) {
                        tmp = weights[i] * weights[i] * gVols[ij];
                        cx += tmp * xyz[i3];
                        cy += tmp * xyz[i3 + 1];
                        cz += tmp * xyz[i3 + 2];
                        totalw += tmp;
                    }
                } else {
                    if (mtype[i] == 1 && mtype[j] == 1) {
                        tmp = 2 * weights[i] * weights[j] * gVols[ij];
                        cx += tmp * (xyz[i3] + xyz[j3]) / 2;
                        cy += tmp * (xyz[i3 + 1] + xyz[j3 + 1]) / 2;
                        cz += tmp * (xyz[i3 + 2] + xyz[j3 + 2]) / 2;

                        totalw += tmp;
                    }
                }
                ij++;
            }
        }
    } else {
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                if (i == j) {
                    if (mtype[i] == 1 && mtype[j] == 1) {
                        tmp = weights[i] * weights[i] * gVols[ij];
                        cx += tmp * xyz[i3];
                        cy += tmp * xyz[i3 + 1];
                        cz += tmp * xyz[i3 + 2];
                        totalw += tmp;
                    }
                } else {
                    if (mtype[i] == 1 && mtype[j] == 1) {
                        tmp = 2 * weights[i] * weights[j] * gVols[ij];
                        a1a2 = alpha[i] + alpha[j];
                        cx += tmp * (xyz[i3] * alpha[i] + xyz[j3] * alpha[j]) / a1a2;
                        cy += tmp * (xyz[i3 + 1] * alpha[i] + xyz[j3 + 1] * alpha[j]) / a1a2;
                        cz += tmp * (xyz[i3 + 2] * alpha[i] + xyz[j3 + 2] * alpha[j]) / a1a2;

                        totalw += tmp;
                    }
                }
                ij++;
            }
        }
    }
    cx = cx / totalw;
    cy = cy / totalw;
    cz = cz / totalw;

    for (int i = 0; i < nSpheres; i++) {
        i3 = i * 3;
        xyz[i3] = xyz[i3] - cx;
        xyz[i3 + 1] = xyz[i3 + 1] - cy;
        xyz[i3 + 2] = xyz[i3 + 2] - cz;
        // print data
        // std::cout << xyz[i3] << "\t" << xyz[i3+1] << "\t" << xyz[i3+2] << "\n";
    }

    if (!useR) return;

    // calculate the second molecule moment(3*3 matrix)
    double M[9];
    for (int i = 0; i < 9; i++) M[i] = 0;

    ij = 0;
    if (equalR) {
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                if (i == j) {
                    tmp = weights[i] * weights[i] * gVols[ij];
                    M[0] += tmp * xyz[i3] * xyz[i3];
                    M[1] += tmp * xyz[i3] * xyz[i3 + 1];
                    M[2] += tmp * xyz[i3] * xyz[i3 + 2];
                    M[4] += tmp * xyz[i3 + 1] * xyz[i3 + 1];
                    M[5] += tmp * xyz[i3 + 1] * xyz[i3 + 2];
                    M[8] += tmp * xyz[i3 + 2] * xyz[i3 + 2];
                } else {
                    tmp = 2 * weights[i] * weights[j] * gVols[ij];

                    centX = (xyz[i3] + xyz[j3]) / 2;
                    centY = (xyz[i3 + 1] + xyz[j3 + 1]) / 2;
                    centZ = (xyz[i3 + 2] + xyz[j3 + 2]) / 2;

                    M[0] += tmp * centX * centX;
                    M[1] += tmp * centX * centY;
                    M[2] += tmp * centX * centZ;
                    M[4] += tmp * centY * centY;
                    M[5] += tmp * centY * centZ;
                    M[8] += tmp * centZ * centZ;
                }
                ij++;
            }
        }
    } else {
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                if (i == j) {
                    tmp = weights[i] * weights[i] * gVols[ij];
                    M[0] += tmp * xyz[i3] * xyz[i3];
                    M[1] += tmp * xyz[i3] * xyz[i3 + 1];
                    M[2] += tmp * xyz[i3] * xyz[i3 + 2];
                    M[4] += tmp * xyz[i3 + 1] * xyz[i3 + 1];
                    M[5] += tmp * xyz[i3 + 1] * xyz[i3 + 2];
                    M[8] += tmp * xyz[i3 + 2] * xyz[i3 + 2];
                } else {
                    tmp = 2 * weights[i] * weights[j] * gVols[ij];
                    a1a2 = alpha[i] + alpha[j];
                    centX = (xyz[i3] * alpha[i] + xyz[j3] * alpha[j]) / a1a2;
                    centY = (xyz[i3 + 1] * alpha[i] + xyz[j3 + 1] * alpha[j]) / a1a2;
                    centZ = (xyz[i3 + 2] * alpha[i] + xyz[j3 + 2] * alpha[j]) / a1a2;

                    M[0] += tmp * centX * centX;
                    M[1] += tmp * centX * centY;
                    M[2] += tmp * centX * centZ;
                    M[4] += tmp * centY * centY;
                    M[5] += tmp * centY * centZ;
                    M[8] += tmp * centZ * centZ;
                }
                ij++;
            }
        }
    }

    M[3] = M[1];
    M[6] = M[2];
    M[7] = M[5];

    /*
       //print data
       for(int i=0; i<3; i++)
       {
         for(int j=0; j<3; j++)
         {
           ij = i*3+j;
           //std::cout << M[ij] << "\t";
         }
         //std::cout << "\n";
       }
    */

    double VEC[9], E[3];
    //  diagnoselization and get eigenvalue and eigenvector
    Jacobi(M, VEC, E, 3, 3);
    double A[3][3];
    for (int J = 0; J < 3; J++) {
        for (int K = 0; K < 3; K++) {
            A[J][K] = VEC[K * 3 + J];
        }
    }
    /*
     *   Sort the three eigen values and the corresponding eigenvectors
     *
     *     i.e. E(0) <= E(1) <= E(2)
     */
    double TEMP;
    if (E[1] > E[0]) {
        TEMP = E[0];
        E[0] = E[1];
        E[1] = TEMP;
        for (int I = 0; I < 3; I++) {
            TEMP = A[I][0];
            A[I][0] = A[I][1];
            A[I][1] = TEMP;
        }
    }
    if (E[2] > E[1]) {
        TEMP = E[1];
        E[1] = E[2];
        E[2] = TEMP;
        for (int I = 0; I < 3; I++) {
            TEMP = A[I][1];
            A[I][1] = A[I][2];
            A[I][2] = TEMP;
        }
    }
    if (E[1] > E[0]) {
        TEMP = E[0];
        E[0] = E[1];
        E[1] = TEMP;
        for (int I = 0; I < 3; I++) {
            TEMP = A[I][0];
            A[I][0] = A[I][1];
            A[I][1] = TEMP;
        }
    }

    E[0] += 100;
    E[1] += 100;
    E[2] += 100;

    if (0 != Eout) {
        Eout[0] = sqrt(E[0]);
        Eout[1] = sqrt(E[1]);
        Eout[2] = sqrt(E[2]);
    }
    // print data
    // std::cout << E[0] << "\t" << E[1] << "\t" << E[2] << "\t";

    double crossprod[3];
    for (int i = 0; i < 3; i++) crossprod[i] = 0;
    crossprod[0] = A[1][0] * A[2][1] - A[1][1] * A[2][0];
    crossprod[1] = A[0][1] * A[2][0] - A[0][0] * A[2][1];
    crossprod[2] = A[0][0] * A[1][1] - A[0][1] * A[1][0];
    double dotprod;
    dotprod = 0.0;
    for (int i = 0; i < 3; i++) {
        dotprod += crossprod[i] * A[i][2];
    }
    if (dotprod < 0) {
        A[0][2] = -A[0][2];
        A[1][2] = -A[1][2];
        A[2][2] = -A[2][2];
    }

    //      find rotation matrix by Kabsch Alg
    double Y[12];
    for (int i = 0; i < 12; i++) Y[i] = 0;
    Y[0] = 1;
    Y[4] = 1;
    Y[8] = 1;
    double rot[3][3];
    double X[12];
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            X[i * 3 + j] = A[j][i];
        }
    }
    X[9] = 0;
    X[10] = 0;
    X[11] = 0;
    superpose(Y, X, 4, rot);
    //      apply rotation to molecule
    double* rotresult = new double[nSpheres * 3];
    for (int i = 0; i < nSpheres * 3; i++) rotresult[i] = 0;
    for (int i = 0; i < nSpheres; i++) {
        i3 = i * 3;
        rotresult[i3] = xyz[i3] * rot[0][0] + xyz[i3 + 1] * rot[0][1] + xyz[i3 + 2] * rot[0][2];
        rotresult[i3 + 1] = xyz[i3] * rot[1][0] + xyz[i3 + 1] * rot[1][1] + xyz[i3 + 2] * rot[1][2];
        rotresult[i3 + 2] = xyz[i3] * rot[2][0] + xyz[i3 + 1] * rot[2][1] + xyz[i3 + 2] * rot[2][2];
    }
    //      export reoriented xyz back to sdfile

    for (int i = 0; i < nSpheres; i++) {
        i3 = i * 3;
        xyz[i3] = rotresult[i3];
        xyz[i3 + 1] = rotresult[i3 + 1];
        xyz[i3 + 2] = rotresult[i3 + 2];
    }

    delete[] rotresult;
}

void initTransAndRotation(int nSpheres, double* xyz, double* alpha, double* weights, double* gVols,
                          double* centGrv, double* Eout, bool equalR, bool useR) {
    int i3, j3, ij, ij3;
    double tmp;
    double centX, centY, centZ;

    if (nSpheres > 1000) {
        std::cout << "More than 1000 atoms, stop\n";
        exit(0);
    }

    double cx = 0;
    double cy = 0;
    double cz = 0;
    double totalw = 0;
    double a1a2 = 0;

    ij = 0;

    if (equalR) {
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                if (i == j) {
                    tmp = weights[i] * weights[i] * gVols[ij];
                    cx += tmp * xyz[i3];
                    cy += tmp * xyz[i3 + 1];
                    cz += tmp * xyz[i3 + 2];
                    totalw += tmp;
                } else {
                    tmp = 2 * weights[i] * weights[j] * gVols[ij];
                    cx += tmp * (xyz[i3] + xyz[j3]) / 2;
                    cy += tmp * (xyz[i3 + 1] + xyz[j3 + 1]) / 2;
                    cz += tmp * (xyz[i3 + 2] + xyz[j3 + 2]) / 2;

                    totalw += tmp;
                }
                ij++;
            }
        }
    } else {
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                if (i == j) {
                    tmp = weights[i] * weights[i] * gVols[ij];
                    cx += tmp * xyz[i3];
                    cy += tmp * xyz[i3 + 1];
                    cz += tmp * xyz[i3 + 2];
                    totalw += tmp;
                } else {
                    tmp = 2 * weights[i] * weights[j] * gVols[ij];
                    a1a2 = alpha[i] + alpha[j];
                    cx += tmp * (xyz[i3] * alpha[i] + xyz[j3] * alpha[j]) / a1a2;
                    cy += tmp * (xyz[i3 + 1] * alpha[i] + xyz[j3 + 1] * alpha[j]) / a1a2;
                    cz += tmp * (xyz[i3 + 2] * alpha[i] + xyz[j3 + 2] * alpha[j]) / a1a2;

                    totalw += tmp;
                }
                ij++;
            }
        }
    }
    cx = cx / totalw;
    cy = cy / totalw;
    cz = cz / totalw;

    centGrv[0] = cx;
    centGrv[1] = cy;
    centGrv[2] = cz;

    for (int i = 0; i < nSpheres; i++) {
        i3 = i * 3;
        xyz[i3] = xyz[i3] - cx;
        xyz[i3 + 1] = xyz[i3 + 1] - cy;
        xyz[i3 + 2] = xyz[i3 + 2] - cz;
    }

    if (!useR) return;

    // calculate the second molecule moment(3*3 matrix)
    double M[9];
    for (int i = 0; i < 9; i++) M[i] = 0;

    ij = 0;
    if (equalR) {
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                if (i == j) {
                    tmp = weights[i] * weights[i] * gVols[ij];
                    M[0] += tmp * xyz[i3] * xyz[i3];
                    M[1] += tmp * xyz[i3] * xyz[i3 + 1];
                    M[2] += tmp * xyz[i3] * xyz[i3 + 2];
                    M[4] += tmp * xyz[i3 + 1] * xyz[i3 + 1];
                    M[5] += tmp * xyz[i3 + 1] * xyz[i3 + 2];
                    M[8] += tmp * xyz[i3 + 2] * xyz[i3 + 2];
                } else {
                    tmp = 2 * weights[i] * weights[j] * gVols[ij];

                    centX = (xyz[i3] + xyz[j3]) / 2;
                    centY = (xyz[i3 + 1] + xyz[j3 + 1]) / 2;
                    centZ = (xyz[i3 + 2] + xyz[j3 + 2]) / 2;

                    M[0] += tmp * centX * centX;
                    M[1] += tmp * centX * centY;
                    M[2] += tmp * centX * centZ;
                    M[4] += tmp * centY * centY;
                    M[5] += tmp * centY * centZ;
                    M[8] += tmp * centZ * centZ;
                }
                ij++;
            }
        }
    } else {
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                if (i == j) {
                    tmp = weights[i] * weights[i] * gVols[ij];
                    M[0] += tmp * xyz[i3] * xyz[i3];
                    M[1] += tmp * xyz[i3] * xyz[i3 + 1];
                    M[2] += tmp * xyz[i3] * xyz[i3 + 2];
                    M[4] += tmp * xyz[i3 + 1] * xyz[i3 + 1];
                    M[5] += tmp * xyz[i3 + 1] * xyz[i3 + 2];
                    M[8] += tmp * xyz[i3 + 2] * xyz[i3 + 2];
                } else {
                    tmp = 2 * weights[i] * weights[j] * gVols[ij];
                    a1a2 = alpha[i] + alpha[j];
                    centX = (xyz[i3] * alpha[i] + xyz[j3] * alpha[j]) / a1a2;
                    centY = (xyz[i3 + 1] * alpha[i] + xyz[j3 + 1] * alpha[j]) / a1a2;
                    centZ = (xyz[i3 + 2] * alpha[i] + xyz[j3 + 2] * alpha[j]) / a1a2;

                    M[0] += tmp * centX * centX;
                    M[1] += tmp * centX * centY;
                    M[2] += tmp * centX * centZ;
                    M[4] += tmp * centY * centY;
                    M[5] += tmp * centY * centZ;
                    M[8] += tmp * centZ * centZ;
                }
                ij++;
            }
        }
    }

    M[3] = M[1];
    M[6] = M[2];
    M[7] = M[5];

    double VEC[9], E[3];
    //  diagnoselization and get eigenvalue and eigenvector
    Jacobi(M, VEC, E, 3, 3);
    double A[3][3];
    for (int J = 0; J < 3; J++) {
        for (int K = 0; K < 3; K++) {
            A[J][K] = VEC[K * 3 + J];
        }
    }
    /*
     *   Sort the three eigen values and the corresponding eigenvectors
     *
     *     i.e. E(0) <= E(1) <= E(2)
     */
    double TEMP;
    if (E[1] > E[0]) {
        TEMP = E[0];
        E[0] = E[1];
        E[1] = TEMP;
        for (int I = 0; I < 3; I++) {
            TEMP = A[I][0];
            A[I][0] = A[I][1];
            A[I][1] = TEMP;
        }
    }
    if (E[2] > E[1]) {
        TEMP = E[1];
        E[1] = E[2];
        E[2] = TEMP;
        for (int I = 0; I < 3; I++) {
            TEMP = A[I][1];
            A[I][1] = A[I][2];
            A[I][2] = TEMP;
        }
    }
    if (E[1] > E[0]) {
        TEMP = E[0];
        E[0] = E[1];
        E[1] = TEMP;
        for (int I = 0; I < 3; I++) {
            TEMP = A[I][0];
            A[I][0] = A[I][1];
            A[I][1] = TEMP;
        }
    }

    E[0] += 100;
    E[1] += 100;
    E[2] += 100;

    if (0 != Eout) {
        Eout[0] = sqrt(E[0]);
        Eout[1] = sqrt(E[1]);
        Eout[2] = sqrt(E[2]);
    }

    double crossprod[3];
    for (int i = 0; i < 3; i++) crossprod[i] = 0;
    crossprod[0] = A[1][0] * A[2][1] - A[1][1] * A[2][0];
    crossprod[1] = A[0][1] * A[2][0] - A[0][0] * A[2][1];
    crossprod[2] = A[0][0] * A[1][1] - A[0][1] * A[1][0];
    double dotprod;
    dotprod = 0.0;
    for (int i = 0; i < 3; i++) {
        dotprod += crossprod[i] * A[i][2];
    }
    if (dotprod < 0) {
        A[0][2] = -A[0][2];
        A[1][2] = -A[1][2];
        A[2][2] = -A[2][2];
    }

    //      find rotation matrix by Kabsch Alg
    double Y[12];
    for (int i = 0; i < 12; i++) Y[i] = 0;
    Y[0] = 1;
    Y[4] = 1;
    Y[8] = 1;
    double rot[3][3];
    double X[12];
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            X[i * 3 + j] = A[j][i];
        }
    }
    X[9] = 0;
    X[10] = 0;
    X[11] = 0;
    superpose(Y, X, 4, rot);
    //      apply rotation to molecule
    double* rotresult = new double[nSpheres * 3];
    for (int i = 0; i < nSpheres * 3; i++) rotresult[i] = 0;
    for (int i = 0; i < nSpheres; i++) {
        i3 = i * 3;
        rotresult[i3] = xyz[i3] * rot[0][0] + xyz[i3 + 1] * rot[0][1] + xyz[i3 + 2] * rot[0][2];
        rotresult[i3 + 1] = xyz[i3] * rot[1][0] + xyz[i3 + 1] * rot[1][1] + xyz[i3 + 2] * rot[1][2];
        rotresult[i3 + 2] = xyz[i3] * rot[2][0] + xyz[i3 + 1] * rot[2][1] + xyz[i3 + 2] * rot[2][2];
    }
    //      export reoriented xyz back to sdfile

    for (int i = 0; i < nSpheres; i++) {
        i3 = i * 3;
        xyz[i3] = rotresult[i3];
        xyz[i3 + 1] = rotresult[i3 + 1];
        xyz[i3 + 2] = rotresult[i3 + 2];
    }

    delete[] rotresult;
}

// lixm.remove core center as the original point.
void initTransAndRotation_SS(int nSpheres, double* xyz, double* alpha, double* weights,
                             double* gVols, double* centGrv, double* Eout, bool equalR, bool useR,
                             int* mtype) {
    int i3, j3, ij, ij3;
    double tmp;
    double centX, centY, centZ;

    if (nSpheres > 1000) {
        std::cout << "More than 1000 atoms, stop\n";
        exit(0);
    }

    double cx = 0;
    double cy = 0;
    double cz = 0;
    double totalw = 0;
    double a1a2 = 0;

    ij = 0;

    /**
    if (equalR)
    {
      for (int i = 0; i < nSpheres; i++)
      {
        i3 = i * 3;
        for (int j = 0; j < i + 1; j++)
        {
          j3 = j * 3;
          if (i == j)
          {
            tmp = weights[i] * weights[i] * gVols[ij];
            cx += tmp * xyz[i3];
            cy += tmp * xyz[i3 + 1];
            cz += tmp * xyz[i3 + 2];
            totalw += tmp;
          }
          else
          {
            tmp = 2 * weights[i] * weights[j] * gVols[ij];
            cx += tmp * (xyz[i3] + xyz[j3]) / 2;
            cy += tmp * (xyz[i3 + 1] + xyz[j3 + 1]) / 2;
            cz += tmp * (xyz[i3 + 2] + xyz[j3 + 2]) / 2;

            totalw += tmp;
          }
          ij++;
        }
      }
    }
    else
    {
      for (int i = 0; i < nSpheres; i++)
      {
        i3 = i * 3;
        for (int j = 0; j < i + 1; j++)
        {
          j3 = j * 3;
          if (i == j)
          {
            tmp = weights[i] * weights[i] * gVols[ij];
            cx += tmp * xyz[i3];
            cy += tmp * xyz[i3 + 1];
            cz += tmp * xyz[i3 + 2];
            totalw += tmp;
          }
          else
          {
            tmp = 2 * weights[i] * weights[j] * gVols[ij];
            a1a2 = alpha[i] + alpha[j];
            cx += tmp * (xyz[i3] * alpha[i] + xyz[j3] * alpha[j]) / a1a2;
            cy +=
              tmp * (xyz[i3 + 1] * alpha[i] + xyz[j3 + 1] * alpha[j]) / a1a2;
            cz +=
              tmp * (xyz[i3 + 2] * alpha[i] + xyz[j3 + 2] * alpha[j]) / a1a2;

            totalw += tmp;
          }
          ij++;
        }
      }
    }
    cx = cx / totalw;
    cy = cy / totalw;
    cz = cz / totalw;
    **/
    // lixm.
    if (equalR) {
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                if (i == j) {
                    if (mtype[i] == 1 && mtype[j] == 1) {
                        tmp = weights[i] * weights[i] * gVols[ij];
                        cx += tmp * xyz[i3];
                        cy += tmp * xyz[i3 + 1];
                        cz += tmp * xyz[i3 + 2];
                        totalw += tmp;
                    }
                } else {
                    if (mtype[i] == 1 && mtype[j] == 1) {
                        tmp = 2 * weights[i] * weights[j] * gVols[ij];
                        cx += tmp * (xyz[i3] + xyz[j3]) / 2;
                        cy += tmp * (xyz[i3 + 1] + xyz[j3 + 1]) / 2;
                        cz += tmp * (xyz[i3 + 2] + xyz[j3 + 2]) / 2;

                        totalw += tmp;
                    }
                }
                ij++;
            }
        }
    } else {
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                if (i == j) {
                    if (mtype[i] == 1 && mtype[j] == 1) {
                        tmp = weights[i] * weights[i] * gVols[ij];
                        cx += tmp * xyz[i3];
                        cy += tmp * xyz[i3 + 1];
                        cz += tmp * xyz[i3 + 2];
                        totalw += tmp;
                    }
                } else {
                    if (mtype[i] == 1 && mtype[j] == 1) {
                        tmp = 2 * weights[i] * weights[j] * gVols[ij];
                        a1a2 = alpha[i] + alpha[j];
                        cx += tmp * (xyz[i3] * alpha[i] + xyz[j3] * alpha[j]) / a1a2;
                        cy += tmp * (xyz[i3 + 1] * alpha[i] + xyz[j3 + 1] * alpha[j]) / a1a2;
                        cz += tmp * (xyz[i3 + 2] * alpha[i] + xyz[j3 + 2] * alpha[j]) / a1a2;

                        totalw += tmp;
                    }
                }
                ij++;
            }
        }
    }
    cx = cx / totalw;
    cy = cy / totalw;
    cz = cz / totalw;

    centGrv[0] = cx;
    centGrv[1] = cy;
    centGrv[2] = cz;

    for (int i = 0; i < nSpheres; i++) {
        i3 = i * 3;
        xyz[i3] = xyz[i3] - cx;
        xyz[i3 + 1] = xyz[i3 + 1] - cy;
        xyz[i3 + 2] = xyz[i3 + 2] - cz;
    }

    if (!useR) return;

    // calculate the second molecule moment(3*3 matrix)
    double M[9];
    for (int i = 0; i < 9; i++) M[i] = 0;

    ij = 0;
    if (equalR) {
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                if (i == j) {
                    tmp = weights[i] * weights[i] * gVols[ij];
                    M[0] += tmp * xyz[i3] * xyz[i3];
                    M[1] += tmp * xyz[i3] * xyz[i3 + 1];
                    M[2] += tmp * xyz[i3] * xyz[i3 + 2];
                    M[4] += tmp * xyz[i3 + 1] * xyz[i3 + 1];
                    M[5] += tmp * xyz[i3 + 1] * xyz[i3 + 2];
                    M[8] += tmp * xyz[i3 + 2] * xyz[i3 + 2];
                } else {
                    tmp = 2 * weights[i] * weights[j] * gVols[ij];

                    centX = (xyz[i3] + xyz[j3]) / 2;
                    centY = (xyz[i3 + 1] + xyz[j3 + 1]) / 2;
                    centZ = (xyz[i3 + 2] + xyz[j3 + 2]) / 2;

                    M[0] += tmp * centX * centX;
                    M[1] += tmp * centX * centY;
                    M[2] += tmp * centX * centZ;
                    M[4] += tmp * centY * centY;
                    M[5] += tmp * centY * centZ;
                    M[8] += tmp * centZ * centZ;
                }
                ij++;
            }
        }
    } else {
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                if (i == j) {
                    tmp = weights[i] * weights[i] * gVols[ij];
                    M[0] += tmp * xyz[i3] * xyz[i3];
                    M[1] += tmp * xyz[i3] * xyz[i3 + 1];
                    M[2] += tmp * xyz[i3] * xyz[i3 + 2];
                    M[4] += tmp * xyz[i3 + 1] * xyz[i3 + 1];
                    M[5] += tmp * xyz[i3 + 1] * xyz[i3 + 2];
                    M[8] += tmp * xyz[i3 + 2] * xyz[i3 + 2];
                } else {
                    tmp = 2 * weights[i] * weights[j] * gVols[ij];
                    a1a2 = alpha[i] + alpha[j];
                    centX = (xyz[i3] * alpha[i] + xyz[j3] * alpha[j]) / a1a2;
                    centY = (xyz[i3 + 1] * alpha[i] + xyz[j3 + 1] * alpha[j]) / a1a2;
                    centZ = (xyz[i3 + 2] * alpha[i] + xyz[j3 + 2] * alpha[j]) / a1a2;

                    M[0] += tmp * centX * centX;
                    M[1] += tmp * centX * centY;
                    M[2] += tmp * centX * centZ;
                    M[4] += tmp * centY * centY;
                    M[5] += tmp * centY * centZ;
                    M[8] += tmp * centZ * centZ;
                }
                ij++;
            }
        }
    }

    M[3] = M[1];
    M[6] = M[2];
    M[7] = M[5];

    double VEC[9], E[3];
    //  diagnoselization and get eigenvalue and eigenvector
    Jacobi(M, VEC, E, 3, 3);
    double A[3][3];
    for (int J = 0; J < 3; J++) {
        for (int K = 0; K < 3; K++) {
            A[J][K] = VEC[K * 3 + J];
        }
    }
    /*
     *   Sort the three eigen values and the corresponding eigenvectors
     *
     *     i.e. E(0) <= E(1) <= E(2)
     */
    double TEMP;
    if (E[1] > E[0]) {
        TEMP = E[0];
        E[0] = E[1];
        E[1] = TEMP;
        for (int I = 0; I < 3; I++) {
            TEMP = A[I][0];
            A[I][0] = A[I][1];
            A[I][1] = TEMP;
        }
    }
    if (E[2] > E[1]) {
        TEMP = E[1];
        E[1] = E[2];
        E[2] = TEMP;
        for (int I = 0; I < 3; I++) {
            TEMP = A[I][1];
            A[I][1] = A[I][2];
            A[I][2] = TEMP;
        }
    }
    if (E[1] > E[0]) {
        TEMP = E[0];
        E[0] = E[1];
        E[1] = TEMP;
        for (int I = 0; I < 3; I++) {
            TEMP = A[I][0];
            A[I][0] = A[I][1];
            A[I][1] = TEMP;
        }
    }

    E[0] += 100;
    E[1] += 100;
    E[2] += 100;

    if (0 != Eout) {
        Eout[0] = sqrt(E[0]);
        Eout[1] = sqrt(E[1]);
        Eout[2] = sqrt(E[2]);
    }

    double crossprod[3];
    for (int i = 0; i < 3; i++) crossprod[i] = 0;
    crossprod[0] = A[1][0] * A[2][1] - A[1][1] * A[2][0];
    crossprod[1] = A[0][1] * A[2][0] - A[0][0] * A[2][1];
    crossprod[2] = A[0][0] * A[1][1] - A[0][1] * A[1][0];
    double dotprod;
    dotprod = 0.0;
    for (int i = 0; i < 3; i++) {
        dotprod += crossprod[i] * A[i][2];
    }
    if (dotprod < 0) {
        A[0][2] = -A[0][2];
        A[1][2] = -A[1][2];
        A[2][2] = -A[2][2];
    }

    //      find rotation matrix by Kabsch Alg
    double Y[12];
    for (int i = 0; i < 12; i++) Y[i] = 0;
    Y[0] = 1;
    Y[4] = 1;
    Y[8] = 1;
    double rot[3][3];
    double X[12];
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            X[i * 3 + j] = A[j][i];
        }
    }
    X[9] = 0;
    X[10] = 0;
    X[11] = 0;
    superpose(Y, X, 4, rot);
    //      apply rotation to molecule
    double* rotresult = new double[nSpheres * 3];
    for (int i = 0; i < nSpheres * 3; i++) rotresult[i] = 0;
    for (int i = 0; i < nSpheres; i++) {
        i3 = i * 3;
        rotresult[i3] = xyz[i3] * rot[0][0] + xyz[i3 + 1] * rot[0][1] + xyz[i3 + 2] * rot[0][2];
        rotresult[i3 + 1] = xyz[i3] * rot[1][0] + xyz[i3 + 1] * rot[1][1] + xyz[i3 + 2] * rot[1][2];
        rotresult[i3 + 2] = xyz[i3] * rot[2][0] + xyz[i3 + 1] * rot[2][1] + xyz[i3 + 2] * rot[2][2];
    }
    //      export reoriented xyz back to sdfile

    for (int i = 0; i < nSpheres; i++) {
        i3 = i * 3;
        xyz[i3] = rotresult[i3];
        xyz[i3 + 1] = rotresult[i3 + 1];
        xyz[i3 + 2] = rotresult[i3 + 2];
    }

    delete[] rotresult;
}

void initTransAndRotation(int nSpheres, double* xyz, double* alpha, double* weights, double* gVols,
                          double* centGrv, double rotMat[][3], double* Eout, bool equalR,
                          bool useR) {
    int i3, j3, ij, ij3;
    double tmp;
    double centX, centY, centZ;

    if (nSpheres > 1000) {
        std::cout << "More than 1000 atoms, stop\n";
        exit(0);
    }

    double cx = 0;
    double cy = 0;
    double cz = 0;
    double totalw = 0;
    double a1a2 = 0;

    ij = 0;

    if (equalR) {
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                if (i == j) {
                    tmp = weights[i] * weights[i] * gVols[ij];
                    cx += tmp * xyz[i3];
                    cy += tmp * xyz[i3 + 1];
                    cz += tmp * xyz[i3 + 2];
                    totalw += tmp;
                } else {
                    tmp = 2 * weights[i] * weights[j] * gVols[ij];
                    cx += tmp * (xyz[i3] + xyz[j3]) / 2;
                    cy += tmp * (xyz[i3 + 1] + xyz[j3 + 1]) / 2;
                    cz += tmp * (xyz[i3 + 2] + xyz[j3 + 2]) / 2;

                    totalw += tmp;
                }
                ij++;
            }
        }
    } else {
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                if (i == j) {
                    tmp = weights[i] * weights[i] * gVols[ij];
                    cx += tmp * xyz[i3];
                    cy += tmp * xyz[i3 + 1];
                    cz += tmp * xyz[i3 + 2];
                    totalw += tmp;
                } else {
                    tmp = 2 * weights[i] * weights[j] * gVols[ij];
                    a1a2 = alpha[i] + alpha[j];
                    cx += tmp * (xyz[i3] * alpha[i] + xyz[j3] * alpha[j]) / a1a2;
                    cy += tmp * (xyz[i3 + 1] * alpha[i] + xyz[j3 + 1] * alpha[j]) / a1a2;
                    cz += tmp * (xyz[i3 + 2] * alpha[i] + xyz[j3 + 2] * alpha[j]) / a1a2;

                    totalw += tmp;
                }
                ij++;
            }
        }
    }
    cx = cx / totalw;
    cy = cy / totalw;
    cz = cz / totalw;

    centGrv[0] = cx;
    centGrv[1] = cy;
    centGrv[2] = cz;

    for (int i = 0; i < nSpheres; i++) {
        i3 = i * 3;
        xyz[i3] = xyz[i3] - cx;
        xyz[i3 + 1] = xyz[i3 + 1] - cy;
        xyz[i3 + 2] = xyz[i3 + 2] - cz;
    }

    if (!useR) return;

    // calculate the second molecule moment(3*3 matrix)
    double M[9];
    for (int i = 0; i < 9; i++) M[i] = 0;

    ij = 0;
    if (equalR) {
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                if (i == j) {
                    tmp = weights[i] * weights[i] * gVols[ij];
                    M[0] += tmp * xyz[i3] * xyz[i3];
                    M[1] += tmp * xyz[i3] * xyz[i3 + 1];
                    M[2] += tmp * xyz[i3] * xyz[i3 + 2];
                    M[4] += tmp * xyz[i3 + 1] * xyz[i3 + 1];
                    M[5] += tmp * xyz[i3 + 1] * xyz[i3 + 2];
                    M[8] += tmp * xyz[i3 + 2] * xyz[i3 + 2];
                } else {
                    tmp = 2 * weights[i] * weights[j] * gVols[ij];

                    centX = (xyz[i3] + xyz[j3]) / 2;
                    centY = (xyz[i3 + 1] + xyz[j3 + 1]) / 2;
                    centZ = (xyz[i3 + 2] + xyz[j3 + 2]) / 2;

                    M[0] += tmp * centX * centX;
                    M[1] += tmp * centX * centY;
                    M[2] += tmp * centX * centZ;
                    M[4] += tmp * centY * centY;
                    M[5] += tmp * centY * centZ;
                    M[8] += tmp * centZ * centZ;
                }
                ij++;
            }
        }
    } else {
        for (int i = 0; i < nSpheres; i++) {
            i3 = i * 3;
            for (int j = 0; j < i + 1; j++) {
                j3 = j * 3;
                if (i == j) {
                    tmp = weights[i] * weights[i] * gVols[ij];
                    M[0] += tmp * xyz[i3] * xyz[i3];
                    M[1] += tmp * xyz[i3] * xyz[i3 + 1];
                    M[2] += tmp * xyz[i3] * xyz[i3 + 2];
                    M[4] += tmp * xyz[i3 + 1] * xyz[i3 + 1];
                    M[5] += tmp * xyz[i3 + 1] * xyz[i3 + 2];
                    M[8] += tmp * xyz[i3 + 2] * xyz[i3 + 2];
                } else {
                    tmp = 2 * weights[i] * weights[j] * gVols[ij];
                    a1a2 = alpha[i] + alpha[j];
                    centX = (xyz[i3] * alpha[i] + xyz[j3] * alpha[j]) / a1a2;
                    centY = (xyz[i3 + 1] * alpha[i] + xyz[j3 + 1] * alpha[j]) / a1a2;
                    centZ = (xyz[i3 + 2] * alpha[i] + xyz[j3 + 2] * alpha[j]) / a1a2;

                    M[0] += tmp * centX * centX;
                    M[1] += tmp * centX * centY;
                    M[2] += tmp * centX * centZ;
                    M[4] += tmp * centY * centY;
                    M[5] += tmp * centY * centZ;
                    M[8] += tmp * centZ * centZ;
                }
                ij++;
            }
        }
    }

    M[3] = M[1];
    M[6] = M[2];
    M[7] = M[5];

    double VEC[9], E[3];
    //  diagnoselization and get eigenvalue and eigenvector
    Jacobi(M, VEC, E, 3, 3);
    double A[3][3];
    for (int J = 0; J < 3; J++) {
        for (int K = 0; K < 3; K++) {
            A[J][K] = VEC[K * 3 + J];
        }
    }
    /*
     *   Sort the three eigen values and the corresponding eigenvectors
     *
     *     i.e. E(0) <= E(1) <= E(2)
     */
    double TEMP;
    if (E[1] > E[0]) {
        TEMP = E[0];
        E[0] = E[1];
        E[1] = TEMP;
        for (int I = 0; I < 3; I++) {
            TEMP = A[I][0];
            A[I][0] = A[I][1];
            A[I][1] = TEMP;
        }
    }
    if (E[2] > E[1]) {
        TEMP = E[1];
        E[1] = E[2];
        E[2] = TEMP;
        for (int I = 0; I < 3; I++) {
            TEMP = A[I][1];
            A[I][1] = A[I][2];
            A[I][2] = TEMP;
        }
    }
    if (E[1] > E[0]) {
        TEMP = E[0];
        E[0] = E[1];
        E[1] = TEMP;
        for (int I = 0; I < 3; I++) {
            TEMP = A[I][0];
            A[I][0] = A[I][1];
            A[I][1] = TEMP;
        }
    }

    E[0] += 100;
    E[1] += 100;
    E[2] += 100;

    if (0 != Eout) {
        Eout[0] = sqrt(E[0]);
        Eout[1] = sqrt(E[1]);
        Eout[2] = sqrt(E[2]);
    }

    double crossprod[3];
    for (int i = 0; i < 3; i++) crossprod[i] = 0;
    crossprod[0] = A[1][0] * A[2][1] - A[1][1] * A[2][0];
    crossprod[1] = A[0][1] * A[2][0] - A[0][0] * A[2][1];
    crossprod[2] = A[0][0] * A[1][1] - A[0][1] * A[1][0];
    double dotprod;
    dotprod = 0.0;
    for (int i = 0; i < 3; i++) {
        dotprod += crossprod[i] * A[i][2];
    }
    if (dotprod < 0) {
        A[0][2] = -A[0][2];
        A[1][2] = -A[1][2];
        A[2][2] = -A[2][2];
    }

    //      find rotation matrix by Kabsch Alg
    double Y[12];
    for (int i = 0; i < 12; i++) Y[i] = 0;
    Y[0] = 1;
    Y[4] = 1;
    Y[8] = 1;
    double rot[3][3];
    double X[12];
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            X[i * 3 + j] = A[j][i];
        }
    }
    X[9] = 0;
    X[10] = 0;
    X[11] = 0;
    superpose(Y, X, 4, rot);

    // copy rotation matrix
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            rotMat[i][j] = rot[i][j];
        }
    }

    //      apply rotation to molecule
    double* rotresult = new double[nSpheres * 3];
    for (int i = 0; i < nSpheres * 3; i++) rotresult[i] = 0;
    for (int i = 0; i < nSpheres; i++) {
        i3 = i * 3;
        rotresult[i3] = xyz[i3] * rot[0][0] + xyz[i3 + 1] * rot[0][1] + xyz[i3 + 2] * rot[0][2];
        rotresult[i3 + 1] = xyz[i3] * rot[1][0] + xyz[i3 + 1] * rot[1][1] + xyz[i3 + 2] * rot[1][2];
        rotresult[i3 + 2] = xyz[i3] * rot[2][0] + xyz[i3 + 1] * rot[2][1] + xyz[i3 + 2] * rot[2][2];
    }
    //      export reoriented xyz back to sdfile

    for (int i = 0; i < nSpheres; i++) {
        i3 = i * 3;
        xyz[i3] = rotresult[i3];
        xyz[i3 + 1] = rotresult[i3 + 1];
        xyz[i3 + 2] = rotresult[i3 + 2];
    }

    delete[] rotresult;
}

void initFeatAlignment(int nSpheres, double* xyz, double* weights, double* centGrv,
                       double rotMat[][3]) {
    int i3, j3, ij, ij3;
    double tmp;
    double centX, centY, centZ;

    if (nSpheres > 1000) {
        std::cout << "More than 1000 atoms, stop\n";
        exit(0);
    }

    double cx = 0;
    double cy = 0;
    double cz = 0;
    double totalw = 0;
    double a1a2 = 0;

    ij = 0;

    for (int i = 0; i < nSpheres; i++) {
        i3 = i * 3;
        tmp = weights[i];
        cx += tmp * xyz[i3];
        cy += tmp * xyz[i3 + 1];
        cz += tmp * xyz[i3 + 2];
        totalw += tmp;
    }
    cx = cx / totalw;
    cy = cy / totalw;
    cz = cz / totalw;

    centGrv[0] = cx;
    centGrv[1] = cy;
    centGrv[2] = cz;

    for (int i = 0; i < nSpheres; i++) {
        i3 = i * 3;
        xyz[i3] = xyz[i3] - cx;
        xyz[i3 + 1] = xyz[i3 + 1] - cy;
        xyz[i3 + 2] = xyz[i3 + 2] - cz;
    }

    // calculate the second molecule moment(3*3 matrix)
    double M[9];
    for (int i = 0; i < 9; i++) M[i] = 0;

    ij = 0;
    for (int i = 0; i < nSpheres; i++) {
        i3 = i * 3;
        tmp = weights[i];
        M[0] += tmp * xyz[i3] * xyz[i3];
        M[1] += tmp * xyz[i3] * xyz[i3 + 1];
        M[2] += tmp * xyz[i3] * xyz[i3 + 2];
        M[4] += tmp * xyz[i3 + 1] * xyz[i3 + 1];
        M[5] += tmp * xyz[i3 + 1] * xyz[i3 + 2];
        M[8] += tmp * xyz[i3 + 2] * xyz[i3 + 2];
    }

    M[3] = M[1];
    M[6] = M[2];
    M[7] = M[5];

    double VEC[9], E[3];
    //  diagnoselization and get eigenvalue and eigenvector
    Jacobi(M, VEC, E, 3, 3);
    double A[3][3];
    for (int J = 0; J < 3; J++) {
        for (int K = 0; K < 3; K++) {
            A[J][K] = VEC[K * 3 + J];
        }
    }
    /*
     *   Sort the three eigen values and the corresponding eigenvectors
     *
     *     i.e. E(0) <= E(1) <= E(2)
     */
    double TEMP;
    if (E[1] > E[0]) {
        TEMP = E[0];
        E[0] = E[1];
        E[1] = TEMP;
        for (int I = 0; I < 3; I++) {
            TEMP = A[I][0];
            A[I][0] = A[I][1];
            A[I][1] = TEMP;
        }
    }
    if (E[2] > E[1]) {
        TEMP = E[1];
        E[1] = E[2];
        E[2] = TEMP;
        for (int I = 0; I < 3; I++) {
            TEMP = A[I][1];
            A[I][1] = A[I][2];
            A[I][2] = TEMP;
        }
    }
    if (E[1] > E[0]) {
        TEMP = E[0];
        E[0] = E[1];
        E[1] = TEMP;
        for (int I = 0; I < 3; I++) {
            TEMP = A[I][0];
            A[I][0] = A[I][1];
            A[I][1] = TEMP;
        }
    }

    E[0] += 100;
    E[1] += 100;
    E[2] += 100;

    double crossprod[3];
    for (int i = 0; i < 3; i++) crossprod[i] = 0;
    crossprod[0] = A[1][0] * A[2][1] - A[1][1] * A[2][0];
    crossprod[1] = A[0][1] * A[2][0] - A[0][0] * A[2][1];
    crossprod[2] = A[0][0] * A[1][1] - A[0][1] * A[1][0];
    double dotprod;
    dotprod = 0.0;
    for (int i = 0; i < 3; i++) {
        dotprod += crossprod[i] * A[i][2];
    }
    if (dotprod < 0) {
        A[0][2] = -A[0][2];
        A[1][2] = -A[1][2];
        A[2][2] = -A[2][2];
    }

    //      find rotation matrix by Kabsch Alg
    double Y[12];
    for (int i = 0; i < 12; i++) Y[i] = 0;
    Y[0] = 1;
    Y[4] = 1;
    Y[8] = 1;
    double rot[3][3];
    double X[12];
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            X[i * 3 + j] = A[j][i];
        }
    }
    X[9] = 0;
    X[10] = 0;
    X[11] = 0;
    superpose(Y, X, 4, rot);

    // copy rotation matrix
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            rotMat[i][j] = rot[i][j];
        }
    }

    //      apply rotation to molecule
    double* rotresult = new double[nSpheres * 3];
    for (int i = 0; i < nSpheres * 3; i++) rotresult[i] = 0;
    for (int i = 0; i < nSpheres; i++) {
        i3 = i * 3;
        rotresult[i3] = xyz[i3] * rot[0][0] + xyz[i3 + 1] * rot[0][1] + xyz[i3 + 2] * rot[0][2];
        rotresult[i3 + 1] = xyz[i3] * rot[1][0] + xyz[i3 + 1] * rot[1][1] + xyz[i3 + 2] * rot[1][2];
        rotresult[i3 + 2] = xyz[i3] * rot[2][0] + xyz[i3 + 1] * rot[2][1] + xyz[i3 + 2] * rot[2][2];
    }
    //      export reoriented xyz back to sdfile

    for (int i = 0; i < nSpheres; i++) {
        i3 = i * 3;
        xyz[i3] = rotresult[i3];
        xyz[i3 + 1] = rotresult[i3 + 1];
        xyz[i3 + 2] = rotresult[i3 + 2];
    }

    delete[] rotresult;
}

double overlayGSpheres(int NA1, double* xyz1, double* alpha1, double* w1, int NA2, double* xyz2,
                       double* alpha2, double* w2, bool trans, bool equalR) {
    //
    // r' = R*r + T
    //
    // r': new position
    // r:  Original position of mol1
    // R:  Rotation matrix
    // T:  Translation
    //
    int i, i3, j, ij;
    double molvol;
    double molvol2;
    double diffVol;
    double xyz0[3], xyzr[3];
    double r[3][3];
    double xyz[3000];
    double a, b, g;
    double T[3];

    double drt[6];
    double hess[6][6], dx[6];
    double dmaxFactor = 1.0;
    double Thresh = 0.01;
    int maxIter = 25;
    double dmax = 0;

    double* cderv = new double[NA1 * 3];
    double* chess = new double[NA1 * 6];

    // Save old coordinates
    for (i = 0; i < NA1; i++) {
        i3 = i * 3;
        xyz[i3] = xyz1[i3];
        xyz[i3 + 1] = xyz1[i3 + 1];
        xyz[i3 + 2] = xyz1[i3 + 2];
    }

    T[0] = 0;
    T[1] = 0;
    T[2] = 0;
    a = 0;
    b = 0;
    g = 0;

    int iter = 0;
    molvol2 = 0;
    double damp = 0.5;

    do {
        iter++;

        molvol =
            calDervsCartesian(NA1, xyz1, alpha1, w1, NA2, xyz2, alpha2, w2, cderv, chess, equalR);

        dervsCartesian2RT(NA1, xyz1, cderv, chess, drt, hess);

        dmax = LSolver6(hess, drt, dx);

        dmaxFactor = 1.0;
        diffVol = fabs(molvol - molvol2);
        if (molvol < molvol2) {
            dmaxFactor = 0.5;
        }

        damp = 1.0;
        if (dmax > 0.5 * dmaxFactor) damp = 0.5 * dmaxFactor / dmax;
        molvol2 = molvol;
        a = -damp * dx[0];
        b = -damp * dx[1];
        g = -damp * dx[2];
        T[0] = -damp * dx[3];
        T[1] = -damp * dx[4];
        T[2] = -damp * dx[5];
        /*
           printf("\ndrt:\n");
           for(i=0;i<6;i++)
           {
             printf("%f ",drt[i]);
           }
           printf("\nhess:");
           for(i=0;i<6;i++)
           {
             printf("\n");
             for(int j=0;j<6;j++)
             {
                printf("%f ",hess[i][j]);
             }
           }
           printf("iteration%d, molvol: %f\n",iter,molvol);
           printf("dx:\n%f %f %f %f %f %f\n",dx[0],dx[1],dx[2],dx[3],dx[4],dx[5]);
           printf("rt:\n%f %f %f %f %f %f\n",a,b,g,T[0],T[1],T[2]);
        */
        // Translation
        RotMat(a, b, g, r);
        for (i = 0; i < NA1; i++) {
            i3 = i * 3;
            Rotation(xyz1 + i3, r, xyzr);
            xyz1[i3] = xyzr[0] + T[0];
            xyz1[i3 + 1] = xyzr[1] + T[1];
            xyz1[i3 + 2] = xyzr[2] + T[2];
        }

    } while (diffVol > Thresh && iter < maxIter);
    // std::cout << "iter: " << iter << "\n";

    /*
       if(diffVol > Thresh && iter == maxIter)
       {
         printf("iter: %d, NR method is not converged\n",iter);
       }
       printf("Iter = %d, molVol2 = %10.5f, dmax = %10.5f\n",iter, molvol2,dmax);
    */

    // Copy xyz back to mol
    if (!trans) {
        for (i = 0; i < NA1; i++) {
            i3 = i * 3;
            xyz1[i3] = xyz[i3];
            xyz1[i3 + 1] = xyz[i3 + 1];
            xyz1[i3 + 2] = xyz[i3 + 2];
        }
    }

    delete[] cderv;
    delete[] chess;
    return molvol;
}

double overlayGSpheres_SS(int NA1, double* xyz1, double* alpha1, double* w1, int NA2, double* xyz2,
                          double* alpha2, double* w2, bool trans, bool equalR, int* qtype,
                          double* qwt, int* stype, double* swt, double* mvol) {
    //
    // r' = R*r + T
    //
    // r': new position
    // r:  Original position of mol1
    // R:  Rotation matrix
    // T:  Translation
    //
    int i, i3, j, ij;
    double molvol;
    double molvol2;
    double diffVol;
    double xyz0[3], xyzr[3];
    double r[3][3];
    double xyz[3000];
    double a, b, g;
    double T[3];

    double drt[6];
    double hess[6][6], dx[6];
    double dmaxFactor = 1.0;
    double Thresh = 0.01;
    int maxIter = 25;
    double dmax = 0;

    double* cderv = new double[NA1 * 3];
    double* chess = new double[NA1 * 6];

    // Save old coordinates
    for (i = 0; i < NA1; i++) {
        i3 = i * 3;
        xyz[i3] = xyz1[i3];
        xyz[i3 + 1] = xyz1[i3 + 1];
        xyz[i3 + 2] = xyz1[i3 + 2];
    }

    T[0] = 0;
    T[1] = 0;
    T[2] = 0;
    a = 0;
    b = 0;
    g = 0;

    int iter = 0;
    molvol2 = 0;
    double damp = 0.5;

    do {
        iter++;

        // molvol = calDervsCartesian(NA1, xyz1, alpha1, w1, NA2, xyz2, alpha2, w2, cderv, chess,
        // equalR);
        mvol[0] = 0;
        mvol[1] = 0;
        molvol = calDervsCartesian_SS(NA1, xyz1, alpha1, w1, NA2, xyz2, alpha2, w2, cderv, chess,
                                      equalR, qtype, qwt, stype, swt, mvol);
        // std::cout << mvol[0] << " " << mvol[1] << " " << molvol << "\n";

        dervsCartesian2RT(NA1, xyz1, cderv, chess, drt, hess);

        dmax = LSolver6(hess, drt, dx);

        dmaxFactor = 1.0;
        diffVol = fabs(molvol - molvol2);
        if (molvol < molvol2) {
            dmaxFactor = 0.5;
        }

        damp = 1.0;
        if (dmax > 0.5 * dmaxFactor) damp = 0.5 * dmaxFactor / dmax;
        molvol2 = molvol;
        a = -damp * dx[0];
        b = -damp * dx[1];
        g = -damp * dx[2];
        T[0] = -damp * dx[3];
        T[1] = -damp * dx[4];
        T[2] = -damp * dx[5];
        /*
           printf("\ndrt:\n");
           for(i=0;i<6;i++)
           {
             printf("%f ",drt[i]);
           }
           printf("\nhess:");
           for(i=0;i<6;i++)
           {
             printf("\n");
             for(int j=0;j<6;j++)
             {
                printf("%f ",hess[i][j]);
             }
           }
           printf("iteration%d, molvol: %f\n",iter,molvol);
           printf("dx:\n%f %f %f %f %f %f\n",dx[0],dx[1],dx[2],dx[3],dx[4],dx[5]);
           printf("rt:\n%f %f %f %f %f %f\n",a,b,g,T[0],T[1],T[2]);
        */
        // Translation
        RotMat(a, b, g, r);
        for (i = 0; i < NA1; i++) {
            i3 = i * 3;
            Rotation(xyz1 + i3, r, xyzr);
            xyz1[i3] = xyzr[0] + T[0];
            xyz1[i3 + 1] = xyzr[1] + T[1];
            xyz1[i3 + 2] = xyzr[2] + T[2];
        }

    } while (diffVol > Thresh && iter < maxIter);
    // std::cout << "iter: " << iter << "\n";

    /*
       if(diffVol > Thresh && iter == maxIter)
       {
         printf("iter: %d, NR method is not converged\n",iter);
       }
       printf("Iter = %d, molVol2 = %10.5f, dmax = %10.5f\n",iter, molvol2,dmax);
    */

    // Copy xyz back to mol
    if (!trans) {
        for (i = 0; i < NA1; i++) {
            i3 = i * 3;
            xyz1[i3] = xyz[i3];
            xyz1[i3 + 1] = xyz[i3 + 1];
            xyz1[i3 + 2] = xyz[i3 + 2];
        }
    }

    // std::cout << mvol[0] << " " << mvol[1] << " " << molvol << "\n";

    delete[] cderv;
    delete[] chess;
    return molvol;
}

float overlayGSpheres_float(int NA1, float* xyz1, float* alpha1, float* w1, int NA2, float* xyz2,
                            float* alpha2, float* w2, bool trans, bool equalR) {
    //
    // r' = R*r + T
    //
    // r': new position
    // r:  Original position of mol1
    // R:  Rotation matrix
    // T:  Translation
    //
    int i, i3, j, ij;
    float molvol;
    float molvol2;
    float diffVol;
    float xyz0[3], xyzr[3];
    float r[3][3];
    float xyz[3000];
    float a, b, g;
    float T[3];

    float drt[6];
    float hess[6][6], dx[6];
    float dmaxFactor = 1.0;
    float Thresh = 0.01;
    int maxIter = 25;
    float dmax = 0;

    float* cderv = new float[NA1 * 3];
    float* chess = new float[NA1 * 6];

    // Save old coordinates
    for (i = 0; i < NA1; i++) {
        i3 = i * 3;
        xyz[i3] = xyz1[i3];
        xyz[i3 + 1] = xyz1[i3 + 1];
        xyz[i3 + 2] = xyz1[i3 + 2];
    }

    T[0] = 0;
    T[1] = 0;
    T[2] = 0;
    a = 0;
    b = 0;
    g = 0;

    int iter = 0;
    molvol2 = 0;
    float damp = 0.5;

    do {
        iter++;

        molvol = calDervsCartesian_float(NA1, xyz1, alpha1, w1, NA2, xyz2, alpha2, w2, cderv, chess,
                                         equalR);

        dervsCartesian2RT_float(NA1, xyz1, cderv, chess, drt, hess);

        dmax = LSolver6_float(hess, drt, dx);

        dmaxFactor = 1.0;
        diffVol = fabs(molvol - molvol2);
        if (molvol < molvol2) {
            dmaxFactor = 0.5;
        }

        damp = 1.0;
        if (dmax > 0.5 * dmaxFactor) damp = 0.5 * dmaxFactor / dmax;
        molvol2 = molvol;
        a = -damp * dx[0];
        b = -damp * dx[1];
        g = -damp * dx[2];
        T[0] = -damp * dx[3];
        T[1] = -damp * dx[4];
        T[2] = -damp * dx[5];
        /*
           printf("\ndrt:\n");
           for(i=0;i<6;i++)
           {
             printf("%f ",drt[i]);
           }
           printf("\nhess:");
           for(i=0;i<6;i++)
           {
             printf("\n");
             for(int j=0;j<6;j++)
             {
                printf("%f ",hess[i][j]);
             }
           }
           printf("iteration%d, molvol: %f\n",iter,molvol);
           printf("dx:\n%f %f %f %f %f %f\n",dx[0],dx[1],dx[2],dx[3],dx[4],dx[5]);
           printf("rt:\n%f %f %f %f %f %f\n",a,b,g,T[0],T[1],T[2]);
        */
        // Translation
        RotMat_float(a, b, g, r);
        for (i = 0; i < NA1; i++) {
            i3 = i * 3;
            Rotation_float(xyz1 + i3, r, xyzr);
            xyz1[i3] = xyzr[0] + T[0];
            xyz1[i3 + 1] = xyzr[1] + T[1];
            xyz1[i3 + 2] = xyzr[2] + T[2];
        }

    } while (diffVol > Thresh && iter < maxIter);
    // std::cout << "iter: " << iter << "\n";

    /*
       if(diffVol > Thresh && iter == maxIter)
       {
         printf("iter: %d, NR method is not converged\n",iter);
       }
       printf("Iter = %d, molVol2 = %10.5f, dmax = %10.5f\n",iter, molvol2,dmax);
    */

    // Copy xyz back to mol
    if (!trans) {
        for (i = 0; i < NA1; i++) {
            i3 = i * 3;
            xyz1[i3] = xyz[i3];
            xyz1[i3 + 1] = xyz[i3 + 1];
            xyz1[i3 + 2] = xyz[i3 + 2];
        }
    }

    delete[] cderv;
    delete[] chess;
    return molvol;
}

double calDervsCartesian(int na1, double* xyz1, double* alpha1, double* w1, int na2, double* xyz2,
                         double* alpha2, double* w2, double* cderv, double* chess, bool equalR) {
    int i, j, ina2;
    int i3, i6, j3;
    double pi = 3.14159265358979;
    double p2 = gParam * gParam;
    double pidltn, w1p2;
    double dltn, kn, dist;
    double tmpd, tav, tavad, tavap;
    double crossVol = 0;
    double rn[3];
    double derv[3], hess[6];

    double* wxpp = new double[na1 * na2];

    if (equalR)  // all vdwR are equal, so all alphas are equal
    {
        dltn = alpha1[0] + alpha2[0];
        pidltn = pi / dltn;
        pidltn = pidltn * sqrt(pidltn);
        for (i = 0; i < na1; i++) {
            w1p2 = w1[i] * p2;
            ina2 = i * na2;
            for (j = 0; j < na2; j++) {
                wxpp[ina2 + j] = w1p2 * w2[j] * pidltn;
            }
        }
    } else {
        for (i = 0; i < na1; i++) {
            w1p2 = w1[i] * p2;
            ina2 = i * na2;
            for (j = 0; j < na2; j++) {
                dltn = alpha1[i] + alpha2[j];
                pidltn = pi / dltn;
                wxpp[ina2 + j] = w1p2 * w2[j] * pidltn * sqrt(pidltn);
            }
        }
    }

    if (equalR)  // all vdwR are equal, so all alpha are equals
    {
        double alpha = alpha1[0];
        double alphaH = alpha / 2;
        double alphaD = alpha * 2;
        for (i = 0; i < na1; i++) {
            i3 = i * 3;
            i6 = i3 + i3;
            ina2 = i * na2;
            derv[0] = 0;
            derv[1] = 0;
            derv[2] = 0;
            hess[0] = 0;
            hess[1] = 0;
            hess[2] = 0;
            hess[3] = 0;
            hess[4] = 0;
            hess[5] = 0;

            for (j = 0; j < na2; j++) {
                j3 = j * 3;
                dist = (xyz1[i3] - xyz2[j3]) * (xyz1[i3] - xyz2[j3]) +
                       (xyz1[i3 + 1] - xyz2[j3 + 1]) * (xyz1[i3 + 1] - xyz2[j3 + 1]) +
                       (xyz1[i3 + 2] - xyz2[j3 + 2]) * (xyz1[i3 + 2] - xyz2[j3 + 2]);
                rn[0] = (xyz1[i3] + xyz2[j3]) / 2;
                rn[1] = (xyz1[i3 + 1] + xyz2[j3 + 1]) / 2;
                rn[2] = (xyz1[i3 + 2] + xyz2[j3 + 2]) / 2;
                kn = exp(-alphaH * dist);
                // A: poor implementation
                // tmpd = w1p2*w2[j]*kn*pow(pi/dltn,1.5);
                //
                // B: maybe a good option for GPU implementation
                // pidltn = 3.14159265358979/dltn;
                // tmpd = w1p2*w2[j]*kn*pidltn*sqrt(pidltn);
                //
                // C: a slightly more efficient CPU implementation using
                //    pre-computed values stored in wxpp.
                tmpd = wxpp[ina2 + j] * kn;
                crossVol += tmpd;
                // First derivatives
                tav = alphaD * tmpd;
                derv[0] += tav * (xyz1[i3] - rn[0]);
                derv[1] += tav * (xyz1[i3 + 1] - rn[1]);
                derv[2] += tav * (xyz1[i3 + 2] - rn[2]);
                tavad = tav * (-0.5);
                tavap = (tav + tav) * alpha;
                // Hessian
                hess[0] -= tavad + tavap * (xyz1[i3] - rn[0]) * (xyz1[i3] - rn[0]);
                hess[1] -= tavap * (xyz1[i3] - rn[0]) * (xyz1[i3 + 1] - rn[1]);
                hess[2] -= tavad + tavap * (xyz1[i3 + 1] - rn[1]) * (xyz1[i3 + 1] - rn[1]);
                hess[3] -= tavap * (xyz1[i3] - rn[0]) * (xyz1[i3 + 2] - rn[2]);
                hess[4] -= tavap * (xyz1[i3 + 1] - rn[1]) * (xyz1[i3 + 2] - rn[2]);
                hess[5] -= tavad + tavap * (xyz1[i3 + 2] - rn[2]) * (xyz1[i3 + 2] - rn[2]);
            }

            // save dervs of each atom in na1
            cderv[i3] = derv[0];
            cderv[i3 + 1] = derv[1];
            cderv[i3 + 2] = derv[2];
            chess[i6] = hess[0];
            chess[i6 + 1] = hess[1];
            chess[i6 + 2] = hess[2];
            chess[i6 + 3] = hess[3];
            chess[i6 + 4] = hess[4];
            chess[i6 + 5] = hess[5];
        }
    } else {
        for (i = 0; i < na1; i++) {
            i3 = i * 3;
            i6 = i3 + i3;
            ina2 = i * na2;
            derv[0] = 0;
            derv[1] = 0;
            derv[2] = 0;
            hess[0] = 0;
            hess[1] = 0;
            hess[2] = 0;
            hess[3] = 0;
            hess[4] = 0;
            hess[5] = 0;

            for (j = 0; j < na2; j++) {
                j3 = j * 3;
                dist = (xyz1[i3] - xyz2[j3]) * (xyz1[i3] - xyz2[j3]) +
                       (xyz1[i3 + 1] - xyz2[j3 + 1]) * (xyz1[i3 + 1] - xyz2[j3 + 1]) +
                       (xyz1[i3 + 2] - xyz2[j3 + 2]) * (xyz1[i3 + 2] - xyz2[j3 + 2]);
                dltn = alpha1[i] + alpha2[j];
                rn[0] = (xyz1[i3] * alpha1[i] + xyz2[j3] * alpha2[j]) / dltn;
                rn[1] = (xyz1[i3 + 1] * alpha1[i] + xyz2[j3 + 1] * alpha2[j]) / dltn;
                rn[2] = (xyz1[i3 + 2] * alpha1[i] + xyz2[j3 + 2] * alpha2[j]) / dltn;
                kn = exp(-alpha1[i] * alpha2[j] * dist / dltn);
                // A: poor implementation
                // tmpd = w1p2*w2[j]*kn*pow(pi/dltn,1.5);
                //
                // B: maybe a good option for GPU implementation
                // pidltn = 3.14159265358979/dltn;
                // tmpd = w1p2*w2[j]*kn*pidltn*sqrt(pidltn);
                //
                // C: a slightly more efficient CPU implementation using
                //    pre-computed values stored in wxpp.
                tmpd = wxpp[ina2 + j] * kn;
                crossVol += tmpd;
                // First derivatives
                tav = alpha1[i] * tmpd * 2;
                derv[0] += tav * (xyz1[i3] - rn[0]);
                derv[1] += tav * (xyz1[i3 + 1] - rn[1]);
                derv[2] += tav * (xyz1[i3 + 2] - rn[2]);
                tavad = tav * (alpha1[i] / dltn - 1);
                tavap = (tav + tav) * alpha1[i];
                // Hessian
                hess[0] -= tavad + tavap * (xyz1[i3] - rn[0]) * (xyz1[i3] - rn[0]);
                hess[1] -= tavap * (xyz1[i3] - rn[0]) * (xyz1[i3 + 1] - rn[1]);
                hess[2] -= tavad + tavap * (xyz1[i3 + 1] - rn[1]) * (xyz1[i3 + 1] - rn[1]);
                hess[3] -= tavap * (xyz1[i3] - rn[0]) * (xyz1[i3 + 2] - rn[2]);
                hess[4] -= tavap * (xyz1[i3 + 1] - rn[1]) * (xyz1[i3 + 2] - rn[2]);
                hess[5] -= tavad + tavap * (xyz1[i3 + 2] - rn[2]) * (xyz1[i3 + 2] - rn[2]);
            }

            // save dervs of each atom in na1
            cderv[i3] = derv[0];
            cderv[i3 + 1] = derv[1];
            cderv[i3 + 2] = derv[2];
            chess[i6] = hess[0];
            chess[i6 + 1] = hess[1];
            chess[i6 + 2] = hess[2];
            chess[i6 + 3] = hess[3];
            chess[i6 + 4] = hess[4];
            chess[i6 + 5] = hess[5];
        }
    }

    delete[] wxpp;
    return crossVol;
}

// lixm:3DSSA
double calDervsCartesian_SS(int na1, double* xyz1, double* alpha1, double* w1, int na2,
                            double* xyz2, double* alpha2, double* w2, double* cderv, double* chess,
                            bool equalR, int* qtype, double* qwt, int* stype, double* swt,
                            double* mvol) {
    int i, j, ina2;
    int i3, i6, j3;
    double pi = 3.14159265358979;
    double p2 = gParam * gParam;
    double pidltn, w1p2;
    double dltn, kn, dist;
    double tmpd, tav, tavad, tavap;
    double crossVol = 0;
    double rn[3];
    double derv[3], hess[6];

    double* wxpp = new double[na1 * na2];

    if (equalR)  // all vdwR are equal, so all alphas are equal
    {
        dltn = alpha1[0] + alpha2[0];
        pidltn = pi / dltn;
        pidltn = pidltn * sqrt(pidltn);
        for (i = 0; i < na1; i++) {
            w1p2 = w1[i] * p2;
            ina2 = i * na2;
            for (j = 0; j < na2; j++) {
                wxpp[ina2 + j] = w1p2 * w2[j] * pidltn;
            }
        }
    } else {
        for (i = 0; i < na1; i++) {
            w1p2 = w1[i] * p2;
            ina2 = i * na2;
            for (j = 0; j < na2; j++) {
                dltn = alpha1[i] + alpha2[j];
                pidltn = pi / dltn;
                wxpp[ina2 + j] = w1p2 * w2[j] * pidltn * sqrt(pidltn);
            }
        }
    }

    mvol[0] = 0;
    mvol[1] = 0;
    mvol[2] = 0;

    if (equalR)  // all vdwR are equal, so all alpha are equals
    {
        double alpha = alpha1[0];
        double alphaH = alpha / 2;
        double alphaD = alpha * 2;
        for (i = 0; i < na1; i++) {
            i3 = i * 3;
            i6 = i3 + i3;
            ina2 = i * na2;
            derv[0] = 0;
            derv[1] = 0;
            derv[2] = 0;
            hess[0] = 0;
            hess[1] = 0;
            hess[2] = 0;
            hess[3] = 0;
            hess[4] = 0;
            hess[5] = 0;

            for (j = 0; j < na2; j++) {
                if (qtype[j] != stype[i]) {
                    // crossVol += wxpp[ina2+j];
                    continue;
                }  // lixm:only core overlap and side overlap.
                j3 = j * 3;
                dist = (xyz1[i3] - xyz2[j3]) * (xyz1[i3] - xyz2[j3]) +
                       (xyz1[i3 + 1] - xyz2[j3 + 1]) * (xyz1[i3 + 1] - xyz2[j3 + 1]) +
                       (xyz1[i3 + 2] - xyz2[j3 + 2]) * (xyz1[i3 + 2] - xyz2[j3 + 2]);
                rn[0] = (xyz1[i3] + xyz2[j3]) / 2;
                rn[1] = (xyz1[i3 + 1] + xyz2[j3 + 1]) / 2;
                rn[2] = (xyz1[i3 + 2] + xyz2[j3 + 2]) / 2;
                kn = exp(-alphaH * dist);
                // A: poor implementation
                // tmpd = w1p2*w2[j]*kn*pow(pi/dltn,1.5);
                //
                // B: maybe a good option for GPU implementation
                // pidltn = 3.14159265358979/dltn;
                // tmpd = w1p2*w2[j]*kn*pidltn*sqrt(pidltn);
                //
                // C: a slightly more efficient CPU implementation using
                //    pre-computed values stored in wxpp.
                // tmpd = wxpp[ina2+j]*kn;
                tmpd = wxpp[ina2 + j] * kn * qwt[j] * swt[i];
                crossVol += tmpd;
                mvol[qtype[j]] += tmpd;  // lixm.calculate core vol and side vol.
                // First derivatives
                tav = alphaD * tmpd;
                derv[0] += tav * (xyz1[i3] - rn[0]);
                derv[1] += tav * (xyz1[i3 + 1] - rn[1]);
                derv[2] += tav * (xyz1[i3 + 2] - rn[2]);
                tavad = tav * (-0.5);
                tavap = (tav + tav) * alpha;
                // Hessian
                hess[0] -= tavad + tavap * (xyz1[i3] - rn[0]) * (xyz1[i3] - rn[0]);
                hess[1] -= tavap * (xyz1[i3] - rn[0]) * (xyz1[i3 + 1] - rn[1]);
                hess[2] -= tavad + tavap * (xyz1[i3 + 1] - rn[1]) * (xyz1[i3 + 1] - rn[1]);
                hess[3] -= tavap * (xyz1[i3] - rn[0]) * (xyz1[i3 + 2] - rn[2]);
                hess[4] -= tavap * (xyz1[i3 + 1] - rn[1]) * (xyz1[i3 + 2] - rn[2]);
                hess[5] -= tavad + tavap * (xyz1[i3 + 2] - rn[2]) * (xyz1[i3 + 2] - rn[2]);
            }

            // save dervs of each atom in na1
            cderv[i3] = derv[0];
            cderv[i3 + 1] = derv[1];
            cderv[i3 + 2] = derv[2];
            chess[i6] = hess[0];
            chess[i6 + 1] = hess[1];
            chess[i6 + 2] = hess[2];
            chess[i6 + 3] = hess[3];
            chess[i6 + 4] = hess[4];
            chess[i6 + 5] = hess[5];
        }
    } else {
        for (i = 0; i < na1; i++) {
            i3 = i * 3;
            i6 = i3 + i3;
            ina2 = i * na2;
            derv[0] = 0;
            derv[1] = 0;
            derv[2] = 0;
            hess[0] = 0;
            hess[1] = 0;
            hess[2] = 0;
            hess[3] = 0;
            hess[4] = 0;
            hess[5] = 0;

            for (j = 0; j < na2; j++) {
                if (qtype[j] != stype[i]) {
                    // crossVol += wxpp[ina2+j];
                    continue;
                }
                j3 = j * 3;
                dist = (xyz1[i3] - xyz2[j3]) * (xyz1[i3] - xyz2[j3]) +
                       (xyz1[i3 + 1] - xyz2[j3 + 1]) * (xyz1[i3 + 1] - xyz2[j3 + 1]) +
                       (xyz1[i3 + 2] - xyz2[j3 + 2]) * (xyz1[i3 + 2] - xyz2[j3 + 2]);
                dltn = alpha1[i] + alpha2[j];
                rn[0] = (xyz1[i3] * alpha1[i] + xyz2[j3] * alpha2[j]) / dltn;
                rn[1] = (xyz1[i3 + 1] * alpha1[i] + xyz2[j3 + 1] * alpha2[j]) / dltn;
                rn[2] = (xyz1[i3 + 2] * alpha1[i] + xyz2[j3 + 2] * alpha2[j]) / dltn;
                kn = exp(-alpha1[i] * alpha2[j] * dist / dltn);
                // A: poor implementation
                // tmpd = w1p2*w2[j]*kn*pow(pi/dltn,1.5);
                //
                // B: maybe a good option for GPU implementation
                // pidltn = 3.14159265358979/dltn;
                // tmpd = w1p2*w2[j]*kn*pidltn*sqrt(pidltn);
                //
                // C: a slightly more efficient CPU implementation using
                //    pre-computed values stored in wxpp.
                // tmpd = wxpp[ina2+j]*kn;
                tmpd = wxpp[ina2 + j] * kn * qwt[j] * swt[i];
                crossVol += tmpd;
                mvol[qtype[j]] += tmpd;  // lixm.
                // First derivatives
                tav = alpha1[i] * tmpd * 2;
                derv[0] += tav * (xyz1[i3] - rn[0]);
                derv[1] += tav * (xyz1[i3 + 1] - rn[1]);
                derv[2] += tav * (xyz1[i3 + 2] - rn[2]);
                tavad = tav * (alpha1[i] / dltn - 1);
                tavap = (tav + tav) * alpha1[i];
                // Hessian
                hess[0] -= tavad + tavap * (xyz1[i3] - rn[0]) * (xyz1[i3] - rn[0]);
                hess[1] -= tavap * (xyz1[i3] - rn[0]) * (xyz1[i3 + 1] - rn[1]);
                hess[2] -= tavad + tavap * (xyz1[i3 + 1] - rn[1]) * (xyz1[i3 + 1] - rn[1]);
                hess[3] -= tavap * (xyz1[i3] - rn[0]) * (xyz1[i3 + 2] - rn[2]);
                hess[4] -= tavap * (xyz1[i3 + 1] - rn[1]) * (xyz1[i3 + 2] - rn[2]);
                hess[5] -= tavad + tavap * (xyz1[i3 + 2] - rn[2]) * (xyz1[i3 + 2] - rn[2]);
            }

            // save dervs of each atom in na1
            cderv[i3] = derv[0];
            cderv[i3 + 1] = derv[1];
            cderv[i3 + 2] = derv[2];
            chess[i6] = hess[0];
            chess[i6 + 1] = hess[1];
            chess[i6 + 2] = hess[2];
            chess[i6 + 3] = hess[3];
            chess[i6 + 4] = hess[4];
            chess[i6 + 5] = hess[5];
        }
    }

    // std::cout << mvol[0] << " " << mvol[1] << " " << crossVol << "\n";

    delete[] wxpp;
    return crossVol;
}

float calDervsCartesian_float(int na1, float* xyz1, float* alpha1, float* w1, int na2, float* xyz2,
                              float* alpha2, float* w2, float* cderv, float* chess, bool equalR) {
    int i, j, ina2;
    int i3, i6, j3;
    float pi = 3.14159265358979;
    float p2 = gParam * gParam;
    float pidltn, w1p2;
    float dltn, kn, dist;
    float tmpd, tav, tavad, tavap;
    float crossVol = 0;
    float rn[3];
    float derv[3], hess[6];

    float* wxpp = new float[na1 * na2];

    if (equalR)  // all vdwR are equal, so all alphas are equal
    {
        dltn = alpha1[0] + alpha2[0];
        pidltn = pi / dltn;
        pidltn = pidltn * sqrt(pidltn);
        for (i = 0; i < na1; i++) {
            w1p2 = w1[i] * p2;
            ina2 = i * na2;
            for (j = 0; j < na2; j++) {
                wxpp[ina2 + j] = w1p2 * w2[j] * pidltn;
            }
        }
    } else {
        for (i = 0; i < na1; i++) {
            w1p2 = w1[i] * p2;
            ina2 = i * na2;
            for (j = 0; j < na2; j++) {
                dltn = alpha1[i] + alpha2[j];
                pidltn = pi / dltn;
                wxpp[ina2 + j] = w1p2 * w2[j] * pidltn * sqrt(pidltn);
            }
        }
    }

    if (equalR)  // all vdwR are equal, so all alpha are equals
    {
        float alpha = alpha1[0];
        float alphaH = alpha / 2;
        float alphaD = alpha * 2;
        for (i = 0; i < na1; i++) {
            i3 = i * 3;
            i6 = i3 + i3;
            ina2 = i * na2;
            derv[0] = 0;
            derv[1] = 0;
            derv[2] = 0;
            hess[0] = 0;
            hess[1] = 0;
            hess[2] = 0;
            hess[3] = 0;
            hess[4] = 0;
            hess[5] = 0;

            for (j = 0; j < na2; j++) {
                j3 = j * 3;
                dist = (xyz1[i3] - xyz2[j3]) * (xyz1[i3] - xyz2[j3]) +
                       (xyz1[i3 + 1] - xyz2[j3 + 1]) * (xyz1[i3 + 1] - xyz2[j3 + 1]) +
                       (xyz1[i3 + 2] - xyz2[j3 + 2]) * (xyz1[i3 + 2] - xyz2[j3 + 2]);
                rn[0] = (xyz1[i3] + xyz2[j3]) / 2;
                rn[1] = (xyz1[i3 + 1] + xyz2[j3 + 1]) / 2;
                rn[2] = (xyz1[i3 + 2] + xyz2[j3 + 2]) / 2;
                kn = exp(-alphaH * dist);
                // A: poor implementation
                // tmpd = w1p2*w2[j]*kn*pow(pi/dltn,1.5);
                //
                // B: maybe a good option for GPU implementation
                // pidltn = 3.14159265358979/dltn;
                // tmpd = w1p2*w2[j]*kn*pidltn*sqrt(pidltn);
                //
                // C: a slightly more efficient CPU implementation using
                //    pre-computed values stored in wxpp.
                tmpd = wxpp[ina2 + j] * kn;
                crossVol += tmpd;
                // First derivatives
                tav = alphaD * tmpd;
                derv[0] += tav * (xyz1[i3] - rn[0]);
                derv[1] += tav * (xyz1[i3 + 1] - rn[1]);
                derv[2] += tav * (xyz1[i3 + 2] - rn[2]);
                tavad = tav * (-0.5);
                tavap = (tav + tav) * alpha;
                // Hessian
                hess[0] -= tavad + tavap * (xyz1[i3] - rn[0]) * (xyz1[i3] - rn[0]);
                hess[1] -= tavap * (xyz1[i3] - rn[0]) * (xyz1[i3 + 1] - rn[1]);
                hess[2] -= tavad + tavap * (xyz1[i3 + 1] - rn[1]) * (xyz1[i3 + 1] - rn[1]);
                hess[3] -= tavap * (xyz1[i3] - rn[0]) * (xyz1[i3 + 2] - rn[2]);
                hess[4] -= tavap * (xyz1[i3 + 1] - rn[1]) * (xyz1[i3 + 2] - rn[2]);
                hess[5] -= tavad + tavap * (xyz1[i3 + 2] - rn[2]) * (xyz1[i3 + 2] - rn[2]);
            }

            // save dervs of each atom in na1
            cderv[i3] = derv[0];
            cderv[i3 + 1] = derv[1];
            cderv[i3 + 2] = derv[2];
            chess[i6] = hess[0];
            chess[i6 + 1] = hess[1];
            chess[i6 + 2] = hess[2];
            chess[i6 + 3] = hess[3];
            chess[i6 + 4] = hess[4];
            chess[i6 + 5] = hess[5];
        }
    } else {
        for (i = 0; i < na1; i++) {
            i3 = i * 3;
            i6 = i3 + i3;
            ina2 = i * na2;
            derv[0] = 0;
            derv[1] = 0;
            derv[2] = 0;
            hess[0] = 0;
            hess[1] = 0;
            hess[2] = 0;
            hess[3] = 0;
            hess[4] = 0;
            hess[5] = 0;

            for (j = 0; j < na2; j++) {
                j3 = j * 3;
                dist = (xyz1[i3] - xyz2[j3]) * (xyz1[i3] - xyz2[j3]) +
                       (xyz1[i3 + 1] - xyz2[j3 + 1]) * (xyz1[i3 + 1] - xyz2[j3 + 1]) +
                       (xyz1[i3 + 2] - xyz2[j3 + 2]) * (xyz1[i3 + 2] - xyz2[j3 + 2]);
                dltn = alpha1[i] + alpha2[j];
                rn[0] = (xyz1[i3] * alpha1[i] + xyz2[j3] * alpha2[j]) / dltn;
                rn[1] = (xyz1[i3 + 1] * alpha1[i] + xyz2[j3 + 1] * alpha2[j]) / dltn;
                rn[2] = (xyz1[i3 + 2] * alpha1[i] + xyz2[j3 + 2] * alpha2[j]) / dltn;
                kn = exp(-alpha1[i] * alpha2[j] * dist / dltn);
                // A: poor implementation
                // tmpd = w1p2*w2[j]*kn*pow(pi/dltn,1.5);
                //
                // B: maybe a good option for GPU implementation
                // pidltn = 3.14159265358979/dltn;
                // tmpd = w1p2*w2[j]*kn*pidltn*sqrt(pidltn);
                //
                // C: a slightly more efficient CPU implementation using
                //    pre-computed values stored in wxpp.
                tmpd = wxpp[ina2 + j] * kn;
                crossVol += tmpd;
                // First derivatives
                tav = alpha1[i] * tmpd * 2;
                derv[0] += tav * (xyz1[i3] - rn[0]);
                derv[1] += tav * (xyz1[i3 + 1] - rn[1]);
                derv[2] += tav * (xyz1[i3 + 2] - rn[2]);
                tavad = tav * (alpha1[i] / dltn - 1);
                tavap = (tav + tav) * alpha1[i];
                // Hessian
                hess[0] -= tavad + tavap * (xyz1[i3] - rn[0]) * (xyz1[i3] - rn[0]);
                hess[1] -= tavap * (xyz1[i3] - rn[0]) * (xyz1[i3 + 1] - rn[1]);
                hess[2] -= tavad + tavap * (xyz1[i3 + 1] - rn[1]) * (xyz1[i3 + 1] - rn[1]);
                hess[3] -= tavap * (xyz1[i3] - rn[0]) * (xyz1[i3 + 2] - rn[2]);
                hess[4] -= tavap * (xyz1[i3 + 1] - rn[1]) * (xyz1[i3 + 2] - rn[2]);
                hess[5] -= tavad + tavap * (xyz1[i3 + 2] - rn[2]) * (xyz1[i3 + 2] - rn[2]);
            }

            // save dervs of each atom in na1
            cderv[i3] = derv[0];
            cderv[i3 + 1] = derv[1];
            cderv[i3 + 2] = derv[2];
            chess[i6] = hess[0];
            chess[i6 + 1] = hess[1];
            chess[i6 + 2] = hess[2];
            chess[i6 + 3] = hess[3];
            chess[i6 + 4] = hess[4];
            chess[i6 + 5] = hess[5];
        }
    }

    delete[] wxpp;
    return crossVol;
}

void dervsCartesian2RT(int na1, double* xyz1, double* cderv, double* chess, double RTderv[6],
                       double RThess[6][6]) {
    int i, i3, i6;
    double x, y, z;
    double derv[3];
    double hess[6];

    for (i = 0; i < 6; i++) {
        RTderv[i] = 0;
        for (i3 = 0; i3 < 6; i3++) RThess[i][i3] = 0;
    }

    for (i = 0; i < na1; i++) {
        i3 = i * 3;
        i6 = i3 + i3;

        derv[0] = cderv[i3];
        derv[1] = cderv[i3 + 1];
        derv[2] = cderv[i3 + 2];
        hess[0] = chess[i6];
        hess[1] = chess[i6 + 1];
        hess[2] = chess[i6 + 2];
        hess[3] = chess[i6 + 3];
        hess[4] = chess[i6 + 4];
        hess[5] = chess[i6 + 5];

        x = xyz1[i3];
        y = xyz1[i3 + 1];
        z = xyz1[i3 + 2];
        //
        // First derivatives
        //
        RTderv[3] += derv[0];
        RTderv[4] += derv[1];
        RTderv[5] += derv[2];
        RTderv[0] += -derv[0] * xyz1[i3 + 1] + derv[1] * xyz1[i3];
        RTderv[1] += -derv[1] * xyz1[i3 + 2] + derv[2] * xyz1[i3 + 1];
        RTderv[2] += derv[0] * xyz1[i3 + 2] - derv[2] * xyz1[i3];
        //
        // Hessian. variables 0=alpha, 1=beta, 2=gamma, 3=tx, 4=ty, 5=tx
        //
        RThess[3][3] += hess[0];
        RThess[3][4] += hess[1];
        RThess[4][4] += hess[2];
        RThess[3][5] += hess[3];
        RThess[4][5] += hess[4];
        RThess[5][5] += hess[5];
        RThess[0][0] += -derv[0] * xyz1[i3] - derv[1] * xyz1[i3 + 1] +
                        hess[0] * xyz1[i3 + 1] * xyz1[i3 + 1] -
                        hess[1] * xyz1[i3 + 1] * xyz1[i3] * 2.0 + hess[2] * xyz1[i3] * xyz1[i3];
        RThess[0][1] += derv[0] * xyz1[i3 + 2] + hess[1] * xyz1[i3 + 1] * xyz1[i3 + 2] -
                        hess[2] * xyz1[i3] * xyz1[i3 + 2] - hess[3] * xyz1[i3 + 1] * xyz1[i3 + 1] +
                        hess[4] * xyz1[i3] * xyz1[i3 + 1];
        RThess[1][1] += -derv[1] * xyz1[i3 + 1] - derv[2] * xyz1[i3 + 2] +
                        hess[2] * xyz1[i3 + 2] * xyz1[i3 + 2] -
                        hess[4] * xyz1[i3 + 1] * xyz1[i3 + 2] * 2.0 +
                        hess[5] * xyz1[i3 + 1] * xyz1[i3 + 1];
        RThess[0][2] += derv[2] * xyz1[i3 + 1] - hess[0] * xyz1[i3 + 1] * xyz1[i3 + 2] +
                        hess[1] * xyz1[i3] * xyz1[i3 + 2] + hess[3] * xyz1[i3] * xyz1[i3 + 1] -
                        hess[4] * xyz1[i3] * xyz1[i3];
        RThess[1][2] += derv[0] * xyz1[i3 + 1] - hess[1] * xyz1[i3 + 2] * xyz1[i3 + 2] +
                        hess[3] * xyz1[i3 + 1] * xyz1[i3 + 2] + hess[4] * xyz1[i3] * xyz1[i3 + 2] -
                        hess[5] * xyz1[i3] * xyz1[i3 + 1];
        RThess[2][2] += -derv[0] * xyz1[i3] - derv[2] * xyz1[i3 + 2] +
                        hess[0] * xyz1[i3 + 2] * xyz1[i3 + 2] -
                        hess[3] * xyz1[i3] * xyz1[i3 + 2] * 2.0 + hess[5] * xyz1[i3] * xyz1[i3];
        RThess[0][3] += -hess[0] * xyz1[i3 + 1] + hess[1] * xyz1[i3];
        RThess[1][3] += -hess[1] * xyz1[i3 + 2] + hess[3] * xyz1[i3 + 1];
        RThess[2][3] += hess[0] * xyz1[i3 + 2] - hess[3] * xyz1[i3];

        RThess[0][4] += -hess[1] * xyz1[i3 + 1] + hess[2] * xyz1[i3];
        RThess[1][4] += -hess[2] * xyz1[i3 + 2] + hess[4] * xyz1[i3 + 1];
        RThess[2][4] += hess[1] * xyz1[i3 + 2] - hess[4] * xyz1[i3];

        RThess[0][5] += -hess[3] * xyz1[i3 + 1] + hess[4] * xyz1[i3];
        RThess[1][5] += -hess[4] * xyz1[i3 + 2] + hess[5] * xyz1[i3 + 1];
        RThess[2][5] += hess[3] * xyz1[i3 + 2] - hess[5] * xyz1[i3];
    }

    for (i = 0; i < 6; i++) {
        for (i3 = 0; i3 < i + 1; i3++) {
            RThess[i][i3] = RThess[i3][i];
        }
    }
}

void dervsCartesian2RT_float(int na1, float* xyz1, float* cderv, float* chess, float RTderv[6],
                             float RThess[6][6]) {
    int i, i3, i6;
    float x, y, z;
    float derv[3];
    float hess[6];

    for (i = 0; i < 6; i++) {
        RTderv[i] = 0;
        for (i3 = 0; i3 < 6; i3++) RThess[i][i3] = 0;
    }

    for (i = 0; i < na1; i++) {
        i3 = i * 3;
        i6 = i3 + i3;

        derv[0] = cderv[i3];
        derv[1] = cderv[i3 + 1];
        derv[2] = cderv[i3 + 2];
        hess[0] = chess[i6];
        hess[1] = chess[i6 + 1];
        hess[2] = chess[i6 + 2];
        hess[3] = chess[i6 + 3];
        hess[4] = chess[i6 + 4];
        hess[5] = chess[i6 + 5];

        x = xyz1[i3];
        y = xyz1[i3 + 1];
        z = xyz1[i3 + 2];
        //
        // First derivatives
        //
        RTderv[3] += derv[0];
        RTderv[4] += derv[1];
        RTderv[5] += derv[2];
        RTderv[0] += -derv[0] * xyz1[i3 + 1] + derv[1] * xyz1[i3];
        RTderv[1] += -derv[1] * xyz1[i3 + 2] + derv[2] * xyz1[i3 + 1];
        RTderv[2] += derv[0] * xyz1[i3 + 2] - derv[2] * xyz1[i3];
        //
        // Hessian. variables 0=alpha, 1=beta, 2=gamma, 3=tx, 4=ty, 5=tx
        //
        RThess[3][3] += hess[0];
        RThess[3][4] += hess[1];
        RThess[4][4] += hess[2];
        RThess[3][5] += hess[3];
        RThess[4][5] += hess[4];
        RThess[5][5] += hess[5];
        RThess[0][0] += -derv[0] * xyz1[i3] - derv[1] * xyz1[i3 + 1] +
                        hess[0] * xyz1[i3 + 1] * xyz1[i3 + 1] -
                        hess[1] * xyz1[i3 + 1] * xyz1[i3] * 2.0 + hess[2] * xyz1[i3] * xyz1[i3];
        RThess[0][1] += derv[0] * xyz1[i3 + 2] + hess[1] * xyz1[i3 + 1] * xyz1[i3 + 2] -
                        hess[2] * xyz1[i3] * xyz1[i3 + 2] - hess[3] * xyz1[i3 + 1] * xyz1[i3 + 1] +
                        hess[4] * xyz1[i3] * xyz1[i3 + 1];
        RThess[1][1] += -derv[1] * xyz1[i3 + 1] - derv[2] * xyz1[i3 + 2] +
                        hess[2] * xyz1[i3 + 2] * xyz1[i3 + 2] -
                        hess[4] * xyz1[i3 + 1] * xyz1[i3 + 2] * 2.0 +
                        hess[5] * xyz1[i3 + 1] * xyz1[i3 + 1];
        RThess[0][2] += derv[2] * xyz1[i3 + 1] - hess[0] * xyz1[i3 + 1] * xyz1[i3 + 2] +
                        hess[1] * xyz1[i3] * xyz1[i3 + 2] + hess[3] * xyz1[i3] * xyz1[i3 + 1] -
                        hess[4] * xyz1[i3] * xyz1[i3];
        RThess[1][2] += derv[0] * xyz1[i3 + 1] - hess[1] * xyz1[i3 + 2] * xyz1[i3 + 2] +
                        hess[3] * xyz1[i3 + 1] * xyz1[i3 + 2] + hess[4] * xyz1[i3] * xyz1[i3 + 2] -
                        hess[5] * xyz1[i3] * xyz1[i3 + 1];
        RThess[2][2] += -derv[0] * xyz1[i3] - derv[2] * xyz1[i3 + 2] +
                        hess[0] * xyz1[i3 + 2] * xyz1[i3 + 2] -
                        hess[3] * xyz1[i3] * xyz1[i3 + 2] * 2.0 + hess[5] * xyz1[i3] * xyz1[i3];
        RThess[0][3] += -hess[0] * xyz1[i3 + 1] + hess[1] * xyz1[i3];
        RThess[1][3] += -hess[1] * xyz1[i3 + 2] + hess[3] * xyz1[i3 + 1];
        RThess[2][3] += hess[0] * xyz1[i3 + 2] - hess[3] * xyz1[i3];

        RThess[0][4] += -hess[1] * xyz1[i3 + 1] + hess[2] * xyz1[i3];
        RThess[1][4] += -hess[2] * xyz1[i3 + 2] + hess[4] * xyz1[i3 + 1];
        RThess[2][4] += hess[1] * xyz1[i3 + 2] - hess[4] * xyz1[i3];

        RThess[0][5] += -hess[3] * xyz1[i3 + 1] + hess[4] * xyz1[i3];
        RThess[1][5] += -hess[4] * xyz1[i3 + 2] + hess[5] * xyz1[i3 + 1];
        RThess[2][5] += hess[3] * xyz1[i3 + 2] - hess[5] * xyz1[i3];
    }

    for (i = 0; i < 6; i++) {
        for (i3 = 0; i3 < i + 1; i3++) {
            RThess[i][i3] = RThess[i3][i];
        }
    }
}

//
// generate the feature list for query molecule and candidate molecule
//
double featureShapeOverlay(MFCFrag* qfrag, MFCFrag* tfrag, bool onlyHeavyAtoms, bool getW,
                           double* selfVol) {
    std::vector<PharmaFeature*> qall;
    std::vector<PharmaFeature*> tall;
    mapAllFeatures(qfrag, qall);
    mapAllFeatures(tfrag, tall);

    int qNormalSphere = 0;
    int qnFeatures = qall.size();
    int tnFeatures = tall.size();
    int fexist[6] = {0};
    for (int i = 0; i < qnFeatures; i++) {
        fexist[qall[i]->fType - 1] = 1;
        if (qall[i]->nSpheres == 2) {
            qNormalSphere++;
        }
    }
    int qSphere = qnFeatures + qNormalSphere;
    int shareFCount = 0;  // share in query molecule
    int tNormalSphere = 0;
    int tqNormalSphere = 0;  // share in query molecule
    for (int j = 0; j < tnFeatures; j++) {
        if (tall[j]->nSpheres == 2) {
            tNormalSphere++;
        }
        if (fexist[tall[j]->fType - 1] == 1) {
            shareFCount++;
            if (tall[j]->nSpheres == 2) {
                tqNormalSphere++;
            }
        }
    }
    int tqSphere = shareFCount + tqNormalSphere;
    int tSphere = tnFeatures + tNormalSphere;

    // check if query and target molecule share features,
    // if no, take all atoms in target molecule into consideration

    if (shareFCount > 0) tSphere = tqSphere;
    double* qxyz = new double[qSphere * 3];
    double* qweight = new double[qSphere];
    double* txyz = new double[tSphere * 3];
    double* tweight = new double[tSphere];

    // put the query molecule feature point coordinate and weight into the array

    int j = 0, j3;
    for (int i = 0; i < qnFeatures; i++) {
        j3 = j * 3;
        qxyz[j3] = qall[i]->x1;
        qxyz[j3 + 1] = qall[i]->y1;
        qxyz[j3 + 2] = qall[i]->z1;

        if (qall[i]->fType == 1 || qall[i]->fType == 2)
            qweight[j] = 1.0;  // HBA or HBD
        else if (qall[i]->fType == 3)
            qweight[j] = 0.5;  // ARO
        else if (qall[i]->fType == 4 || qall[i]->fType == 5)
            qweight[j] = 2.0;  // POS or NEG
        else
            qweight[j] = 1.0;  // HYD

        if (qall[i]->nSpheres == 2) {
            j++;
            j3 = j * 3;
            qxyz[j3] = qall[i]->x2;
            qxyz[j3 + 1] = qall[i]->y2;
            qxyz[j3 + 2] = qall[i]->z2;
            if (qall[i]->fType == 1 || qall[i]->fType == 2)
                qweight[j] = 1.0;
            else
                qweight[j] = 0.5;
        }
        j++;
    }

    // put the shared feature point in target molecule coordinate and weight into the array

    j = 0;
    if (shareFCount > 0) {
        for (int i = 0; i < tnFeatures; i++) {
            if (fexist[tall[i]->fType - 1] == 0) continue;
            j3 = j * 3;
            txyz[j3] = tall[i]->x1;
            txyz[j3 + 1] = tall[i]->y1;
            txyz[j3 + 2] = tall[i]->z1;

            if (tall[i]->fType == 1 || tall[i]->fType == 2)
                tweight[j] = 1.0;  // HBA or HBD
            else if (tall[i]->fType == 3)
                tweight[j] = 0.5;  // ARO
            else if (tall[i]->fType == 4 || tall[i]->fType == 5)
                tweight[j] = 2.0;  // POS or NEG
            else
                tweight[j] = 1.0;  // HYD

            if (tall[i]->nSpheres == 2) {
                j++;
                j3 = j * 3;
                txyz[j3] = tall[i]->x2;
                txyz[j3 + 1] = tall[i]->y2;
                txyz[j3 + 2] = tall[i]->z2;
                if (tall[i]->fType == 1 || tall[i]->fType == 2)
                    tweight[j] = 1.0;
                else
                    tweight[j] = 0.5;
            }
            j++;
        }
    }
    /*for(int i=0;i<qSphere;i++){
       std::cout<<"qsphere"<<i+1<<"\t"<<qxyz[i*3+0]<<"\t"<<qxyz[i*3+1]<<"\t"<<qxyz[i*3+2]<<"\t"<<qweight[i]<<"\n";
    }
    for(int i=0;i<tSphere;i++){
       std::cout<<"tsphere"<<i+1<<"\t"<<txyz[i*3+0]<<"\t"<<txyz[i*3+1]<<"\t"<<txyz[i*3+2]<<"\t"<<tweight[i]<<"\n";
    }
    */

    for (int i = 0; i < qnFeatures; i++) {
        delete qall[i];
    }
    for (int i = 0; i < tnFeatures; i++) {
        delete tall[i];
    }

    // Get the Translatation vector (qcent, tcent) and rotation matrix
    // For target molecule, if no features share with query molecule,
    // take all atoms into consideration

    double qcent[3], tcent[3];
    double qrotMat[3][3], trotMat[3][3];

    int qAtoms = getNSpheres(qfrag, onlyHeavyAtoms);
    double* qfxyz = new double[qAtoms * 3];
    double* qvdwR = new double[qAtoms];
    double* qw = new double[qAtoms];
    getFragXYZVDWR(qfrag, qfxyz, qvdwR, onlyHeavyAtoms, true);

    int tAtoms = getNSpheres(tfrag, onlyHeavyAtoms);
    double* tfxyz = new double[tAtoms * 3];
    double* tvdwR = new double[tAtoms];
    double* tw = new double[tAtoms];
    getFragXYZVDWR(tfrag, tfxyz, tvdwR, onlyHeavyAtoms, true);

    selfVol[0] = calMolSelfVolGS(tAtoms, tfxyz, tvdwR, tw, getW, true);
    selfVol[1] = calMolSelfVolGS(qAtoms, qfxyz, qvdwR, qw, getW, true);

    // initial alignment
    initFeatAlignment(qSphere, qxyz, qweight, qcent, qrotMat);

    if (shareFCount > 0) {
        initFeatAlignment(tSphere, txyz, tweight, tcent, trotMat);
    } else {
        double* tweight = new double[tAtoms];
        for (int i = 0; i < tAtoms; i++) tweight[i] = 1.0;
        initFeatAlignment(tAtoms, tfxyz, tweight, tcent, trotMat);
        delete[] tweight;
    }

    // Translate and rotate the molecule coordinate to get the initial structure

    int i3;
    double* ttmpxyz = new double[tAtoms * 3];
    double* qtmpxyz = new double[qAtoms * 3];
    for (int i = 0; i < qAtoms; i++) {
        i3 = i * 3;
        qfxyz[i3] -= qcent[0];
        qfxyz[i3 + 1] -= qcent[1];
        qfxyz[i3 + 2] -= qcent[2];
    }
    for (int j = 0; j < qAtoms; j++) {
        j3 = j * 3;
        Rotation(&qfxyz[j3], qrotMat, &qtmpxyz[j3]);
    }

    // find the rotation matrix to change query back to original coordinates
    double rotMatBack[3][3];
    double* tmpXYZ = new double[qAtoms * 3];
    for (int i = 0; i < qAtoms; i++) {
        i3 = i * 3;
        tmpXYZ[i3] = qtmpxyz[i3];
        tmpXYZ[i3 + 1] = qtmpxyz[i3 + 1];
        tmpXYZ[i3 + 2] = qtmpxyz[i3 + 2];
    }
    superpose(qfxyz, tmpXYZ, qAtoms, rotMatBack);
    delete[] tmpXYZ;

    if (shareFCount > 0) {
        for (int i = 0; i < tAtoms; i++) {
            i3 = i * 3;
            tfxyz[i3] -= tcent[0];
            tfxyz[i3 + 1] -= tcent[1];
            tfxyz[i3 + 2] -= tcent[2];
        }
        for (int j = 0; j < tAtoms; j++) {
            j3 = j * 3;
            Rotation(&tfxyz[j3], trotMat, &ttmpxyz[j3]);
            tfxyz[j3] = ttmpxyz[j3];
            tfxyz[j3 + 1] = ttmpxyz[j3 + 1];
            tfxyz[j3 + 2] = ttmpxyz[j3 + 2];
        }
    }

    // output

    /*
    setFragXYZ(qfrag,qtmpxyz,true);
    if(shareFCount > 0){
       setFragXYZ(tfrag,ttmpxyz,true);
    }
    else setFragXYZ(tfrag,tfxyz,true);
    std::ofstream qfout,tfout;
    qfout.open("init_qfrag_.sdf");
    tfout.open("init_tfrag_.sdf");
    writeMFCFrag2SD(qfrag,qfout,true);
    writeMFCFrag2SD(tfrag,tfout,true);
    qfout.close();
    tfout.close(); */

    //
    // optimize based on the initial structure
    //
    double* tXYZ = new double[tAtoms * 3];  // save coordinates of target molecule after overlay
    double vol[4] = {0};
    if (shareFCount <= 0) {
        for (int i = 0; i < tAtoms; i++) {
            i3 = i * 3;
            ttmpxyz[i3] = tfxyz[i3];
            ttmpxyz[i3 + 1] = tfxyz[i3 + 1];
            ttmpxyz[i3 + 2] = tfxyz[i3 + 2];
        }
    }
    vol[0] =
        optimizeOverlapVol(tAtoms, ttmpxyz, tvdwR, tw, qAtoms, qtmpxyz, qvdwR, qw, onlyHeavyAtoms);
    // std::cout<<"vol1 = "<<vol[0]<<"\n";
    double maxVol = vol[0];
    for (int i = 0; i < tAtoms; i++) {
        i3 = i * 3;
        tXYZ[i3] = ttmpxyz[i3];
        tXYZ[i3 + 1] = ttmpxyz[i3 + 1];
        tXYZ[i3 + 2] = ttmpxyz[i3 + 2];
    }

    /* qfout.open("opti_qfrag_.sdf");
       tfout.open("opti_tfrag_.sdf");
       writeMFCFrag2SD(qfrag,qfout,true);
       writeMFCFrag2SD(tfrag,tfout,true);
    */

    //
    // -x, -y, rotate 180 around Z axis
    //
    for (int i = 0; i < tAtoms; i++) {
        i3 = i * 3;
        ttmpxyz[i3] = -tfxyz[i3];
        ttmpxyz[i3 + 1] = -tfxyz[i3 + 1];
        ttmpxyz[i3 + 2] = tfxyz[i3 + 2];
    }
    vol[1] =
        optimizeOverlapVol(tAtoms, ttmpxyz, tvdwR, tw, qAtoms, qtmpxyz, qvdwR, qw, onlyHeavyAtoms);
    // std::cout<<"vol2 = "<<vol[1]<<"\n";
    if (vol[1] > maxVol) {
        maxVol = vol[1];
        for (int i = 0; i < tAtoms; i++) {
            i3 = i * 3;
            tXYZ[i3] = ttmpxyz[i3];
            tXYZ[i3 + 1] = ttmpxyz[i3 + 1];
            tXYZ[i3 + 2] = ttmpxyz[i3 + 2];
        }
        // setFragXYZ(tfrag,ttmpxyz,onlyHeavyAtoms);
    }

    //
    // -x,-z, rotate 180 around Y axis
    //
    for (int i = 0; i < tAtoms; i++) {
        i3 = i * 3;
        ttmpxyz[i3] = -tfxyz[i3];
        ttmpxyz[i3 + 1] = tfxyz[i3 + 1];
        ttmpxyz[i3 + 2] = -tfxyz[i3 + 2];
    }
    vol[2] =
        optimizeOverlapVol(tAtoms, ttmpxyz, tvdwR, tw, qAtoms, qtmpxyz, qvdwR, qw, onlyHeavyAtoms);
    // std::cout<<"vol3 = "<<vol[2]<<"\n";
    if (vol[2] > maxVol) {
        maxVol = vol[2];
        for (int i = 0; i < tAtoms; i++) {
            i3 = i * 3;
            tXYZ[i3] = ttmpxyz[i3];
            tXYZ[i3 + 1] = ttmpxyz[i3 + 1];
            tXYZ[i3 + 2] = ttmpxyz[i3 + 2];
        }
        // setFragXYZ(tfrag,ttmpxyz,onlyHeavyAtoms);
    }

    //
    // -y,-z, rotate 180 around X axis
    //
    for (int i = 0; i < tAtoms; i++) {
        i3 = i * 3;
        ttmpxyz[i3] = tfxyz[i3];
        ttmpxyz[i3 + 1] = -tfxyz[i3 + 1];
        ttmpxyz[i3 + 2] = -tfxyz[i3 + 2];
    }
    vol[3] = optimizeOverlapVol(tAtoms, ttmpxyz, tvdwR, tw, qAtoms, qtmpxyz, qvdwR, qw, true);
    // std::cout<<"vol4 = "<<vol[3]<<"\n";
    if (vol[3] > maxVol) {
        maxVol = vol[3];
        for (int i = 0; i < tAtoms; i++) {
            i3 = i * 3;
            tXYZ[i3] = ttmpxyz[i3];
            tXYZ[i3 + 1] = ttmpxyz[i3 + 1];
            tXYZ[i3 + 2] = ttmpxyz[i3 + 2];
        }
        // setFragXYZ(tfrag,ttmpxyz,onlyHeavyAtoms);
    }

    // std::cout<<"Max volume = "<<maxVol<<"\n";

    // for the query change back to its original coordinates, apply the same translation and
    // rotation to target molecules
    for (int j = 0; j < tAtoms; j++) {
        j3 = j * 3;
        Rotation(&tXYZ[j3], rotMatBack, &tfxyz[j3]);
        tfxyz[j3] += qcent[0];
        tfxyz[j3 + 1] += qcent[1];
        tfxyz[j3 + 2] += qcent[2];
    }
    setFragXYZ(tfrag, tfxyz, onlyHeavyAtoms);

    delete[] tXYZ;

    delete[] qxyz;
    delete[] txyz;
    delete[] qweight;
    delete[] tweight;
    delete[] qfxyz;
    delete[] tfxyz;
    delete[] qtmpxyz;
    delete[] ttmpxyz;
    delete[] qvdwR;
    delete[] tvdwR;
    delete[] qw;
    delete[] tw;

    return maxVol;
}

}  // namespace MISS
