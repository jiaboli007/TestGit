#ifndef gshape_h
#define gshape_h
#include <fstream>
#include <iostream>

#include "Misc/fragment2D.h"
#include "Misc/ssdUtil.h"
#include "Utils/mfcUtil.hpp"

namespace MISS {
//
// n: number of overlapping Guassian
// aList: indexes of the atom list of the Guassians
// xyz: coordinates of the whole molecule
// rn: coordiates of the coalesense center of the overlapping Guassians
// vn: overlapping volume
// vdwR: van der Waals radii
// pix: p(i)
// dltn: delta-n
// atomSA: return value
//
void calGSA(int n, int* aList, double vn, double* xyz, double* rn, double* vdwR, double* pix,
            double dltn, double* atomSA);
double calGCrossVolume(int na1, int na2, double* xyz1, double* vdwR1, double* xyz2, double* vdwR2,
                       double* w1, double* w2);
double calGDCrossVolFB(double* v, int na1S, int* sAtomIdx, int na1F, int* fAtomIdx, double* xyz1,
                       double alpha1, double* w1, int na2, double* xyz2, double* alpha2, double* w2,
                       bool equalR, double* wxpp, double* dtr, double* hess);
double LSolver6x(double hess[6][6], double der6[6], double dx[6]);
double LSolver6(double hess[6][6], double der6[6], double dx[6]);
float LSolver6_float(float hess[6][6], float der6[6], float dx[6]);

double overlayFGMols(MFCFrag* Frag1, MFCFrag* Frag2, double a, double b, double g, double* t,
                     bool useWeights = true, double* WF = 0, double* WV = 0);
double overlayFGSpheres2(int NA1, double* xyz1, double* vdwR1, double* w1, int NA2, double* xyz2,
                         double* vdwR2, double* w2, int nFeatAtoms1, int* FeatTypes1,
                         int* FAtomIdx1, int nFeatAtoms2, int* FeatTypes2, int* FAtomIdx2, double a,
                         double b, double g, double* t, bool trans = true, double* WF = 0,
                         double* WV = 0);

// new feature overlay
double overlayFGSpheres(int NA1, double* xyz1, double* alpha1, double* w1, int NA2, double* xyz2,
                        double* alpha2, double* w2, int nFA1, int* FATypes1, int* FAIdx1, int nFA2,
                        int* FATypes2, int* FAIdx2, double a, double b, double g, double* t,
                        bool trans, double* W, double* cVol);

double calFGDCrossVol(int na1, double* xyz1, double* alpha1, double* w1, int na2, double* xyz2,
                      double* alpha2, double* w2, int nFA1, int* FATypes1, int* FAIdx1, int nFA2,
                      int* FATypes2, int* FAIdx2, double dtr0[6], double hess6[6][6], double* WF,
                      double* cVol);

double overlayFGSpheres_ourPharma(int NA1, double* xyz1, double* alpha1, double* w1, int NA2,
                                  double* xyz2, double* alpha2, double* w2, int nFeat1,
                                  int* FeatTypes1, double* featXYZ1, int nDirc1, int* dircTypes1,
                                  double* dircXYZ1, int nFeat2, int* FeatTypes2, double* featXYZ2,
                                  int nDirc2, int* dircTypes2, double* dircXYZ2, bool trans,
                                  bool equalR, double* W, double* cVol, double* diffVolume = 0);

double calFGDCrossVol_ourPharma(int nFeat1, int* FeatTypes1, double* featXYZ1, int nDirc1,
                                int* dircTypes1, double* dircXYZ1, int nFeat2, int* FeatTypes2,
                                double* featXYZ2, int nDirc2, int* dircTypes2, double* dircXYZ2,
                                double dtr0[6], double hess6[6][6], double* WF, double* cVol);

double calHSMolVolume(int nAtoms, double* xyz, double* vdwR);
double calHSMolVolumeMC(MFCFrag* mfcFrag);
double calHSVolumeMC(int nAtoms, double* xyz, double* vdwR);
double calHSMolCrossVolumeMC(MFCFrag* Frag1, MFCFrag* Frag2);
// for the fitting of param K in GS Weight calculation
double calMolSelfVolGS_fitK(int nSpheres, double* xyz, double* vdwR, double* weights, double* gVols,
                            double* alpha, bool getW, bool equalR, double k);

struct NBAtomBoxes {
    ~NBAtomBoxes() {
        delete[] startIndexes;
        delete[] nbAtomList;
    }
    double x0;
    double y0;
    double z0;
    double boxSize;
    int nBoxes;
    int nx, ny, nz;
    int* startIndexes;
    int* nbAtomList;
};

NBAtomBoxes* findNeighborAtoms(MFCFrag* mfcFrag);

/**optimize cross volume by Conjugate Gradient**/
double calGDCrossVol(int na1, double* xyz1, double* vdwR1, double* w1, int na2, double* xyz2,
                     double* vdwR2, double* w2, double* cderv, bool computeCderv);
double optimizeOverlapVol(MFCFrag* Frag1, MFCFrag* Frag2, bool onlyHeavyAtoms, double* selfVol);
double calGGradient(int NA1, double* xyz1, double* vdwR1, double* w1, int NA2, double* xyz2,
                    double* vdwR2, double* w2, double* dtr, double* rt, bool computeGrad);
double lineMinimizer(int NA1, double* xyz1, double* vdwR1, double* w1, int NA2, double* xyz2,
                     double* vdwR2, double* w2, double* rt, double step, double vOld,
                     double* direction);

double overlayFGMols_readSimpleSD(simpleMolData* molData1, simpleMolData* molData2, double a,
                                  double b, double g, double* t, bool computeWeights, double* WF,
                                  double* WV);

// calculate accessible surface area of Guassian Sphere
double calMolSelfVol_ASA(int nSpheres, double* xyz, double* vdwR, double P, double F);
void calGSASA(int nSpheres, double* xyz, double* vdwR, double* weights, double* sa, double* P,
              double* F, bool equalR = false);

void calSelfVolFeature(double* xyz, int nFAtoms, int* atomsFType, int* fAtoms, double* selfVol);
double calSelfVolPerF(double* xyz, int nFAtoms, std::vector<int>& fAtoms);

void calSelfVolFeature_ownPharma(int nFeat, int* featTypes, double* featXYZ, int nDirc,
                                 int* dircTypes, double* dircXYZ, double* selfVol);
void calSelfVolFeature_ownPharma(std::vector<PharmaFeature*>& allFeatures, double* selfVol);

double calMolSelfVolGS(int nSpheres, double* xyz, double* vdwR, double* weights, bool getW = false,
                       bool equalR = false);
double calMolSelfVolGS(int nSpheres, double* xyz, double* vdwR, double* weights, double* gVols = 0,
                       double* alpha = 0, bool getW = false, bool equalR = false);

// lixm:3DSSA
double calMolSelfVolGS_SS(int nSpheres, double* xyz, double* vdwR, double* weights, double* gVols,
                          double* alpha, bool getW, bool equalR, double* vol, int* mtype,
                          double* mwt);

void Set_StdOrientation(int nSpheres, double* xyz, double* alpha, double* w, double* gVols,
                        double* Eout = 0, bool onlyHeavyAtoms = false);

void initTransAndRotation(int nSpheres, double* xyz, double* alpha, double* w, double* gVols,
                          double* Eout = 0, bool equalR = false, bool useR = false);
void initTransAndRotation(int nSpheres, double* xyz, double* alpha, double* w, double* gVols,
                          double* centGrv, double* Eout = 0, bool equalR = false,
                          bool useR = false);
void initTransAndRotation(int nSpheres, double* xyz, double* alpha, double* weights, double* gVols,
                          double* centGrv, double rotMat[][3], double* Eout, bool equalR,
                          bool useR);
void initFeatAlignment(int nSpheres, double* xyz, double* weights, double* centGrv,
                       double rotMat[][3]);

// lixm
void initTransAndRotation_SS(int nSpheres, double* xyz, double* alpha, double* weights,
                             double* gVols, double* centGrv, double* Eout, bool equalR, bool useR,
                             int* mtype);
void initTransAndRotation_SS(int nSpheres, double* xyz, double* alpha, double* weights,
                             double* gVols, double* Eout, bool equalR, bool useR, int* mtype);

double overlayGSpheres(int NA1, double* xyz1, double* alpha1, double* w1, int NA2, double* xyz2,
                       double* alpha2, double* w2, bool trans, bool equalR);

double overlayGSpheres_SS(int NA1, double* xyz1, double* alpha1, double* w1, int NA2, double* xyz2,
                          double* alpha2, double* w2, bool trans, bool equalR, int* qtype,
                          double* qwt, int* stype, double* swt, double* mvol);

float overlayGSpheres_float(int NA1, float* xyz1, float* alpha1, float* w1, int NA2, float* xyz2,
                            float* alpha2, float* w2, bool trans, bool equalR);

double calDervsCartesian(int na1, double* xyz1, double* alpha1, double* w1, int na2, double* xyz2,
                         double* alpha2, double* w2, double* cderv, double* chess, bool equalR);

double calDervsCartesian_SS(int na1, double* xyz1, double* alpha1, double* w1, int na2,
                            double* xyz2, double* alpha2, double* w2, double* cderv, double* chess,
                            bool equalR, int* qtype, double* qwt, int* stype, double* swt,
                            double* mvol);

float calDervsCartesian_float(int na1, float* xyz1, float* alpha1, float* w1, int na2, float* xyz2,
                              float* alpha2, float* w2, float* cderv, float* chess, bool equalR);

void dervsCartesian2RT(int na1, double* xyz1, double* cderv, double* chess, double RTderv[6],
                       double RThess[6][6]);

void dervsCartesian2RT_float(int na1, float* xyz1, float* cderv, float* chess, float RTderv[6],
                             float RThess[6][6]);

double featureShapeOverlay(MFCFrag* qfrag, MFCFrag* tfrag, bool onlyHeavyAtoms, bool getW,
                           double* selfVol);

}  // namespace MISS

#endif /* gshape_h */
