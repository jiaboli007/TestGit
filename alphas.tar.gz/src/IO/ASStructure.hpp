
#ifndef ALPHACS_ASSTRUCTURE_HPP
#define ALPHACS_ASSTRUCTURE_HPP

#include <array>
#include <concepts>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <numeric>
#include <ranges>
#include <type_traits>
#include <vector>

#include <boost/iostreams/device/mapped_file.hpp>
#include <boost/range/irange.hpp>
#include <boost/uuid/uuid.hpp>
#include <boost/uuid/uuid_generators.hpp>
#include <boost/uuid/uuid_io.hpp>

#include <cuda_fp16.h>
#include <fmt/format.h>

#include "SdfTopology.hpp"

namespace MISS::AS {
inline namespace v1 {

constexpr char MAGIC_NUMBER[] = "%ALPHAS";

enum class AS_VERSION : uint8_t { _0 = 0, _1 = 1 };

enum { HBA, HBD, ARO, POS, NEG, HYD };

template <typename T>
concept arithmetic = std::integral<T> or std::floating_point<T> or std::same_as<T, __half>;
struct compress_tag {};
struct compress_radio_tag {};
struct compress_half_tag {};
struct no_compress_tag {};

// File Header
struct Header {
    boost::uuids::uuid uuid;
    uint32_t total_molecule_number{};
    AS_VERSION version;
};

struct Molecule {
    // Header for each molecule
    struct Header {
        uint8_t heavy_atom_number{};
        uint16_t conformations_number{};
    };

    struct Conformation {
        [[nodiscard]] int get_num_feats() const {
            return std::accumulate(begin(pharma_feature_numbers), end(pharma_feature_numbers), 0,
                                   std::plus{}) +
                   std::accumulate(begin(pharma_feature_numbers), begin(pharma_feature_numbers) + 3,
                                   0, std::plus{});
        }
        [[nodiscard]] int get_num_dircs() const {
            return int(pharma_feature_numbers[0]) + pharma_feature_numbers[1] +
                   pharma_feature_numbers[2];
        }

        std::vector<std::array<float, 3>> coordinates;
        std::vector<float> wt;
        float vol;
        // PharmaFeature numbers
        std::array<uint8_t, 6> pharma_feature_numbers;

        std::vector<std::array<float, 3>> pharmaFeatures;

        std::array<float, 9> selfVol;
    };

    Header header;
    std::vector<Conformation> conformations;
    std::string name;
    std::vector<char> topology_blob;

    std::size_t offset_in_as_begin, offset_in_as_end;

    std::function<void(const Molecule &)> pre_callback;

    void reset() {
        conformations.clear();
        name.clear();
        topology_blob.clear();
        header.heavy_atom_number = 0;
        header.conformations_number = 0;
    }
};

class MMapFile {
public:
    void open(const std::string &filename) {
        mapped_file.open(filename);
        if (!mapped_file) {
            throw std::runtime_error(fmt::format("ERROR! AS file ({}) cannot open", filename));
        }
        cursor = mapped_file.begin();
    }

    void read(char *_s, std::size_t length) {
        std::memcpy(_s, cursor, length);
        cursor += length;
    }

    [[nodiscard]] auto tellg() const { return cursor - mapped_file.begin(); }
    void seekg(std::size_t offset) { cursor = mapped_file.begin() + offset; }

private:
    boost::iostreams::mapped_file_source mapped_file;
    boost::iostreams::mapped_file_source::iterator cursor;
};

template <typename FileStream = MMapFile>
class Reader : public FileStream {
public:
    explicit Reader(const std::string &filename) {
        open(filename);
        read_header();
        molecule_number_left = header.total_molecule_number;
    }

    Reader(Reader &&) = delete;
    Reader &operator=(Reader &&) = delete;

    explicit operator bool() { return molecule_number_left != 0; }

    const Header &get_header() { return header; }

    Molecule read_mol() {
        auto offset_in_as_begin = tellg();
        auto mol = read_mol_from_offset();
        mol.offset_in_as_begin = offset_in_as_begin;
        mol.offset_in_as_end = tellg();
        molecule_number_left--;
        return mol;
    }

    Molecule read_mol_from_offset(std::size_t offset = 0) {
        if (offset != 0) seekg(offset);

        Molecule mol;
        read(mol.header.heavy_atom_number);
        read(mol.header.conformations_number);

        mol.conformations.reserve(mol.header.conformations_number);

        for ([[maybe_unused]] auto i : boost::irange(mol.header.conformations_number)) {
            Molecule::Conformation conf;
            conf.coordinates.resize(mol.header.heavy_atom_number);

            header.version == AS_VERSION::_0 ? read(conf.coordinates)
                                             : read(conf.coordinates, compress_tag{});

            conf.wt.resize(mol.header.heavy_atom_number);
            header.version == AS_VERSION::_0 ? read(conf.wt) : read(conf.wt, compress_radio_tag{});

            read(conf.vol);

            read(conf.pharma_feature_numbers);

            conf.pharmaFeatures.resize(conf.get_num_feats());

            header.version == AS_VERSION::_0 ? read(conf.pharmaFeatures)
                                             : read(conf.pharmaFeatures, compress_tag{});
            header.version == AS_VERSION::_0 ? read(conf.selfVol)
                                             : read(conf.selfVol, compress_half_tag{});

            mol.conformations.push_back(std::move(conf));
        }
        return mol;
    }

private:
    using FileStream::open, FileStream::read, FileStream::tellg, FileStream::seekg;

    uint32_t molecule_number_left;

    void read_header() {
        char magic_number[std::extent_v<decltype(MAGIC_NUMBER)>]{};
        read(magic_number, std::extent_v<decltype(MAGIC_NUMBER)> - 1);

        if (memcmp(magic_number, MAGIC_NUMBER, std::extent_v<decltype(MAGIC_NUMBER)> - 1) != 0)
            throw std::runtime_error("MAGIC NUMBER(%ALPHAS) not match");

        uint8_t version;
        read(version);

        if (version != 0 and version != 1)
            throw std::runtime_error("Only version 0 and 1 is supported");
        header.version = static_cast<AS_VERSION>(version);

        read(reinterpret_cast<char *>(header.uuid.begin()), header.uuid.size());
        read(header.total_molecule_number);
    }

    void read(float &value, compress_tag) {
        int16_t v;
        read(v);
        value = static_cast<float>(v) * 0.01f;
    }

    void read(float &value, compress_radio_tag) {
        uint16_t v;
        read(v);
        value = static_cast<double>(v) / std::numeric_limits<uint16_t>::max();
    }
    void read(float &value, compress_half_tag) {
        __half v;
        static_assert(sizeof(__half) == 2);
        read(v);
        value = __half2float(v);
    }

    template <arithmetic T>
    void read(T &value, no_compress_tag = {}) {
        read(reinterpret_cast<char *>(&value), sizeof(value));
    }

    template <std::ranges::forward_range T, typename Tag = no_compress_tag>
    void read(T &value, Tag tag = {}) {
        read(begin(value), end(value), tag);
    }

    template <std::forward_iterator It, typename Tag = no_compress_tag>
    void read(It begin, It end, Tag tag = {}) {
        for (auto it = begin; it != end; ++it) read(*it, tag);
    }

    Header header;
};

class Writer {
public:
    explicit Writer(const std::string &filename, AS_VERSION version = AS_VERSION::_0)
        : version(version) {
        open(filename);
    }

    Writer(Writer &&) = delete;
    Writer &operator=(Writer &&) = delete;

    void write(Molecule &mol) {
        mol.header.conformations_number = mol.conformations.size();
        mol.offset_in_as_begin = ofs.tellp();
        if (mol.pre_callback) mol.pre_callback(mol);
        write(mol.header);

        for (auto &&conf : mol.conformations) {
            assert(std::accumulate(begin(conf.pharma_feature_numbers),
                                   end(conf.pharma_feature_numbers), 0UL, std::plus{}) +
                       std::accumulate(begin(conf.pharma_feature_numbers),
                                       begin(conf.pharma_feature_numbers) + 3, 0UL, std::plus{}) ==
                   conf.pharmaFeatures.size());
            write(conf);
        }
        mol.offset_in_as_end = ofs.tellp();

        ++total_molecule_number;
    }

    ~Writer() {
        try {
            writeFileHeader();
        } catch (...) {
            std::cerr << "Write AS Header failed" << std::endl;
            std::exit(EXIT_FAILURE);
        }
    }

    auto get_total_molecule_number() const { return total_molecule_number; }

private:
    void open(const std::string &filename) {
        ofs.exceptions(std::ios_base::badbit | std::ios_base::failbit);
        ofs.open(filename, std::ios_base::binary);
        // skip header
        ofs.seekp(28);
    };

    void writeFileHeader() {
        ofs.seekp(0);

        std::string_view magic_number = MAGIC_NUMBER;
        ofs.write(magic_number.data(), magic_number.size());

        auto ver = static_cast<uint8_t>(version);
        write(ver);

        boost::uuids::uuid uuid = boost::uuids::random_generator()();
        static_assert(uuid.size() == 16);
        ofs.write(reinterpret_cast<const char *>(uuid.begin()), uuid.size());

        write(total_molecule_number);
    }

    void write(const Molecule::Header &header) {
        write(header.heavy_atom_number);
        write(header.conformations_number);
    }

    void write(const Molecule::Conformation &conf) {
        version == AS_VERSION::_0 ? write(conf.coordinates)
                                  : write(conf.coordinates, compress_tag{});
        version == AS_VERSION::_0 ? write(conf.wt) : write(conf.wt, compress_radio_tag{});
        write(conf.vol);
        write(conf.pharma_feature_numbers);
        version == AS_VERSION::_0 ? write(conf.pharmaFeatures)
                                  : write(conf.pharmaFeatures, compress_tag{});
        version == AS_VERSION::_0 ? write(conf.selfVol) : write(conf.selfVol, compress_half_tag{});
    }

    template <std::ranges::input_range T, typename Tag = no_compress_tag>
    void write(const T &value, Tag tag = {}) {
        for (auto &&v : value) write(v, tag);
    }

    void write(float value, compress_tag) {
        auto v = static_cast<int16_t>(value * 100.0f);
        write(v);
    }

    void write(float value, compress_radio_tag) {
        auto v = static_cast<uint16_t>(static_cast<double>(value) *
                                       std::numeric_limits<uint16_t>::max());
        write(v);
    }

    void write(float value, compress_half_tag) {
        auto v = __float2half(value);
        write(v);
    }

    template <arithmetic T>
    void write(T value, no_compress_tag = {}) {
        ofs.write(reinterpret_cast<const char *>(&value), sizeof(value));
    };

    std::ofstream ofs;
    uint32_t total_molecule_number{};

    AS_VERSION version;
};
}  // namespace v1
}  // namespace MISS::AS

#endif  // ALPHACS_ASSTRUCTURE_HPP
