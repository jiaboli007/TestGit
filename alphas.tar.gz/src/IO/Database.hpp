//
// Created by xiamr on 9/1/20.
//

#ifndef ALPHACS_DATABASE_HPP
#define ALPHACS_DATABASE_HPP

#include <string>
#include <vector>

namespace MISS {

struct Database {
    int all_heavy_atoms = 0;

    std::vector<float> X;
    std::vector<float> Y;
    std::vector<float> Z;
    std::vector<float> W;
    std::vector<float> selfVol;
    std::vector<int> nHeavyAtom;
    std::vector<int> startPosPMol;

    // for features
    std::vector<float> featX;
    std::vector<float> featY;
    std::vector<float> featZ;

    int all_num_feats = 0;
    std::vector<int> startFeatPosPMol;
    std::vector<int> numPerF_V;

    std::vector<uint16_t> conformations_number_per_mol;
};

}  // namespace MISS
#endif  // ALPHACS_DATABASE_HPP
