//
// Created by xiamr on 9/2/20.
//

#include "config.hpp"

#include <algorithm>
#include <iostream>
#include <type_traits>

#include <boost/range/adaptors.hpp>
#include <boost/range/numeric.hpp>

#include "DatabaseUtil.hpp"

#include "Database.hpp"

using namespace MISS;

DatabaseUtil::DatabaseUtil(const std::string &as_filename, double size_load_once)
    : reader(as_filename),
      header(reader.get_header()),
      size_load_once(size_load_once * 1024 * 1024 * 1024L) {
    molecule_number_left_in_file = header.total_molecule_number;
}

namespace {
void update_capability(std::size_t &predefined_capability, std::size_t size) {
    predefined_capability = std::max(predefined_capability, size);
}
}  // namespace

boost::optional<Database> DatabaseUtil::load() {
    if (molecule_number_left_in_file == 0) return {};
    struct {
        int conf_num_in_group{};
        int max_atom_in_group{};
        std::array<int, 9> max_feature_atom{};
    } state;

    std::size_t coordinate_array_length = 0;
    std::size_t feature_array_length = 0;

    static std::size_t x_y_z_w_vector_capability{0};
    static std::size_t n_conf_vector_capability{0};
    static std::size_t featX_vector_capability{0};
    static std::size_t conformations_number_per_mol_vector_capability{0};

    Database db;
    if (molecule_number_left_in_file > 0) {
        std::size_t cap = x_y_z_w_vector_capability;
        db.X.reserve(cap);
        db.Y.reserve(cap);
        db.Z.reserve(cap);
        db.W.reserve(cap);

        cap = n_conf_vector_capability;
        db.selfVol.reserve(10 * cap);
        db.nHeavyAtom.reserve(cap);
        db.startPosPMol.reserve(cap);
        db.startFeatPosPMol.reserve(cap);
        db.numPerF_V.reserve(9 * cap);

        cap = featX_vector_capability;
        db.featX.reserve(cap);
        db.featY.reserve(cap);
        db.featZ.reserve(cap);

        db.conformations_number_per_mol.reserve(conformations_number_per_mol_vector_capability);
    }
    try {
        while (molecule_number_left_in_file > 0) {
            const auto &mol = reader.read_mol();
            molecule_number_left_in_file--;
            if (mol.header.heavy_atom_number > MAX_DB_ATOM_NUMBER) {
                std::cerr << "too many heavy atoms : will overflow in GPU code\n";
                std::exit(EXIT_FAILURE);
            }
            db.conformations_number_per_mol.push_back(mol.conformations.size());
            for (const auto &conf : mol.conformations) {
                db.nHeavyAtom.push_back(mol.header.heavy_atom_number);
                db.startPosPMol.push_back(db.all_heavy_atoms);
                db.all_heavy_atoms += mol.header.heavy_atom_number;
                state.conf_num_in_group++;
                state.max_atom_in_group = std::max(state.max_atom_in_group,
                                                   static_cast<int>(mol.header.heavy_atom_number));

                for (const auto &[i, coord] : conf.coordinates | boost::adaptors::indexed(0)) {
                    const auto &[x, y, z] = coord;
                    db.X.push_back(x);
                    db.Y.push_back(y);
                    db.Z.push_back(z);
                    db.W.push_back(conf.wt[i]);
                }

                db.selfVol.push_back(conf.vol);
                db.startFeatPosPMol.push_back(db.all_num_feats);

                for (const auto &feat : conf.pharmaFeatures) {
                    db.featX.push_back(feat[0]);
                    db.featY.push_back(feat[1]);
                    db.featZ.push_back(feat[2]);
                }

                int numPerF[9];
                std::copy(begin(conf.pharma_feature_numbers), end(conf.pharma_feature_numbers),
                          numPerF);
                numPerF[6] = numPerF[0];  // HBA: number of directions == number of features
                numPerF[7] = numPerF[1];
                numPerF[8] = numPerF[2];

                for (auto [idx, perf] : numPerF | boost::adaptors::indexed(0)) {
                    db.numPerF_V.push_back(perf);
                    db.all_num_feats += perf;
                    state.max_feature_atom[idx] = std::max(state.max_feature_atom[idx], perf);
                }

                if (state.conf_num_in_group == grpSize) {
                    coordinate_array_length += std::exchange(state.max_atom_in_group, 0);
                    for (auto &num : state.max_feature_atom) {
                        feature_array_length += std::exchange(num, 0);
                    }
                    state.conf_num_in_group = 0;
                }

                if (conf.get_num_feats() > MAX_DB_FEATURE_NUMBER) {
                    std::cerr << "error load database, number of feature spheres >"
                              << MAX_DB_FEATURE_NUMBER << " \n";
                    std::exit(EXIT_FAILURE);
                }

                for (auto vol : conf.selfVol) {
                    db.selfVol.push_back(vol);
                }
            }
            // calculate memory demand
            auto total_molecule_number = db.nHeavyAtom.size();

            auto nGrp = (total_molecule_number + grpSize - 1) / grpSize;
            // clang-format off
            auto estimated_gpu_mem =
                total_molecule_number * sizeof(float) +
                grpSize * 4 * (coordinate_array_length + state.max_atom_in_group ) * sizeof(float) +
                db.selfVol.size() * sizeof(float) +
                12 * nGrp * sizeof(int) +
                grpSize * 4 * (feature_array_length + boost::accumulate(state.max_feature_atom, 0))
                                                                                * sizeof(float);
            // clang-format on
            if (estimated_gpu_mem > size_load_once) {
                update_capability(x_y_z_w_vector_capability, db.X.capacity());
                update_capability(n_conf_vector_capability, db.nHeavyAtom.capacity());
                update_capability(featX_vector_capability, db.featX.capacity());
                update_capability(conformations_number_per_mol_vector_capability,
                                  db.conformations_number_per_mol.capacity());
                return db;
            }
        }
    } catch (const std::ios_base::failure &e) {
        if (reader) {
            std::cerr << "Exception : " << e.what() << std::endl;
            std::exit(EXIT_FAILURE);
        }
    }

    return db;
}
