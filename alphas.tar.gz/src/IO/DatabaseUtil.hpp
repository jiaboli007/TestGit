//
// Created by xiamr on 9/2/20.
//

#ifndef ALPHACS_DATABASEUTIL_HPP
#define ALPHACS_DATABASEUTIL_HPP

#include <boost/optional.hpp>

#include "Database.hpp"
#include "IO/ASStructure.hpp"

namespace MISS {
struct DatabaseUtil {
public:
    DatabaseUtil(const std::string &as_filename, double size_load_once = 1 /* 1GB */);

    boost::optional<Database> load();

    auto get_total_molecule_number() const { return header.total_molecule_number; }

private:
    AS::Reader<AS::MMapFile> reader;

    const MISS::AS::Header header;

    const std::size_t size_load_once;  // 4 million conformations

    std::size_t molecule_number_left_in_file;
};
}  // namespace MISS

#endif  // ALPHACS_DATABASEUTIL_HPP
