//
// Created by xiamr on 9/1/20.
//

#ifndef ALPHACS_QUERYINFO_HPP
#define ALPHACS_QUERYINFO_HPP

#include "config.hpp"

#include <array>
#include <string>

struct QueryInfo {
    int nAtoms;
    std::vector<std::array<float, 3>> xyz;
    std::vector<float> weight;
    std::array<int, 9> numFeat;
    std::vector<std::array<float, 3>> featXYZ;
    std::array<float, 10> selfVol;

    std::string name;

    auto get_name() const { return name; }
};

#endif  // ALPHACS_QUERYINFO_HPP
