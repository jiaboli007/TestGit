
#include <boost/scope_exit.hpp>

#include "IO/QueryReader.hpp"

#include "ForceField/ffUtil.h"
#include "GPU/GPUEngine.hpp"
#include "GShape/mfcGShape.hpp"
#include "IO/ASStructure.hpp"
#include "IO/Database.hpp"
#include "IO/DatabaseUtil.hpp"
#include "IO/SQLiteSchema.hpp"
#include "Misc/ssdUtil.h"
#include "QueryInfo.hpp"
#include "Topology/topology.h"
#include "Utils/mathUtil.hpp"
#include "Utils/mfcUtil.hpp"
#include "Utils/utils.hpp"

using namespace MISS;

boost::optional<QueryInfo> QueryReader::readQuery() {
    for (;;) {
        if (sdReader.endOfSD()) return {};
        QueryInfo q;
        MFCFrag *frag = sdReader.readLargestMFCFrag();
        if (frag == nullptr) return {};
        BOOST_SCOPE_EXIT(frag) { delete frag; }
        BOOST_SCOPE_EXIT_END

        q.name = frag->fragname;

        auto conf = Optimize::transform_to_conf(frag, pharmacophore, getW, initR);
        q.nAtoms = conf.coordinates.size();
        if (q.nAtoms > MAX_QUERY_ATOM_NUMBER) {
            std::cerr << "error! number of atoms in query is greater than " << MAX_QUERY_ATOM_NUMBER
                      << " !\n";
            std::exit(EXIT_FAILURE);
        }
        if (conf.get_num_feats() > MAX_QUERY_FEATURE_NUMBER) {
            std::cerr << "error! number of query feature spheres > " << MAX_QUERY_FEATURE_NUMBER
                      << " !\n";
            std::exit(EXIT_FAILURE);
        }

        q.xyz = std::move(conf.coordinates);
        q.weight = std::move(conf.wt);
        std::copy(std::begin(conf.pharma_feature_numbers), std::end(conf.pharma_feature_numbers),
                  std::begin(q.numFeat));
        std::copy(std::begin(conf.pharma_feature_numbers),
                  std::begin(conf.pharma_feature_numbers) + 3, std::begin(q.numFeat) + 6);
        q.featXYZ = std::move(conf.pharmaFeatures);
        q.selfVol[0] = conf.vol;
        std::copy(std::begin(conf.selfVol), std::end(conf.selfVol), q.selfVol.data() + 1);

        return q;
    }
}