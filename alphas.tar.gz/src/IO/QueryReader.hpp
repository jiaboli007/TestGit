//
// Created by xiamr on 9/15/20.
//

#ifndef ALPHACS_QUERYREADER_H
#define ALPHACS_QUERYREADER_H

#include <boost/optional.hpp>
#include <boost/stl_interfaces/iterator_interface.hpp>

#include "QueryInfo.hpp"
#include "Utils/mfcUtil.hpp"
#include "Utils/utils.hpp"

class QueryReaderIterator;

class QueryReader {
public:
    QueryReader(const std::string &filename, bool getW = true, bool initR = true)
        : sdReader(filename),
          getW(getW),
          initR(initR),
          pharmacophore(MISS::Optimize::load_pharmacophore_graph()) {}

    boost::optional<QueryInfo> readQuery();

    QueryReaderIterator begin();
    QueryReaderIterator end();

private:
    MISS::SDReader sdReader;
    const bool getW;
    const bool initR;
    static constexpr bool onlyHeavyAtoms = true;

    MISS::Optimize::PharmacophoreGraph pharmacophore;
};

class QueryReaderIterator
    : public boost::stl_interfaces::iterator_interface<QueryReaderIterator, std::input_iterator_tag,
                                                       QueryInfo> {
public:
    explicit QueryReaderIterator(QueryReader *reader) : reader(reader) {}

    QueryInfo &&operator*() {
        if (!query_info.has_value()) query_info = reader->readQuery();
        return std::move(query_info.get());
    }

    friend bool operator==(const QueryReaderIterator &lhs, const QueryReaderIterator &rhs) {
        return lhs.reader == rhs.reader;
    }

    QueryReaderIterator &operator++() {
        query_info = reader->readQuery();
        if (!query_info.has_value()) reader = nullptr;
        return *this;
    }

private:
    boost::optional<QueryInfo> query_info;
    QueryReader *reader = nullptr;
};

inline QueryReaderIterator QueryReader::begin() { return QueryReaderIterator(this); }
inline QueryReaderIterator QueryReader::end() { return QueryReaderIterator(nullptr); }

#endif  // ALPHACS_QUERYREADER_H
