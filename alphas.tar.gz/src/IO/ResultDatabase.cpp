
#include "config.hpp"

#include <boost/filesystem.hpp>

#include "IO/ResultDatabase.hpp"

#include "IO/QueryInfo.hpp"
#include "IO/QueryReader.hpp"
#include "IO/SQLiteSchema.hpp"
#include "Utils/utils.hpp"

template <typename T>
void output_result(const std::vector<QueryResult> &screen_results, const std::vector<T> &queries,
                   const std::string &result_db) {
    boost::filesystem::remove(result_db);
    auto result_storage = make_result_storage(result_db);

    result_storage.pragma.journal_mode(sqlite_orm::journal_mode::OFF);
    result_storage.pragma.set_pragma("synchronous", "OFF");
    result_storage.pragma.user_version(0);  // version of result database
    result_storage.pragma.set_pragma(
        "application_id",
        AlphaS_Result_File_Application_ID);  // Application ID: AlphaS Result File

    cout << "Creating sqlite3 result file ..." << endl;
    for (const auto &[item, result] : result_storage.sync_schema()) {
        cout << '\t' << item << "\t->\t" << result << endl;
    }

    auto guard = result_storage.transaction_guard();
    for (auto &query : queries) {
        result_storage.insert(MolName{.name = query.get_name()});
    }
    for (const auto &res : screen_results) {
        result_storage.insert(res);
    }
    guard.commit();
}

template void output_result(const std::vector<QueryResult> &screen_results,
                            const std::vector<QueryInfo> &queries, const std::string &result_db);

template void output_result(const std::vector<QueryResult> &screen_results,
                            const std::vector<MISS::Optimize::QueryItem> &queries,
                            const std::string &result_db);