

#ifndef ALPHACS_SRC_IO_RESULTDATABASE_HPP
#define ALPHACS_SRC_IO_RESULTDATABASE_HPP

#include <string>
#include <vector>

struct QueryResult;

template <typename T>
void output_result(const std::vector<QueryResult> &screen_results, const std::vector<T> &queries,
                   const std::string &result_db);

#endif  // ALPHACS_SRC_IO_RESULTDATABASE_HPP
