
#ifndef ALPHACS_SQLITESCHEMA_HPP
#define ALPHACS_SQLITESCHEMA_HPP

#include <string>

#include <sqlite_orm/sqlite_orm.h>

struct MolName {
    std::size_t id;                   // molecule id, start from 1
    std::string name;                 // molecule name
    std::vector<char> topology_blob;  // binary sdf topology
};

struct ConfOffset {
    std::size_t conf_id;  // conformation index, start from 1
    std::size_t mol_id;   // corresponding molecule id, start from 1
    std::size_t offset;   // offset of associated AS file (in Bytes)
};

struct QueryResult {
    std::size_t conf_id;   // conformation index, start from 1
    std::size_t query_id;  // query molecule id, start from 1
    double score;          // score value
};

struct MolConfSet {
    std::size_t id;                   // molecule id, start from 1
    std::string name;                 // molecule name
    std::size_t offset;               // offset of associated AS file (in Bytes)
    std::vector<char> topology_blob;  // binary sdf topology

    auto operator<=>(const MolConfSet &) const = default;
};

/*
 *  Index file SQLite Schema, as intermediate data structure for preprocess and postprocess
 */
inline auto make_index_storage(const std::string &filename) {
    using namespace sqlite_orm;
    return make_storage(
        filename,
        make_table("mol_name", make_column("id", &MolName::id, autoincrement(), primary_key()),
                   make_column("name", &MolName::name),
                   make_column("topology", &MolName::topology_blob)),
        make_table("conf_offset",
                   make_column("conf_id", &ConfOffset::conf_id, autoincrement(), primary_key()),
                   make_column("mol_id", &ConfOffset::mol_id),
                   make_column("offset", &ConfOffset::offset),
                   foreign_key(&ConfOffset::mol_id).references(&MolName::id)));
}

inline auto make_index_storage_v2(const std::string &filename) {
    using namespace sqlite_orm;
    return make_storage(
        filename,
        make_table("mol_offset", make_column("id", &MolConfSet::id, autoincrement(), primary_key()),
                   make_column("name", &MolConfSet::name),
                   make_column("offset", &MolConfSet::offset),
                   make_column("topology", &MolConfSet::topology_blob)));
}

/*
 *  Result file SQLite Schema, shapeGPU output
 */
inline auto make_result_storage(const std::string &filename) {
    using namespace sqlite_orm;
    return make_storage(filename,
                        make_table("query_mol_name",
                                   make_column("id", &MolName::id, autoincrement(), primary_key()),
                                   make_column("name", &MolName::name)),
                        make_table("result", make_column("conf_id", &QueryResult::conf_id),
                                   make_column("query_id", &QueryResult::query_id),
                                   make_column("score", &QueryResult::score),
                                   foreign_key(&QueryResult::query_id).references(&MolName::id)));
}

#endif  // ALPHACS_SQLITESCHEMA_HPP
