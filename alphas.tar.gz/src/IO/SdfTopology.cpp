
#include <cstring>
#include <iomanip>

#include <boost/range/combine.hpp>
#include <boost/range/irange.hpp>

#include "SdfTopology.hpp"

#include "IO/ASStructure.hpp"
#include "Singleton/params.h"

namespace MISS {

namespace {
template <typename T>
void write(char *&ptr, T value) {
    std::memcpy(ptr, &value, sizeof(T));
    ptr += sizeof(T);
}
template <typename... Args>
void write(char *&ptr, Args... values) {
    (..., write(ptr, values));
}

template <typename T>
void read(const char *&ptr, const char *const end, T &value) {
    if (ptr + sizeof(T) > end)
        throw std::runtime_error(fmt::format("address out-of-range in {}:{}", __FILE__, __LINE__));
    std::memcpy(&value, ptr, sizeof(T));
    ptr += sizeof(T);
}
template <typename... Args>
void read(const char *&ptr, const char *const end, Args &...values) {
    (..., read(ptr, end, values));
}

void read_compress(const char *&ptr, const char *const end, float &value) {
    if (ptr + sizeof(int16_t) > end)
        throw std::runtime_error(fmt::format("address out-of-range in {}:{}", __FILE__, __LINE__));
    int16_t v;
    std::memcpy(&v, ptr, sizeof(v));
    ptr += sizeof(v);
    value = static_cast<float>(v) * 0.01f;
}
template <typename... Args>
void read_compress(const char *&ptr, const char *const end, Args &...values) {
    (..., read(ptr, end, values));
}
}  // namespace

std::vector<char> SdfTopology::to_blob() const {
    static_assert(sizeof(Atom) == 2);
    static_assert(sizeof(Bond) == 3);
    std::vector<char> blob(sizeof(Atom) * nAtoms() + sizeof(Bond) * nBonds() + sizeof(nAtoms()) +
                           sizeof(nBonds()) + sizeof(cFlag));
    char *ptr = blob.data();
    auto n_atoms = nAtoms();
    auto n_bonds = nBonds();
    write(ptr, n_atoms, n_bonds, cFlag);

    for (auto atom : atoms) write(ptr, atom);
    for (auto bond : bonds) write(ptr, bond);

    return blob;
}

SdfTopology SdfTopology::from_blob(const std::vector<char> &blob) {
    return from_blob(blob.data(), blob.data() + blob.size());
}

SdfTopology SdfTopology::from_blob(const char *ptr, const char *const end) {
    std::uint8_t n_atoms, n_bonds;
    SdfTopology top;
    read(ptr, end, n_atoms, n_bonds, top.cFlag);

    top.atoms.resize(n_atoms);
    top.bonds.resize(n_bonds);

    for (int i : boost::irange(n_atoms)) read(ptr, end, top.atoms[i]);
    for (int i : boost::irange(n_bonds)) read(ptr, end, top.bonds[i]);

    return top;
}

void SdfTopology::to_sdf(std::ostream &out, std::string_view mol_name,
                         const std::vector<std::array<float, 3>> &coordinate) const {
    PeriodicTable *xTable = PeriodicTable::Instance();

    out << mol_name << "\n";
    out << "AlphaS post_overlay SD reconstitution\n";
    out << "\n";
    out << std::setw(3) << int(nAtoms()) << std::setw(3) << int(nBonds());
    out << std::setw(3) << 0 << std::setw(3) << int(cFlag);
    out << std::setw(3) << 0 << "  0  0  0  0  0  0 V2000\n";

    for (auto &&[coord, atom] : boost::combine(coordinate, atoms)) {
        out << std::setw(10) << std::setiosflags(std::ios::fixed) << std::setprecision(4)
            << coord[0];
        out << std::setw(10) << std::setiosflags(std::ios::fixed) << std::setprecision(4)
            << coord[1];
        out << std::setw(10) << std::setiosflags(std::ios::fixed) << std::setprecision(4)
            << coord[2];
        out << " " << std::setw(2) << xTable->AtomicSymbol(int(atom.atomicNumber));
        out << std::setw(3) << 0 << std::setw(3) << int(atom.cFlag);
        out << std::setw(3) << int(atom.stereoParity) << "  0  0" << '\n';
    }

    for (auto &bond : bonds) {
        out << std::setw(3) << int(bond.atom1) + 1 << std::setw(3) << int(bond.atom2) + 1
            << std::setw(3) << int(bond.bondOrder) << std::setw(3) << int(bond.bondDir) << "  0  0"
            << '\n';
    }

    out << "M  END\n";
}

void SdfTopology::make() {
    atoms.clear();
    bonds.clear();

    for (int i = 0; auto &atom : atoms_) {
        if (atom->atom.atomicNumber != 1) {
            atom->atom_no = i++;
            atoms.push_back(atom->atom);
        }
    }

    for (auto &bond : bonds_) {
        if (bond.atom1->atom.atomicNumber != 1 and bond.atom2->atom.atomicNumber != 1) {
            bonds.push_back({.atom1 = bond.atom1->atom_no,
                             .atom2 = bond.atom2->atom_no,
                             .bondOrder = bond.bondOrder,
                             .bondDir = bond.bondDir});
        }
    }
    atoms_.clear();
    bonds_.clear();
}

}  // namespace MISS
