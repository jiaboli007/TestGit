

#ifndef ALPHACS_SDFTOPOLOGY_HPP
#define ALPHACS_SDFTOPOLOGY_HPP

/**
 *  Topology part of molecule in SDF file
 *   contains atoms and bonds
 */

#include <memory>
#include <ostream>
#include <string_view>
#include <vector>

namespace MISS {
class SdfTopology {
public:
    [[nodiscard]] std::uint8_t nAtoms() const { return atoms.size(); }
    [[nodiscard]] std::uint8_t nBonds() const { return bonds.size(); }

    struct __attribute__((packed)) Atom {
        std::int8_t cFlag : 4;
        std::uint8_t stereoParity : 5;
        std::uint8_t atomicNumber : 7;

        auto operator<=>(const Atom &) const = default;
    };

    struct __attribute__((packed)) Bond {
        std::uint8_t atom1 : 8;
        std::uint8_t atom2 : 8;
        std::uint8_t bondOrder : 4;
        std::uint8_t bondDir : 4;
        auto operator<=>(const Bond &) const = default;
    };

    struct Atom_ {
        Atom atom;
        int atom_no;
    };

    struct Bond_ {
        Atom_ *atom1, *atom2;
        std::uint8_t bondOrder;
        std::uint8_t bondDir;
    };

    void add_atom(Atom_ atom) { atoms_.push_back(std::make_shared<Atom_>(atom)); }
    void add_bond(Bond_ bond) { bonds_.push_back(bond); }

    void make();

    [[nodiscard]] std::vector<char> to_blob() const;

    [[nodiscard]] static SdfTopology from_blob(const std::vector<char> &blob);

    [[nodiscard]] static SdfTopology from_blob(const char *ptr, const char *const end);

    void to_sdf(std::ostream &out, std::string_view mol_name,
                const std::vector<std::array<float, 3>> &coordinate) const;

    std::int8_t cFlag;

    std::vector<std::shared_ptr<Atom_>> atoms_;
    std::vector<Bond_> bonds_;

    std::vector<Atom> atoms;
    std::vector<Bond> bonds;
};
}  // namespace MISS

#endif  // ALPHACS_SDFTOPOLOGY_HPP
