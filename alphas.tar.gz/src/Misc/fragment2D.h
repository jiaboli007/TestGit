#ifndef fragment2D_h
#define fragment2D_h
/******************************************************************************
 *                                                                             *
 *    Category:   Molecule Foundation Classes (MFC)                            *
 *    Function:   Implement topology analysis of breaking down a fragment      *
 *    Author:     James Li                                                     *
 *    Date:       March, 2011                                                  *
 *                                                                             *
 ******************************************************************************/
#include <fstream>
#include <functional>
#include <iostream>
#include <map>
#include <string>
#include <vector>

#include "ForceField/ffUtil.h"
#include "MolStructure/mfcAtom.h"
#include "MolStructure/mfcBond.h"
#include "MolStructure/mfcMolecule.h"
#include "MolStructure/stereo.h"
#include "Utils/mathUtil.hpp"
#include "Utils/mfcUtil.hpp"

namespace MISS {

// Frag-Topology Analysis

struct ConnIdx {
    ConnIdx(int edgeIdx, int aIdx, int tnIdx);
    ConnIdx(ConnIdx* conn);
    ~ConnIdx() {}
    int EdgeIdx;
    int AIdx;
    int TNIdx;
    int MapUp;
};

struct FragConf {
    FragConf();
    FragConf(int natoms, int nedges, int nnodes);
    FragConf(FragConf* conf);
    ~FragConf();
    int nAtoms, nNodes, nRotSym, nEdges;
    double* xyz;
    double confE;
    Quaternion** qNodes;
    Quaternion** qEdges;
    FragConf* prevConf;
    FragConf* nextConf;
};

struct FragID {
    FragID(double rv, char* type, char* formula);
    std::string fragIDName();
    ~FragID();
    double rankvalue;
    char* formula;
    char Type[2];  // T=tree, R=ring; F=fused ring
};

struct Fragmentation {
    Fragmentation();
    ~Fragmentation();
    FragConf* firstConf;
    int nConfs, nNodes, nAtoms, nSizeA, nSizeB, LinkEdgeIdx, LinkEdgeRotFlag;
    int nEdges;  // Number of connection edges of this frag
    int IA, IB;  // Atom Index in this fragment
    int JA, JB;  // Atom Index in the sub-fragment (A and B)
    int pLevel, isTNode;
    int nodeIdxA, nodeIdxB;
    int linkNodePosA, linkNodePosB;
    int *nodeListA, *nodeListB;
    int *edgeListA, *edgeListB;
    int *NodeA2AB, *NodeB2AB;
    int *AtomA2AB, *AtomB2AB;
    int* NodeAtomAdd;
    int* NodeList;
    int* atomList;

    ConnIdx** connIdxs;

    int nVDWPairs;
    int nRGrids;
    double torsionGridEnergy[36];
    int *topDistanceA, *topDistanceB;
    double lowestConfEnergy;
    std::vector<FragConf*> confList;

    Fragmentation *FragA, *FragB;
    VdwTerm** vdwList;
};

struct TNodeConf {
    TNodeConf(int nNodes, int nEdges);
    ~TNodeConf();
    int TNIdx;
    int nTNAtoms;
    int nTNEdges;
    int TNConfIdx;
    double* xyz;
    Quaternion** qEdges;
    void* ownerTreeNode;
};

struct TreeNode {
    TreeNode(int nNodes, int nEdges);
    void addTNConf(double* xyz);
    void setTNConfRMat();  // Set Edge rotation matrices for all TNConfs
    ~TreeNode();
    int TNIdx;
    int nTNAtoms;
    int nTNEdges;
    int nACount;
    int nECount;
    int nTNConfs;
    int nTNConfMax;
    int* TNAtomList;
    int* TNEdgeList;
    double nodeWeight;
    void* ownerFrag;
    void* ownerSchFrag;
    FragConf** TNConfList;
};

struct TreeEdge {
    TreeEdge();
    ~TreeEdge();
    int TreeNode1, TreeNode2;  // TreeNode1 < TreeNode 2
    int atomIdx1, atomIdx2, linkBondIdx;
    double weight1, weight2, edgeLength;
    int nAtom1, nAtom2;
    int TEIdx;
    int rotFlag;  //
    int *branch1, *branch2;
    void* ownerFrag;
};

struct FragSchTree {
    FragSchTree();
    FragSchTree(int nTreeNodes);
    ~FragSchTree();
    int nTreeNodes, nTreeEdges;
    TreeNode** nodeList;
    TreeEdge** edgeList;
    void* ownerFrag;
};
struct Conformations {
    Conformations();
    ~Conformations();
    void addConf(double* xyz);
    std::string FragID;
    int nAtoms;
    int nConfs;
    std::vector<double*> confList;
};

class FragLib {
public:
    FragLib();
    FragLib(std::string FDFileName);
    FragLib(std::string FDFileName, std::string IdxFileName);
    ~FragLib();
    Conformations* findFragConf(FragID* fragid);
    Conformations* findFragConf(std::string fragname);
    void addFragConfLib(Conformations* confmodel);
    int status;

private:
    int nFrags;
    SDReader* fragReader;
    std::map<std::string, Conformations*> FragConfLib;
    std::map<std::string, long> FragConfIdx;
};

struct compareConfEnergy : public std::binary_function<FragConf*, FragConf*, bool> {
    bool operator()(FragConf* A, FragConf* B) { return (A->confE < B->confE); }
};

void setTNConfs(FragSchTree* schFrag);

void sortConfs(FragConf** confList, int nConfs);
FragID* genFragID(MFCFrag* Frag);
std::string genFragIDString(FragID* fragid);
FragSchTree* genFragSchTree(MFCFrag* Frag, bool InitTNConfs = true);
int TreeNodeWalker(FragSchTree* schFrag, int edgeNodeIdx, int& nTNodes, int* nodeList,
                   int* edgeList, int* edgeVisited, int& nEdges, int& nHeavy);
int walkFragSchTree(FragSchTree* schFrag, TreeNode* pNode, int level, int& nodeIdx, int* edgeVisted,
                    int& atomCount, int* atomList);
void findUniqueTNodes(FragSchTree* schFrag, std::map<std::string, int>& fragCounts,
                      std::ofstream& fragout);
void printFragmentation(Fragmentation* fraction, int level);

int findMiddleTreeEdge(FragSchTree* schFrag);

MFCFrag* findLargestFrag(MFCFrag* inFrag);

void setOrientation(double* xyz1, double* xyz2, double* xyz3, Quaternion* q);
int RecursivePartition(FragSchTree* schFrag, int* edgeVisited, int nEdges, int* edgeList,
                       int* nodeList, double weight, Fragmentation* fraction);
Fragmentation* MolFragmentation(FragSchTree* schFrag);

MFCFrag* TNodeToFrag(TreeNode* treenode, int* mapFrag2TNode, int atomSubstitution);

void setVdwTerms(MFCFrag* Frag, Fragmentation* fraction);

}  // namespace MISS

#endif /* fragment2D_h */
