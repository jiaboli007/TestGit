#ifndef fragment3D_h
#define fragment3D_h
/******************************************************************************
 *                                                                             *
 *    Function:       Define Molecular Foundation Classes                      *
 *    Category:      Foundmental classes of molecular systems                 *
 *    Author:         James Li                                                 *
 *    Date:           March, 2011                                              *
 *                                                                             *
 ******************************************************************************/
#include <fstream>
#include <functional>
#include <iostream>
#include <map>
#include <string>
#include <vector>

#include "ForceField/ffUtil.h"
#include "MolStructure/mfcAtom.h"
#include "MolStructure/mfcBond.h"
#include "MolStructure/mfcMolecule.h"
#include "MolStructure/stereo.h"
#include "Utils/mathUtil.hpp"
#include "Utils/mfcUtil.hpp"

namespace MISS {
// 3D operations
class Template3D {
public:
    Template3D(int type, int a, int b, int c, int d, int e, int f, double L1, double L2, double L3,
               double L4, double L5, double Weight);
    ~Template3D();
    void Fit2Template(double* atomxyz, double* deltaxyz, double* maxmove, int ctln, int* hFlags);

private:
    int nType;  // 1=bond, 2= angle, 3= linar, 4=planar, 5= torsion 6=chiral
    int atomIdx[6];
    double bondLength[6];
    double tempXYZ[18];
    double weight;
};
// double molVolume(MFCFrag* Frag);
// 3D Operations: Frag/Node Conf Initialization
Conformations* genFragConfs(MFCFrag* Frag);
bool setNodeConfs(FragSchTree* schFrag, FragLib* fraglib);
int setFragConfs(FragSchTree* schFrag, Fragmentation* fraction);
void debugTNodess(FragSchTree* schFrag);

// 3D Operations: check rotation symmetry
void setRotGrids(FragSchTree* schFrag, Fragmentation* fraction);
void setRotSymmetry(MFCFrag* Frag, Fragmentation* fraction, FragConf* conf, int IA, double v[3]);

// 3D Operations: Conf rotation and translation.
void TreeEdgeRotation(FragSchTree* schFrag, int edgeIdx, double angle, int flip);
void getCoordinates(FragSchTree* schFrag, double* xyz0);
void confRotation(FragConf* conf, int AnchorAIdx, Quaternion* quat);
void confRotation(FragConf* conf, int AnchorAIdx, Quaternion* quat, FragConf* confout);
void coordRotation(FragConf* conf, int AnchorAIdx, Quaternion* quat, double* xyzout);
void confTranslation(FragConf* conf, double v[3]);
void printNodeConf(FragConf* conf, Fragmentation* fraction, int nodeIdx);

// 3D Conf Search
// Option 1: Start from one initial input 3D confs.
int RecursiveConfBuild_I(FragSchTree* schFrag, Fragmentation* fraction, int nConfs, double eThresh);
// Option 2: Start from multiple initial ring conformations.
int RecursiveConfBuild_II(FragSchTree* schFrag, Fragmentation* fraction, int nConfs,
                          double eThresh);

}  // namespace MISS

#endif /* fragment3D_h */
