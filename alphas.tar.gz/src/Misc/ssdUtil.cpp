/******************************************************************************
 *                                                                             *
 *    Function:   simpleSD reader Utilities                                                *
 *    Author:     Xin Yan                                                     *
 *    Date:       May, 2012                                                  *
 *                                                                             *
 ******************************************************************************/
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <map>
#include <string>
#include <vector>

#include <boost/algorithm/string.hpp>

#include "ssdUtil.h"

#include "Singleton/params.h"
#include "Utils/mathUtil.hpp"

namespace MISS {

int getIntProperty(const std::vector<std::string>& PropertyDoc, std::string_view propName) {
    int Value = 0;
    for (std::size_t i = 0; i < PropertyDoc.size(); i++) {
        if (boost::contains(PropertyDoc[i], propName)) {
            auto tmpstr = PropertyDoc[i + 1];
            boost::replace_all(tmpstr, ",", " ");
            std::stringstream ss(tmpstr);
            ss >> Value;
            break;
        }
    }
    return Value;
}

std::vector<std::string> getStringPropertyArray(const std::vector<std::string>& PropertyDoc,
                                                std::string_view propName) {
    std::vector<std::string> array;
    // std::cout << "String Array Property = " << propName << "\n";
    for (std::size_t i = 0; i < PropertyDoc.size(); i++) {
        if (boost::contains(PropertyDoc[i], propName)) {
            auto tmpstr = PropertyDoc[i + 1];
            int j = i + 1;
            // std::cout << "Read String Array Property\n";
            do {
                tmpstr = PropertyDoc[j++];
                // std::cout << tmpstr << "\n";
                array.push_back(tmpstr);
                tmpstr = PropertyDoc[j];
            } while (!boost::contains(tmpstr, "> <") && !tmpstr.empty());
            // std::cout << "Property done \n";

            return array;
        }
    }
    return array;
}

void getPropertyIntList(const std::vector<std::string>& PropertyDoc, std::string_view propName,
                        std::vector<int>& FANumList, std::vector<int>& FAtomList) {
    int value;
    int i;
    std::string tmpstr;
    for (i = 0; i < PropertyDoc.size(); i++) {
        std::string tmpstr = PropertyDoc[i];
        if (tmpstr.find(propName) != std::string::npos) {
            i++;
            break;
        }
    }
    do {
        tmpstr = PropertyDoc[i++];
        boost::replace_all(tmpstr, ",", " ");
        std::stringstream ss(tmpstr);
        int nfnum = 0;
        while (!(ss >> value).fail()) {
            FAtomList.push_back(value);
            nfnum++;
        }
        FANumList.push_back(nfnum);

    } while (!boost::contains(tmpstr, "> <") && !tmpstr.empty());
}

simpleMolData* readSimpleSD(std::ifstream& fin) {
    PeriodicTable* xTable = PeriodicTable::Instance();
    std::string tmpstr;
    std::string fragname;
    std::string element;
    bool isV3000 = false;

    auto molData = new simpleMolData();
    int nAtoms;
    int nBonds;
    int atom1, atom2, bondType;
    /*
       int* atomicNum;
       double* xyz;
       double* vdwR;
       std::vector<std::string> PropertyDoc;
    */

    try {
        if (fin.eof()) return nullptr;
        // skip 3 lines
        if (!std::getline(fin, fragname)) return nullptr;
        if (!std::getline(fin, tmpstr)) return nullptr;
        std::getline(fin, tmpstr);

        std::getline(fin, tmpstr);
        int ipos = tmpstr.find("V3000");
        if (ipos > -1) {
            isV3000 = true;
            // std::cout << "This is V3000 format \n";
            std::getline(fin, tmpstr);
            std::getline(fin, tmpstr);
            tmpstr = tmpstr.substr(14);
            const std::string& ss = tmpstr.substr(0, tmpstr.find(' '));
            nAtoms = std::stoi(ss);
            tmpstr = tmpstr.substr(tmpstr.find(' ') + 1);
            const std::string& ss1 = tmpstr.substr(0, tmpstr.find(' '));
            nBonds = std::stoi(ss1);
        } else {
            // std::cout << "This is V2000 format \n";
            const std::string& ss = tmpstr.substr(0, 3);
            nAtoms = std::stoi(ss);
            const std::string& ss1 = tmpstr.substr(3, 3);
            nBonds = std::stoi(ss1);
        }

        molData->nAtoms = nAtoms;
        molData->nBonds = nBonds;
        if (nAtoms > 0) {
            molData->atomicNum = new int[nAtoms];
            molData->vdwR = new double[nAtoms];
            molData->xyz = new double[nAtoms * 3];
        }
        if (nBonds > 0) molData->bonds = new int[nBonds * 3];

        if (fragname == std::string("")) fragname = std::string("NONAME");
        molData->name = fragname;

        // Skip one line for V3000
        if (isV3000) std::getline(fin, tmpstr);
        for (int i = 0; i < nAtoms; i++) {
            std::getline(fin, tmpstr);
            int i3 = i * 3;
            if (isV3000) {
                // V3000 format
                std::istringstream iss(tmpstr);
                int nSkips = 3;
                for (int j = 0; j < nSkips; j++) iss >> tmpstr;
                iss >> element;
                if (element.length() == 1) {
                    element += " ";
                }
                molData->atomicNum[i] = xTable->AtomicNumber(element);
                iss >> molData->xyz[i3];
                iss >> molData->xyz[i3 + 1];
                iss >> molData->xyz[i3 + 2];
            } else {
                // V2000 format
                const std::string& ss = tmpstr.substr(0, 10);
                molData->xyz[i3] = std::stod(ss);
                const std::string& ss1 = tmpstr.substr(10, 10);
                molData->xyz[i3 + 1] = std::stod(ss1);
                const std::string& ss2 = tmpstr.substr(20, 10);
                molData->xyz[i3 + 2] = std::stod(ss2);
                molData->atomicNum[i] = xTable->AtomicNumber(tmpstr.substr(31, 3));
            }
        }

        // init connection table
        molData->adjs.resize(nAtoms);

        // Bonds
        if (isV3000) {
            std::getline(fin, tmpstr);
            std::getline(fin, tmpstr);
        }
        for (int i = 0; i < nBonds; i++) {
            std::getline(fin, tmpstr);
            //
            // Atom Index is "0" based!!
            //
            if (isV3000) {
                // V3000
                std::istringstream iss(tmpstr);
                int nSkips = 3;
                for (int i = 0; i < nSkips; i++) iss >> tmpstr;

                iss >> bondType;
                iss >> atom1;
                iss >> atom2;

                atom1--;
                atom2--;
            } else {
                // V2000
                const std::string& ss = tmpstr.substr(0, 3);
                atom1 = std::stoi(ss) - 1;
                const std::string& ss1 = tmpstr.substr(3, 3);
                atom2 = std::stoi(ss1) - 1;
                const std::string& ss2 = tmpstr.substr(6, 3);
                bondType = std::stoi(ss2);
            }
            molData->adjs[atom1].push_back(atom2);
            molData->adjs[atom2].push_back(atom1);

            int i3 = i * 3;
            molData->bonds[i3] = atom1;
            molData->bonds[i3 + 1] = atom2;
            molData->bonds[i3 + 2] = bondType;
        }
    } catch (...) {
        std::cout << "Found error in reading molecule \n";
        // skip2MolEnd
        do {
            std::getline(fin, tmpstr);
        } while (tmpstr.substr(0, 4) != std::string("$$$$") && !fin.eof());

        throw("Error found in the reading molecule \n");
        //        delete[] molData->xyz;
        //        delete[] molData->vdwR;
        //        delete[] molData->atomicNum;
        //        return NULL;
    }

    if (nAtoms < 1) {
        // Handle special cases, where there molecule is empty, i.e. nAtoms=0
        do {
            std::getline(fin, tmpstr);
        } while (tmpstr.substr(0, 4) != std::string("$$$$") && !fin.eof());
        return nullptr;
    }

    for (int i = 0; i < nAtoms; i++) {
        if (molData->atomicNum[i] == 1) {
            molData->vdwR[i] = 120;
        } else if (molData->atomicNum[i] == 6) {
            molData->vdwR[i] = 180;
        } else if (molData->atomicNum[i] == 7) {
            molData->vdwR[i] = 183;
        } else if (molData->atomicNum[i] == 8) {
            molData->vdwR[i] = 160;
        } else if (molData->atomicNum[i] == 9) {
            molData->vdwR[i] = 165;
        } else if (molData->atomicNum[i] == 16) {
            molData->vdwR[i] = 169;
        } else if (molData->atomicNum[i] == 17) {
            molData->vdwR[i] = 203;
        } else if (molData->atomicNum[i] == 35) {
            molData->vdwR[i] = 218;
        } else if (molData->atomicNum[i] == 53) {
            molData->vdwR[i] = 215;
        } else {
            // std::cout << "Unknown Atom type \n";
            molData->vdwR[i] = xTable->AtomicVDWR(molData->atomicNum[i]) * 100;
        }
    }

    // read Properties
    // skip to "M END"
    do {
        std::getline(fin, tmpstr);
    } while (tmpstr.substr(0, 6) != "M  END" && !fin.eof());

    do {
        std::getline(fin, tmpstr);
        if (tmpstr.substr(0, 4) == "$$$$") break;

        molData->PropertyDoc.push_back(tmpstr);
    } while (!fin.eof());

    return molData;
}

void writeConf2SD(simpleMolData* molData, std::ostream& fout, bool onlyHeavyAtoms) {
    PeriodicTable* xTable = PeriodicTable::Instance();
    int nAtoms = molData->nAtoms;
    int nBonds = molData->nBonds;
    int i, i3, aNum;

    if (onlyHeavyAtoms) {
        int nHAtoms = 0;
        int nRealBonds = 0;

        // new index for Heavy Atoms
        int* HAtomIdx = new int[nAtoms];
        for (i = 0; i < nAtoms; i++) HAtomIdx[i] = -1;

        for (i = 0; i < nAtoms; i++) {
            if (1 == molData->atomicNum[i]) continue;

            HAtomIdx[i] = nHAtoms;  // i is old index for heavy atom
            nHAtoms++;
        }

        // calculate the number of bonds without X-H
        for (i = 0; i < nBonds; i++) {
            i3 = i * 3;
            if (-1 == HAtomIdx[molData->bonds[i3]] || -1 == HAtomIdx[molData->bonds[i3 + 1]])
                continue;

            nRealBonds++;
        }

        fout << molData->name << "\n";
        fout << "MolData2SD\n";
        fout << "\n";
        fout << std::setw(3) << nHAtoms << std::setw(3) << nRealBonds;
        fout << std::setw(3) << 0 << std::setw(3) << 0;
        fout << std::setw(3) << 0 << "  0  0  0  0  0  0 V2000\n";

        for (i = 0; i < nAtoms; i++) {
            aNum = molData->atomicNum[i];
            if (1 == aNum) continue;

            i3 = i * 3;
            fout << std::setw(10) << std::setiosflags(std::ios::fixed) << std::setprecision(4)
                 << molData->xyz[i3];
            fout << std::setw(10) << std::setiosflags(std::ios::fixed) << std::setprecision(4)
                 << molData->xyz[i3 + 1];
            fout << std::setw(10) << std::setiosflags(std::ios::fixed) << std::setprecision(4)
                 << molData->xyz[i3 + 2];
            fout << " " << std::setw(2) << xTable->AtomicSymbol(aNum);
            fout << std::setw(3) << 0 << std::setw(3) << 0;
            fout << std::setw(3) << 0 << "  0  0" << '\n';
        }
        for (i = 0; i < nBonds; i++) {
            i3 = i * 3;
            if (-1 == HAtomIdx[molData->bonds[i3]] || -1 == HAtomIdx[molData->bonds[i3 + 1]])
                continue;

            fout << std::setw(3) << HAtomIdx[molData->bonds[i3]] + 1 << std::setw(3)
                 << HAtomIdx[molData->bonds[i3 + 1]] + 1 << std::setw(3) << molData->bonds[i3 + 2]
                 << std::setw(3) << 0 << "  0  0" << '\n';
        }

        fout << "M  END\n";

    } else {
        fout << molData->name << "\n";
        fout << "MolData2SD\n";
        fout << "\n";
        fout << std::setw(3) << molData->nAtoms << std::setw(3) << molData->nBonds;
        fout << std::setw(3) << 0 << std::setw(3) << 0;
        fout << std::setw(3) << 0 << "  0  0  0  0  0  0 V2000\n";

        for (i = 0; i < nAtoms; i++) {
            aNum = molData->atomicNum[i];
            i3 = i * 3;
            fout << std::setw(10) << std::setiosflags(std::ios::fixed) << std::setprecision(4)
                 << molData->xyz[i3];
            fout << std::setw(10) << std::setiosflags(std::ios::fixed) << std::setprecision(4)
                 << molData->xyz[i3 + 1];
            fout << std::setw(10) << std::setiosflags(std::ios::fixed) << std::setprecision(4)
                 << molData->xyz[i3 + 2];
            fout << " " << std::setw(2) << xTable->AtomicSymbol(aNum);
            fout << std::setw(3) << 0 << std::setw(3) << 0;
            fout << std::setw(3) << 0 << "  0  0" << '\n';
        }
        for (i = 0; i < nBonds; i++) {
            i3 = i * 3;
            fout << std::setw(3) << molData->bonds[i3] + 1 << std::setw(3)
                 << molData->bonds[i3 + 1] + 1 << std::setw(3) << molData->bonds[i3 + 2]
                 << std::setw(3) << 0 << "  0  0" << '\n';
        }

        fout << "M  END\n";
    }

    // properties
    int size = molData->PropertyDoc.size();
    for (i = 0; i < size; i++) {
        fout << molData->PropertyDoc[i] << "\n";
    }
}

simpleMolData* getHalfAtomsFromMol(simpleMolData* molData) {
    int i, i3, j;
    int size, idx;
    int nAtoms = molData->nAtoms;
    int* choosed = new int[nAtoms];
    std::vector<int> del;
    std::vector<int> maint;

    for (i = 0; i < nAtoms; i++) {
        choosed[i] = 0;
    }

    for (i = 0; i < nAtoms; i++) {
        if (1 == molData->atomicNum[i]) continue;
        if (0 == choosed[i]) {
            choosed[i] = 1;
            maint.push_back(i);
        } else
            continue;

        std::vector<int> atomAdj = molData->adjs[i];
        size = atomAdj.size();
        for (j = 0; j < size; j++) {
            i3 = atomAdj[j];
            if (1 == molData->atomicNum[i3] || choosed[i3] == -1) continue;

            choosed[i3] = -1;
            del.push_back(i3);
        }
    }

    int countY = maint.size();
    int countN = del.size();

    // std::cout << "countY: " << countY << "\n";
    for (i = 0; i < countY; i++) {
        // std::cout << maint[i]+1 << " ";
    }
    // std::cout << "\ncountN: " << countN << "\n";
    for (i = 0; i < countN; i++) {
        // std::cout << del[i]+1 << " ";
    }
    // std::cout << "\n";

    // output .xyz file
    /*
      PeriodicTable *xTable = PeriodicTable::Instance();
      std::ofstream fout;
      fout.open("diverse100.xyz", std::ios::app);
      fout << std::setw(3) << countY << "\n\n";
      for(i=0; i<countY; i++)
      {
        fout << std::setw(2)  << xTable->AtomicSymbol(molData->atomicNum[maint[i]]);
        fout << std::setw(10)
             << std::setiosflags(std::ios::fixed)
             << std::setprecision(4) << molData->xyz[maint[i]*3];
        fout << std::setw(10)
             << std::setiosflags(std::ios::fixed)
             << std::setprecision(4) << molData->xyz[maint[i]*3+1];
        fout << std::setw(10)
             << std::setiosflags(std::ios::fixed)
             << std::setprecision(4) << molData->xyz[maint[i]*3+2] << "\n";
      }

      fout << std::setw(3) << countN << "\n\n";
      for(i=0; i<countN; i++)
      {
        fout << std::setw(2)  << xTable->AtomicSymbol(molData->atomicNum[del[i]]);
        fout << std::setw(10)
             << std::setiosflags(std::ios::fixed)
             << std::setprecision(4) << molData->xyz[del[i]*3];
        fout << std::setw(10)
             << std::setiosflags(std::ios::fixed)
             << std::setprecision(4) << molData->xyz[del[i]*3+1];
        fout << std::setw(10)
             << std::setiosflags(std::ios::fixed)
             << std::setprecision(4) << molData->xyz[del[i]*3+2] << "\n";
      }
      fout.close();
    */
    double* trans = new double[nAtoms * 3];
    for (i = 0; i < nAtoms; i++) {
        i3 = i * 3;
        trans[i3] = 0;
        trans[i3 + 1] = 0;
        trans[i3 + 2] = 0;
    }

    int idxY, idxN;
    int idxY3, idxN3;
    int count = 0;
    for (i = 0; i < countN; i++) {
        idxN = del[i];
        idxN3 = del[i] * 3;
        std::vector<int> adj = molData->adjs[del[i]];
        size = adj.size();

        count = 0;
        for (j = 0; j < size; j++) {
            if (1 == molData->atomicNum[adj[j]]) continue;
            if (1 == choosed[adj[j]]) count++;
        }
        // std::cout << del[i]+1 << ",count: " << count << "\n";
        count = count * 2;
        for (j = 0; j < size; j++) {
            if (1 == molData->atomicNum[adj[j]]) continue;
            idxY = adj[j];
            if (1 == choosed[idxY]) {
                idxY3 = idxY * 3;
                trans[idxY3] += (molData->xyz[idxN3] - molData->xyz[idxY3]) / count;
                trans[idxY3 + 1] += (molData->xyz[idxN3 + 1] - molData->xyz[idxY3 + 1]) / count;
                trans[idxY3 + 2] += (molData->xyz[idxN3 + 2] - molData->xyz[idxY3 + 2]) / count;

                // std::cout << idxY+1 << "->" << idxN+1 << "\n";
                // std::cout << (molData->xyz[idxN3] - molData->xyz[idxY3])/count << ", " <<
                // (molData->xyz[idxN3+1] - molData->xyz[idxY3+1])/count << ", " <<
                // (molData->xyz[idxN3+2] - molData->xyz[idxY3+2])/count << "\n";
            }
        }
    }

    for (i = 0; i < nAtoms; i++) {
        if (1 != choosed[i]) continue;

        i3 = i * 3;
        // std::cout << i+1 << ": " << trans[i3] << ", " << trans[i3+1] << ", " << trans[i3+2] <<
        // "\n";
    }

    double* wt = new double[nAtoms];

    // generate halfMol
    auto halfMol = new simpleMolData();

    halfMol->nAtoms = countY;
    halfMol->atomicNum = new int[countY];
    halfMol->vdwR = new double[countY];
    halfMol->xyz = new double[countY * 3];
    for (i = 0; i < countY; i++) {
        i3 = i * 3;
        idxY = maint[i];
        idxY3 = idxY * 3;
        halfMol->xyz[i3] = molData->xyz[idxY3] + trans[idxY3];
        halfMol->xyz[i3 + 1] = molData->xyz[idxY3 + 1] + trans[idxY3 + 1];
        halfMol->xyz[i3 + 2] = molData->xyz[idxY3 + 2] + trans[idxY3 + 2];

        halfMol->atomicNum[i] = molData->atomicNum[idxY];
        halfMol->vdwR[i] = molData->vdwR[idxY];
    }

    delete[] choosed;
    delete[] trans;

    return halfMol;
}

int getNSpheres(simpleMolData* molData, bool onlyHeavyAtoms) {
    int i, i3;
    int nSpheres = molData->nAtoms;
    if (onlyHeavyAtoms) {
        i3 = 0;
        for (i = 0; i < nSpheres; i++) {
            if (1 == molData->atomicNum[i]) continue;
            i3++;
        }
        nSpheres = i3;
    }
    return nSpheres;
}

int getXYZ(simpleMolData* molData, double* xyz, bool onlyHeavyAtoms) {
    int i, i3;
    int nSpheres, nSpheres3;
    int nAtoms = molData->nAtoms;

    if (onlyHeavyAtoms) {
        nSpheres = 0;
        for (i = 0; i < nAtoms; i++) {
            if (1 == molData->atomicNum[i]) continue;
            i3 = i * 3;
            nSpheres3 = nSpheres * 3;
            xyz[nSpheres3] = molData->xyz[i3];
            xyz[nSpheres3 + 1] = molData->xyz[i3 + 1];
            xyz[nSpheres3 + 2] = molData->xyz[i3 + 2];
            nSpheres++;
        }
    } else {
        for (i = 0; i < nAtoms; i++) {
            i3 = i * 3;
            xyz[i3] = molData->xyz[i3];
            xyz[i3 + 1] = molData->xyz[i3 + 1];
            xyz[i3 + 2] = molData->xyz[i3 + 2];
        }
        nSpheres = nAtoms;
    }

    return nSpheres;
}

int getXYZVDWR(simpleMolData* molData, double* xyz, double* vdwR, bool onlyHeavyAtoms,
               bool equalR) {
    int i;
    int nSpheres = getXYZ(molData, xyz, onlyHeavyAtoms);

    if (equalR) {
        std::fill_n(vdwR, nSpheres, 2.0);
        return nSpheres;
    }

    if (onlyHeavyAtoms) {
        int nAtoms = molData->nAtoms;
        nSpheres = 0;
        for (i = 0; i < nAtoms; i++) {
            if (1 == molData->atomicNum[i]) continue;
            vdwR[nSpheres] = molData->vdwR[i] / 100;
            nSpheres++;
        }
    } else {
        for (i = 0; i < nSpheres; i++) {
            vdwR[i] = molData->vdwR[i] / 100;
        }
    }

    return nSpheres;
}

void setXYZ(simpleMolData* molData, double* xyz, bool onlyHeavyAtoms) {
    int i, i3;
    int nSpheres, nSpheres3;
    int nAtoms = molData->nAtoms;
    if (onlyHeavyAtoms) {
        nSpheres = 0;
        for (i = 0; i < nAtoms; i++) {
            if (1 == molData->atomicNum[i]) continue;
            i3 = i * 3;
            nSpheres3 = nSpheres * 3;
            molData->xyz[i3] = xyz[nSpheres3];
            molData->xyz[i3 + 1] = xyz[nSpheres3 + 1];
            molData->xyz[i3 + 2] = xyz[nSpheres3 + 2];
            nSpheres++;
        }
    } else {
        for (i = 0; i < nAtoms; i++) {
            i3 = i * 3;
            molData->xyz[i3] = xyz[i3];
            molData->xyz[i3 + 1] = xyz[i3 + 1];
            molData->xyz[i3 + 2] = xyz[i3 + 2];
        }
    }
}

}  // namespace MISS
