#ifndef ssdUtil_h
#define ssdUtil_h
/******************************************************************************
 *                                                                             *
 *    Function:   simpleSD reader Utilities                                                *
 *    Author:     Xin Yan                                                     *
 *    Date:       May, 2012                                                  *
 *                                                                             *
 ******************************************************************************/
#include <fstream>
#include <functional>
#include <iostream>
#include <map>
#include <string>
#include <string_view>
#include <vector>

namespace MISS {

struct simpleMolData {
    ~simpleMolData() {
        delete[] atomicNum;
        delete[] xyz;
        delete[] vdwR;
        if (nBonds > 0) delete[] bonds;
    }
    std::string name;
    int nAtoms;
    int nBonds;
    int* atomicNum;
    int* bonds;
    double* xyz;
    double* vdwR;
    std::vector<std::string> PropertyDoc;
    std::vector<std::vector<int> > adjs;
};

int getIntProperty(const std::vector<std::string>& PropertyDoc, std::string_view propName);
std::vector<std::string> getStringPropertyArray(const std::vector<std::string>& PropertyDoc,
                                                std::string_view propName);
void getPropertyIntList(const std::vector<std::string>& PropertyDoc, std::string_view propName,
                        std::vector<int>& FANumList, std::vector<int>& FAtomList);

simpleMolData* readSimpleSD(std::ifstream& fin);
void writeConf2SD(simpleMolData* molData, std::ostream& fout, bool onlyHeavyAtoms = false);
simpleMolData* getHalfAtomsFromMol(simpleMolData* molData);

int getNSpheres(simpleMolData* molData, bool onlyHeavyAtoms);
int getXYZ(simpleMolData* molData, double* xyz, bool onlyHeavyAtoms);
int getXYZVDWR(simpleMolData* molData, double* xyz, double* vdwR, bool onlyHeavyAtoms,
               bool equalR = false);
void setXYZ(simpleMolData* molData, double* xyz, bool onlyHeavyAtoms);

}  // namespace MISS

#endif /*ssdUtil.h*/
