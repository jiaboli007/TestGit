#ifndef canonutil_h
#define canonutil_h
/******************************************************************************
 *                                                                             *
 *    Category:   Molecule Foundation Classes                                  *
 *    Function:   Implementation of canonicalization utilities                 *
 *    Author:     James Li                                                     *
 *    Date:       March 2011                                                   *
 *                                                                             *
 ******************************************************************************/
#include "Misc/fragment2D.h"

namespace MISS {
// Recusive normalization of a real number
// If x is negative, flip it to the positive number
// If x is greater than 1, reduce it by half, and so on until it is less
// than 1.
double xscale(double x);

// Full ranking of a fragment and return the canonical order of atoms in map
double fullRanking(MFCFrag* Frag, int* map);
void TopoAtomTyping(MFCFrag* Frag, int RankLevel);

// The smallest ring size of an atom
int smallestRingSize(MFCAtom* AtomA);

}  // namespace MISS
#endif /* canonutil_h */
