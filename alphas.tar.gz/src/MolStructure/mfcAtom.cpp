/******************************************************************************
 *    Description: Implementation of Molecular Foundation Classes              *
 *                                                                             *
 *    Author:      James Li                                                    *
 *                                                                             *
 *    Date:        March 2011                                                  *
 *                                                                             *
 ******************************************************************************/

#include "mfcAtom.h"

#include "stereo.h"

namespace MISS {

MFCAtom::MFCAtom(int Idx, int atomNum) {
    AIdx = Idx;
    atomicNumber = atomNum;
//    treeNodeIdx = -1;
//    fusedRingIdx = -1;
}

MFCAtom::MFCAtom(const MFCAtom &srcObj)
    : bondList(srcObj.bondList), atomList(srcObj.atomList), RankedValues(srcObj.RankedValues) {
    atomicNumber = srcObj.atomicNumber;
    massDiff = srcObj.massDiff;
    nH = srcObj.nH;
    AIdx = srcObj.AIdx;
    hybride = srcObj.hybride;
//    isTreeEdgeAtom = srcObj.isTreeEdgeAtom;
    stereoGenic = srcObj.stereoGenic;
    stereoParity = srcObj.stereoParity;
    // treeNodeIdx    = srcObj.treeNodeIdx;
    // fusedRingIdx   = srcObj.fusedRingIdx;
    nBonds = srcObj.nBonds;
    ringAtomFlag = srcObj.ringAtomFlag;
    aromaticFlag = srcObj.aromaticFlag;
    genFlag = srcObj.genFlag;
    freeValence = srcObj.freeValence;
    stereoParity = -1;  // Not defined at this moment, depending on atom order
//    fusedRingIdx = -1;  // Not defined at this moment.
    mdlChargeFlag = srcObj.mdlChargeFlag;
    charge = srcObj.charge;
    RankValue = srcObj.RankValue;
    x = srcObj.x;
    y = srcObj.y;
    z = srcObj.z;
    FormalCharge = srcObj.FormalCharge;
    vdwR = srcObj.vdwR;
    vdwE = srcObj.vdwE;
    ownerFrag = nullptr;
    if (srcObj.chiralStruct != nullptr) {
        chiralStruct = new TChirality(*(srcObj.chiralStruct));
    } else {
        chiralStruct = nullptr;
    }
    /*
    for (int i=0; i < srcObj.nBonds; i++) {
        atomList.push_back(srcObj.atomList[i]);
        bondList.push_back(srcObj.bondList[i]);
    }
    */
}

MFCAtom::~MFCAtom() { delete chiralStruct; }

}  // namespace MISS
