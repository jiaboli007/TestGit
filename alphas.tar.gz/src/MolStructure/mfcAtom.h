#ifndef mfcAtom_h
#define mfcAtom_h
/******************************************************************************
 *                                                                             *
 *    Category:   Molecule Foundation Classes (MFC)                            *
 *    Function:   Define Atom Classes                                          *
 *    Author:     James Li                                                     *
 *    Date:       March, 2011                                                  *
 *                                                                             *
 ******************************************************************************/
#include <vector>

#include "stereo.h"

namespace MISS {

class MFCAtom {
public:
    MFCAtom(int Idx, int atomNum);
    MFCAtom(const MFCAtom& AtomObj);
    ~MFCAtom();
    int atomicNumber;
    int massDiff{};
    int nH{};    // Number of hydrogen atoms bonded to this atom.
    int AIdx;  // Atom index in a molecule
    int hybride{};
//    int isTreeEdgeAtom{};
    int stereoGenic{};  // MFC convention: 0 = not stereo
                      //                1 = absolute chiral center
                      //                2 = ring cis-trans center
                      //                3 = chiral spiro center
                      //                4 = relative chiral center
                      //                5 = relative ring cis-trans center
                      //                6 = relative spiro center
//    int treeNodeIdx{};
//    int fusedRingIdx;
    int nBonds{};
    int ringAtomFlag{};
    int aromaticFlag{};
    int genFlag{};
    int freeValence{};     //  only if (cFlag == 4) freeValence = 1;  // Radical
//    int stereoRanked{};
    int stereoUnknown{};  // Used in enumerate stereo isomers
    int stereoParity{};   // MDL convention: 0=not stereo
                        //                 1=odd parity
                        //                 2=even parity
                        //                 3=either parity
                        //                 4=stereo (1,2 or 3)
                        //                   the chirality is specified by
                        //                   chiralStruct.
    int mdlChargeFlag{};  // MDL formal charge flag.
                        // Formal Charge = MDLChargeFlag-4.
    std::vector<int> bondList;
    std::vector<int> atomList;
    TChirality* chiralStruct{};
    // Absolute definition of 3D orientation of
    // neighbor atoms for a tetrahedral center,
    // even for a non-stereo center
    double x{}, y{}, z{};                    // Atom position
    double charge{};                     // Atomic point charge
    double FormalCharge{};               // MFC formal charge. in -NO2, O has formal charge -0.5.
    double vdwR{}, vdwE{};                 // VDW parameters.
    double RankValue{};                  // A value for canonicalization. Not used Now
    std::vector<double> RankedValues;  // Ranked values from 0 to level n

    void* ownerFrag{};  // Hold the pointer for the parent MFCFrag.

    // lixm.property defined for "topology.cpp".begin.

    // int atomMark;//0:unmark; 1:mark;
    int chargeC();
    // lixm.property defined for "topology.cpp".end.
};

enum MFC_AtomHybrideType {
    MFC_S_HYBRID,
    MFC_P_HYBRID,
    MFC_SP_HYBRID,
    MFC_SP2_HYBRID,
    MFC_SP3_HYBRID,
    MFC_OTHER_HYBRID,
    MFC_NO_HYBRID
};

}  // namespace MISS

#endif /* mfcAtom_h */
