/******************************************************************************
 *    Description: Implementation of Molecular Foundation Classes              *
 *                                                                             *
 *    Author:      James Li                                                    *
 *                                                                             *
 *    Date:        March 2011                                                  *
 *                                                                             *
 ******************************************************************************/

#include <iostream>

#include "mfcBond.h"

namespace MISS {

MFCBond::MFCBond(int atomA, int atomB, int bondorder, int Idx) {
    if (atomA > atomB) {
        atom1 = atomB;
        atom2 = atomA;
    } else {
        atom1 = atomA;
        atom2 = atomB;
    }

    bondOrder = bondorder;
    BIdx = Idx;
    if (bondorder == 100)
        bondType = 1;
    else if (bondorder == 200)
        bondType = 2;
    else if (bondorder == 300)
        bondType = 3;
    else if (bondorder == 400)
        bondType = 4;  // Aromatic bond type
    else if (bondorder == 500)
        bondType = 5;  // Aromatic bond type
    else if (bondorder == 600)
        bondType = 6;  // Aromatic bond type
    else {
        std::cout << "bondorder = " << bondorder << "\n";
        std::cout << "unknown type \n";
    }
    ctFlag = nullptr;
}

MFCBond::MFCBond(const MFCBond &srcObj) {
    atom1 = srcObj.atom1;
    atom2 = srcObj.atom2;
    BIdx = srcObj.BIdx;
    ringBondFlag = srcObj.ringBondFlag;
    idealBondLength = srcObj.idealBondLength;
    aromaticFlag = srcObj.aromaticFlag;
    bondStereo = -1;     // Need resigned
    bondDirection = -1;  // need resigned. srcObj.bondDirection;
    bondType = srcObj.bondType;
    bondOrder = srcObj.bondOrder;
    if (srcObj.ctFlag != nullptr) {
        ctFlag = new CTFlag(*(srcObj.ctFlag));
    } else {
        ctFlag = nullptr;
    }
}

MFCBond::~MFCBond() { delete ctFlag; }

}  // namespace MISS
