#ifndef mfcBond_h
#define mfcBond_h
/******************************************************************************
 *                                                                             *
 *    Category:   Molecule Foundation Classes (MFC)                            *
 *    Function:   Define Bond Classes                                          *
 *    Author:     James Li                                                     *
 *    Date:       March, 2011                                                  *
 *                                                                             *
 ******************************************************************************/
#include <vector>

#include "stereo.h"

#define BOND_CUT 10000

namespace MISS {

class MFCBond {
public:
    MFCBond(int atomA, int atomB, int bondorder, int Idx);
    MFCBond(const MFCBond& BondObj);
    ~MFCBond();
    int atom1, atom2;  // Two bonding atoms. atom1 < atom2
    int genFlag{};       // Flag for general purpose
    int BIdx;          // Bond index in a molecule
    int ringBondFlag{};
    int aromaticFlag{};
    int bondStereo{};
    int ctRanked{};       // Flag for cis-trans ranking.
    int ctUnknown{};      // Unknown cis-trans flag used in enumerate stereo
                        // isomers
    int bondDirection{};  // 0 = not stereo for single bond or use xyz for double
                        // 1 = up (atom2 relative to atom1)
                        // 6 = down
                        // 4 = either up or down
                        // 3 = either cis or trans for a double bond
    int bondType;       // single (1),
                        // double (2),
                        // triple (3),
                        // aromatic (4),
                        // one-and-half (5),
                        // two-and-half(6) ...
    //   Bond Type should be canonicalized, i.e. the bond type should be always
    //   the same independent how the molecule is represented. Equivalent bond
    //   should have the same bond type. For instance, -NO2, the two NO bond
    //   should be equal. However, the bond orders can be single and double.

    int bondOrder;  // 100, 200, 300, 150, 250, ....
                    // (may not canonicalized, such as in Kekule structures)
    double idealBondLength{};
    CTFlag* ctFlag;   // Using a CTFlag to describe the cis-trans state.
    void* ownerFrag{};  // Pointer for parent fragment.

    // lixm.property defined for "topology.cpp".begin.

    // int bondMark;//0:unmark; 1:mark;
    int getadjatomidx(int atom_idx);  // return adjacent atom idx;
    // lixm.property defined for "topology.cpp".end.
};

enum MFC_BondType {
    MFC_SINGLE = 1,
    MFC_DOUBLE,
    MFC_TRIPLE,
    MFC_AROMATIC,
    MFC_ONE_AND_HALF,
    MFC_TWO_AND_HALF
};

}  // namespace MISS

#endif /* mfcBond_h */
