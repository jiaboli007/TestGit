/******************************************************************************
 *    Description: Implementation of Molecular Foundation Classes              *
 *                                                                             *
 *    Author:      James Li                                                    *
 *                                                                             *
 *    Date:        March 2011                                                  *
 *                                                                             *
 ******************************************************************************/

#include <algorithm>
#include <iostream>

#include <boost/algorithm/string.hpp>
#include <boost/range/algorithm.hpp>
#include <boost/utility.hpp>

#include "mfcMolecule.h"

#include "Topology/topology.h"
#include "Utils/dfs.h"
#include "canonUtil.h"
#include "stereo.h"
using namespace std;

namespace MISS {

int MolProperties::getIntProperty(const string &propName) {
    int Value = 0;
    for (std::size_t i = 0; i < PropertyDoc.size(); i++) {
        if (boost::contains(PropertyDoc[i], propName)) {
            auto tmpstr = PropertyDoc[i + 1];
            boost::replace_all(tmpstr, ",", " ");
            std::stringstream ss(tmpstr);
            ss >> Value;
            break;
        }
    }
    return Value;
}

double MolProperties::getRealProperty(const string &propName) {
    double Value = 0;
    return Value;
}

std::vector<int> MolProperties::getIntPropertyArray(const string &propName) {
    std::vector<int> array;
    return array;
}

std::vector<double> MolProperties::getRealPropertyArray(const string &propName) {
    std::vector<double> array;
    return array;
}

std::vector<std::string> MolProperties::getStringPropertyArray(const string &propName) {
    std::vector<std::string> array;
    for (std::size_t i = 0; i < PropertyDoc.size(); i++) {
        if (boost::contains(PropertyDoc[i], propName)) {
            auto tmpstr = PropertyDoc[i + 1];
            auto j = i + 1;
            do {
                tmpstr = PropertyDoc[j++];
                array.push_back(tmpstr);
                tmpstr = PropertyDoc[j];
            } while (!boost::contains(tmpstr, "> <") && !tmpstr.empty());

            return array;
        }
    }
    return array;
}

void MolProperties::getPropertyIntList(const string &propName, std::vector<int> &FANumList,
                                       std::vector<int> &FAatomList) {
    std::size_t i;
    for (i = 0; i < PropertyDoc.size(); i++) {
        if (boost::contains(PropertyDoc[i], propName)) {
            i++;
            break;
        }
    }
    std::string tmpstr;
    do {
        tmpstr = PropertyDoc[i++];
        boost::replace_all(tmpstr, ",", " ");
        std::stringstream ss(tmpstr);
        int nfnum = 0;
        int value;
        while (!(ss >> value).fail()) {
            FAatomList.push_back(value);
            nfnum++;
        }
        FANumList.push_back(nfnum);

    } while (!boost::contains(tmpstr, "> <") && !tmpstr.empty());
}

int MFCFrag::setUnknownStereoCenters() {
    int ucenters = 0;
    int ubonds = 0;
    int uatoms = 0;

    MFCAtom *Atom;
    MFCBond *Bond;

    for (int i = 0; i < numAtoms; i++) {
        Atom = atomList[i];
        if (Atom->stereoParity == 3) {
            Atom->stereoUnknown = 1;
            ucenters++;
            uatoms++;
        }
    }
    for (int i = 0; i < numBonds; i++) {
        Bond = bondList[i];
        if (Bond->ctFlag && Bond->ctFlag->cisTransUnknownFlag() == 1) {
            Bond->ctUnknown = 1;
            ucenters++;
            ubonds++;
        }
    }
    std::cout << "uatoms = " << uatoms << "\n";
    std::cout << "ubonds = " << ubonds << "\n";

    return ucenters;
}

void MFCFrag::setStereoFlags(int isomerID) {
    int tmp = isomerID;
    int flag;
    int Sign;
    MFCAtom *Atom;
    MFCBond *Bond;

    for (int i = 0; i < numAtoms; i++) {
        Atom = atomList[i];
        if (Atom->stereoUnknown == 1) {
            flag = tmp / 2;
            flag = tmp - flag * 2;
            tmp = tmp / 2;
            if (flag == 0)
                Sign = 1;
            else
                Sign = -1;
            Atom->stereoParity = 4;
            Atom->chiralStruct->setSign(Sign);
        }
    }
    for (int i = 0; i < numBonds; i++) {
        Bond = bondList[i];
        if (Bond->ctFlag && Bond->ctUnknown == 1) {
            flag = tmp / 2;
            flag = tmp - flag * 2;
            tmp = tmp / 2;
            if (flag == 0)
                Sign = 1;
            else
                Sign = -1;
            Bond->ctFlag->setCTFlag(Sign);
        }
    }
}
void MFCFrag::setMolPro(MolProperties *molP) { molPro = molP; }

MolProperties *MFCFrag::getMolPro() { return molPro; }
void MFCFrag::resetUnknownStereoFlags() {
    MFCAtom *Atom;
    MFCBond *Bond;
    for (int i = 0; i < numAtoms; i++) {
        Atom = atomList[i];
        if (Atom->stereoUnknown == 1) {
            Atom->stereoParity = 3;
            Atom->chiralStruct->setSign(0);
        }
    }
    for (int i = 0; i < numBonds; i++) {
        Bond = bondList[i];
        if (Bond->ctFlag && Bond->ctUnknown == 1) {
            Bond->ctFlag->setCTFlag(0);
        }
    }
}

MFCFrag::MFCFrag(int nAtoms, int nBonds, std::string fragName) : fragname(std::move(fragName)) {
    numAtoms = nAtoms;
    numBonds = nBonds;
    numRings = nBonds - nAtoms + 1;
}

void MFCFrag::copyInit(const MFCFrag &src) {
    numAtoms = src.numAtoms;
    numBonds = src.numBonds;
    numRings = src.numRings;
    ringCount = src.ringCount;
    stereoFlag = src.stereoFlag;
    TopDistance = nullptr;
    RotEdgeFlag = nullptr;
    fraction = nullptr;
    molPro = new MolProperties(*src.molPro);
    fragProp = src.fragProp;
    fragname = src.fragname;

    atomList.reserve(src.atomList.size());
    for (std::size_t i = 0; i < src.atomList.size(); i++)
        atomList.push_back(src.atomList[i] ? new MFCAtom(*src.atomList[i]) : nullptr);
    bondList.reserve(src.bondList.size());
    for (std::size_t i = 0; i < src.bondList.size(); i++)
        bondList.push_back(src.bondList[i] ? new MFCBond(*src.bondList[i]) : nullptr);
    ringList.reserve(src.ringList.size());
    for (std::size_t i = 0; i < src.ringList.size(); i++)
        ringList.push_back(src.ringList[i] ? new MFCRing(*src.ringList[i]) : nullptr);
}

MFCFrag::~MFCFrag() { dtor(); }

void MFCFrag::dtor() {
    boost::for_each(atomList, boost::checked_deleter<MFCAtom>{});
    boost::for_each(bondList, boost::checked_deleter<MFCBond>{});
    boost::for_each(ringList, boost::checked_deleter<MFCRing>{});
    boost::checked_array_delete(TopDistance);
    boost::checked_array_delete(RotEdgeFlag);
    boost::checked_delete(molPro);
}

//
// Calculate the rough estimation of a group size around an atom.
// Then, a general ranking algorithm is applied for all atoms in the Frag.
// The Ranking value of an atom is between 0 and 1.0. The group size is an
// Integer.
// The final ranking value is obtained as groupSize+generalRankingValue. Since
// the groupSize is the largest portion of the final ranking value,
// therefore the final ranking value is also rough in the order of group size.
//
void MFCFrag::addAtomSizeToRanking() {
    int IRankValue = 0, otherAtomIdx = 0;
    MFCBond *Bond;
    MFCAtom *Atom;
    MFCAtom *otherAtom;
    for (int i = 0; i < numAtoms; i++) {
        IRankValue = 0;
        Atom = atomList[i];
        for (int j = 0; j < Atom->nBonds; j++) {
            Bond = bondList[Atom->bondList[j]];
            otherAtomIdx = findOtherBondAtom(Bond, Atom->AIdx);
            otherAtom = atomList[otherAtomIdx];
            IRankValue++;
            if (otherAtom->atomicNumber > 1) IRankValue++;
        }
        Atom->RankValue = IRankValue;
    }
}

void MFCFrag::removeAtom(int AId) {
    int i, bid;
    while (!atomList[AId]->bondList.empty()) {
        bid = atomList[AId]->bondList.back();
        removeBond(bid);
    }
    delete atomList[AId];
    atomList[AId] = nullptr;
    numAtoms--;
}

void MFCFrag::removeBond(int BId) {
    if (bondList[BId]->bondType == 4) bondList[BId]->bondType = 1;
    int a1 = bondList[BId]->atom1, a2 = bondList[BId]->atom2;
    atomList[a1]->atomList.erase(
        find(atomList[a1]->atomList.begin(), atomList[a1]->atomList.end(), a2));
    atomList[a1]->bondList.erase(
        find(atomList[a1]->bondList.begin(), atomList[a1]->bondList.end(), BId));
    atomList[a1]->nBonds--;
    if (atomList[a2]->atomicNumber != 1 && atomList[a1]->atomicNumber != 1)
        atomList[a1]->nH += bondList[BId]->bondType;
    atomList[a2]->atomList.erase(
        find(atomList[a2]->atomList.begin(), atomList[a2]->atomList.end(), a1));
    atomList[a2]->bondList.erase(
        find(atomList[a2]->bondList.begin(), atomList[a2]->bondList.end(), BId));
    atomList[a2]->nBonds--;
    if (atomList[a1]->atomicNumber != 1 && atomList[a2]->atomicNumber != 1)
        atomList[a2]->nH += bondList[BId]->bondType;
    delete bondList[BId];
    bondList[BId] = nullptr;
    numBonds--;
}

void MFCFrag::updateBondType(int BId) {
    MFCBond &bond = *bondList[BId];
    int bond_type = 1;
    if (bond.ringBondFlag) {
        vector<int>::iterator it;
        for (it = atomList[bond.atom1]->bondList.begin();
             it != atomList[bond.atom1]->bondList.end(); ++it)
            if (bondList[*it]->ringBondFlag && bondList[*it]->bondType != 4) {
                bond_type = 2;
                break;
            }
    }
    bond.bondType = bond_type;
    bond.bondOrder = 100 * bond_type;
}

void MFCFrag::updateAtomAromaticFlag(int AId) {
    MFCAtom &atom = *atomList[AId];
    vector<int>::iterator it;
    for (it = atom.bondList.begin(); it != atom.bondList.end() && bondList[*it]->aromaticFlag == 0;
         ++it)
        ;
    atom.aromaticFlag = (it != atom.bondList.end());
}

void MFCFrag::removeAtomsOnRing(int RId, vector<int> &atoms) {
    std::size_t i, j;
    MFCRing &ring = *ringList[RId];
    for (i = 0; i < atoms.size(); i++) removeAtom(atoms[i]);
    ringList[RId] = nullptr;
    vector<int> ringBondList;
    for (i = 0; i < ring.ringAtomList.size(); i++) {
        MFCAtom *a1 = atomList[ring.ringAtomList[i]];
        if (a1 == nullptr) continue;
        for (j = i + 1; j < ring.ringAtomList.size(); j++) {
            if (atomList[ring.ringAtomList[j]] == nullptr) continue;
            auto it = find(a1->atomList.begin(), a1->atomList.end(), ring.ringAtomList[j]);
            if (it != a1->atomList.end())
                ringBondList.push_back(a1->bondList.begin()[it - a1->atomList.begin()]);
        }
    }
    for (i = 0; i < ringBondList.size(); i++) {
        setRingBondFlags(this, ringBondList[i]);
        MFCBond &bond = *bondList[ringBondList[i]];
        if (ring.aromaticity && bond.aromaticFlag == 0) {
            updateBondType(bond.BIdx);
            updateAtomAromaticFlag(bond.atom1);
            updateAtomAromaticFlag(bond.atom2);
        }
    }
    delete &ring;
    ringCount = --numRings;
}

// AId is the index of the first atom connected to the ring
void MFCFrag::removeOneBranch(int AId) {
    OnBranch search_condition;
    DeleteAtom search_operation;
    NullOperation nop;
    dfs(*this, AId, search_condition, search_operation, nop);
}

// this function takes the premise that H is expressed implicitly
void MFCFrag::addBond(MFCBond &bond)  // no new ring
{
    bond.BIdx = static_cast<int>(bondList.size());
    bondList.push_back(&bond);
    MFCAtom &a1 = *atomList[bond.atom1], a2 = *atomList[bond.atom2];
    a1.atomList.push_back(bond.atom2);
    a1.bondList.push_back(bond.BIdx);
    a1.nH--;
    a2.atomList.push_back(bond.atom1);
    a2.atomList.push_back(bond.BIdx);
    a2.nH--;
    numBonds++;
}

// call after the two atoms have been added to this frag
void MFCFrag::insertBond(MFCBond &bond, int loc)  // no new ring
{
    // update bond idx in bondList of atoms
    for (auto atom : atomList) {
        if (atom == nullptr) continue;
        for (int &it : atom->bondList)
            if (it >= loc) it += 1;
    }

    // insert bond
    bond.BIdx = loc;
    bondList.insert(bondList.begin() + loc, &bond);
    MFCAtom &a1 = *atomList[bond.atom1], a2 = *atomList[bond.atom2];
    a1.atomList.push_back(bond.atom2);
    a1.bondList.push_back(bond.BIdx);
    a1.nH--;
    a2.atomList.push_back(bond.atom1);
    a2.atomList.push_back(bond.BIdx);
    a2.nH--;
    numBonds++;

    // update bond idx
    for (auto i = loc + 1; i < bondList.size(); i++) {
        MFCBond *b = bondList[i];
        if (b == nullptr) continue;
        b->BIdx += 1;
    }
}

void MFCFrag::compress() {
    vector<int> atomIdc, bondIdc, ringIdc;
    indice_after_compress(atomList, atomIdc);
    indice_after_compress(bondList, bondIdc);
    indice_after_compress(ringList, ringIdc);
    vector<int>::iterator it;
    for (std::size_t i = 0; i < atomList.size(); i++) {
        MFCAtom *atom = atomList[i];
        if (atom == nullptr) continue;
        atom->AIdx = atomIdc[atom->AIdx];
        for (it = atom->atomList.begin(); it != atom->atomList.end(); ++it) *it = atomIdc[*it];
        for (it = atom->bondList.begin(); it != atom->bondList.end(); ++it) *it = bondIdc[*it];
        atomList[atomIdc[i]] = atom;
    }
    for (std::size_t i = 0; i < bondList.size(); i++) {
        MFCBond *bond = bondList[i];
        if (bond == nullptr) continue;
        bond->BIdx = bondIdc[bond->BIdx];
        bond->atom1 = atomIdc[bond->atom1];
        bond->atom2 = atomIdc[bond->atom2];
        bondList[bondIdc[i]] = bond;
    }
    for (std::size_t i = 0; i < ringList.size(); i++) {
        MFCRing *ring = ringList[i];
        if (ring == nullptr) continue;
        ring->RIdx = ringIdc[ring->RIdx];
        for (it = ring->ringAtomList.begin(); it != ring->ringAtomList.end(); ++it)
            *it = atomIdc[*it];
        ringList[ringIdc[i]] = ring;
    }
    atomList.erase(atomList.begin() + numAtoms, atomList.end());
    bondList.erase(bondList.begin() + numBonds, bondList.end());
    ringList.erase(ringList.begin() + numRings, ringList.end());
}

//
// Post process: add H to mol
//
void MFCFrag::add_hydrogens() {
    int nHAtoms = numAtoms;
    int nHBonds = numBonds;
    for (int i = 0; i < numAtoms; i++) {
        auto Atom1 = atomList[i];
        int MissH = gAtomValence(Atom1) - gAtomTotalBondOrder(Atom1) - Atom1->freeValence +
                    (int)(Atom1->FormalCharge * 1.0000001);
        for (int j = 0; j < MissH; j++) {
            // Add H
            auto Atom2 = new MFCAtom(nHAtoms, 1);
            Atom2->ownerFrag = this;
            atomList.push_back(Atom2);
            // Add X-H bond
            auto atom1 = i;
            auto atom2 = nHAtoms;
            auto Bond = new MFCBond(atom1, atom2, 100, nHBonds);
            Bond->bondDirection = 0;

            bondList.push_back(Bond);

            Atom1->atomList.push_back(atom2);
            Atom2->atomList.push_back(atom1);
            Atom1->bondList.push_back(nHBonds);
            Atom2->bondList.push_back(nHBonds);

            Atom1->genFlag++;
            Atom2->genFlag++;
            Atom1->nBonds++;
            Atom2->nBonds++;
            nHAtoms++;
            nHBonds++;
        }
    }
    numAtoms = nHAtoms;
    numBonds = nHBonds;
}

//
// Set chirality by stereo parity
//
void MFCFrag::set_chirality() {
    for (int i = 0; i < numAtoms; i++) {
        auto Atom = atomList[i];
        // std::cout << "i, atom, stereoParity = " << i << " " << Atom->atomicNumber << " " <<
        // Atom->stereoParity << "\n";
        int Sign = 0;
        if (Atom->stereoParity == 1) Sign = 1;
        if (Atom->stereoParity == 2) Sign = -1;
        if (Sign != 0) {
            // Set chiralStruct by atom parity
            vector<int> atomList;
            if (Atom->nBonds < 3) {
                cout << "Error on atom i = " << i << "\n";
                throw "Exception 16";
            }
            for (int j = 0; j < Atom->nBonds; j++) {
                atomList.push_back(Atom->atomList[j]);
            }
            sort(atomList.begin(), atomList.end());
            auto a1 = atomList[0];
            auto a2 = atomList[1];
            auto a3 = atomList[2];
            if (Atom->nBonds == 4) {
                auto a4 = atomList[3];
                delete Atom->chiralStruct;
                Atom->chiralStruct = new TChirality(Sign, a1, a2, a3, a4);
            } else {
                delete Atom->chiralStruct;
                Atom->chiralStruct = new TChirality(Sign, a1, a2, a3);
            }
        } else if (Atom->stereoParity == 3) {
            if (Atom->nBonds < 3) {
                cout << "Error in SD file \n";
            }
            vector<int> atomList;
            for (int j = 0; j < Atom->nBonds; j++) {
                atomList.push_back(Atom->atomList[j]);
            }
            auto a1 = atomList[0];
            auto a2 = atomList[1];
            auto a3 = atomList[2];
            if (Atom->nBonds == 4) {
                auto a4 = atomList[3];
                delete Atom->chiralStruct;
                Atom->chiralStruct = new TChirality(0, a1, a2, a3, a4);
            } else {
                delete Atom->chiralStruct;
                Atom->chiralStruct = new TChirality(0, a1, a2, a3);
            }
            // std::cout << "Unknown chiral center created here\n";
        }
    }
}

void MFCFrag::set_parity(bool isFlat) {
    constexpr double eps = 1.0E-10;
    double zold = 0;
    double v1[3], v2[3], v3[3];
    auto nAtoms = numAtoms;
    for (int i = 0; i < nAtoms; i++) {
        auto Atom = atomList[i];
        if (Atom->nBonds < 3) Atom->stereoParity = 0;
        int va[4] = {-1, -1, -1, -1};
        if (isFlat && Atom->stereoParity == 4) {
            {
                //
                // Search for bond direction flag
                //
                int nca = 0;
                for (int j = 0; j < Atom->nBonds; j++) {
                    auto Bond = bondList[Atom->bondList[j]];
                    if (Bond->bondDirection == 1) {
                        if (Bond->atom1 == Atom->AIdx) {
                            va[0] = Bond->atom2;
                        } else {
                            va[0] = Bond->atom1;
                        }
                        auto Atom1 = atomList[va[0]];
                        zold = Atom1->z;
                        Atom1->z += 1.0;
                    } else if (Bond->bondDirection == 6) {
                        if (Bond->atom1 == Atom->AIdx) {
                            va[0] = Bond->atom2;
                        } else {
                            va[0] = Bond->atom1;
                        }
                        auto Atom1 = atomList[va[0]];
                        zold = Atom1->z;
                        Atom1->z -= 1.0;
                    } else if (Bond->bondDirection == 4) {
                        // Skip it, as the stereoparity is set by the previous
                        // code for processing bonds
                    }
                    if (va[0] > -1) break;
                }
                if (va[0] == -1) break;
                nca = 1;
                for (int j = 0; j < Atom->nBonds; j++) {
                    if (Atom->atomList[j] != va[0]) {
                        va[nca++] = Atom->atomList[j];
                    }
                }
                auto Atom1 = atomList[va[0]];
                auto Atom2 = atomList[va[1]];
                auto Atom3 = atomList[va[2]];
                v1[0] = Atom1->x - Atom->x;
                v1[1] = Atom1->y - Atom->y;
                v1[2] = Atom1->z - Atom->z;
                v2[0] = Atom2->x - Atom->x;
                v2[1] = Atom2->y - Atom->y;
                v2[2] = Atom2->z - Atom->z;
                v3[0] = Atom3->x - Atom->x;
                v3[1] = Atom3->y - Atom->y;
                v3[2] = Atom3->z - Atom->z;

                double testv = vectorVolume(v1, v2, v3);

                // July 10 2008 Bug Fix: chiral convention consistancy from vectorVolume and
                // stereoParity
                //
                // It can be considerated as the Steering wheel convention. August 2, 2008.
                //

                if (vectorVolume(v1, v2, v3) < eps) {
                    delete Atom->chiralStruct;
                    Atom->chiralStruct = new TChirality(1, va[0], va[1], va[2], va[3]);
                } else if (vectorVolume(v1, v2, v3) > -eps) {
                    delete Atom->chiralStruct;
                    Atom->chiralStruct = new TChirality(1, va[1], va[0], va[2], va[3]);
                } else {
                    delete Atom->chiralStruct;
                    Atom->chiralStruct = new TChirality(0, va[0], va[1], va[2], va[3]);
                }
                // Reset the original value
                Atom1->z = zold;
            }
        }
        if (isFlat && Atom->stereoParity == 3) {
            delete Atom->chiralStruct;
            Atom->chiralStruct = new TChirality(0, va[0], va[1], va[2], va[3]);
        }
        if (isFlat && Atom->stereoParity == 0 && Atom->nBonds > 3) {
            delete Atom->chiralStruct;
            Atom->chiralStruct = new TChirality(0, va[0], va[1], va[2], va[3]);
        }
    }
}

void MFCFrag::set_stereo(bool threeD2chiral, bool threeD2cistrans, bool isFlat) {
    // Optionally set stereo configuration by initial structure
    // (threeD2chiral = true
    //  The conditions are:
    //  1. Molecule is not flat.
    //  2. At least three neighbors
    //  3. stereoParity is not set (0).
    //

    constexpr double eps = 1.0E-10;

    bool cisflag = true;
    bool ctUnknown = false;
    double v1[3], v2[3], v3[3];
    double v12[3], v23[3];

    double vectV = 0;
    int nAtoms = numAtoms;
    int nBonds = numBonds;
    if (threeD2chiral) {
        for (int i = 0; i < nAtoms; i++) {
            auto Atom = atomList[i];
            if (!isFlat && (Atom->stereoParity == 0 || Atom->stereoParity == 3) &&
                Atom->nBonds > 2) {
                int a1 = Atom->atomList[0];
                int a2 = Atom->atomList[1];
                int a3 = Atom->atomList[2];
                int a4 = -1;
                if (Atom->nBonds > 3) a4 = Atom->atomList[3];
                auto Atom1 = atomList[Atom->atomList[0]];
                auto Atom2 = atomList[Atom->atomList[1]];
                auto Atom3 = atomList[Atom->atomList[2]];
                v1[0] = Atom1->x - Atom->x;
                v1[1] = Atom1->y - Atom->y;
                v1[2] = Atom1->z - Atom->z;
                v2[0] = Atom2->x - Atom->x;
                v2[1] = Atom2->y - Atom->y;
                v2[2] = Atom2->z - Atom->z;
                v3[0] = Atom3->x - Atom->x;
                v3[1] = Atom3->y - Atom->y;
                v3[2] = Atom3->z - Atom->z;
                vectV = vectorVolume(v1, v2, v3);
                delete Atom->chiralStruct;
                if (Atom->stereoParity == 0) {
                    if (vectV < eps) {
                        Atom->chiralStruct = new TChirality(1, a1, a2, a3, a4);
                    } else if (vectV > -eps) {
                        Atom->chiralStruct = new TChirality(1, a2, a1, a3, a4);
                    } else {
                        Atom->chiralStruct = new TChirality(0, a1, a2, a3, a4);
                    }
                } else {
                    //
                    // Notes July 2 2008
                    // For unknown chiral centers, the chiralStruct sign is set to 0.
                    // Always use chiralStruct as the internal expression for stereo expression and
                    // in ranking.
                    //
                    if (vectV > eps) {
                        Atom->chiralStruct = new TChirality(0, a1, a2, a3, a4);
                    } else if (vectV < -eps) {
                        Atom->chiralStruct = new TChirality(0, a2, a1, a3, a4);
                    } else {
                        Atom->chiralStruct = new TChirality(0, a1, a2, a3, a4);
                    }
                }
            }
        }
    }

    /* To this point, if an atom's stereo parity is 0, then it is not a stereo
    // generic center.
    // However, we should be able to handle the following errors:
    // 1. The stereo parity is not set(zero), but it is a chiral center
    //    according to the topology
    // 2. The stereo parity flag is set, but it is not a stereo generic.
    //
    // For both cases, we need a integrity check
    //
    // Cis-Trans
    //

    //  0       3
    //   \     /
    //    1===2
    //   /     \
    //  4       5
    */

    int Sign = 1;
    if (threeD2cistrans) {
        for (int i = 0; i < nBonds; i++) {
            auto Bond = bondList[i];
            if (Bond->ctFlag != nullptr) {
                delete Bond->ctFlag;
                throw std::runtime_error("ctFlag already existed");
            }
            Bond->ctFlag = nullptr;
            ctUnknown = false;
            Sign = 1;
            if (Bond->bondType != 2) continue;
            if (Bond->bondDirection == 3) {
                ctUnknown = true;
                Sign = 0;
            }
            auto Atom1 = atomList[Bond->atom1];
            auto Atom2 = atomList[Bond->atom2];
            // each bond atom has at least 2 neighbors, and no more than 3
            // neighbors.
            if (Atom1->nBonds < 2 || Atom2->nBonds < 2) continue;
            if (Atom1->nBonds > 3 || Atom2->nBonds > 3) continue;
            //
            // Consider a special case
            // >C=N(+)=O
            // The C=N double bond.
            // Another special case
            // >C=C=C<
            //
            int multiBonds = 0;
            for (int j = 0; j < Atom1->nBonds; j++) {
                auto Bond0 = bondList[Atom1->bondList[j]];
                if (Bond0->bondType >= 2) multiBonds++;
            }
            if (multiBonds > 1) continue;
            multiBonds = 0;
            for (int j = 0; j < Atom2->nBonds; j++) {
                auto Bond0 = bondList[Atom2->bondList[j]];
                if (Bond0->bondType >= 2) multiBonds++;
            }
            if (multiBonds > 1) continue;
            MFCAtom *Atom0 = 0;
            MFCAtom *Atom3 = 0;
            MFCAtom *Atom4 = 0;
            MFCAtom *Atom5 = 0;
            int atomIdx0 = -1;
            int atomIdx3 = -1;
            int atomIdx4 = -1;
            int atomIdx5 = -1;

            for (int j = 0; j < Atom1->nBonds; j++) {
                auto Atom = atomList[Atom1->atomList[j]];
                if (Atom == Atom2) continue;
                if (atomIdx0 == -1) {
                    atomIdx0 = Atom->AIdx;
                    Atom0 = Atom;
                } else {
                    atomIdx4 = Atom->AIdx;
                    Atom4 = Atom;
                }
            }
            for (int j = 0; j < Atom2->nBonds; j++) {
                auto Atom = atomList[Atom2->atomList[j]];
                if (Atom == Atom1) continue;
                if (atomIdx3 == -1) {
                    atomIdx3 = Atom->AIdx;
                    Atom3 = Atom;
                } else {
                    atomIdx5 = Atom->AIdx;
                    Atom5 = Atom;
                }
            }

            //
            // For 2D structures, the atom positions may be very bad and
            // cis-trans relationship may not be consistant for differnt atom pairs.
            // To remove the randomness, use the largest cis-trans value to
            // assign cis-trans flag.
            // Notes: July 9, 2008 JLI
            //

            double ctCP;

            // v1 = atom1-atom0
            v1[0] = Atom1->x - Atom0->x;
            v1[1] = Atom1->y - Atom0->y;
            v1[2] = Atom1->z - Atom0->z;

            // v2 = atom2-atom1
            v2[0] = Atom2->x - Atom1->x;
            v2[1] = Atom2->y - Atom1->y;
            v2[2] = Atom2->z - Atom1->z;

            // v3 = atom3-atom2
            v3[0] = Atom3->x - Atom2->x;
            v3[1] = Atom3->y - Atom2->y;
            v3[2] = Atom3->z - Atom2->z;

            //
            // Cross Product
            // v12 = v1xv2
            // v23 = v2xv3
            // If v12.v23 > 0, cis
            // Else
            //     trans
            //

            v12[0] = v1[1] * v2[2] - v2[1] * v1[2];
            v12[1] = v2[0] * v1[2] - v1[0] * v2[2];
            v12[2] = v1[0] * v2[1] - v2[0] * v1[1];

            v23[0] = v2[1] * v3[2] - v3[1] * v2[2];
            v23[1] = v3[0] * v2[2] - v2[0] * v3[2];
            v23[2] = v2[0] * v3[1] - v3[0] * v2[1];

            //
            // Use the biggest value to assign ctFlag
            //
            // 0-1-2-3 cis
            ctCP = v12[0] * v23[0] + v12[1] * v23[1] + v12[2] * v23[2];

            if (ctCP > eps)
                cisflag = true;
            else if (ctCP < -eps)
                cisflag = false;
            else
                Sign = 0;
            delete Bond->ctFlag;
            if (cisflag) {
                Bond->ctFlag = new CTFlag(Sign, atomIdx0, atomIdx3, atomIdx4, atomIdx5);
            } else {
                Bond->ctFlag = new CTFlag(Sign, atomIdx0, atomIdx5, atomIdx4, atomIdx3);
            }

            if (ctUnknown) continue;
            // Check for another pair
            double tmp;

            if (Atom2->nBonds > 2) {
                // v1 = atom1-atom0
                v1[0] = Atom1->x - Atom0->x;
                v1[1] = Atom1->y - Atom0->y;
                v1[2] = Atom1->z - Atom0->z;

                // v2 = atom2-atom1
                v2[0] = Atom2->x - Atom1->x;
                v2[1] = Atom2->y - Atom1->y;
                v2[2] = Atom2->z - Atom1->z;

                // v3 = atom5-atom2
                v3[0] = Atom5->x - Atom2->x;
                v3[1] = Atom5->y - Atom2->y;
                v3[2] = Atom5->z - Atom2->z;

                v12[0] = v1[1] * v2[2] - v2[1] * v1[2];
                v12[1] = v2[0] * v1[2] - v1[0] * v2[2];
                v12[2] = v1[0] * v2[1] - v2[0] * v1[1];

                v23[0] = v2[1] * v3[2] - v3[1] * v2[2];
                v23[1] = v3[0] * v2[2] - v2[0] * v3[2];
                v23[2] = v2[0] * v3[1] - v3[0] * v2[1];

                // 0-1-2-5 cis
                tmp = v12[0] * v23[0] + v12[1] * v23[1] + v12[2] * v23[2];
                if (abs(tmp) > abs(ctCP)) {
                    ctCP = tmp;
                    Sign = 1;
                    if (ctCP > eps)
                        cisflag = true;
                    else if (ctCP < -eps)
                        cisflag = false;
                    else
                        Sign = 0;
                    delete Bond->ctFlag;
                    if (cisflag) {
                        Bond->ctFlag = new CTFlag(Sign, atomIdx0, atomIdx5, atomIdx4, atomIdx3);
                    } else {
                        Bond->ctFlag = new CTFlag(Sign, atomIdx0, atomIdx3, atomIdx4, atomIdx5);
                    }
                }
            }

            if (Atom1->nBonds > 2 && Atom2->nBonds > 2) {
                // v1 = atom1-atom4
                v1[0] = Atom1->x - Atom4->x;
                v1[1] = Atom1->y - Atom4->y;
                v1[2] = Atom1->z - Atom4->z;

                // v2 = atom2-atom1
                v2[0] = Atom2->x - Atom1->x;
                v2[1] = Atom2->y - Atom1->y;
                v2[2] = Atom2->z - Atom1->z;

                // v3 = atom5-atom2
                v3[0] = Atom5->x - Atom2->x;
                v3[1] = Atom5->y - Atom2->y;
                v3[2] = Atom5->z - Atom2->z;

                v12[0] = v1[1] * v2[2] - v2[1] * v1[2];
                v12[1] = v2[0] * v1[2] - v1[0] * v2[2];
                v12[2] = v1[0] * v2[1] - v2[0] * v1[1];

                v23[0] = v2[1] * v3[2] - v3[1] * v2[2];
                v23[1] = v3[0] * v2[2] - v2[0] * v3[2];
                v23[2] = v2[0] * v3[1] - v3[0] * v2[1];

                // 4-1-2-5 cis
                tmp = v12[0] * v23[0] + v12[1] * v23[1] + v12[2] * v23[2];

                if (abs(tmp) > abs(ctCP)) {
                    ctCP = tmp;
                    Sign = 1;
                    if (ctCP > eps)
                        cisflag = true;
                    else if (ctCP < -eps)
                        cisflag = false;
                    else
                        Sign = 0;
                    delete Bond->ctFlag;
                    if (cisflag) {
                        Bond->ctFlag = new CTFlag(Sign, atomIdx4, atomIdx5, atomIdx0, atomIdx3);
                    } else {
                        Bond->ctFlag = new CTFlag(Sign, atomIdx4, atomIdx3, atomIdx0, atomIdx5);
                    }
                }
            }

            if (Atom1->nBonds > 2) {
                // v1 = atom1-atom4
                v1[0] = Atom1->x - Atom4->x;
                v1[1] = Atom1->y - Atom4->y;
                v1[2] = Atom1->z - Atom4->z;

                // v2 = atom2-atom1
                v2[0] = Atom2->x - Atom1->x;
                v2[1] = Atom2->y - Atom1->y;
                v2[2] = Atom2->z - Atom1->z;

                // v3 = atom3-atom2
                v3[0] = Atom3->x - Atom2->x;
                v3[1] = Atom3->y - Atom2->y;
                v3[2] = Atom3->z - Atom2->z;

                v12[0] = v1[1] * v2[2] - v2[1] * v1[2];
                v12[1] = v2[0] * v1[2] - v1[0] * v2[2];
                v12[2] = v1[0] * v2[1] - v2[0] * v1[1];

                v23[0] = v2[1] * v3[2] - v3[1] * v2[2];
                v23[1] = v3[0] * v2[2] - v2[0] * v3[2];
                v23[2] = v2[0] * v3[1] - v3[0] * v2[1];

                // 4-1-2-3 cis
                tmp = v12[0] * v23[0] + v12[1] * v23[1] + v12[2] * v23[2];

                if (abs(tmp) > abs(ctCP)) {
                    ctCP = tmp;
                    Sign = 1;
                    if (ctCP > eps)
                        cisflag = true;
                    else if (ctCP < -eps)
                        cisflag = false;
                    else
                        Sign = 0;
                    delete Bond->ctFlag;
                    if (cisflag) {
                        Bond->ctFlag = new CTFlag(Sign, atomIdx4, atomIdx3, atomIdx0, atomIdx5);
                    } else {
                        Bond->ctFlag = new CTFlag(Sign, atomIdx4, atomIdx5, atomIdx0, atomIdx3);
                    }
                }
            }
        }
    }
}
}  // namespace MISS
