#ifndef mfcMolecule_h
#define mfcMolecule_h
/******************************************************************************
 *                                                                             *
 *    Category:   Molecule Foundation Classes (MFC)                            *
 *    Function:   Define classes of molecule objects                           *
 *    Author:     James Li                                                     *
 *    Date:       March, 2011                                                  *
 *                                                                             *
 ******************************************************************************/
#include <algorithm>
#include <cassert>
#include <iostream>
#include <map>
#include <memory>
#include <string>
#include <vector>

#include "IO/SdfTopology.hpp"
#include "MolStructure/mfcAtom.h"
#include "MolStructure/mfcBond.h"
#include "mfcRing.h"

using namespace std;

namespace MISS {

// Store and parse properties in SD files
class MolProperties {
public:
    int getIntProperty(const string &propName);
    double getRealProperty(const string &propName);
    std::vector<int> getIntPropertyArray(const string &propName);
    std::vector<double> getRealPropertyArray(const string &propName);
    std::vector<std::string> getStringPropertyArray(const string &propName);
    void getPropertyIntList(const string &propName, std::vector<int> &FANumList,
                            std::vector<int> &FAatomList);

    std::vector<std::string> PropertyDoc;
};

// A fragment is a set of atoms which are linked via chemical bond.
// Therefore, a molecule may have one or more fragments.

class MFCFrag {
public:
    MFCFrag() = default;
    MFCFrag(int nAtoms, int nBonds, std::string fragName);
    ~MFCFrag();

    SdfTopology topology;

    int numAtoms{};
    int numBonds{};
    int numRings{};
    int ringCount{};
    int stereoFlag{};
    int nTreeNodes{};    // not used
    int nTreeEdges{};    // not used
    int nRotEdges{};     // not used
    int *TopDistance{};  // Array for topological distances
                         // between atoms.
    int *RotEdgeFlag{};  // Array for rotatable bond indexes

    std::string fragname{"NoName"};

    void addAtomSizeToRanking();
    int setUnknownStereoCenters();      // Return number of unknown elements
                                        // (atoms and bonds)
    void setStereoFlags(int isomerID);  // Set stereo flags for stereo isomer
                                        // with isomerID
    void resetUnknownStereoFlags();     // Reset the stereo flags to original
                                        // status
    void setMolPro(MolProperties *molP);
    MolProperties *getMolPro();
    void removeAtom(int AId);
    void removeBond(int BId);
    void removeAtomsOnRing(int RId, vector<int> &atoms);
    void removeOneBranch(int AId);  // AId is the index of the first atom connected to the ring
    void addBond(MFCBond &bond);    // no new ring
    void insertBond(MFCBond &bond, int loc);
    void compress();

    std::vector<MFCAtom *> atomList;
    std::vector<MFCBond *> bondList;
    std::vector<MFCRing *> ringList;
    // A general data pointer for the fragmentation of a fragment
    void *fraction{};

    // lixm.property defined for "topology.cpp".begin.

    // void unmarkFragBond();
    int isBonded(int atom_idx, int adjatom_idx);
    //    int isSuperRing(MFCRing *ring);
    int isSP2Atom(MFCAtom *atom);
    int potentialAromatic(int atom_idx, int ring_idx);
    // lixm.property defined for "topology.cpp".end.

    void add_hydrogens();
    void set_chirality();
    void set_parity(bool isFlat);
    void set_stereo(bool threeD2chiral, bool threeD2cistrans, bool isFlat);

private:
    void copyInit(const MFCFrag &src);
    void dtor();
    void updateBondType(int BId);
    void updateAtomAromaticFlag(int AId);
    std::map<std::string, std::string> fragProp;
    MolProperties *molPro{};
};

class Molecule {
public:
    void addFrag(MFCFrag *frag) { fragList.emplace_back(frag); }

    std::unique_ptr<MFCFrag> &getFrag(std::size_t FragID) {
        assert(FragID < fragList.size());
        return fragList[FragID];
    }

    decltype(auto) begin() { return std::begin(fragList); }
    decltype(auto) end() { return std::end(fragList); }

    std::vector<std::unique_ptr<MFCFrag>> fragList;
};

struct OnBranch {
    bool operator()(MFCFrag &frag, int AId, int direction) const {
        // cout<<AId<<" "<<frag.atomList[AId]<<" at Ln"<<__LINE__<<" in "<<__FILE__<<endl;
        MFCAtom *atom = frag.atomList[AId];
        MFCAtom *nextAtom = frag.atomList[atom->atomList[direction]];
        return nextAtom->ringAtomFlag == 0;
    }
};

struct DeleteAtom {
    void operator()(MFCFrag &frag, int AId) const {
        // cout<<AId<<" "<<frag.atomList[AId]<<" at Ln"<<__LINE__<<" in "<<__FILE__<<endl;
        frag.removeAtom(AId);
    }
};

}  // namespace MISS

#endif /* mfcMolecule_h */
