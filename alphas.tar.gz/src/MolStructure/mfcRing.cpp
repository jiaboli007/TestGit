/******************************************************************************
 *                                                                             *
 *    Categoryn:   Molecule Foundation Classes (MFC)                           *
 *    Functionn:   Implementation of Ring Class                                *
 *    Author:      James Li                                                    *
 *    Date:        March 2011                                                  *
 *                                                                             *
 ******************************************************************************/

#include "mfcRing.h"

namespace MISS {

MFCRing::MFCRing(int size, const int* list) {
    ringSize = size;
    ringAtomList.assign(list, list + size);
}

}  // namespace MISS
