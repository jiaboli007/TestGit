#ifndef mfcRing_h
#define mfcRing_h
/******************************************************************************
 *                                                                             *
 *    Category:   Molecule Foundation Classes (MFC)                            *
 *    Function:   Define Ring Class                                            *
 *    Author:     James Li                                                     *
 *    Date:       March, 2011                                                  *
 *                                                                             *
 ******************************************************************************/
#include <string>
#include <vector>

namespace MISS {

class MFCRing {
public:
    MFCRing() = default;
    MFCRing(int Size, const int* List);

    int ringSize{};
    int RIdx{};
    std::vector<int> ringAtomList;
    int aromaticity{};  // Yes=1, No=0
    void* ownerFrag{};  // Pointer to parent fragment

    // lixm.property defined for "topology.cpp".begin.
    // std::vector<int> ringBondList;
    int checkAtomInRing(int atom_idx);
//    int checkBondInRing(int bond_idx);
    void printRing();
    // lixm.property defined for "topology.cpp".end.
};

}  // namespace MISS

#endif /* mfcRing_h */
