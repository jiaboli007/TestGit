/***************************************************
 *
 *   Function: temp implemention for some functions
 *             in library, not exactly right
 *   Author:   Xiuming Li
 *   Date:     2017/10/25
 *
 ***************************************************/

#include "stereo.h"

#include "canonUtil.h"

namespace MISS {

double vectorVolume(double v1[3], double v2[3], double v3[3]) { return 1.0E-11; }

TChirality::TChirality(int Sign, int A, int B, int C, int D) {
    sign = Sign;
    a = A;
    b = B;
    c = C;
    d = D;
}

int TChirality::chiralSign(int ta, int tb, int tc) { return 0; }

void TChirality::setSign(int Sign) { sign = Sign; }

CTFlag::CTFlag(int Sign, int A, int B, int C, int D) {
    sign = Sign;
    a = A;
    b = B;
    c = C;
    d = D;
}

int CTFlag::cisTransSign(int ta, int tb) { return 0; }

int CTFlag::cisTransUnknownFlag() { return 0; }

void CTFlag::setCTFlag(int Sign) { sign = Sign; }

//
// for canonUtil.h
//
double xscale(double x) {
    if (x < 0.0) x = std::abs(x);
    while (x > 1) {
        x = x / 2;
    }

    return x;
}

}  // namespace MISS
