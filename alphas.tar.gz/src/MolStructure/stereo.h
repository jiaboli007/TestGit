#ifndef stereo_h
#define stereo_h
/******************************************************************************
 *                                                                             *
 *    Category:   Molecule Foundation Classes                                  *
 *    Function:   Implementation of stereo classes.                            *
 *    Author:     James Li                                                     *
 *    Date:       March 2011                                                   *
 *                                                                             *
 ******************************************************************************/

#include <array>
#include <string>

namespace MISS {

double vectorVolume(double v1[3], double v2[3], double v3[3]);

/*
//    1
//     \
//   2--C--4
//     /
//    3
//
//   Use four atoms around center atom C and their orientation to
//   characterize a chiral center.
//   Atoms 1,2,3 form a right hand system which points to atom 4.
*/

class TChirality {
public:
    TChirality(int Sign, int A, int B, int C, int D = -1);

    int chiralSign(int ta, int tb, int tc);
    void setSign(int Sign);

    int sign;  // 1 = right, -1 = left, 0 = unknown stereo or not stereo
    int a, b, c, d;
};

/*
//   a      b
//    \    /
//     X==Y
//    /    \
//   c      d
//
//   a . b = cis
//   a . d = trans
//   c . b = trans
//   c . d = cis
//
//   cisTrans class
*/

class CTFlag {
public:
    CTFlag(int Sign, int A, int B, int C, int D);

    int cisTransSign(int ta, int tb);
    int cisTransUnknownFlag();
    void setCTFlag(int Sign);

    int a, b, c, d;

private:
    int sign;  // 1=fixed, 0=either cis or trans
};

}  // namespace MISS
#endif /* stereo_h */
