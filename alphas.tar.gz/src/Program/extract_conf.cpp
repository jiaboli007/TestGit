
#include <fstream>
#include <iostream>

#include <boost/iostreams/device/mapped_file.hpp>
#include <boost/program_options.hpp>
#include <boost/range/adaptors.hpp>
#include <boost/range/algorithm.hpp>

#include <SQLiteCpp/SQLiteCpp.h>

#include "IO/ASStructure.hpp"
#include "IO/SQLiteSchema.hpp"
#include "Utils/utils.hpp"

namespace {
using namespace MISS;

int Main(int argc, char *argv[]) {
    namespace po = boost::program_options;

    po::options_description options("Options");

    std::string as_filename, index_filename, out;
    std::vector<std::size_t> conformation_no;  // start from 1

    // clang-format off
    options.add_options()
            ("help,h", "show this help message")
            ("as", po::value(&as_filename)->value_name("input_as_database"),
                                                    "conformation database in as format")
            ("index", po::value(&index_filename)->value_name("output_index_file"),
                                                    "index sqlite file")
            ("conf", po::value(&conformation_no)->value_name("conf_no")->composing(),
                                                    "conformation NO.")
            ("out", po::value(&out)->value_name("output_sd_file"), "output sd file");
    // clang-format on

    auto print_usage = [&] {
        std::cout << "Usage :" << argv[0]
                  << " --as as_database.as --index index.sqlite --out out.sd --conf conf_id1 "
                     "[,conf_id2,...]\n";
        std::cout << options;
    };
    po::variables_map vm;
    try {
        po::store(po::command_line_parser(argc, argv)
                      .options(options)
                      .style(po::command_line_style::unix_style |
                             po::command_line_style::allow_long_disguise)
                      .run(),
                  vm);
        po::notify(vm);
    } catch (std::exception &e) {
        std::cerr << e.what() << '\n';
        print_usage();
        std::exit(EXIT_FAILURE);
    }

    if (vm.count("help")) {
        print_usage();
        std::exit(EXIT_SUCCESS);
    }
    for (const auto &key : {"as", "index", "conf", "out"}) {
        if (!vm.count(key)) {
            std::cerr << "--" << key << " must be specified" << std::endl;
            print_usage();
            std::exit(EXIT_FAILURE);
        }
    }

    check(as_filename);
    check(index_filename);

    SQLite::Database db(index_filename);

    if (db.execAndGet("PRAGMA application_id").getInt() != AlphaS_Index_File_Application_ID) {
        std::cerr << fmt::format("{} is not AlphaS Index File \n", index_filename);
        return EXIT_FAILURE;
    }
    auto user_version = db.execAndGet("PRAGMA user_version").getInt();
    if (user_version != 0 and user_version != 1) {
        std::cerr << fmt::format("Result database version () not supported!\n", user_version);
        return EXIT_FAILURE;
    }

    if (user_version == 0) {
        db.exec(
            "create temp view mol_offset as select mol_name.id as id, mol_name.name as name, "
            "min(conf_offset.offset)-3 as offset, mol_name.topology from ind.conf_offset inner "
            "join ind.mol_name where ind.conf_offset.mol_id == ind.mol_name.id group by "
            "ind.mol_name.id");
    }
    constexpr std::string_view pattern = "\n$$$$\n";
    AS::Reader<AS::MMapFile> as_reader(as_filename);
    SQLite::Statement select_stmt(
        db, fmt::format("select mol_offset.offset, mol_offset.name, mol_offset.topology from "
                        "mol_offset where mol_offset.id == ?"));
    std::ofstream sdf_sink(out);
    for (auto conf_id : conformation_no) {
        select_stmt.bind(1, static_cast<long long int>(conf_id >> 16));
        if (select_stmt.executeStep()) {
            std::cout << fmt::format("Conformation (conf_id = {}, mol_id = {}, shift = {})\n",
                                     conf_id, conf_id & 0xFFFFFFFFFFFF0000, conf_id & 0xFFFF);
            int64_t offset = select_stmt.getColumn(0);
            std::string_view name = static_cast<const char *>(select_stmt.getColumn(1));

            auto blob_start = static_cast<const char *>(select_stmt.getColumn(2).getBlob());
            auto blob_size = select_stmt.getColumn(2).getBytes();
            auto topology = SdfTopology::from_blob(blob_start, blob_start + blob_size);

            auto mol = as_reader.read_mol_from_offset(offset);
            auto coord = mol.conformations.at(conf_id & 0xFFFF).coordinates;
            topology.to_sdf(sdf_sink, name, coord);
            sdf_sink << "> <conformation_no>\n" << conf_id << '\n' << pattern;
        } else {
            std::cerr << fmt::format(
                "Can not find conformation (conf_id = {}, mol_id = {}, shift = {})\n", conf_id,
                conf_id & 0xFFFFFFFFFFFF0000, conf_id & 0xFFFF);
            return EXIT_FAILURE;
        }
        select_stmt.reset();
    }

    return EXIT_SUCCESS;
}
}  // namespace

int main(int argc, char *argv[]) {
    try {
        register_signals();

        return Main(argc, argv);
    } catch (std::exception &e) {
        std::cerr << "Exception(" << boost::typeindex::type_id_runtime(e).pretty_name()
                  << ") : " << e.what() << std::endl;
    } catch (...) {
        boost::typeindex::stl_type_index sti = *std::current_exception().__cxa_exception_type();
        std::cerr << "Exception(" << sti.pretty_name() << ")\n";
    }
    return EXIT_FAILURE;
}
