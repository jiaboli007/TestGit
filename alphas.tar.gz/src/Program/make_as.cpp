/******************************************************************************
 * Principal function:                                                         *
 *    Database preprocess
 *                                                                             *
 * Usage:
 *
 * Authors:                                                                    *
 *    Xia Miaoren,  Ang 2020
 *                                                                             *
 ******************************************************************************/
#include "config.hpp"

#include <boost/filesystem.hpp>
#include <boost/iostreams/filter/bzip2.hpp>
#include <boost/iostreams/filter/gzip.hpp>
#include <boost/iostreams/filter/lzma.hpp>
#include <boost/iostreams/filtering_streambuf.hpp>
#include <boost/program_options.hpp>

#include <tbb/tbb.h>

#include <alphac/alphaCEngine.h>
#include <alphac/alphaMaster.h>
#include <fmt/format.h>
#include <sqlite_orm/sqlite_orm.h>

#include "Utils/utils.hpp"

namespace {
using namespace MISS;
using namespace MISS::Optimize;

template <typename SDReader_>
using ReaderSource = std::tuple<std::size_t /* conformation_sequence_number */,
                                bool /* whether is whole molecule */, SDReader_>;

using ProcessItem = std::tuple<AS::Molecule::Conformation, std::string, SdfTopology>;
using ProcessVector = std::vector<ProcessItem>;
using ProcessSource = std::tuple<std::size_t, bool /* whether is whole molecule */, ProcessVector>;

enum class FileKind { AC, AC_MolData3D, SD, SDGZ, SDBZ2, SDXZ };

template <typename From, typename To>
concept move_construct_to = requires(From t) {
    {To{std::move(t)}};
};

template <typename T>
concept FragReaderConcept = requires(T reader) {
    { reader->endOfSD() } -> std::convertible_to<bool>;
    { reader->readLargestMFCFrag() } -> move_construct_to<std::unique_ptr<MFCFrag>>;
};

ProcessVector process_one_molecule(FragReaderConcept auto&& reader,
                                   PharmacophoreGraph& pharmacophore, bool getW, bool initR) {
    ProcessVector ret;
    std::cout << "Process one molecule at a time\n";
    while (!reader->endOfSD()) {
        std::unique_ptr<MFCFrag> frag{reader->readLargestMFCFrag()};

        if (!frag) continue;

	std::cout << "Process one one conf at a time: " << frag->fragname << "\n";
        auto conf = transform_to_conf(frag.get(), pharmacophore, getW, initR);
        if (conf.coordinates.size() > MAX_DB_ATOM_NUMBER) {
            std::cerr << "too many heavy atoms : will overflow in GPU code\n";
            continue;
        }
        if (conf.get_num_feats() > MAX_DB_FEATURE_NUMBER) {
            std::cerr << "error load database, number of feature spheres >" << MAX_DB_FEATURE_NUMBER
                      << " \n";
            continue;
        }
        ret.emplace_back(std::move(conf), std::move(frag->fragname), std::move(frag->topology));
    }
    return ret;
}

template <FileKind>
struct ReaderNode;

class FragReader {
public:
    std::unique_ptr<MFCFrag> readLargestMFCFrag() {
        auto frag = std::move(q.front());
        q.pop();
        return frag;
    }
    [[nodiscard]] bool endOfSD() const { return q.empty(); }

private:
    friend struct ReaderNode_impl;
    friend class FragReaderofMolData3D;

    void add_frag(std::unique_ptr<MFCFrag> frag) { q.push(std::move(frag)); }
    [[nodiscard]] auto size() const { return q.size(); };
    [[nodiscard]] bool empty() const { return q.empty(); }

    std::queue<std::unique_ptr<MFCFrag>> q;
};

class FragReaderofMolData3D {
public:
    FragReader get_frag_reader() {
        if (!q.empty()) {
            auto mol = std::move(q.front());
            q.pop();
            return convert_MolData3D_to_frags(std::move(mol));
        } else
            throw std::runtime_error("MolData3D queue is empty!");
    }
    [[nodiscard]] bool endOfSD() const { return q.empty(); }

    static std::unique_ptr<MFCFrag> build_frag_scaffold(std::unique_ptr<ALPHA::MolData3D>& confs) {
        auto frag = std::make_unique<MFCFrag>(confs->nAtoms, confs->nBonds,
                                              confs->mol_name.empty() ? "NONAME" : confs->mol_name);

        frag->topology.cFlag = frag->stereoFlag = confs->chiralFlag;

        for (const auto& [i, atom_bits] : confs->atom_list | boost::adaptors::indexed()) {
            auto atom = new MFCAtom(i, atom_bits.atomic_number);
            frag->topology.add_atom({.atom = {.cFlag = atom_bits.charge_flag,
                                              .stereoParity = atom_bits.stereo_parity,
                                              .atomicNumber = atom_bits.atomic_number}});

            auto formalCharge = atom_bits.charge_flag == 0 ? 0 : (4 - atom_bits.charge_flag);
            auto freeValence = atom_bits.charge_flag == 4 ? 1 : 0;  // Radical

            atom->genFlag = 0;
            atom->nBonds = 0;
            atom->ownerFrag = frag.get();
            atom->FormalCharge = formalCharge;
            atom->mdlChargeFlag = atom_bits.charge_flag;
            atom->charge = formalCharge;
            atom->freeValence = freeValence;
            atom->massDiff = 0;
            atom->stereoParity = atom_bits.stereo_parity;
            frag->atomList.push_back(atom);
        }
        for (const auto& [i, bond_bits] : confs->bond_list | boost::adaptors::indexed()) {
            auto atom1 = bond_bits.atom1_idx;
            auto atom2 = bond_bits.atom2_idx;
            auto bondOrder = bond_bits.bond_type;
            auto bondDir = bond_bits.bond_dir;

            frag->topology.add_bond({.atom1 = frag->topology.atoms_.at(atom1).get(),
                                     .atom2 = frag->topology.atoms_.at(atom2).get(),
                                     .bondOrder = bondOrder,
                                     .bondDir = bondDir});
            auto bondType = bondOrder;
            bondOrder = bondOrder * 100;
            auto bond = new MFCBond(atom1, atom2, bondOrder, i);

            frag->bondList.push_back(bond);
            auto Atom1 = frag->atomList[atom1];
            auto Atom2 = frag->atomList[atom2];
            Atom1->nBonds++;
            Atom2->nBonds++;

            bond->bondDirection = bondDir;
            if (atom1 > atom2 && bondDir == 1) {
                bond->bondDirection = 6;
            } else if (atom1 > atom2 && bondDir == 6) {
                bond->bondDirection = 1;
            }

            if (bondType == 2) bond->bondDirection = bondDir;
            // stereoParity = 0 (not a stereo center or not set)
            // 1/2 (R/S), 3 (unknown),
            // 4 (fixed, determine by 3D).
            // modify is stereoParity is not set yet
            //
            if (bondDir == 4)
                Atom1->stereoParity = 3;
            else if (bondDir == 1 || bondDir == 6)
                Atom1->stereoParity = 4;
        }
        // Setup atom bond list
        for (int i : boost::irange(confs->nBonds)) {
            auto Bond = frag->bondList[i];
            auto atom1 = Bond->atom1;
            auto atom2 = Bond->atom2;
            auto Atom1 = frag->atomList[atom1];
            auto Atom2 = frag->atomList[atom2];
            Atom1->atomList.push_back(atom2);
            Atom2->atomList.push_back(atom1);
            Atom1->bondList.push_back(i);
            Atom2->bondList.push_back(i);
            Atom1->genFlag++;
            Atom2->genFlag++;
        }
        frag->numAtoms = confs->nAtoms;
        frag->numBonds = confs->nBonds;
        frag->topology.make();

        return frag;
    }

    FragReader convert_MolData3D_to_frags(std::unique_ptr<ALPHA::MolData3D> confs) {
        std::vector<std::unique_ptr<MFCFrag>> frag_vector;
        frag_vector.reserve(confs->conf_xyz.size());
        FragReader reader;
        for (auto ptr : confs->conf_xyz) {
            bool threeD2chiral = true;
            bool threeD2cistrans = true;
            bool isFlat = true;

            auto frag = build_frag_scaffold(confs);

            double z0;
            for (auto&& [id, atom] : frag->atomList | boost::adaptors::indexed()) {
                atom->x = ptr[0];
                atom->y = ptr[1];
                atom->z = ptr[2];
                if (id == 0)
                    z0 = atom->z;
                else if (atom->z != z0)
                    isFlat = false;
                ptr += 3;
            }
            //
            // Post process: add H to mol
            //
            frag->add_hydrogens();
            //
            // Set chirality by stereo parity
            //
            frag->set_chirality();
            //
            // Set parity by bond direction if the molecule is flat and there is a bond
            // direction flag (1,6)
            // For either bond direction (4), the chiral sign of the atom is set to 0.
            //
            frag->set_parity(isFlat);
            frag->set_stereo(threeD2chiral, threeD2cistrans, isFlat);

            std::unique_ptr<Molecule> molecule{convertFragToMol(frag.release())};
            std::unique_ptr<MFCFrag> f{
                molecule ? std::max_element(std::begin(*molecule), std::end(*molecule),
                                            [](const auto& lhs, const auto& rhs) {
                                                return lhs->numAtoms < rhs->numAtoms;
                                            })
                               ->release()
                         : nullptr};

            reader.add_frag(std::move(f));
        }
        return reader;
    }

private:
    friend struct ReaderNode<FileKind::AC_MolData3D>;

    void add_MolData3D(const std::vector<ALPHA::MolData3D*>& mol_datas) {
        for (auto& mol : mol_datas) q.push(std::unique_ptr<ALPHA::MolData3D>(mol));
    }
    [[nodiscard]] auto size() const { return q.size(); };
    [[nodiscard]] bool empty() const { return q.empty(); }

    std::queue<std::unique_ptr<ALPHA::MolData3D>> q;
};

template <typename T>
struct ProcessNode {
    using using_moldata3d =
        std::bool_constant<std::is_same_v<T, std::shared_ptr<FragReaderofMolData3D>>>;

    using Input =
        std::conditional_t<using_moldata3d::value, std::tuple<std::size_t, T>, ReaderSource<T>>;
    using Output =
        std::conditional_t<using_moldata3d::value,
                           std::tuple<std::size_t, std::vector<ProcessVector>>, ProcessSource>;

    ProcessNode(tbb::flow::graph& g, bool getW, bool initR)
        : pharmacophore{load_pharmacophore_graph()},
          preprocess_node(g, tbb::flow::unlimited, [this, getW, initR](const Input& reader_tuple) {
              auto& reader = const_cast<T&>(std::get<T>(reader_tuple));
              if constexpr (using_moldata3d::value) {
                  std::vector<ProcessVector> ret;
                  while (!reader->endOfSD()) {
                      FragReader r = reader->get_frag_reader();
		      std::cout << "using_moldata3d value 01\n";
                      auto one_mol = process_one_molecule(&r, pharmacophore, getW, initR);
                      ret.push_back(std::move(one_mol));
                  }
                  return std::tuple{std::get<std::size_t>(reader_tuple), ret};
              } else {
		  std::cout << "using_moldata3d value 02\n";
                  auto ret = process_one_molecule(reader, pharmacophore, getW, initR);
                  return std::tuple{std::get<std::size_t>(reader_tuple),
                                    std::get<bool>(reader_tuple), ret};
              };
          }) {}

    PharmacophoreGraph pharmacophore;
    tbb::flow::function_node<Input, Output> preprocess_node;
};

template <>
struct ReaderNode<FileKind::SD> : public ProcessNode<std::shared_ptr<SDReaderT<MMapStream>>> {
    using SDReader_ = std::shared_ptr<SDReaderT<MMapStream>>;

    ReaderNode(tbb::flow::graph& g, bool getW, bool initR, const std::string& sd_filename)
        : ProcessNode(g, getW, initR),
          source(sd_filename),
          source_begin(source.begin()),
          source_end(source.end()),
          source_it(source_begin),
          sub{"\n$$$$\n"},
          bmsearch{sub.begin(), sub.end()},
          source_node(g, [this](tbb::flow_control& fc) -> ReaderSource<SDReader_> {
              if (source_it < source_end) {
                  auto reader = std::make_tuple(conformation_sequence_number++, false,
                                                std::make_shared<SDReaderT<MMapStream>>());
                  constexpr std::size_t chunk_size = SDF_SPLIT_CHUNK_SIZE;
                  if (source_it + chunk_size < source_end) {
                      auto it =
                          std::search(source_it + chunk_size - sub.size(), source_end, bmsearch);
                      auto new_end = std::min(it + sub.size(), source_end);
                      std::get<SDReader_>(reader)->open(source_it, new_end);
                      source_it = new_end;
                      return reader;
                  } else {
                      std::get<SDReader_>(reader)->open(source_it, source_end);
                      source_it = source_end;
                      return reader;
                  }
              }
              fc.stop();
              return {};
          }) {}

    std::size_t conformation_sequence_number = 0;
    boost::iostreams::mapped_file_source source;
    boost::iostreams::mapped_file_source::iterator source_begin, source_end, source_it;
    std::string_view sub;
    std::boyer_moore_searcher<std::string_view::iterator> bmsearch;

    tbb::flow::input_node<ReaderSource<SDReader_>> source_node;
};

template <>
struct ReaderNode<FileKind::AC>
    : public ProcessNode<std::shared_ptr<SDReaderT<iStringFileStream>>> {
    using SDReader_ = std::shared_ptr<SDReaderT<iStringFileStream>>;

    ReaderNode(tbb::flow::graph& g, bool getW, bool initR, const std::string& ac_filename,
               const std::string& fraglib_name)
        : ProcessNode(g, getW, initR),
          acReader{ac_filename, (ALPHA::initAlphaCEngine(fraglib_name, true), fraglib_name)},
          source_node(g, [this](tbb::flow_control& fc) -> ReaderSource<SDReader_> {
              if (!acReader.endOfAC()) {
                  auto reader = std::make_tuple(conformation_sequence_number++, true,
                                                std::make_shared<SDReaderT<iStringFileStream>>());
                  std::vector<std::string> sdDoc = acReader.read_confs(1);
                  auto sd_str = fmt::format("{}", fmt::join(sdDoc, ""));
                  std::get<SDReader_>(reader)->open(sd_str);
                  return reader;
              }
              fc.stop();
              return {};
          }) {}

    std::size_t conformation_sequence_number = 0;
    ALPHA::AC2SDReader acReader;
    tbb::flow::input_node<ReaderSource<SDReader_>> source_node;
};

template <>
struct ReaderNode<FileKind::AC_MolData3D>
    : public ProcessNode<std::shared_ptr<FragReaderofMolData3D>> {
    using SDReader_ = std::shared_ptr<FragReaderofMolData3D>;

    static constexpr auto STEP_SIZE = 100;

    ReaderNode(tbb::flow::graph& g, bool getW, bool initR, const std::string& ac_filename,
               const std::string& fraglib_name)
        : ProcessNode(g, getW, initR),
          ac_reader{ac_filename, (ALPHA::initAlphaCEngine(fraglib_name, true), fraglib_name)},
          source_node(g, [this](tbb::flow_control& fc) -> std::tuple<std::size_t, SDReader_> {
              while (!ac_reader.endOfAC()) {
                  if (auto confs_vector = ac_reader.read_confs(STEP_SIZE); !confs_vector.empty()) {
                      auto reader = std::make_tuple(conformation_sequence_number++,
                                                    std::make_shared<FragReaderofMolData3D>());
                      std::get<std::shared_ptr<FragReaderofMolData3D>>(reader)->add_MolData3D(
                          confs_vector);
                      return reader;
                  }
              }
              fc.stop();
              return {};
          }) {}

    std::size_t conformation_sequence_number = 0;
    ALPHA::AC2MolDataReader ac_reader;
    tbb::flow::input_node<std::tuple<std::size_t, SDReader_>> source_node;
};

struct ReaderNode_impl : public ProcessNode<std::shared_ptr<FragReader>> {
    using SDReader_ = std::shared_ptr<FragReader>;
    ReaderNode_impl(FileKind Kind, tbb::flow::graph& g, bool getW, bool initR,
                    const std::string& sd_gz_filename)
        : ProcessNode(g, getW, initR),
          file(sd_gz_filename, std::ios_base::in | std::ios_base::binary),
          source_node(g, [this](tbb::flow_control& fc) -> ReaderSource<SDReader_> {
              auto reader = std::make_tuple(conformation_sequence_number++, false,
                                            std::make_shared<FragReader>());
              while (!sd_reader->endOfSD() and std::get<SDReader_>(reader)->size() < 100) {
                  if (std::unique_ptr<MFCFrag> frag{sd_reader->readLargestMFCFrag()}; frag) {
                      std::get<SDReader_>(reader)->add_frag(std::move(frag));
                  }
              }
              if (std::get<SDReader_>(reader)->empty()) {
                  fc.stop();
                  return {};
              }
              return reader;
          }) {
        using namespace boost::iostreams;
        switch (Kind) {
            case FileKind::SDGZ:
                in.push(gzip_decompressor{});
                break;
            case FileKind::SDBZ2:
                in.push(bzip2_decompressor{});
                break;
            case FileKind::SDXZ:
                in.push(lzma_decompressor{});
                break;
        }

        in.push(file);
        sd_reader = std::make_unique<SDReaderT<std::istream>>(in);
    }

    std::size_t conformation_sequence_number = 0;

    std::ifstream file;
    boost::iostreams::filtering_istreambuf in;
    std::unique_ptr<SDReaderT<std::istream>> sd_reader;

    tbb::flow::input_node<ReaderSource<SDReader_>> source_node;
};

template <FileKind Kind>
struct ReaderNode : public ReaderNode_impl {
    template <typename... ARGS>
    requires(Kind == FileKind::SDGZ or Kind == FileKind::SDBZ2 or
             Kind == FileKind::SDXZ) explicit ReaderNode(ARGS&&... args)
        : ReaderNode_impl(Kind, std::forward<ARGS>(args)...) {}
};

struct WriterNodeBase {
    WriterNodeBase(const std::string& index_filename, AS::Writer& writer)
        : writer(writer),
          index_storage(make_index_storage_v2(index_filename)),
          insert_mol_statement{[this] {
              index_storage.pragma.journal_mode(sqlite_orm::journal_mode::OFF);
              index_storage.pragma.set_pragma("synchronous", "OFF");
              index_storage.pragma.user_version(1);  // version of AS database index
              index_storage.pragma.set_pragma(
                  "application_id",
                  AlphaS_Index_File_Application_ID);  // Application ID: AlphaS Index File

              std::cout << "Creating sqlite3 index file ..." << std::endl;
              for (const auto& [item, result] : index_storage.sync_schema()) {
                  std::cout << '\t' << item << "\t->\t" << result << std::endl;
              }

              index_storage.begin_transaction();
              return index_storage.prepare(sqlite_orm::insert(MolConfSet{}));
          }()} {}

    void commit() {
        if (!mol.conformations.empty()) writer.write(mol);
        index_storage.commit();
    }

    void process_mol(ProcessVector& process_vector) {
        for (auto& [conf, name, topology] : process_vector) {
            auto blob = topology.to_blob();
            if (name != mol.name) {
                mol.pre_callback = [this](const AS::Molecule& m) {
                    sqlite_orm::get<0>(insert_mol_statement).name = m.name;
                    sqlite_orm::get<0>(insert_mol_statement).topology_blob = m.topology_blob;
                    sqlite_orm::get<0>(insert_mol_statement).offset = m.offset_in_as_begin;
                    index_storage.execute(insert_mol_statement);
                };
                if (!mol.conformations.empty()) writer.write(mol);

                mol.reset();
                mol.name = std::move(name);
                mol.topology_blob = std::move(blob);
                mol.header.heavy_atom_number = conf.coordinates.size();
            }
            conformation_number++;
            if (mol.header.heavy_atom_number != conf.coordinates.size()) {
                std::cerr << "ERROR : different molecules have same mol_name (" << mol.name
                          << ")!\n";
                std::exit(EXIT_FAILURE);
            }
            mol.conformations.push_back(std::move(conf));
        }
    };

    int conformation_number = 0;
    AS::Molecule mol;
    AS::Writer& writer;

    using Index = decltype(make_index_storage_v2(std::declval<std::string>()));
    using Index_Insert_Stmt =
        decltype(std::declval<Index>().prepare(sqlite_orm::insert(MolConfSet{})));

    Index index_storage;
    Index_Insert_Stmt insert_mol_statement;
};

template <typename T>
requires(std::same_as<T, std::tuple<std::size_t, std::vector<ProcessVector>>> or
         std::same_as<T, ProcessSource>) struct WriterNode : public WriterNodeBase {
    WriterNode(tbb::flow::graph& g, const std::string& index_filename, AS::Writer& writer)
        : WriterNodeBase(index_filename, writer),
          writer_node(g, tbb::flow::serial, [&](const T& conf_ptr) {
              if constexpr (std::is_same_v<T,
                                           std::tuple<std::size_t, std::vector<ProcessVector>>>) {
                  for (auto& process_vector : std::get<1>(conf_ptr)) {
                      process_mol(const_cast<ProcessVector&>(process_vector));
                      if (!mol.conformations.empty()) writer.write(mol);
                      mol.reset();
                  }
              } else {
                  if (std::get<bool>(conf_ptr) and !mol.conformations.empty()) {
                      writer.write(mol);
                      mol.reset();
                  }
                  process_mol(const_cast<ProcessVector&>(std::get<2>(conf_ptr)));
              }
          }) {}

    tbb::flow::function_node<T> writer_node;
};

template <FileKind fileKind, typename... ARGS>
void preprocess(bool compress, const std::string& as_filename, const std::string& index_filename,
                bool getW, bool initR, ARGS&&... args) requires requires {
    {ReaderNode<fileKind>(std::declval<tbb::flow::graph&>(), getW, initR, args...)};
}
{
    auto start = std::chrono::steady_clock::now();

    tbb::flow::graph g;
    ReaderNode<fileKind> input(g, getW, initR, args...);

    using WriteType =
        std::conditional_t<fileKind == FileKind::AC_MolData3D,
                           std::tuple<std::size_t, std::vector<ProcessVector>>, ProcessSource>;

    tbb::flow::sequencer_node<WriteType> sequence_node(
        g, [](const WriteType& conf_ptr) { return std::get<std::size_t>(conf_ptr); });

    AS::Writer writer(as_filename, compress ? AS::AS_VERSION::_1 : AS::AS_VERSION::_0);
    boost::filesystem::remove(index_filename);
    WriterNode<WriteType> writer_node(g, index_filename, writer);

    tbb::flow::make_edge(input.source_node, input.preprocess_node);
    tbb::flow::make_edge(input.preprocess_node, sequence_node);
    tbb::flow::make_edge(sequence_node, writer_node.writer_node);

    input.source_node.activate();

    g.wait_for_all();
    writer_node.commit();

    std::cout << "Time elapsed : "
              << std::chrono::duration_cast<std::chrono::seconds>(std::chrono::steady_clock::now() -
                                                                  start)
                     .count()
              << " second(s)\n"
              << "Total Conformation number : " << writer_node.conformation_number << '\n'
              << "Total Molecule number : " << writer.get_total_molecule_number() << std::endl;
}

int Main(int argc, char* argv[]) {
    namespace po = boost::program_options;

    po::options_description options("Options");

    std::string sd_filename, as_filename, index_filename;
    std::string ac_filename, fraglib_name;

    int nthreads;
    bool compress;
    bool fast;

    // clang-format off
    options.add_options()
        ("help,h", "show this help message")
        ("sd", po::value(&sd_filename)->value_name("input_sdf_database"),
                    "conformation database in sdf format")
        ("sdgz", po::value(&sd_filename)->value_name("input_sd_gz_database"),
                    "conformation database in sdf gz format")
        ("sdbz2", po::value(&sd_filename)->value_name("input_sd_bz2_database"),
                    "conformation database in sdf bzip2 format")
        ("sdxz", po::value(&sd_filename)->value_name("input_sd_xz_database"),
                    "conformation database in sdf xz format")
        ("ac", po::value(&ac_filename)->value_name("input_ac_database"),
                    "conformation database in ac format")
        ("fraglib", po::value(&fraglib_name)->value_name("fraglib_name"),
                    "conformation frag library")
        ("as", po::value(&as_filename)->value_name("output_as_database"))
        ("index", po::value(&index_filename)->value_name("output_index_file"),
                    "index sqlite file")
        ("nthreads", po::value(&nthreads)->value_name("num_threads")->default_value(0),
                    "number of threads (0 for automatic mode)")
        ("compress", po::bool_switch(&compress)->default_value(false),
                    "used 2 Bytes compress mode for coordinate value")
        ("fast", po::bool_switch(&fast) ->default_value(false),
                    "use MolData3D");
    // clang-format on
    auto print_usage = [&] {
        std::cout
            << "Usage :" << argv[0]
            << " (--sd sd_database.sd | --sdgz sd_database.sd.gz | --sdbz2 sd_database.sd.bz2 | "
               "--sdxz sd_database.sd.xz | --ac ac_filename --fraglib fraglib_name [--fast]) --as "
               "as_database.as --index index.sqlite\n";
        std::cout << options;
    };
    po::variables_map vm;
    try {
        po::store(po::command_line_parser(argc, argv)
                      .options(options)
                      .style(po::command_line_style::unix_style |
                             po::command_line_style::allow_long_disguise)
                      .run(),
                  vm);
        po::notify(vm);
    } catch (std::exception& e) {
        std::cerr << e.what() << '\n';
        print_usage();
        std::exit(EXIT_FAILURE);
    }

    if (vm.contains("help")) {
        print_usage();
        std::exit(EXIT_SUCCESS);
    }

    for (const auto& key : {"as", "index"}) {
        if (!vm.contains(key)) {
            std::cerr << "--" << key << " must be specified" << std::endl;
            print_usage();
            std::exit(EXIT_FAILURE);
        }
    }
    if (vm.count("sd") or vm.contains("sdgz") or vm.contains("sdbz2") or vm.contains("sdxz"))
        check(sd_filename);
    else if (vm.contains("ac") and vm.contains("fraglib")) {
        check(ac_filename);
        check(fraglib_name + ".idx");
        check(fraglib_name + ".sd");
    } else {
        std::cout << "conformation database input error" << std::endl;
        return EXIT_FAILURE;
    }
    if (nthreads < 0) {
        std::cerr << "the number of threads must greater than 0 or just 0 (automatic mode)\n";
        std::exit(EXIT_FAILURE);
    }

    if (nthreads > sysconf(_SC_NPROCESSORS_ONLN)) {
        cout << "WARNING !! nthreads larger than max core of system CPU, will use automatic mode\n";
        nthreads = 0;
    }

    oneapi::tbb::global_control global_limit(
        oneapi::tbb::global_control::max_allowed_parallelism,
        nthreads == 0 ? oneapi::tbb::info::default_concurrency() : nthreads);

    if (vm.contains("sd"))
        preprocess<FileKind::SD>(compress, as_filename, index_filename, true, true, sd_filename);
    else if (vm.contains("sdgz"))
        preprocess<FileKind::SDGZ>(compress, as_filename, index_filename, true, true, sd_filename);
    else if (vm.contains("sdbz2"))
        preprocess<FileKind::SDBZ2>(compress, as_filename, index_filename, true, true, sd_filename);
    else if (vm.contains("sdxz"))
        preprocess<FileKind::SDXZ>(compress, as_filename, index_filename, true, true, sd_filename);
    else if (vm.contains("ac") and fast)
        preprocess<FileKind::AC_MolData3D>(compress, as_filename, index_filename, true, true,
                                           ac_filename, fraglib_name);
    else
        preprocess<FileKind::AC>(compress, as_filename, index_filename, true, true, ac_filename,
                                 fraglib_name);
    return EXIT_SUCCESS;
}
}  // namespace

int main(int argc, char* argv[]) {
    try {
        register_signals();

        return Main(argc, argv);
    } catch (std::exception& e) {
        std::cerr << "Exception(" << boost::typeindex::type_id_runtime(e).pretty_name()
                  << ") : " << e.what() << std::endl;
    } catch (...) {
        boost::typeindex::stl_type_index sti = *std::current_exception().__cxa_exception_type();
        std::cerr << "Exception(" << sti.pretty_name() << ")\n";
    }
    return EXIT_FAILURE;
}
