
/******************************************************************************
 * Principal function:                                                         *
 *    Shape matching result post-analysis
 *                                                                             *
 * Usage:
 *
 * Authors:                                                                    *
 *    Xia Miaoren,  Sep 2020
 *                                                                             *
 ******************************************************************************/

#include <cmath>
#include <cstring>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <iostream>

#include <boost/filesystem.hpp>
#include <boost/iostreams/device/mapped_file.hpp>
#include <boost/program_options.hpp>
#include <boost/range/adaptors.hpp>
#include <boost/range/algorithm.hpp>

#include <fmt/format.h>
#include <range/v3/all.hpp>
#include <sqlite_orm/sqlite_orm.h>

#include "ForceField/ffUtil.h"
#include "GShape/mfcGShape.hpp"
#include "IO/ASStructure.hpp"
#include "IO/SQLiteSchema.hpp"
#include "Misc/ssdUtil.h"
#include "MolStructure/mfcAtom.h"
#include "MolStructure/mfcMolecule.h"
#include "SQLiteCpp/SQLiteCpp.h"
#include "Topology/RingDecomposerLib_findSSSR.hpp"
#include "Topology/chemgraph.h"
#include "Topology/topology.h"
#include "Utils/mathUtil.hpp"
#include "Utils/mfcUtil.hpp"
#include "Utils/utils.hpp"

namespace {
using namespace MISS;
using namespace MISS::Optimize;

void do_alignment(const std::string &qsd_filename, const std::string &db_filename) {
    auto pharmacophore = load_pharmacophore_graph();
    auto queries = QueryItem::read_query(qsd_filename, pharmacophore);
    std::cout << "queries: " << queries.size() << "\n";

    for (auto &&[idx, query] : queries | boost::adaptors::indexed(1)) {
        std::ofstream align_result_ofs(queries.size() == 1
                                           ? "ResultsAlignWithQuery.sd"
                                           : fmt::format("ResultsAlignWithQuery_{}.sd", idx));
        SDReader sdReader2(db_filename);
        do {
            std::unique_ptr<MFCFrag> frag{sdReader2.readLargestMFCFrag()};
            if (frag) {
                auto db_frag = DBItem::process_db(std::move(frag), pharmacophore);
                overlay(db_frag, query, align_result_ofs);
            }
        } while (!sdReader2.endOfSD());
    }
}

int Main(int argc, char *argv[]) {
    namespace po = boost::program_options;

    po::options_description options("Options");

    std::string as_filename, qsd_filename, index_filename, screen_results, out;

    int limit_count;
    float limit_score;

    // clang-format off
    options.add_options()
            ("help,h", "show this help message")
            ("as", po::value(&as_filename)->value_name("input_as_database"),
             "conformation database in sdf format")
            ("qsd", po::value(&qsd_filename)->value_name("query_file"), "query_sd_filename")
            ("index", po::value(&index_filename)->value_name("output_index_file"), "index sqlite file")
            ("results", po::value(&screen_results)->value_name("output_screen_results_file"),
             "screen results file by shapeGPU_as")
            ("limit_count", po::value(&limit_count)->value_name("limit"), "limit count")
            ("limit_score", po::value(&limit_score)->value_name("limit"), "limit score cutoff")
            ("out", po::value(&out)->value_name("output_sd_file"), "output sd file");
    // clang-format on

    auto print_usage = [&] {
        std::cout << "Usage :" << argv[0]
                  << " --as as_database.as --qsd query.sd --index index.sqlite --results "
                     "results.sqlite --out out.sd (--limit_count limit | --limit_score limit)\n";
        std::cout << options;
    };
    po::variables_map vm;
    try {
        po::store(po::command_line_parser(argc, argv)
                      .options(options)
                      .style(po::command_line_style::unix_style |
                             po::command_line_style::allow_long_disguise)
                      .run(),
                  vm);
        po::notify(vm);
    } catch (std::exception &e) {
        std::cerr << e.what() << '\n';
        print_usage();
        std::exit(EXIT_FAILURE);
    }

    if (vm.count("help")) {
        print_usage();
        std::exit(EXIT_SUCCESS);
    }

    for (const auto &key : {"as", "qsd", "index", "results", "out"}) {
        if (!vm.count(key)) {
            std::cerr << "--" << key << " must be specified" << std::endl;
            print_usage();
            std::exit(EXIT_FAILURE);
        }
    }
    enum class COMPUTE_MODE { COUNT_ALL_QUERY, SCORE_ALL_QUERY } mode;

    if (vm.count("limit_count") and not vm.count("limit_score")) {
        mode = COMPUTE_MODE ::COUNT_ALL_QUERY;
        if (limit_count <= 0) {
            std::cerr << "limit_count must greater than 0\n";
            std::exit(EXIT_FAILURE);
        }
    } else if (not vm.count("limit_count") and vm.count("limit_score")) {
        mode = COMPUTE_MODE ::SCORE_ALL_QUERY;
        if (limit_score <= 0.0f or limit_score >= 1.0f) {
            std::cerr << "limit_score must in range of (0.0, 1.0)\n";
            std::exit(EXIT_FAILURE);
        }
    } else if (vm.count("limit_count") and vm.count("limit_score")) {
        std::cerr << "mode <limit_count> and <limit_score> can not be used simultaneously\n";
        return EXIT_FAILURE;
    } else {
        std::cerr << "mode <limit_count> and <limit_score> must choose one\n";
        return EXIT_FAILURE;
    }

    check(as_filename);
    check(qsd_filename);
    check(index_filename);
    check(screen_results);

    auto pharmacophore = load_pharmacophore_graph();

    boost::iostreams::mapped_file_source as_source(as_filename);

    constexpr std::string_view sdf_ending_pattern = "\n$$$$\n";
    std::cout << "target molecule name,query molecule name,similarity" << std::endl;

    boost::iostreams::mapped_file_source qsd_source(qsd_filename);
    auto queries = QueryItem::read_query(qsd_source.begin(), qsd_source.end(), pharmacophore);

    SQLite::Database db(":memory:");

    // open index and result sqlite database
    db.exec("attach '" + screen_results + "' as res");
    db.exec("attach '" + index_filename + "' as ind");

    if (db.execAndGet("PRAGMA res.application_id").getInt() != AlphaS_Result_File_Application_ID) {
        std::cerr << fmt::format("{} is not AlphaS Result File \n", screen_results);
        return EXIT_FAILURE;
    }
    if (db.execAndGet("PRAGMA ind.application_id").getInt() != AlphaS_Index_File_Application_ID) {
        std::cerr << fmt::format("{} is not AlphaS Index File \n", index_filename);
        return EXIT_FAILURE;
    }
    auto res_user_version = db.execAndGet("PRAGMA res.user_version").getInt();
    if (res_user_version != 0) {
        std::cerr << fmt::format("Result database version {} not supported!\n", res_user_version);
        return EXIT_FAILURE;
    }
    auto ind_user_version = db.execAndGet("PRAGMA ind.user_version").getInt();
    if (ind_user_version != 0 and ind_user_version != 1) {
        std::cerr << fmt::format("Index database version {} not supported!\n", ind_user_version);
        return EXIT_FAILURE;
    }
    if (ind_user_version == 0) {  // create sql view for keeping compatibility with old index file
        db.exec(
            "create temp view mol_offset as select mol_name.id as id, mol_name.name as name, "
            "min(conf_offset.offset)-3 as offset, mol_name.topology from ind.conf_offset inner "
            "join ind.mol_name where ind.conf_offset.mol_id == ind.mol_name.id group by "
            "ind.mol_name.id");
    }
    SQLite::Statement select_stmt = [&] {
        auto quoted_names = queries | ::ranges::views::transform([](const auto &q) {
                                return fmt::format(FMT_STRING("'{}'"), q.get_name());
                            }) |
                            ::ranges::to_vector;

        if (mode == COMPUTE_MODE::SCORE_ALL_QUERY) {  // select by score
            // very complex sql select statement for join database tables
            SQLite::Statement score_select_stmt(
                db,
                fmt::format("select {0}.name, {0}.topology, res.query_mol_name.name as "
                            "query_name, {0}.offset, res.result.conf_id, max(res.result.score) as "
                            "score from res.result inner join {0},res.query_mol_name on "
                            "{0}.id = (res.result.conf_id >> 16) and res.query_mol_name.id = "
                            "res.result.query_id where query_name in ({1}) group by "
                            "(res.result.conf_id >> 16) having score > ? order by score desc",
                            ind_user_version == 1 ? "ind.mol_offset" : "mol_offset",
                            fmt::join(quoted_names, ",")));

            score_select_stmt.bind(1, limit_score);
            return score_select_stmt;
        } else {  // select by count number
            // very complex sql select statement for join database tables
            SQLite::Statement count_select_stmt(
                db,
                fmt::format("select {0}.name, {0}.topology, res.query_mol_name.name as "
                            "query_name, {0}.offset, res.result.conf_id, max(res.result.score) as "
                            "score from res.result inner join {0},res.query_mol_name on "
                            "{0}.id = (res.result.conf_id >> 16) and res.query_mol_name.id = "
                            "res.result.query_id where query_name in ({1}) group by "
                            "(res.result.conf_id >> 16) order by score desc limit ?",
                            ind_user_version == 1 ? "ind.mol_offset" : "mol_offset",
                            fmt::join(quoted_names, ",")));
            count_select_stmt.bind(1, limit_count);
            return count_select_stmt;
        }
    }();
    AS::Reader<AS::MMapFile> as_reader(as_filename);

    double W1[10];  // weights for cross volume in molecular superposition
    double W2[10];  // weights for score function

    W1[0] = 1.0;
    W1[1] = 1.0;  // HBA in ownPharma
    W1[2] = 1.0;  // HBD
    W1[3] = 0.5;  // ARO
    W1[4] = 2.0;  // POS
    W1[5] = 2.0;  // NEG
    W1[6] = 2.0;  // HYD
    W1[7] = 1.0;  // for direction of HBA in overlay
    W1[8] = 1.0;  // for direction of HBD
    W1[9] = 0.5;  // for direction of ARO

    W2[0] = 1.0;
    W2[1] = 1.0;
    W2[2] = 1.0;
    W2[3] = 0.5;
    W2[4] = 2.0;
    W2[5] = 2.0;
    W2[6] = 2.0;
    W2[7] = 1.0;  // for direction of HBA in scoring
    W2[8] = 1.0;  // for direction of HBD
    W2[9] = 0.5;  // for direction of ARO

    double W[20];
    for (int i = 0; i < 10; i++) {
        W[i] = W1[i];
        W[i + 10] = W2[i];
    }

    for (int i = 0; i < 10; i++) {
        if (W[i] < 0.01) W[i] = 0.000001;
    }

    std::size_t count = 1;
    boost::filesystem::path out_basic_path(out);
    std::ofstream sdf_out(out);
    while (select_stmt.executeStep()) {
        std::string_view name = static_cast<const char *>(select_stmt.getColumn(0));
        auto blob_start = static_cast<const char *>(select_stmt.getColumn(1).getBlob());
        auto blob_size = select_stmt.getColumn(1).getBytes();
        auto topology = SdfTopology::from_blob(blob_start, blob_start + blob_size);
        std::string_view query_name = static_cast<const char *>(select_stmt.getColumn(2));
        int64_t offset = select_stmt.getColumn(3);
        std::size_t conf_id = select_stmt.getColumn(4).getInt64();
        double score = select_stmt.getColumn(5);
        std::cout << name << "," << query_name << "," << score << std::endl;

        std::stringstream ss;
        auto mol = as_reader.read_mol_from_offset(offset);
        auto conf_id_shift = conf_id & 0xFFFF;
        auto conf = mol.conformations.at(conf_id_shift);
        auto coord = conf.coordinates;
        topology.to_sdf(ss, name, coord);
        ss << "> <" << query_name << "_score>\n" << score << '\n' << sdf_ending_pattern;

        auto sdf_content = ss.str();
        SDReaderT<iStringFileStream> reader(sdf_content);
        std::unique_ptr<MFCFrag> frag{reader.readLargestMFCFrag()};
        if (frag) {
            std::ofstream sdf_sink((out_basic_path.parent_path() /
                                    (out_basic_path.stem().string() + "_" +
                                     std::to_string(count++) + out_basic_path.extension().string()))
                                       .string());
            std::ostringstream oss;

            auto q_it = boost::find_if(
                queries, [&](const QueryItem &q) { return q.get_name() == query_name; });
            if (q_it == std::end(queries)) {
                fmt::print(FMT_STRING("Query name '{}' not found \n"), query_name);
                std::exit(EXIT_FAILURE);
            }
            auto [simi, xyz] = calc_similarity<true>(conf, *q_it, W);

            if (auto diff = std::abs(simi - score); diff > 0.01)
                std::cerr << fmt::format(
                    "WARNING!! reproduce_score = {}, db_score = {}, difference = {}\n", simi, score,
                    diff);

            setFragXYZ(frag.get(), xyz.data(), onlyHeavyAtoms);
            writeMFCFrag2SD(frag.get(), oss, onlyHeavyAtoms);

            auto sdf_string = oss.str();
            sdf_sink << sdf_string << *q_it;
            sdf_out << sdf_string;
        }
    }
    return EXIT_SUCCESS;
}
}  // namespace

int main(int argc, char *argv[]) {
    try {
        register_signals();

        return Main(argc, argv);
    } catch (std::exception &e) {
        std::cerr << "Exception(" << boost::typeindex::type_id_runtime(e).pretty_name()
                  << ") : " << e.what() << std::endl;
    } catch (...) {
        boost::typeindex::stl_type_index sti = *std::current_exception().__cxa_exception_type();
        std::cerr << "Exception(" << sti.pretty_name() << ")\n";
    }
    return EXIT_FAILURE;
}
