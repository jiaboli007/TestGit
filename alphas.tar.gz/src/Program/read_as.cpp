#include <csignal>
#include <iostream>

#include <boost/program_options.hpp>
#include <boost/range/adaptors.hpp>
#include <boost/range/combine.hpp>
#include <boost/range/join.hpp>

#include <fmt/format.h>
#include <fmt/ostream.h>

#include "IO/ASStructure.hpp"
#include "Utils/utils.hpp"

namespace {
using namespace MISS;

void print_content(const std::string &as_filename) {
    AS::Reader reader(as_filename);
    const auto &header = reader.get_header();

    fmt::print(FMT_STRING(" # uuid = {} total_molecule_number = {} version = {}{}\n"), header.uuid,
               header.total_molecule_number, header.version,
               header.version == AS::AS_VERSION::_1 ? " (compress mode)" : "");

    std::size_t mol_count{}, conf_count{};

    try {
        while (reader) {
            auto mol = reader.read_mol();
            mol_count++;
            fmt::print(
                FMT_STRING("\n Mol No. = {}  heavy_atom_number = {}  Conformation_Number = {}\n"),
                mol_count, static_cast<uint32_t>(mol.header.heavy_atom_number),
                mol.header.conformations_number);

            for (const auto &conf : mol.conformations) {
                conf_count++;
                fmt::print(
                    FMT_STRING(
                        " Conf No. = {} coordinate_number = {} pharma_feature_number = {}\n"),
                    conf_count, conf.coordinates.size(), conf.pharmaFeatures.size());

                fmt::print(FMT_STRING(" coordinates and weights: \n"));
                for (const auto &[i, coord_wt] :
                     boost::combine(conf.coordinates, conf.wt) | boost::adaptors::indexed(0)) {
                    const auto &[coord, wt] = coord_wt;
                    const auto &[x, y, z] = coord;
                    fmt::print(FMT_STRING("x[{0:2}] = {1:6.2f} y[{0:2}] = {2:6.2f} z[{0:2}] "
                                          "={3:6.2f} w[{0:2}] = {4:6.2f}\n"),
                               i, x, y, z, wt);
                }

                fmt::print(
                    FMT_STRING(
                        " features :  HBA = {} HBD = {} ARO = {} POS = {} NEG = {} HYD = {}\n"),
                    static_cast<uint32_t>(conf.pharma_feature_numbers[AS::HBA]),
                    static_cast<uint32_t>(conf.pharma_feature_numbers[AS::HBD]),
                    static_cast<uint32_t>(conf.pharma_feature_numbers[AS::ARO]),
                    static_cast<uint32_t>(conf.pharma_feature_numbers[AS::POS]),
                    static_cast<uint32_t>(conf.pharma_feature_numbers[AS::NEG]),
                    static_cast<uint32_t>(conf.pharma_feature_numbers[AS::HYD]));

                for (const auto &[i, feat] : conf.pharmaFeatures | boost::adaptors::indexed(0)) {
                    const auto &[x, y, z] = feat;
                    fmt::print(
                        FMT_STRING("x[{0:2}] = {1:6.2f} y[{0:2}] = {2:6.2f} z[{0:2}] = {3:6.2f}\n"),
                        i, x, y, z);
                }
                fmt::print(FMT_STRING(" volume :\n"));
                std::array conf_vol{conf.vol};
                for (auto [i, vol] :
                     boost::join(conf_vol, conf.selfVol) | boost::adaptors::indexed(0)) {
                    fmt::print(FMT_STRING("vol[{}] = {:6.2f}{}"), i, vol, i == 4 ? '\n' : ' ');
                }
                fmt::print(FMT_STRING("\n"));
            }
        }
    } catch (const std::ios_base::failure &e) {
        std::cerr << "Exception : " << e.what() << std::endl;
    }
}

int Main(int argc, char *argv[]) {
    namespace po = boost::program_options;

    po::options_description options("Options");

    std::string as_filename;
    // clang-format off
    options.add_options()
        ("help,h", "show this help message")
        ("as", po::value<std::string>(&as_filename)->value_name("as_database"),
            "preprocessed database in as format");
    // clang-format on

    po::positional_options_description positional_options;
    positional_options.add("ac", 1);
    po::variables_map vm;

    auto print_usage = [&] {
        std::cout << "Usage :" << argv[0] << " [--as] as_database.as\n";
        std::cout << options;
    };
    try {
        po::store(po::command_line_parser(argc, argv)
                      .options(options)
                      .positional(positional_options)
                      .style(po::command_line_style::unix_style |
                             po::command_line_style::allow_long_disguise)
                      .run(),
                  vm);
        po::notify(vm);
    } catch (std::exception &e) {
        std::cerr << e.what() << '\n';
        print_usage();
        std::exit(EXIT_FAILURE);
    }

    if (vm.count("help")) {
        print_usage();
        std::exit(EXIT_SUCCESS);
    }

    if (!vm.count("as")) {
        std::cerr << "--as must be specified" << std::endl;
        print_usage();
        std::exit(EXIT_FAILURE);
    }

    check(as_filename);

    print_content(as_filename);
    return EXIT_SUCCESS;
}
}  // namespace

int main(int argc, char *argv[]) {
    try {
        register_signals();

        return Main(argc, argv);
    } catch (std::exception &e) {
        std::cerr << "Exception(" << boost::typeindex::type_id_runtime(e).pretty_name()
                  << ") : " << e.what() << std::endl;
    } catch (...) {
        boost::typeindex::stl_type_index sti = *std::current_exception().__cxa_exception_type();
        std::cerr << "Exception(" << sti.pretty_name() << ")\n";
    }
    return EXIT_FAILURE;
}
