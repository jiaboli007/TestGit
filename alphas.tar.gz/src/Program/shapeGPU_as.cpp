/******************************************************************************
 * Principal function:                                                         *
 *    GPU version for molecule shape overlay: standalone and Server version
 *                                                                             *
 * Usage:
 *
 * Authors:                                                                    *
 *    Xia Miaoren,  Sep 2020
 *                                                                             *
 ******************************************************************************/
#include <algorithm>
#include <fstream>
#include <future>
#include <iostream>
#include <vector>

#include <boost/filesystem.hpp>
#include <boost/program_options.hpp>
#include <boost/range/adaptors.hpp>
#include <boost/range/algorithm.hpp>
#include <boost/range/algorithm_ext.hpp>
#include <boost/range/numeric.hpp>
#include <boost/scope_exit.hpp>

#include <tbb/tbb.h>

#include <cuda.h>
#include <cuda_runtime_api.h>
#include <fmt/format.h>
#include <sqlite_orm/sqlite_orm.h>

#include "GPU/GPUEngine.hpp"
#include "IO/ASStructure.hpp"
#include "IO/Database.hpp"
#include "IO/DatabaseUtil.hpp"
#include "IO/QueryInfo.hpp"
#include "IO/QueryReader.hpp"
#include "IO/ResultDatabase.hpp"
#include "IO/SQLiteSchema.hpp"
#include "Utils/cuda_utility.hpp"

namespace {
using namespace MISS;

std::vector<QueryResult> do_screen(const string &as_filename, vector<QueryInfo> &queries,
                                   double real_gpu_mem, const float *W, const int topN,
                                   int queue_bound) {
    //
    // read database molecules
    //
    DatabaseUtil db_util(as_filename, real_gpu_mem);

    auto total_molecule_number_in_as = db_util.get_total_molecule_number();

    auto desc_cmp = [](const auto &lhs, const auto &rhs) { return lhs.score > rhs.score; };

    auto t0 = tbb::tick_count::now();
    auto t1 = t0;

    std::vector<std::vector<QueryResult>> screen_results(queries.size());

    tbb::flow::graph g;

    std::atomic<bool> finish_flag{false};
    std::size_t sequence_number{0};
    tbb::flow::input_node<std::tuple<std::size_t, boost::optional<Database>>> source_node(
        g, [&](tbb::flow_control &fc) -> std::tuple<std::size_t, boost::optional<Database>> {
            if (auto db_opt = db_util.load(); db_opt.has_value()) {
                return {sequence_number++, std::move(db_opt)};
            } else if (!finish_flag) {
                finish_flag.store(true);
                return {sequence_number++, std::move(db_opt)};
            }
            fc.stop();
            return {};
        });

    tbb::flow::function_node<std::tuple<std::size_t, boost::optional<Database>>,
                             std::shared_ptr<std::tuple<std::size_t, boost::optional<Database>,
                                                        std::unique_ptr<GPUEngine>>>>
        preprocess_node(g, tbb::flow::unlimited, [&](auto &db) {
            auto engine =
                std::get<boost::optional<Database>>(db).has_value()
                    ? std::make_unique<GPUEngine>(*std::get<boost::optional<Database>>(db))
                    : std::unique_ptr<GPUEngine>{};

            return std::make_shared<
                std::tuple<std::size_t, boost::optional<Database>, std::unique_ptr<GPUEngine>>>(
                std::get<std::size_t>(db), std::move(std::get<boost::optional<Database>>(db)),
                std::move(engine));
        });

    tbb::flow::sequencer_node<std::shared_ptr<
        std::tuple<std::size_t, boost::optional<Database>, std::unique_ptr<GPUEngine>>>>
        sequence_node(g, [](const auto &db) { return std::get<std::size_t>(*db); });

    tbb::concurrent_bounded_queue<std::shared_ptr<
        std::tuple<std::size_t, boost::optional<Database>, std::unique_ptr<GPUEngine>>>>
        queue;
    queue.set_capacity(queue_bound);

    tbb::flow::function_node<std::shared_ptr<
        std::tuple<std::size_t, boost::optional<Database>, std::unique_ptr<GPUEngine>>>>
        writer_node(g, tbb::flow::serial, [&](auto &db_) { queue.push(std::move(db_)); });

    tbb::flow::make_edge(source_node, preprocess_node);
    tbb::flow::make_edge(preprocess_node, sequence_node);
    tbb::flow::make_edge(sequence_node, writer_node);

    source_node.activate();

    size_t total_molecule_offset = 1 << 16;
    std::size_t round_ = 0;
    auto print_round = [&round_] {
        std::cout << fmt::format(FMT_STRING("\n>>> ------ Round {} ------ <<<\n"), ++round_);
        return true;
    };

    std::size_t total_molecule_number_processed = 0;
    while (true) {
        std::shared_ptr<
            std::tuple<std::size_t, boost::optional<Database>, std::unique_ptr<GPUEngine>>>
            db_;
        queue.pop(db_);
        auto &[_, db, gpu] = *db_;
        if (!db.has_value()) break;

        print_round();

        const auto total_molecule_number = db->conformations_number_per_mol.size();
        const auto total_conformation_number = db->nHeavyAtom.size();

        auto t2 = tbb::tick_count::now();
        cout << "database load time: " << (t2 - t1).seconds() << endl;

        cout << "average Heavy Atoms: " << db->all_heavy_atoms / total_conformation_number << "\n";
        cout << "number of molecules     in database: " << total_molecule_number << "\n";
        cout << "number of conformations in database: " << total_conformation_number << "\n";

	cout << "Copy db to device\n";
    auto tdb0 = tbb::tick_count::now();

        gpu->copy_db_to_device();
    auto tdb1 = tbb::tick_count::now();
        cout << "gpu_copy_db_to_device: " << (tdb1 - tdb0).seconds() << endl;

        cout << "copy host memory to device time: " << (tbb::tick_count::now() - t2).seconds()
             << endl;
        float *simi;
        gpuErrChk(cudaHostAlloc((void **)&simi, total_conformation_number * sizeof(float),
                                cudaHostAllocDefault));

        for (auto &&[id, q] : queries | boost::adaptors::indexed(1)) {
            cout << fmt::format(FMT_STRING("qid : {} name : {}\t"), id, q.name);
            auto gpu_t1 = tbb::tick_count::now();
            gpu->query(q, W, simi);
            auto gpu_t2 = tbb::tick_count::now();

            auto scores_index = find_score_record(simi, db->conformations_number_per_mol);

            if (topN > 0) {
                boost::nth_element(scores_index, min(begin(scores_index) + topN, end(scores_index)),
                                   desc_cmp);
            }
            for (auto i :
                 boost::irange(min(scores_index.size(),
                                   topN > 0 ? topN : std::numeric_limits<std::size_t>::max()))) {
                screen_results[id - 1].push_back({scores_index[i].idx + total_molecule_offset,
                                                  static_cast<size_t>(id), scores_index[i].score});
            }
            std::cout << fmt::format(FMT_STRING("GPU time : {:.6f} <> CPU time : {:.6f}\n"),
                                     (gpu_t2 - gpu_t1).seconds(),
                                     (tbb::tick_count::now() - gpu_t2).seconds());
        }
        gpuErrChk(cudaFreeHost((void *)simi));
        if (topN > 0) {
            for (auto i : boost::irange(queries.size())) {
                boost::nth_element(screen_results[i],
                                   min(begin(screen_results[i]) + topN, end(screen_results[i])),
                                   desc_cmp);
                screen_results[i].resize(min<std::size_t>(screen_results[i].size(), topN));
            }
        }
        t1 = tbb::tick_count::now();
        total_molecule_offset += total_molecule_number << 16;

        total_molecule_number_processed += total_molecule_number;
        cout << fmt::format(
            FMT_STRING(">>>> progress: {}/{}  {:6.2f}% remain {} seconds <<<<\n"),
            total_molecule_number_in_as - total_molecule_number_processed,
            total_molecule_number_in_as,
            total_molecule_number_processed * 100.0 / total_molecule_number_in_as,
            static_cast<int>((total_molecule_number_in_as - total_molecule_number_processed) *
                             (t1 - t0).seconds() / total_molecule_number_processed));
    }

    g.wait_for_all();

    if (queries.size() == 1) {  // Only one query is used
        tbb::parallel_sort(screen_results.front(), desc_cmp);
        return screen_results.front();
    }

    std::vector<QueryResult> screen_results_all;
    screen_results_all.reserve(boost::accumulate(
        screen_results, 0UL, [](auto init, const auto &res) { return init + res.size(); }));
    for (auto &res : screen_results) {
        screen_results_all.insert(screen_results_all.end(), res.begin(), res.end());
    }
    tbb::parallel_sort(screen_results_all, desc_cmp);

    return screen_results_all;
}

int Main(int argc, char *argv[]) {
    namespace po = boost::program_options;

    po::options_description options("Options");

    std::string as_filename;
    std::string query_sd_filename;
    std::string result_db;

    int topN;  // the N most similar molecules
    double gpu_mem;
    double gpu_mem_scale;
    int nthreads;
    int queue_bound;

    // clang-format off
    options.add_options()
        ("help,h", "show this help message")
        ("as", po::value<std::string>(&as_filename)->value_name("as_database"),
                                              "preprocessed database in as format")
        ("qsd", po::value(&query_sd_filename)->value_name("query_file"), "query_sd_filename")
        ("outdb", po::value(&result_db)->value_name("output_screen_results_file"),
                                              "screen results file")
        ("TN", po::value(&topN)->value_name("topN")->default_value(1000),
                                              "the N most similar molecules, -1 to unlimited")
        ("GpuMem", po::value<double>()->value_name("GPU Mem(GB)"),"GPU memory to be used")
        ("GpuScale", po::value(&gpu_mem_scale)->value_name("gpu_mem_scale")->default_value(1.35),
                                              "GPU memory scale value")
        ("nthreads", po::value(&nthreads)->value_name("num_threads")->default_value(2),
                                              "number of threads (0 for automatic mode)")
        ("queue_bound", po::value(&queue_bound)->value_name("queue_bound")->default_value(1),
                                              "the maximum number of values that the queue can hold");
    // clang-format on

    po::variables_map vm;

    auto print_usage = [&] {
        std::cout << "Usage :" << argv[0]
                  << " --as database.as --qsd query.sd --TN 1000 --outdb results.sqlite\n";
        std::cout << options;
    };
    try {
        po::store(po::command_line_parser(argc, argv)
                      .options(options)
                      .style(po::command_line_style::unix_style |
                             po::command_line_style::allow_long_disguise)
                      .run(),
                  vm);
        po::notify(vm);
    } catch (std::exception &e) {
        std::cerr << e.what() << '\n';
        print_usage();
        std::exit(EXIT_FAILURE);
    }

    if (vm.contains("help")) {
        print_usage();
        std::exit(EXIT_SUCCESS);
    }

    for (const auto &key : {"as", "qsd", "outdb"}) {
        if (!vm.contains(key)) {
            std::cerr << "--" << key << " must be specified" << std::endl;
            print_usage();
            std::exit(EXIT_FAILURE);
        }
    }
    if (topN < 0 and topN != -1) {
        std::cerr << "irregular topN number: " << topN << "\n";
        std::cerr << "topN should be a non-negative integer\n";
        std::exit(EXIT_FAILURE);
    }

    if (gpu_mem_scale <= 1.0) {
        std::cerr << "irregular gpu_mem_scale number: " << gpu_mem_scale << "\n";
        std::cerr << "gpu_mem_scale should be a  double greater than one\n";
        std::exit(EXIT_FAILURE);
    }
    if (nthreads < 0 or nthreads == 1) {
        std::cerr << "the number of threads must greater than 1 or just 0 (automatic mode)\n";
        std::exit(EXIT_FAILURE);
    }
    if (queue_bound < 1) {
        std::cerr << "queue_bound must greater than 0\n";
        std::exit(EXIT_FAILURE);
    }

    auto t0 = tbb::tick_count::now();

    int deviceCount = 0;
    gpuErrChk(cudaGetDeviceCount(&deviceCount));

    if (deviceCount == 0) {
        std::cout << "There is no device supporting CUDA!\nPlease run with CPU version\n";
        std::exit(EXIT_FAILURE);
    } else {
        std::cout << "Found " << deviceCount << " CUDA Capable device(s)\n";
        int deviceId;
        gpuErrChk(cudaGetDevice(&deviceId));
        cudaDeviceProp prop;
        gpuErrChk(cudaGetDeviceProperties(&prop, deviceId));
        fmt::print(FMT_STRING("     >>> Current Device <<<\n"
                              "         Device id : {}\n"
                              "              Name : {}\n"
                              "Compute capability : {}.{}\n"
                              "       ECC enabled : {}\n"
                              "     Global memory : {} MB\n"
                              " Number of engines : {}\n\n"),
                   deviceId, prop.name, prop.major, prop.minor, static_cast<bool>(prop.ECCEnabled),
                   static_cast<std::size_t>(prop.totalGlobalMem / 1024.0 / 1024),
                   prop.asyncEngineCount);

        gpuErrChk(cudaSetDeviceFlags(cudaDeviceScheduleBlockingSync));

        if (!vm.contains("GpuMem"))
            gpu_mem = prop.totalGlobalMem / 1024.0 / 1024 / 1024 * 0.25;
        else
            gpu_mem = vm["GpuMem"].as<double>();
        std::cout << ">>> set GpuMem to " << gpu_mem << " GB\n";
        if (gpu_mem <= 0.0) {
            std::cerr << "irregular gpu_mem number: " << gpu_mem << "\n";
            std::cerr << "gpu_mem should be a non-negative double\n";
            std::exit(EXIT_FAILURE);
        }
    }

    check(as_filename);
    check(query_sd_filename);

    float W1[10];  // weights for cross volume in molecular superposition
    float W2[10];  // weights for score function

    constexpr bool initR = true;
    constexpr bool getW = true;

    W1[0] = 1.0;
    W1[1] = 1.0;  // HBA in ownPharma
    W1[2] = 1.0;  // HBD
    W1[3] = 0.5;  // ARO
    W1[4] = 2.0;  // POS
    W1[5] = 2.0;  // NEG
    W1[6] = 2.0;  // HYD
    W1[7] = 1.0;  // for direction of HBA in overlay
    W1[8] = 1.0;  // for direction of HBD
    W1[9] = 0.5;  // for direction of ARO

    W2[0] = 1.0;
    W2[1] = 1.0;
    W2[2] = 1.0;
    W2[3] = 0.5;
    W2[4] = 2.0;
    W2[5] = 2.0;
    W2[6] = 2.0;
    W2[7] = 1.0;  // for direction of HBA in scoring
    W2[8] = 1.0;  // for direction of HBD
    W2[9] = 0.5;  // for direction of ARO

    float W[20];
    for (int i = 0; i < 10; i++) {
        W[i] = W1[i];
        W[i + 10] = W2[i];
    }

    for (int i = 0; i < 10; i++) {
        if (W[i] < 0.01) W[i] = 0.000001;
    }
    std::cout << "\n";

    std::vector<QueryInfo> queries;
    QueryReader reader(query_sd_filename, getW, initR);
    std::copy(reader.begin(), reader.end(), std::back_inserter(queries));

    oneapi::tbb::global_control global_limit(
        oneapi::tbb::global_control::max_allowed_parallelism,
        nthreads == 0 ? oneapi::tbb::info::default_concurrency() : nthreads);

    auto screen_results =
        do_screen(as_filename, queries, gpu_mem / gpu_mem_scale, W, topN, queue_bound);

    boost::filesystem::remove(result_db);  // remove result db if exists;

    output_result(screen_results, queries, result_db);

    std::cout << "Total time: " << (tbb::tick_count::now() - t0).seconds() << " second(s)"
              << std::endl;
    return EXIT_SUCCESS;
}
}  // namespace

int main(int argc, char *argv[]) {
    try {
        register_signals();

        return Main(argc, argv);
    } catch (std::exception &e) {
        std::cerr << "Exception(" << boost::typeindex::type_id_runtime(e).pretty_name()
                  << ") : " << e.what() << std::endl;
    } catch (...) {
        boost::typeindex::stl_type_index sti = *std::current_exception().__cxa_exception_type();
        std::cerr << "Exception(" << sti.pretty_name() << ")\n";
    }
    return EXIT_FAILURE;
}
