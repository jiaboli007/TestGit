
#include <fstream>
#include <future>
#include <iostream>
#include <vector>

#include <boost/filesystem.hpp>
#include <boost/program_options.hpp>
#include <boost/range/adaptors.hpp>
#include <boost/range/algorithm.hpp>
#include <boost/range/algorithm_ext.hpp>
#include <boost/range/numeric.hpp>
#include <boost/scope_exit.hpp>

#include <tbb/tbb.h>

#include <fmt/format.h>
#include <sqlite_orm/sqlite_orm.h>

#include "IO/ASStructure.hpp"
#include "IO/Database.hpp"
#include "IO/DatabaseUtil.hpp"
#include "IO/QueryInfo.hpp"
#include "IO/QueryReader.hpp"
#include "IO/ResultDatabase.hpp"
#include "IO/SQLiteSchema.hpp"
#include "Utils/utils.hpp"

namespace {
using namespace MISS;

std::vector<QueryResult> do_screen(const string &as_filename,
                                   std::vector<Optimize::QueryItem> &queries, double *W,
                                   const int topN) {
    auto desc_cmp = [](const auto &lhs, const auto &rhs) { return lhs.score > rhs.score; };

    std::vector<std::vector<QueryResult>> screen_results(queries.size());

    AS::Reader<AS::MMapFile> reader(as_filename);

    const auto total_molecule_number = reader.get_header().total_molecule_number;

    tbb::flow::graph g;

    size_t total_molecule_offset = 1, total_conformation_offset = 1;

    tbb::flow::input_node<std::tuple<std::size_t, std::shared_ptr<AS::Molecule>>> source_node(
        g, [&](tbb::flow_control &fc) -> std::tuple<std::size_t, std::shared_ptr<AS::Molecule>> {
            if (reader) {
                std::tuple<std::size_t, std::shared_ptr<AS::Molecule>> molecule;
                std::get<std::size_t>(molecule) = total_molecule_offset;
                auto mol = reader.read_mol();
                ++total_molecule_offset;
                total_conformation_offset += mol.conformations.size();
                std::get<std::shared_ptr<AS::Molecule>>(molecule) =
                    std::make_shared<AS::Molecule>(std::move(mol));
                return molecule;
            }
            fc.stop();
            return {};
        });

    tbb::flow::function_node<std::tuple<std::size_t, std::shared_ptr<AS::Molecule>>,
                             std::vector<std::vector<QueryResult>>>
        preprocess_node(g, tbb::flow::unlimited, [&](auto &mol) {
            std::vector<std::vector<QueryResult>> screen_results(queries.size());
            for (auto &&[id, query] : queries | boost::adaptors::indexed(1)) {
	        std::cout << "Loop over query\n"; 
                auto total_conformation_offset = std::get<std::size_t>(mol) << 16;
                std::pair<std::size_t, double> max_smi{0, 0.0};
		std::cout << "Loop over DB mol\n";
                for (auto &conf : std::get<std::shared_ptr<AS::Molecule>>(mol)->conformations) {
		    std::cout << "Loop over conf of mol\n";
                    auto smi = Optimize::calc_similarity(conf, query, W);
                    if (smi > max_smi.second) {
                        max_smi = std::make_pair(total_conformation_offset, smi);
                    }
                    total_conformation_offset++;
                }
                screen_results[id - 1].push_back(
                    {max_smi.first, static_cast<size_t>(id), max_smi.second});
            }
            return screen_results;
        });

    auto resize_results = [&] {
        if (topN > 0) {
            for (auto i : boost::irange(queries.size())) {
                boost::nth_element(screen_results[i],
                                   min(begin(screen_results[i]) + topN, end(screen_results[i])),
                                   desc_cmp);
                screen_results[i].resize(min<std::size_t>(screen_results[i].size(), topN));
            }
        }
    };

    tbb::flow::function_node<std::vector<std::vector<QueryResult>>> writer_node(
        g, tbb::flow::serial, [&](auto &result) {
            for (const auto &[id, rv] : result | boost::adaptors::indexed())
                for (auto &r : rv) screen_results[id].push_back(r);

            resize_results();
        });

    tbb::flow::make_edge(source_node, preprocess_node);
    tbb::flow::make_edge(preprocess_node, writer_node);

    source_node.activate();
    g.wait_for_all();

    auto print_end = [&] {
        cout << "number of molecules     in database: " << total_molecule_number << "\n";
        cout << "number of conformations in database: " << total_conformation_offset - 1 << "\n";
    };
    if (queries.size() == 1) {  // Only one query is used
        tbb::parallel_sort(screen_results.front(), desc_cmp);
        print_end();
        return screen_results.front();
    }

    std::vector<QueryResult> screen_results_all;
    screen_results_all.reserve(boost::accumulate(
        screen_results, 0UL, [](auto init, const auto &res) { return init + res.size(); }));
    for (auto &res : screen_results) {
        screen_results_all.insert(screen_results_all.end(), res.begin(), res.end());
    }
    tbb::parallel_sort(screen_results_all, desc_cmp);
    print_end();
    return screen_results_all;
}

int Main(int argc, char *argv[]) {
    namespace po = boost::program_options;

    po::options_description options("Options");

    std::string as_filename;
    std::string query_sd_filename;
    std::string result_db;

    int topN;  // the N most similar molecules
    int nthreads;

    // clang-format off
    options.add_options()
        ("help,h", "show this help message")
        ("as", po::value<std::string>(&as_filename)->value_name("as_database"),
                                              "preprocessed database in as format")
        ("qsd", po::value(&query_sd_filename)->value_name("query_file"), "query_sd_filename")
        ("outdb", po::value(&result_db)->value_name("output_screen_results_file"),
                                              "screen results file")
        ("TN", po::value(&topN)->value_name("topN")->default_value(1000),
                                              "the N most similar molecules, -1 to unlimited")
        ("nthreads", po::value(&nthreads)->value_name("num_threads")->default_value(0),
                                              "number of threads (0 for automatic mode)");
    // clang-format on

    po::variables_map vm;

    auto print_usage = [&] {
        std::cout << "Usage :" << argv[0]
                  << " --as database.as --qsd query.sd --TN 1000 --outdb results.sqlite\n";
        std::cout << options;
    };
    try {
        po::store(po::command_line_parser(argc, argv)
                      .options(options)
                      .style(po::command_line_style::unix_style |
                             po::command_line_style::allow_long_disguise)
                      .run(),
                  vm);
        po::notify(vm);
    } catch (std::exception &e) {
        std::cerr << e.what() << '\n';
        print_usage();
        std::exit(EXIT_FAILURE);
    }

    if (vm.count("help")) {
        print_usage();
        std::exit(EXIT_SUCCESS);
    }

    for (const auto &key : {"as", "qsd", "outdb"}) {
        if (!vm.count(key)) {
            std::cerr << "--" << key << " must be specified" << std::endl;
            print_usage();
            std::exit(EXIT_FAILURE);
        }
    }
    if (topN < 0 and topN != -1) {
        std::cerr << "irregular topN number: " << topN << "\n";
        std::cerr << "topN should be a non-negative integer\n";
        std::exit(EXIT_FAILURE);
    }
    if (nthreads < 0) {
        std::cerr << "the number of threads must greater than 0 or just 0 (automatic mode)\n";
        std::exit(EXIT_FAILURE);
    }

    check(as_filename);
    check(query_sd_filename);

    auto t0 = tbb::tick_count::now();

    double W1[10];  // weights for cross volume in molecular superposition
    double W2[10];  // weights for score function

    constexpr bool initR = true;
    constexpr bool getW = true;

    W1[0] = 1.0;
    W1[1] = 1.0;  // HBA in ownPharma
    W1[2] = 1.0;  // HBD
    W1[3] = 0.5;  // ARO
    W1[4] = 2.0;  // POS
    W1[5] = 2.0;  // NEG
    W1[6] = 2.0;  // HYD
    W1[7] = 1.0;  // for direction of HBA in overlay
    W1[8] = 1.0;  // for direction of HBD
    W1[9] = 0.5;  // for direction of ARO

    W2[0] = 1.0;
    W2[1] = 1.0;
    W2[2] = 1.0;
    W2[3] = 0.5;
    W2[4] = 2.0;
    W2[5] = 2.0;
    W2[6] = 2.0;
    W2[7] = 1.0;  // for direction of HBA in scoring
    W2[8] = 1.0;  // for direction of HBD
    W2[9] = 0.5;  // for direction of ARO

    double W[20];
    for (int i = 0; i < 10; i++) {
        W[i] = W1[i];
        W[i + 10] = W2[i];
    }

    for (int i = 0; i < 10; i++) {
        if (W[i] < 0.01) W[i] = 0.000001;
    }
    std::cout << "\n";

    auto pharmacophore = Optimize::load_pharmacophore_graph();
    auto queries = Optimize::QueryItem::read_query(query_sd_filename, pharmacophore);

    oneapi::tbb::global_control global_limit(
        oneapi::tbb::global_control::max_allowed_parallelism,
        nthreads == 0 ? oneapi::tbb::info::default_concurrency() : nthreads);

    auto screen_results = do_screen(as_filename, queries, W, topN);

    boost::filesystem::remove(result_db);  // remove result db if exists;

    output_result(screen_results, queries, result_db);

    std::cout << "Total time: " << (tbb::tick_count::now() - t0).seconds() << " second(s)"
              << std::endl;
    return EXIT_SUCCESS;
}
}  // namespace

int main(int argc, char *argv[]) {
    try {
        register_signals();

        return Main(argc, argv);
    } catch (std::exception &e) {
        std::cerr << "Exception(" << boost::typeindex::type_id_runtime(e).pretty_name()
                  << ") : " << e.what() << std::endl;
    } catch (...) {
        boost::typeindex::stl_type_index sti = *std::current_exception().__cxa_exception_type();
        std::cerr << "Exception(" << sti.pretty_name() << ")\n";
    }
    return EXIT_FAILURE;
}
