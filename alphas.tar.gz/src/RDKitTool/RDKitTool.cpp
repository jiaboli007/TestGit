
#include <cassert>

#include <Geometry/point.h>
#include <GraphMol/Depictor/RDDepictor.h>
#include <GraphMol/FileParsers/FileParsers.h>
#include <GraphMol/FileParsers/MolSupplier.h>
#include <GraphMol/FileParsers/MolWriters.h>
#include <GraphMol/RDKitBase.h>
#include <GraphMol/SmilesParse/SmilesParse.h>
#include <GraphMol/SmilesParse/SmilesWrite.h>
#include <RDGeneral/Ranking.h>

#include "RDKitTool.hpp"

#include "ForceField/ffUtil.h"
#include "MolStructure/mfcBond.h"
#include "MolStructure/mfcMolecule.h"
#include "RDKitTool/RDKitTool.hpp"
#include "Topology/topology.h"
#include "Utils/mfcUtil.hpp"

using namespace RDKit;
using namespace MISS;

namespace {
unsigned int getAtomParityFlag(const Atom *atom, const Conformer *conf) {
    PRECONDITION(atom, "bad atom");
    PRECONDITION(conf, "bad conformer");
    if (!conf->is3D() || !(atom->getDegree() >= 3 && atom->getTotalDegree() == 4)) {
        return 0;
    }

    const ROMol &mol = atom->getOwningMol();
    RDGeom::Point3D pos = conf->getAtomPos(atom->getIdx());
    std::vector<std::pair<unsigned int, RDGeom::Point3D>> vs;
    ROMol::ADJ_ITER nbrIdx, endNbrs;
    boost::tie(nbrIdx, endNbrs) = mol.getAtomNeighbors(atom);
    while (nbrIdx != endNbrs) {
        const Atom *at = mol.getAtomWithIdx(*nbrIdx);
        unsigned int idx = at->getIdx();
        RDGeom::Point3D v = conf->getAtomPos(idx);
        v -= pos;
        if (at->getAtomicNum() == 1) {
            idx += mol.getNumAtoms();
        }
        vs.push_back(std::make_pair(idx, v));
        ++nbrIdx;
    }
    std::sort(vs.begin(), vs.end(), Rankers::pairLess<unsigned int, RDGeom::Point3D>());
    double vol;
    if (vs.size() == 4) {
        vol = vs[0].second.crossProduct(vs[1].second).dotProduct(vs[3].second);
    } else {
        vol = -vs[0].second.crossProduct(vs[1].second).dotProduct(vs[2].second);
    }
    if (vol < 0) {
        return 2;
    } else if (vol > 0) {
        return 1;
    }
    return 0;
}

bool hasNonDefaultValence(const Atom *atom) {
    if (atom->getNumRadicalElectrons() != 0) {
        return true;
    }
    if (atom->hasQuery()) {
        return false;
    }
    if (atom->getAtomicNum() == 1 || SmilesWrite ::inOrganicSubset(atom->getAtomicNum())) {
        // for the ones we "know", we may have to specify the valence if it's
        // not the default value
        if (atom->getNoImplicit() &&
            (atom->getExplicitValence() !=
             PeriodicTable::getTable()->getDefaultValence(atom->getAtomicNum()))) {
            return true;
        } else {
            return false;
        }
    }
    return true;
}

void GetMolFileAtomProperties(const Atom *atom, const Conformer *conf, int &totValence,
                              int &atomMapNumber, unsigned int &parityFlag, double &x, double &y,
                              double &z) {
    PRECONDITION(atom, "");
    totValence = 0;
    atomMapNumber = 0;
    parityFlag = 0;
    x = y = z = 0.0;

    if (!atom->getPropIfPresent(common_properties::molAtomMapNumber, atomMapNumber)) {
        // XXX FIX ME->should we fail here? previously we would not assign
        // the atomMapNumber if it didn't exist which could result in garbage
        //  values.
        atomMapNumber = 0;
    }

    if (conf) {
        const RDGeom::Point3D pos = conf->getAtomPos(atom->getIdx());
        x = pos.x;
        y = pos.y;
        z = pos.z;
        if (conf->is3D() && atom->getChiralTag() != Atom::CHI_UNSPECIFIED &&
            atom->getChiralTag() != Atom::CHI_OTHER && atom->getDegree() >= 3 &&
            atom->getTotalDegree() == 4) {
            parityFlag = getAtomParityFlag(atom, conf);
        }
    }
    if (hasNonDefaultValence(atom)) {
        if (atom->getTotalDegree() == 0) {
            // Specify zero valence for elements/metals without neighbors
            // or hydrogens (degree 0) instead of writing them as radicals.
            totValence = 15;
        } else {
            // write the total valence for other atoms
            totValence = atom->getTotalValence() % 15;
        }
    }
}
Bond::BondDir DetermineBondWedgeState(const Bond *bond, unsigned int fromAtomIdx,
                                      const Conformer *conf) {
    PRECONDITION(bond, "no bond");
    PRECONDITION(bond->getBondType() == Bond::SINGLE, "bad bond order for wedging");
    const ROMol *mol = &(bond->getOwningMol());
    PRECONDITION(mol, "no mol");

    Bond::BondDir res = bond->getBondDir();
    if (!conf) {
        return res;
    }

    Atom *atom, *bondAtom;  // = bond->getBeginAtom();
    if (bond->getBeginAtom()->getIdx() == fromAtomIdx) {
        atom = bond->getBeginAtom();
        bondAtom = bond->getEndAtom();
    } else {
        atom = bond->getEndAtom();
        bondAtom = bond->getBeginAtom();
    }

    Atom::ChiralType chiralType = atom->getChiralTag();
    CHECK_INVARIANT(
        chiralType == Atom::CHI_TETRAHEDRAL_CW || chiralType == Atom::CHI_TETRAHEDRAL_CCW, "");

    // if we got this far, we really need to think about it:
    INT_LIST neighborBondIndices;
    std::list<double> neighborBondAngles;
    RDGeom::Point3D centerLoc, tmpPt;
    centerLoc = conf->getAtomPos(atom->getIdx());
    tmpPt = conf->getAtomPos(bondAtom->getIdx());
    centerLoc.z = 0.0;
    tmpPt.z = 0.0;
    RDGeom::Point3D refVect = centerLoc.directionVector(tmpPt);

    neighborBondIndices.push_back(bond->getIdx());
    neighborBondAngles.push_back(0.0);

    ROMol::OEDGE_ITER beg, end;
    boost::tie(beg, end) = mol->getAtomBonds(atom);
    while (beg != end) {
        const Bond *nbrBond = (*mol)[*beg];
        Atom *otherAtom = nbrBond->getOtherAtom(atom);
        if (nbrBond != bond) {
            tmpPt = conf->getAtomPos(otherAtom->getIdx());
            tmpPt.z = 0.0;
            RDGeom::Point3D tmpVect = centerLoc.directionVector(tmpPt);
            double angle = refVect.signedAngleTo(tmpVect);
            if (angle < 0.0) {
                angle += 2. * M_PI;
            }
            auto nbrIt = neighborBondIndices.begin();
            auto angleIt = neighborBondAngles.begin();
            // find the location of this neighbor in our angle-sorted list
            // of neighbors:
            while (angleIt != neighborBondAngles.end() && angle > (*angleIt)) {
                ++angleIt;
                ++nbrIt;
            }
            neighborBondAngles.insert(angleIt, angle);
            neighborBondIndices.insert(nbrIt, nbrBond->getIdx());
        }
        ++beg;
    }

    // at this point, neighborBondIndices contains a list of bond
    // indices from the central atom.  They are arranged starting
    // at the reference bond in CCW order (based on the current
    // depiction).
    int nSwaps = atom->getPerturbationOrder(neighborBondIndices);

    // in the case of three-coordinated atoms we may have to worry about
    // the location of the implicit hydrogen - Issue 209
    // Check if we have one of these situation
    //
    //      0        1 0 2
    //      *         \*/
    //  1 - C - 2      C
    //
    // here the hydrogen will be between 1 and 2 and we need to add an additional
    // swap
    if (neighborBondAngles.size() == 3) {
        // three coordinated
        auto angleIt = neighborBondAngles.begin();
        ++angleIt;  // the first is the 0 (or reference bond - we will ignoire that
        double angle1 = (*angleIt);
        ++angleIt;
        double angle2 = (*angleIt);
        if (angle2 - angle1 >= (M_PI - 1e-4)) {
            // we have the above situation
            nSwaps++;
        }
    }

#ifdef VERBOSE_STEREOCHEM
    BOOST_LOG(rdDebugLog) << "--------- " << nSwaps << std::endl;
    std::copy(neighborBondIndices.begin(), neighborBondIndices.end(),
              std::ostream_iterator<int>(BOOST_LOG(rdDebugLog), " "));
    BOOST_LOG(rdDebugLog) << std::endl;
    std::copy(neighborBondAngles.begin(), neighborBondAngles.end(),
              std::ostream_iterator<double>(BOOST_LOG(rdDebugLog), " "));
    BOOST_LOG(rdDebugLog) << std::endl;
#endif
    if (chiralType == Atom::CHI_TETRAHEDRAL_CCW) {
        if (nSwaps % 2 == 1) {  // ^ reverse) {
            res = Bond::BEGINDASH;
        } else {
            res = Bond::BEGINWEDGE;
        }
    } else {
        if (nSwaps % 2 == 1) {  // ^ reverse) {
            res = Bond::BEGINWEDGE;
        } else {
            res = Bond::BEGINDASH;
        }
    }

    return res;
}

Bond::BondDir DetermineBondWedgeState(const Bond *bond, const INT_MAP_INT &wedgeBonds,
                                      const Conformer *conf) {
    PRECONDITION(bond, "no bond");
    int bid = bond->getIdx();
    auto wbi = wedgeBonds.find(bid);
    if (wbi == wedgeBonds.end()) {
        return bond->getBondDir();
    }

    unsigned int waid = wbi->second;
    return DetermineBondWedgeState(bond, waid, conf);
}

// only valid for single bonds
int BondGetDirCode(const Bond::BondDir dir) {
    int res = 0;
    switch (dir) {
        case Bond::NONE:
            res = 0;
            break;
        case Bond::BEGINWEDGE:
            res = 1;
            break;
        case Bond::BEGINDASH:
            res = 6;
            break;
        case Bond::UNKNOWN:
            res = 4;
            break;
        default:
            break;
    }
    return res;
}

void GetMolFileBondStereoInfo(const Bond *bond, const INT_MAP_INT &wedgeBonds,
                              const Conformer *conf, int &dirCode, bool &reverse) {
    PRECONDITION(bond, "");
    dirCode = 0;
    reverse = false;
    Bond::BondDir dir = Bond::NONE;
    if (bond->getBondType() == Bond::SINGLE) {
        // single bond stereo chemistry
        dir = DetermineBondWedgeState(bond, wedgeBonds, conf);
        dirCode = BondGetDirCode(dir);
        // if this bond needs to be wedged it is possible that this
        // wedging was determined by a chiral atom at the end of the
        // bond (instead of at the beginning). In this case we need to
        // reverse the begin and end atoms for the bond when we write
        // the mol file
        if ((dirCode == 1) || (dirCode == 6)) {
            auto wbi = wedgeBonds.find(bond->getIdx());
            if (wbi != wedgeBonds.end() &&
                static_cast<unsigned int>(wbi->second) != bond->getBeginAtomIdx()) {
                reverse = true;
            }
        }
    } else if (bond->getBondType() == Bond::DOUBLE) {
        // double bond stereochemistry -
        // if the bond isn't specified, then it should go in the mol block
        // as "any", this was sf.net issue 2963522.
        // two caveats to this:
        // 1) if it's a ring bond, we'll only put the "any"
        //    in the mol block if the user specifically asked for it.
        //    Constantly seeing crossed bonds in rings, though maybe
        //    technically correct, is irritating.
        // 2) if it's a terminal bond (where there's no chance of
        //    stereochemistry anyway), we also skip the any.
        //    this was sf.net issue 3009756
        if (bond->getStereo() <= Bond::STEREOANY) {
            if (bond->getStereo() == Bond::STEREOANY) {
                dirCode = 3;
            } else if (!(bond->getOwningMol().getRingInfo()->numBondRings(bond->getIdx())) &&
                       bond->getBeginAtom()->getDegree() > 1 &&
                       bond->getEndAtom()->getDegree() > 1) {
                // we don't know that it's explicitly unspecified (covered above with
                // the ==STEREOANY check)
                // look to see if one of the atoms has a bond with direction set
                if (bond->getBondDir() == Bond::EITHERDOUBLE) {
                    dirCode = 3;
                } else {
                    if ((bond->getBeginAtom()->getTotalValence() -
                         bond->getBeginAtom()->getTotalDegree()) == 1 &&
                        (bond->getEndAtom()->getTotalValence() -
                         bond->getEndAtom()->getTotalDegree()) == 1) {
                        // we only do this if each atom only has one unsaturation
                        // FIX: this is the fix for github #2649, but we will need to change
                        // it once we start handling allenes properly

                        bool nbrHasDir = false;

                        ROMol::OEDGE_ITER beg, end;
                        boost::tie(beg, end) =
                            bond->getOwningMol().getAtomBonds(bond->getBeginAtom());
                        while (beg != end && !nbrHasDir) {
                            const Bond *nbrBond = bond->getOwningMol()[*beg];
                            if (nbrBond->getBondType() == Bond::SINGLE &&
                                (nbrBond->getBondDir() == Bond::ENDUPRIGHT ||
                                 nbrBond->getBondDir() == Bond::ENDDOWNRIGHT)) {
                                nbrHasDir = true;
                            }
                            ++beg;
                        }
                        boost::tie(beg, end) =
                            bond->getOwningMol().getAtomBonds(bond->getEndAtom());
                        while (beg != end && !nbrHasDir) {
                            const Bond *nbrBond = bond->getOwningMol()[*beg];
                            if (nbrBond->getBondType() == Bond::SINGLE &&
                                (nbrBond->getBondDir() == Bond::ENDUPRIGHT ||
                                 nbrBond->getBondDir() == Bond::ENDDOWNRIGHT)) {
                                nbrHasDir = true;
                            }
                            ++beg;
                        }
                        if (!nbrHasDir) {
                            dirCode = 3;
                        }
                    }
                }
            }
        }
    }
}

}  // namespace

std::unique_ptr<MFCFrag> RDKitTool::ROMol_to_MFCFrag_Optimize(const ROMol &m) {
    using namespace common_properties;

    std::unique_ptr<ROMol> pmol{MolOps::addHs(m, true)};
    RWMol &mol = *static_cast<RWMol *>(pmol.get());

    if (!mol.getNumConformers()) {
        // generate coordinates so that the stereo we generate makes sense
        RDDepict::compute2DCoords(mol);
    }

    //    RDKit::MolOps::sanitizeMol(mol);

    if (mol.needsUpdatePropertyCache()) {
        mol.updatePropertyCache(false);
    }

    MolOps::Kekulize(mol);
    MolOps::findSSSR(mol);

    auto frag = std::make_unique<MFCFrag>(
        mol.getNumAtoms(), mol.getNumBonds(),
        mol.hasProp(_Name) ? mol.getProp<std::string>(common_properties::_Name) : "NONAME");

    //    mol.getProp(common_properties::_MolFileChiralFlag, frag->stereoFlag);
    mol.getPropIfPresent(common_properties::_MolFileChiralFlag, frag->stereoFlag);

    // get 3D coordinates
    const auto &conf = mol.getConformer();

    int isFlat = true;
    double z0;
    frag->atomList.reserve(frag->numAtoms);
    for (auto atom : mol.atoms()) {
        auto mfcAtom = new MFCAtom(atom->getIdx(), atom->getAtomicNum());
        //        auto isotope = atom->getIsotope();
        //        auto isodef =
        //        PeriodicTable::getTable()->getMostCommonIsotope(atom->getAtomicNum());
        //        mfcAtom->massDiff = isotope - isodef;

        mfcAtom->FormalCharge = atom->getFormalCharge();
        mfcAtom->massDiff = 0;
        mfcAtom->mdlChargeFlag = 0;  // Cannot determined
        mfcAtom->freeValence = static_cast<int>(atom->getNumRadicalElectrons() != 0);

        int totValence, atomMapNumber;
        unsigned int parityFlag;
        GetMolFileAtomProperties(atom, &conf, totValence, atomMapNumber, parityFlag, mfcAtom->x,
                                 mfcAtom->y, mfcAtom->z);

        mfcAtom->stereoParity = 0;
        if (atom->getIdx() == 0) z0 = mfcAtom->z;
        if (mfcAtom->z != z0) isFlat = false;

        mfcAtom->ownerFrag = frag.get();
        mfcAtom->aromaticFlag = atom->getIsAromatic();
        switch (atom->getHybridization()) {
            case Atom::UNSPECIFIED:
                mfcAtom->hybride = MFC_NO_HYBRID;
                break;
            case Atom::S:
                mfcAtom->hybride = MFC_S_HYBRID;
                break;
            case Atom::SP:
                mfcAtom->hybride = MFC_SP_HYBRID;
                break;
            case Atom::SP2:
                mfcAtom->hybride = MFC_SP2_HYBRID;
                break;
            case Atom::SP3:
            case Atom::SP3D:
            case Atom::SP3D2:
                mfcAtom->hybride = MFC_SP3_HYBRID;
                break;
            case Atom::OTHER:
                mfcAtom->hybride = MFC_OTHER_HYBRID;
                break;
        }

        mfcAtom->genFlag = 0;
        mfcAtom->nBonds = 0;

        frag->atomList.push_back(mfcAtom);
    }

    frag->bondList.reserve(frag->numBonds);
    for (auto bond : mol.bonds()) {
        int atom1 = bond->getBeginAtomIdx();
        int atom2 = bond->getEndAtomIdx();

        auto bondorder = bond->getBondType();

        auto mfcBond = new MFCBond(atom1, atom2, bondorder * 100, bond->getIdx());
        mfcBond->ownerFrag = frag.get();
        if (bond->getIsAromatic()) mfcBond->bondType = 4;
        //        switch (bond->getBondType())

        frag->bondList.push_back(mfcBond);
        auto Atom1 = frag->atomList[atom1];
        auto Atom2 = frag->atomList[atom2];
        Atom1->nBonds++;
        Atom2->nBonds++;

        bool reverse;
        const INT_MAP_INT wedgeBonds;
        int bondDir;

        GetMolFileBondStereoInfo(bond, wedgeBonds, &conf, bondDir, reverse);

        mfcBond->bondDirection = bondDir;
        if (atom1 > atom2 && bondDir == 1) {
            mfcBond->bondDirection = 6;
        } else if (atom1 > atom2 && bondDir == 6) {
            mfcBond->bondDirection = 1;
        }

        if (bondorder == 2) mfcBond->bondDirection = bondDir;
        // stereoParity = 0 (not a stereo center or not set)
        // 1/2 (R/S), 3 (unknown),
        // 4 (fixed, determine by 3D).
        // modify is stereoParity is not set yet
        //
        if (bondDir == 4)
            Atom1->stereoParity = 3;
        else if (bondDir == 1 || bondDir == 6)
            Atom1->stereoParity = 4;
    }

    // Setup atom bond list
    for (int i = 0; i < frag->numBonds; i++) {
        auto Bond = frag->bondList[i];
        auto atom1 = Bond->atom1;
        auto atom2 = Bond->atom2;
        auto Atom1 = frag->atomList[atom1];
        auto Atom2 = frag->atomList[atom2];
        Atom1->atomList.push_back(atom2);
        Atom2->atomList.push_back(atom1);
        Atom1->bondList.push_back(i);
        Atom2->bondList.push_back(i);
        Atom1->genFlag++;
        Atom2->genFlag++;
    }

    //    frag->add_hydrogens();
    //
    // Set chirality by stereo parity
    //
    frag->set_chirality();
    //
    // Set parity by bond direction if the molecule is flat and there is a bond
    // direction flag (1,6)
    // For either bond direction (4), the chiral sign of the atom is set to 0.
    //
    frag->set_parity(isFlat);

    frag->set_stereo(true, true, isFlat);

    auto *molPro = new MolProperties();

    molPro->PropertyDoc.emplace_back("M  END");
    frag->setMolPro(molPro);

    setMFCAtomVDW(frag.get());

    auto ringInfo = mol.getRingInfo();
    frag->ringList.reserve(ringInfo->numRings());
    for (auto i : boost::irange(ringInfo->numRings())) {
        auto &&ring = ringInfo->atomRingSizes(i);
        auto mfcRing = new MFCRing(ring.size(), ring.data());
        mfcRing->RIdx = i;
        mfcRing->ownerFrag = frag.get();
        mfcRing->aromaticity = std::all_of(begin(ring), end(ring), [&mol](int i) {
            return mol.getAtomWithIdx(i)->getIsAromatic();
        });
        frag->ringList.push_back(mfcRing);
        if (ring.size() == 6) {
            int cnt = 0;  // benzene atoms count;
            for (auto atomId : mfcRing->ringAtomList) {
                auto atom = frag->atomList[atomId];
                if (atom->atomicNumber == 6 && atom->aromaticFlag == 1) cnt++;
            }
            // if is benzene
            if (cnt == 6) {
                for (auto atomId : mfcRing->ringAtomList) {
                    frag->atomList[atomId]->ringAtomFlag = 2;  // benzene Flag
                }
            }
        }
    }

    //    findSSSR(frag.get());

//        setHybridization(frag.get());
    //
    // Find aromatic rings
    //
//        setRingAtomFlags(frag.get());
    //    clearringBondMap();
    //
    // Set ideal bond length according to atom and bond type
    //
    SetBondLength(frag.get());
    setFragnH(frag.get());

    return frag;
}

std::unique_ptr<MFCFrag> RDKitTool::ROMol_to_MFCFrag(const ROMol &mol) {
    std::ostringstream oss;
    SDWriter writer(&oss);
    writer.write(mol);
    writer.close();
    SDReaderT<iStringFileStream> sdReader(oss.str());
    std::unique_ptr<MFCFrag> frag{sdReader.readLargestMFCFrag()};
    setMFCAtomVDW(frag.get());
    findSSSR(frag.get());

    //
    // Find aromatic rings
    //
    setRingAtomFlags(frag.get());
    setHybridization(frag.get());
    clearringBondMap();
    //
    // Set ideal bond length according to atom and bond type
    //
    SetBondLength(frag.get());
    setFragnH(frag.get());
    return frag;
}



std::unique_ptr<ROMol> RDKitTool::MFCFrag_to_ROMol(const MFCFrag &frag) {
    auto ss = std::make_unique<std::stringstream>();
    writeMFCFrag2SD(const_cast<MFCFrag *>(&frag), *ss, true);
    //    std::cout << ss->str() << std::endl;
    SDMolSupplier reader(ss.get());
    ss.release();
    assert(reader.length() == 1);
    return std::unique_ptr<RDKit::ROMol>(reader[0]);
}
