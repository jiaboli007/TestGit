

#ifndef ALPHACS_RDKITTOOL_HPP
#define ALPHACS_RDKITTOOL_HPP

#include <memory>

#include <GraphMol/ROMol.h>

#include "MolStructure/mfcMolecule.h"
#include "Utils/mfcUtil.hpp"

namespace MISS {
class RDKitTool {
public:
    static std::unique_ptr<MFCFrag> ROMol_to_MFCFrag(const RDKit::ROMol& mol);
    static std::unique_ptr<MFCFrag> ROMol_to_MFCFrag_Optimize(const RDKit::ROMol& mol);

    static std::unique_ptr<RDKit::ROMol> MFCFrag_to_ROMol(const MFCFrag& frag);
};
}  // namespace MISS

#endif  // ALPHACS_RDKITTOOL_HPP
