#include <cmath>
#include <iostream>

#include <boost/algorithm/string.hpp>

#include "params.h"

namespace MISS {

CodingProfile* CodingProfile::Instance() {
    static CodingProfile instance;  // thread sace since C++14
    return &instance;               // return address of static instance
}

CodingProfile::CodingProfile() {
    eps = 1.0E-12;
    int primex[136] = {
        0,   53,  59,  61,  67,  71,  73,  79,  83,  89,  97,  101, 103, 107, 109, 113, 127,
        131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197, 199, 211, 223,
        227, 229, 233, 239, 241, 251, 257, 263, 269, 271, 277, 281, 283, 293, 307, 311, 313,
        317, 331, 337, 347, 349, 353, 359, 367, 373, 379, 383, 389, 397, 401, 409, 419, 421,
        431, 433, 439, 443, 449, 457, 461, 463, 467, 479, 487, 491, 499, 503, 509, 521, 523,
        541, 547, 557, 563, 569, 571, 577, 587, 593, 599, 601, 607, 613, 617, 619, 631, 641,
        643, 647, 653, 659, 661, 673, 677, 683, 691, 701, 709, 719, 727, 733, 739, 743, 751,
        757, 761, 769, 773, 787, 797, 809, 811, 821, 823, 827, 829, 839, 853, 857, 859, 863};

    // Atomimc contribution < 2.0
    for (int i = 0; i < 136; i++) {
        aFactors[i] = sqrt(static_cast<double>(primex[i]));
        while (aFactors[i] > 2) {
            aFactors[i] = aFactors[i] / 2;
        }
    }

    cFactor = 2.7182818284590452353602874713527 / 2;
    vFactor = 3.1415926535897932384626433832795 / 2;
    //
    // Coding factor for bond types: single, double, triple
    // one-and-half, two-and-half, and other
    // All bonding factor : 0.5-2.0

    b10 = sqrt(double(3)) / 2;
    b20 = sqrt(double(5)) / 2;
    b30 = sqrt(double(7)) / 2;
    b40 = sqrt(double(11)) / 4;
    b15 = sqrt(double(13)) / 4;
    b25 = sqrt(double(17)) / 4;
    b35 = sqrt(double(19)) / 4;
    bxx = sqrt(double(23)) / 4;
    chiral = sqrt(double(29)) / 4;
    quasi = sqrt(double(31)) / 4;
    a = sqrt(double(41)) / 4;
    b = sqrt(double(43)) / 4;
    c = sqrt(double(47)) / 4;
    bFactors[1] = b10;
    bFactors[2] = b20;
    bFactors[3] = b30;
    bFactors[4] = b40;
    bFactors[5] = b15;
    bFactors[6] = b25;
    bFactors[7] = b35;
    bFactors[8] = bxx;
}

PeriodicTable* PeriodicTable::Instance() {
    static PeriodicTable instance;
    return &instance;
}

PeriodicTable::PeriodicTable() {
    std::string tmp1[112] = {
        "  ", "H ", "He", "Li", "Be", "B ", "C ", "N ", "O ", "F ", "Ne", "Na", "Mg", "Al",
        "Si", "P ", "S ", "Cl", "Ar", "K ", "Ca", "Sc", "Ti", "V ", "Cr", "Mn", "Fe", "Co",
        "Ni", "Cu", "Zn", "Ga", "Ge", "As", "Se", "Br", "Kr", "Rb", "Sr", "Y ", "Zr", "Nb",
        "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn", "Sb", "Te", "I ", "Xe", "Cs",
        "Ba", "La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm",
        "Yb", "Lu", "Hf", "Ta", "W ", "Re", "Os", "Ir", "Pt", "Au", "Hg", "Tl", "Pb", "Bi",
        "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th", "Pa", "U ", "Np", "Pu", "Am", "Cm", "Bk",
        "Cf", "Es", "Fm", "Md", "No", "Lr", "Rf", "Db", "Sg", "Bh", "Hs", "Mt", "Ds", "Rg"};

    std::string tmp2[112] = {
        "  ", "H ", "HE", "LI", "BE", "B ", "C ", "N ", "O ", "F ", "NE", "NA", "MG", "AL",
        "SI", "P ", "S ", "CL", "AR", "K ", "CA", "SC", "TI", "V ", "CR", "MN", "FE", "CO",
        "NI", "CU", "ZN", "GA", "GE", "AS", "SE", "BR", "KR", "RB", "SR", "Y ", "ZR", "NB",
        "MO", "TC", "RU", "RH", "PD", "AG", "CD", "IN", "SN", "SB", "TE", "I ", "XE", "CS",
        "BA", "LA", "CE", "PR", "ND", "PM", "SM", "EU", "GD", "TB", "DY", "HO", "ER", "TM",
        "YB", "LU", "HF", "TA", "W ", "RE", "OS", "IR", "PT", "AU", "HG", "TL", "PB", "BI",
        "PO", "AT", "RN", "FR", "RA", "AC", "TH", "PA", "U ", "NP", "PU", "AM", "CM", "BK",
        "CF", "ES", "FM", "MD", "NO", "LR", "RF", "DB", "SG", "BH", "HS", "MT", "DS", "RG"};

    //
    // Load Pauling Eletronegativity (from http://environmentalchemitry.com/
    // First one is a junk, from the second one starts H, He, Li, ....
    //
    double tmp3[112] = {
        0.0,  2.2,  0.0,  0.98, 1.57, 2.04, 2.55, 3.04, 3.44, 3.98, 0.0,  0.93, 1.31, 1.61,
        1.9,  2.19, 2.58, 3.16, 0,    0.82, 1,    1.36, 1.54, 1.63, 1.66, 1.55, 1.83, 1.88,
        1.91, 1.9,  1.65, 1.81, 2.01, 2.18, 2.55, 2.96, 0,    0.82, 0.95, 1.22, 1.33, 1.6,
        2.16, 1.9,  2.2,  2.28, 2.2,  1.93, 1.69, 1.78, 1.96, 2.05, 2.1,  2.66, 0,    0.79,
        0.89, 1.1,  1.12, 1.13, 1.14, 1.13, 1.17, 1.2,  1.2,  1.2,  1.22, 1.23, 1.24, 1.25,
        1.1,  1.27, 1.3,  1.5,  2.36, 1.9,  2.2,  2.2,  2.28, 2.54, 2,    2.04, 2.33, 2.02,
        2,    2.2,  0,    0.7,  0.9,  1.1,  1.3,  1.5,  1.38, 1.36, 1.28, 1.3,  1.3,  1.3,
        1.3,  1.3,  1.3,  1.3,  1.3,  1.3,  1.3,  1.3,  1.3,  1.3,  1.3,  1.3,  1.3,  1.3};

    //
    // Load covalent radii (from http://www.ccdc.cam.ac.uk)
    // First one is a junk, from the second one starts H, He, Li, ....
    //
    double tmp4[112] = {
        0.0,  0.23, 1.50, 0.68, 0.35, 0.83, 0.68, 0.68, 0.68, 0.64, 1.50, 0.97, 1.10, 1.35,
        1.20, 1.05, 1.02, 0.99, 1.51, 1.33, 0.99, 1.44, 1.47, 1.33, 1.35, 1.35, 1.34, 1.33,
        1.50, 1.52, 1.45, 1.22, 1.17, 1.21, 1.22, 1.21, 1.50, 1.47, 1.12, 1.78, 1.56, 1.48,
        1.47, 1.35, 1.40, 1.45, 1.50, 1.59, 1.69, 1.63, 1.46, 1.46, 1.47, 1.40, 1.50, 1.67,
        1.34, 1.87, 1.83, 1.82, 1.81, 1.80, 1.80, 1.99, 1.79, 1.76, 1.75, 1.74, 1.73, 1.72,
        1.94, 1.72, 1.57, 1.43, 1.37, 1.35, 1.37, 1.32, 1.50, 1.50, 1.70, 1.55, 1.54, 1.54,
        1.68, 1.21, 1.50, 1.50, 1.90, 1.88, 1.79, 1.61, 1.58, 1.55, 1.53, 1.51, 0.99, 1.54,
        1.83, 1.50, 1.50, 1.50, 1.50, 1.50, 1.50, 1.50, 1.50, 1.50, 1.50, 1.50, 1.50, 1.50};

    //
    //
    // Load VDW radii (from http://www.ccdc.cam.ac.uk)
    // First one is a junk, from the second one starts H, He, Li, ....
    //
    double tmp5[112] = {
        0.0,  1.20, 1.40, 1.82, 2.00, 2.00, 1.70, 1.55, 1.52, 1.47, 1.54, 2.27, 1.73, 2.00,
        2.10, 1.80, 1.80, 1.75, 1.88, 2.75, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00,
        1.63, 1.40, 1.39, 1.87, 2.00, 1.85, 1.90, 1.85, 2.02, 2.00, 2.00, 2.00, 2.00, 2.00,
        2.00, 2.00, 2.00, 2.00, 1.63, 1.72, 1.58, 1.93, 2.17, 2.00, 2.06, 1.98, 2.16, 2.00,
        2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00,
        2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 1.72, 1.66, 1.55, 1.96, 2.02, 2.00,
        2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 1.86, 2.00, 2.00, 2.00, 2.00, 2.00,
        2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00, 2.00};

    //
    // Atom Valence
    int tmp6[112] = {0, 1, 0, 1, 2, 3, 4, 3, 2, 1, 0, 1, 2, 3, 4, 3, 2, 1, 0, 1, 2, 3, 4,
                     5, 6, 7, 3, 3, 3, 2, 2, 3, 4, 3, 2, 1, 0, 1, 2, 3, 4, 5, 6, 7, 3, 3,
                     3, 2, 2, 3, 4, 3, 2, 1, 0, 1, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
                     3, 3, 3, 4, 5, 6, 7, 3, 3, 3, 2, 2, 3, 4, 3, 2, 1, 0, 1, 2, 3, 3, 3,
                     3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 5, 6, 7, 3, 3, 3, 3};

    //
    // Atom Group
    //
    int tmp7[112] = {0,  1,  0,  1,  2,  3,  4,  5,  6,  7,  8,  1,  2,  3,  4,  5,  6,  7,  8,
                     1,  2,  13, 14, 15, 16, 17, 18, 18, 18, 11, 12, 3,  4,  5,  6,  7,  8,  1,
                     2,  13, 14, 15, 16, 17, 18, 18, 18, 11, 12, 3,  4,  5,  6,  7,  8,  1,  2,
                     13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 14, 15, 16, 17,
                     18, 18, 18, 11, 12, 3,  4,  5,  6,  7,  8,  1,  2,  13, 13, 13, 13, 13, 13,
                     13, 13, 13, 13, 13, 13, 13, 13, 13, 14, 15, 16, 17, 18, 18, 18, 18};

    //
    // Load covalent radii2
    // http://en.wikipedia.org/wiki.Atomic_radii_of_the_elements_%28data_page%29)
    // First one is a junk, from the second one starts H, He, Li, ....
    //
    double tmp8[112] = {
        0.0,  0.37, 0.32, 1.34, 0.90, 0.82, 0.77, 0.75, 0.73, 0.71, 0.69, 1.54, 1.30, 1.18,
        1.11, 1.06, 1.02, 0.99, 0.97, 1.96, 1.74, 1.44, 1.36, 1.25, 1.27, 1.39, 1.25, 1.26,
        1.21, 1.38, 1.31, 1.26, 1.22, 1.19, 1.16, 1.14, 1.10, 2.11, 1.92, 1.62, 1.48, 1.37,
        1.45, 1.56, 1.26, 1.35, 1.31, 1.53, 1.48, 1.44, 1.41, 1.38, 1.35, 1.33, 1.30, 2.25,
        1.98, 1.69, 1.69, 1.69, 1.69, 1.69, 1.69, 1.69, 1.69, 1.69, 1.69, 1.69, 1.69, 1.69,
        1.69, 1.60, 1.50, 1.38, 1.46, 1.59, 1.28, 1.37, 1.28, 1.44, 1.49, 1.48, 1.47, 1.46,
        1.46, 1.46, 1.45, 1.46, 1.90, 1.88, 1.79, 1.61, 1.58, 1.55, 1.53, 1.51, 0.99, 1.54,
        1.83, 1.50, 1.50, 1.50, 1.50, 1.50, 1.50, 1.50, 1.50, 1.50, 1.50, 1.50, 1.50, 1.50};

    //
    // Load covalent radii3 for triple-bond
    //(http://en.wikipedia.org/wiki.Atomic_radii_of_the_elements_%28data_page%29)
    // First one is a junk, from the second one starts H, He, Li, ....
    //
    double tmp9[112] = {
        0.0,  0.00, 0.00, 0.00, 0.85, 0.73, 0.60, 0.54, 0.53, 0.53, 0.00, 0.00, 1.27, 1.11,
        1.02, 0.94, 0.95, 0.93, 0.96, 0.00, 1.33, 1.14, 1.08, 1.06, 1.03, 1.03, 1.02, 0.96,
        1.01, 1.20, 0.00, 1.21, 1.14, 1.06, 1.07, 1.10, 1.08, 0.00, 1.39, 1.24, 1.21, 1.16,
        1.13, 1.10, 1.03, 1.06, 1.12, 1.37, 0.00, 1.46, 1.32, 1.27, 1.21, 1.25, 1.22, 0.00,
        1.49, 1.39, 1.31, 1.28, 1.28, 1.28, 1.28, 1.28, 1.32, 1.32, 1.32, 1.32, 1.32, 1.32,
        1.32, 1.31, 1.22, 1.19, 1.15, 1.10, 1.09, 1.07, 1.10, 1.23, 1.49, 1.50, 1.37, 1.35,
        1.29, 1.38, 1.33, 1.46, 1.59, 1.40, 1.36, 1.29, 1.18, 1.16, 1.16, 1.16, 1.16, 1.16,
        1.16, 1.16, 1.16, 1.16, 1.16, 1.16, 1.31, 1.26, 1.21, 1.19, 1.18, 1.13, 1.12, 1.18};

    std::string_view tmp10[112] = {
        "",   "H",  "He", "Li", "Be", "B",  "C",  "N",  "O",  "F",  "Ne", "Na", "Mg", "Al",
        "Si", "P",  "S",  "Cl", "Ar", "K",  "Ca", "Sc", "Ti", "V",  "Cr", "Mn", "Fe", "Co",
        "Ni", "Cu", "Zn", "Ga", "Ge", "As", "Se", "Br", "Kr", "Rb", "Sr", "Y",  "Zr", "Nb",
        "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn", "Sb", "Te", "I",  "Xe", "Cs",
        "Ba", "La", "Ce", "Pr", "Nd", "Pm", "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm",
        "Yb", "Lu", "Hf", "Ta", "W",  "Re", "Os", "Ir", "Pt", "Au", "Hg", "Tl", "Pb", "Bi",
        "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th", "Pa", "U",  "Np", "Pu", "Am", "Cm", "Bk",
        "Cf", "Es", "Fm", "Md", "No", "Lr", "Rf", "Db", "Sg", "Bh", "Hs", "Mt", "Ds", "Rg"};

    for (int i = 1; i < 112; i++) {
        atomsymb1[i] = tmp1[i];
        atomsymb2[i] = tmp2[i];
        atomsymb3[i] = tmp10[i];
        PaulingEN[i] = tmp3[i];
        CovalentRadii[i] = tmp4[i];
        CovalentRadii2[i] = tmp8[i];
        CovalentRadii3[i] = tmp9[i];
        VDWRadii[i] = tmp5[i];
        AtomValence[i] = tmp6[i];
        AtomGroup[i] = tmp7[i];
        map2Int1[atomsymb1[i]] = i;
        map2Int2[atomsymb2[i]] = i;
        map2Int3[atomsymb3[i]] = i;
    }
}

double PeriodicTable::PaulingEletroNegativity(int atomicNumber) { return PaulingEN[atomicNumber]; }

double PeriodicTable::AtomicVDWR(int atomicNumber) { return VDWRadii[atomicNumber]; }

double PeriodicTable::AtomicCovalentR(int atomicNumber) { return CovalentRadii[atomicNumber]; }

double PeriodicTable::AtomicCovalentR2(int atomicNumber) { return CovalentRadii2[atomicNumber]; }
double PeriodicTable::AtomicCovalentR3(int atomicNumber) { return CovalentRadii3[atomicNumber]; }

int PeriodicTable::AtomicGroup(int atomicNumber) { return AtomGroup[atomicNumber]; }

int PeriodicTable::AtomicValence(int atomicNumber) { return AtomValence[atomicNumber]; }

std::string_view ltrim(std::string_view s) {
    s.remove_prefix(std::distance(
        s.cbegin(), std::find_if(s.cbegin(), s.cend(), [](int c) { return !std::isspace(c); })));

    return s;
}

std::string_view rtrim(std::string_view s) {
    s.remove_suffix(std::distance(
        s.crbegin(), std::find_if(s.crbegin(), s.crend(), [](int c) { return !std::isspace(c); })));

    return s;
}

std::string_view trim(std::string_view s) { return ltrim(rtrim(s)); }

int PeriodicTable::AtomicNumber(std::string_view symbol) {
    int aNumber = 0;
    // aNumber = map2Int1[symbol];
    aNumber = map2Int3[trim(symbol)];
    // if(aNumber == 0)
    //  aNumber = map2Int2[symbol];
    if (aNumber == 0) {
        aNumber = 1;
    }
    return aNumber;
}

std::string PeriodicTable::AtomicSymbol(int atomicNumber) { return atomsymb1[atomicNumber]; }

std::string PeriodicTable::AtomicSymbolNoSpace(int atomicNumber) { return atomsymb3[atomicNumber]; }

}  // namespace MISS
