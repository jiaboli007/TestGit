#ifndef params_h
#define params_h
#include <fstream>
#include <functional>
#include <map>
#include <string>
#include <vector>

namespace MISS {

// A singleton class to hold all parameters

class CodingProfile {
public:
    static CodingProfile* Instance();
    double eps;
    double aFactors[146];
    double cFactor;
    double vFactor;
    double bFactors[10];
    //
    // Coding factor for bond types: single, double, triple, aromatic,
    // one-and-half, two-and-half, and other

    double b10;
    double b20;
    double b30;
    double b40;
    double b15;
    double b25;
    double b35;
    double bxx;
    double chiral;
    double quasi;
    double cistrans;
    double a, b, c;

    CodingProfile(const CodingProfile&) = delete;
    CodingProfile& operator=(const CodingProfile&) = delete;

protected:
    CodingProfile();
};

class PeriodicTable {
public:
    static PeriodicTable* Instance();
    int AtomicGroup(int AtomicNumber);
    int AtomicValence(int AtomicNumber);
    int AtomicNumber(std::string_view symbol);
    double AtomicVDWR(int AtomicNumber);
    double AtomicCovalentR(int AtomicNumber);
    double AtomicCovalentR2(int AtomicNumber);
    double AtomicCovalentR3(int AtomicNumber);
    double PaulingEletroNegativity(int AtomicNumber);
    std::string AtomicSymbol(int AtomicNumber);
    std::string AtomicSymbolNoSpace(int AtomicNumber);

    PeriodicTable(const PeriodicTable&) = delete;
    PeriodicTable& operator=(const PeriodicTable&) = delete;

protected:
    PeriodicTable();

private:
    int AtomValence[112];
    int AtomGroup[112];
    double PaulingEN[112];
    double CovalentRadii[112];
    double CovalentRadii2[112];
    double CovalentRadii3[112];
    double VDWRadii[112];
    std::string atomsymb1[112];
    std::string atomsymb2[112];
    std::string atomsymb3[112];  // No Space
    std::map<std::string, int> map2Int1;
    std::map<std::string, int> map2Int2;
    std::map<std::string_view, int> map2Int3;
};

}  // namespace MISS

#endif /* params_h */
