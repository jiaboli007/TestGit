#include <memory>

#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/depth_first_search.hpp>
#include <boost/range/combine.hpp>

namespace RDL {
#include <RingDecomposerLib.h>
}

#include "ForceField/ffUtil.h"
#include "MolStructure/mfcMolecule.h"
#include "Topology/RingDecomposerLib_findSSSR.hpp"
#include "Topology/topology.h"
#include "Utils/mfcUtil.hpp"

namespace MISS {
extern thread_local map<int, vector<int>> ringBondMap;
extern thread_local std::vector<int> ringBondList;
}  // namespace MISS

namespace {
using MISS::ringBondList;
class Visitor : public boost::default_dfs_visitor {
public:
    explicit Visitor(MISS::MFCFrag* frag, MISS::MFCRing* ring) : frag(frag), ring(ring) {}

    template <typename Vertex, typename Graph>
    void discover_vertex(Vertex v, const Graph&) const {
        ring->ringAtomList.push_back(v);
    }

    template <typename Edge, typename Graph>
    void tree_edge(Edge e, const Graph& g) const {
        ringBondList.push_back(frag->isBonded(source(e, g), target(e, g)));
    }

private:
    MISS::MFCFrag* frag;
    MISS::MFCRing* ring;
};

}  // namespace

void RingDecomposerLib_findSSSR(MISS::MFCFrag* frag) {
    using namespace MISS;
    using namespace RDL;
    ringBondMap.clear();

    frag->ringCount = 0;

    RDL_graph* graph = RDL_initNewGraph(frag->numAtoms);

    using Graph_t = boost::adjacency_list<boost::setS, boost::vecS, boost::directedS>;
    Graph_t g;
    for (auto atom : frag->atomList) {
        boost::add_vertex(g);
    }
    for (auto bond : frag->bondList) {
        RDL_addUEdge(graph, bond->atom1, bond->atom2);
    }
    RDL_data* data = RDL_calculate(graph);
    scope_exit rdl_data_deleter([&data] { RDL_deleteData(data); });

    RDL_cycle** cycle_array;

    auto ring_num = RDL_getSSSR(data, &cycle_array);
    scope_exit cycle_array_deleter(
        [&cycle_array, ring_num] { RDL_deleteCycles(cycle_array, ring_num); });
    frag->ringList.reserve(ring_num);

    std::vector<std::tuple<MFCRing*, std::vector<int>>> rings;
    for (auto i : boost::irange(ring_num)) {
        auto ring = cycle_array[i];
        ringBondList.clear();
        ringBondList.reserve(ring->weight);

        auto r = new MFCRing();
        auto start_atom_idx = ring->edges[0][0];
        std::array<unsigned, 2> start_edges{ring->edges[0][1]};
        for (auto edge_idx : boost::irange(1U, ring->weight)) {
            auto edge = ring->edges[edge_idx];
            if (edge[0] != start_atom_idx) {
                boost::add_edge(edge[0], edge[1], g);
                boost::add_edge(edge[1], edge[0], g);
            } else {
                start_edges[1] = edge[1];
            }
        }

        for (auto bond : frag->atomList[start_atom_idx]->bondList) {
            if (auto adjAtom = frag->bondList[bond]->getadjatomidx(start_atom_idx); adjAtom != -1) {
                if (adjAtom == start_edges[0]) {
                    boost::add_edge(start_atom_idx, start_edges[0], g);
                    boost::add_edge(start_edges[1], start_atom_idx, g);
                    break;
                } else if (adjAtom == start_edges[1]) {
                    boost::add_edge(start_atom_idx, start_edges[1], g);
                    boost::add_edge(start_edges[0], start_atom_idx, g);
                    break;
                }
            }
        }

        Visitor vis(frag, r);
        boost::depth_first_visit(g, ring->edges[0][0], vis,
                                 boost::make_vector_property_map<boost::default_color_type>(
                                     boost::get(boost::vertex_index, g)));
        auto [b, e] = boost::out_edges(r->ringAtomList.back(), g);
        for (auto it = b; it != e; ++it) {
            auto bondIdx = frag->isBonded(source(*it, g), target(*it, g));
            if (std::find(begin(ringBondList), end(ringBondList), bondIdx) == end(ringBondList)) {
                ringBondList.insert(begin(ringBondList), bondIdx);
                break;
            }
        }
        boost::remove_edge_if([](auto) { return true; }, g);
        r->ringSize = ring->weight;
        assert(r->ringAtomList.size() == ring->weight);
        assert(ringBondList.size() == ring->weight);
        rings.emplace_back(r, std::move(ringBondList));
    }
    std::sort(rings.begin(), rings.end(), [&](const auto& lhs, const auto& rhs) {
        return std::get<MFCRing*>(lhs)->ringSize < std::get<MFCRing*>(rhs)->ringSize;
    });
    for (auto& ring : rings) {
        std::get<0>(ring)->RIdx = frag->ringCount++;
        frag->ringList.push_back(std::get<0>(ring));
        ringBondMap.insert(
            {std::get<MFCRing*>(ring)->RIdx, std::move(std::get<std::vector<int>>(ring))});
    }
}
