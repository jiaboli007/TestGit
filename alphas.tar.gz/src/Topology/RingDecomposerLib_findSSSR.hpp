//
// Created by xiamr on 8/8/20.
//

#ifndef ALPHACS_RINGDECOMPOSERLIB_FINDSSSR_HPP
#define ALPHACS_RINGDECOMPOSERLIB_FINDSSSR_HPP

#include <memory>

void RingDecomposerLib_findSSSR(MISS::MFCFrag* frag);

inline void RingDecomposerLib_findSSSR(std::unique_ptr<MISS::MFCFrag>& frag) {
    RingDecomposerLib_findSSSR(frag.get());
};

inline void RingDecomposerLib_findSSSR(MISS::MFCFrag& frag) { RingDecomposerLib_findSSSR(&frag); };

#endif  // ALPHACS_RINGDECOMPOSERLIB_FINDSSSR_HPP
