#include "chemgraph.h"

#include "MolStructure/mfcMolecule.h"
#include "Topology/topology.h"

namespace MISS {
// Recursive call to generate permutations
void permugen(int n, int m, int* iarray, int plevel, int* permuts, int* np) {
    if (plevel == m) {
        for (int i = 0; i < m; i++) {
            permuts[*np * m + i] = iarray[i];
        }
        (*np)++;
    } else {
        // Go to the next permuation level
        int nplevel = plevel + 1;
        int* jarray = new int[n];
        for (int i = 0; i < n; i++) jarray[i] = iarray[i];
        // Permutation
        for (int j = plevel; j < n; j++) {
            // exchange jarray[plevel] and jarray[j]
            for (int i = 0; i < n; i++) jarray[i] = iarray[i];
            jarray[plevel] = iarray[j];
            jarray[j] = iarray[plevel];
            permugen(n, m, jarray, nplevel, permuts, np);
        }
        delete[] jarray;
    }
}
// Find the permutation of m elements from n elements (n >= m)
int* permutation(int n, int m) {
    int nx = 1;
    int np = 0;
    int plevel = 0;
    for (int i = 0; i < m; i++) nx = nx * (n - i);
    int* permuts = new int[nx * m];
    int* iarray = new int[n];
    for (int i = 0; i < n; i++) iarray[i] = i;
    permugen(n, m, iarray, plevel, permuts, &np);
    delete[] iarray;
    return permuts;
}

// Implement Graph Node Class
GNode::GNode() {
    for (int i = 0; i < 10; i++) {
        neighborList[i] = -1;
        edgeList[i] = -1;
    }
    ringFlag = 0;
    // Modify or extend this if needed
}

// Graph Edge Class
GEdge::GEdge() {
    ringFlag = 0;
    // Extend if needed
}

ChemGraph::~ChemGraph() {
    for (int i = 0; i < nNodes; i++) {
        if (nodeList[i] != NULL) delete nodeList[i];
    }
    for (int i = 0; i < nEdges; i++) {
        if (edgeList[i] != NULL) delete edgeList[i];
    }
}

ChemGraph* Frag2Graph(MFCFrag* frag) {
    auto graph = std::make_unique<ChemGraph>();
    int nHAtoms = 0;
    int nAtoms = frag->numAtoms;
    int newAtomIdx[nAtoms];
    // overlook H
    for (int i = 0; i < nAtoms; i++) {
        auto Atom = frag->atomList[i];
        if (Atom->atomicNumber == 1) {
            newAtomIdx[i] = -1;
            continue;
        }
        newAtomIdx[i] = nHAtoms;
        nHAtoms++;
    }
    //
    // atoms to nodes
    //
    for (int i = 0; i < nAtoms; i++) {
        auto Atom = frag->atomList[i];
        if (Atom->atomicNumber == 1) continue;
        auto Node = std::make_unique<GNode>();
        // GNode* Node;
        Node->nodeID = newAtomIdx[Atom->AIdx];
        Node->nodeColor = Atom->atomicNumber;
        Node->nConnections = 0;
        Node->ringFlag = Atom->ringAtomFlag;
        Node->visited = 0;
        graph->nodeList.push_back(Node.release());
    }
    //
    // bonds to edges
    //
    int nRealBonds = 0;
    for (int i = 0; i < frag->numBonds; i++) {
        auto Bond = frag->bondList[i];
        if (-1 == newAtomIdx[Bond->atom1] || -1 == newAtomIdx[Bond->atom2]) continue;
        auto Edge = new GEdge();
        Edge->edgeID = nRealBonds;
        Edge->edgeColor = Bond->bondType;
        Edge->node1 = newAtomIdx[Bond->atom1];
        Edge->node2 = newAtomIdx[Bond->atom2];
        Edge->visited = 0;
        graph->edgeList.push_back(Edge);
        nRealBonds++;

        //
        // build relations between nodes and edges
        //
        auto node1 = graph->nodeList[Edge->node1];
        auto node2 = graph->nodeList[Edge->node2];
        node1->neighborList[node1->nConnections] = Edge->node2;
        node2->neighborList[node2->nConnections] = Edge->node1;
        node1->edgeList[node1->nConnections] = Edge->edgeID;
        node2->edgeList[node2->nConnections] = Edge->edgeID;
        node1->nConnections++;
        node2->nConnections++;
    }

    graph->nNodes = graph->nodeList.size();
    graph->nEdges = graph->edgeList.size();

    return graph.release();
}

int DFSWalk(int startNode, ChemGraph* g, GDFSPath* p, int* gNodeID2DFSNodeID) {
    GNode* Node1;
    GNode* Node2;
    GEdge* edge;
    Node1 = g->nodeList[startNode];
    DFSNode* dfsNode = new DFSNode();
    dfsNode->dfsNodeID = p->dfsNodes.size();
    p->dfsNodes.push_back(dfsNode);

    gNodeID2DFSNodeID[Node1->nodeID] = dfsNode->dfsNodeID;

    Node1->visited = 1;
    int nDepth = 0;
    int nOut = 0;

    for (int i = 0; i < Node1->nConnections; i++) {
        int j = Node1->edgeList[i];
        edge = g->edgeList[j];
        if (edge->visited == 0) {
            DFSWalkStep* step = new DFSWalkStep();
            step->startNode = startNode;
            if (startNode == edge->node1)
                step->stopNode = edge->node2;
            else
                step->stopNode = edge->node1;

            step->edgeColor = edge->edgeColor;
            edge->visited = 1;
            //   std::cout << "Add a new step\n";
            p->addStep(step);
            // p->dfsSteps.push_back(step);
            nDepth++;
            Node2 = g->nodeList[step->stopNode];
            if (Node2->visited == 0) {
                // int dfsNodeID = -1;
                nDepth += DFSWalk(step->stopNode, g, p, gNodeID2DFSNodeID);
                // dfsNode->outNodes[nOut] = dfsNodeID;
            }

            dfsNode->outNodes[nOut] = gNodeID2DFSNodeID[Node2->nodeID];
            nOut++;
        }
    }
    dfsNode->DFSDepth = nDepth;
    dfsNode->nConnections = Node1->nConnections;
    dfsNode->nodeColor = Node1->nodeColor;
    dfsNode->nOut = nOut;
    return nDepth;
}

GDFSPath::GDFSPath() { nSteps = 0; }
GDFSPath::~GDFSPath() {
    for (std::size_t i = 0; i < dfsSteps.size(); i++) {
        delete dfsSteps[i];
    }
    for (std::size_t i = 0; i < dfsNodes.size(); i++) {
        delete dfsNodes[i];
    }
    // Extend it when needed
}

int GDFSPath::addStep(DFSWalkStep* step) {
    dfsSteps.push_back(step);
    nSteps++;
    return nSteps;
}

GDFSPath* DFSWalkOnGraph(ChemGraph* g) {
    auto path = std::make_unique<GDFSPath>();

    int nodes = g->nNodes;
    int gNodeID2DFSNodeID[nodes];
    for (int i = 0; i < nodes; i++) gNodeID2DFSNodeID[i] = -1;

    int startNodeID = 0;
    // First step from heavn:
    // Start node from heaven, Edge from heavn (-1)
    //
    DFSWalkStep* step = new DFSWalkStep();
    step->startNode = -1;
    step->stopNode = startNodeID;
    step->edgeColor = -1;
    path->addStep(step);

    DFSWalk(startNodeID, g, path.get(), gNodeID2DFSNodeID);
    //
    // Renumber nodes in path steps.
    //
    for (int i = 0; i < path->getSteps(); i++) {
        step = path->dfsSteps[i];
        if (step->startNode > -1) step->startNode = gNodeID2DFSNodeID[step->startNode];
        if (step->stopNode > -1) step->stopNode = gNodeID2DFSNodeID[step->stopNode];
    }
    return path.release();
}

BTPath::BTPath(int maxsteps, ChemGraph* tg)
    : real_internal_memory(4 * maxsteps * 4 + tg->nNodes, -1) {
    maxSteps = maxsteps;

    startNodes = real_internal_memory.data();
    stopNodes = startNodes + maxSteps;
    visitedEdges = stopNodes + maxSteps;
    walk2NewNodes = visitedEdges + maxSteps;
    gNodeID2PathNodeID = walk2NewNodes + maxSteps;

    target = tg;
    nSteps = 0;
    pathNodes = 0;
}

int BTPath::getSteps() { return nSteps; }

void BTPath::addFirstStep(int stopNode) {
    // First step is to select start node.
    nSteps = 0;
    pathNodes = 0;
    startNodes[nSteps] = -1;
    stopNodes[nSteps] = stopNode;
    visitedEdges[nSteps] = -1;
    walk2NewNodes[nSteps] = 1;
    nSteps++;
    gNodeID2PathNodeID[stopNode] = pathNodes;
    pathNodes++;
    // Mark node and edge as visited
    GNode* gNode = target->nodeList[stopNode];
    gNode->visited = 1;
}

void BTPath::addStep(int startNode, int stopNode, int edgeID, int newnode) {
    startNodes[nSteps] = startNode;
    stopNodes[nSteps] = stopNode;
    visitedEdges[nSteps] = edgeID;
    walk2NewNodes[nSteps] = newnode;
    GEdge* gEdge = target->edgeList[edgeID];
    gEdge->visited = 1;
    nSteps++;
    if (newnode > 0) {
        gNodeID2PathNodeID[stopNode] = pathNodes;
        pathNodes++;
        GNode* gNode = target->nodeList[stopNode];
        gNode->visited = 1;
    }
}
//
//  Roll back rSteps from the current step on BTPath
//
void BTPath::rollBackSteps(int rSteps) {
    for (int i = nSteps - 1; i >= nSteps - rSteps; i--) {
        if (visitedEdges[i] > -1) {
            GEdge* edge = target->edgeList[visitedEdges[i]];
            edge->visited = 0;
        }
        if (walk2NewNodes[i] > 0) {
            GNode* node = target->nodeList[stopNodes[i]];
            node->visited = 0;
            pathNodes--;
        }
        nSteps--;
    }
}
//
//  Roll back to xStep on BTPath (i.e. keep the first xSteps)
//
void BTPath::rollBackToStep(int xStep) {
    for (int i = nSteps - 1; i >= xStep; i--) {
        if (visitedEdges[i] > -1) {
            GEdge* edge = target->edgeList[visitedEdges[i]];
            edge->visited = 0;
        }
        if (walk2NewNodes[i] > 0) {
            GNode* node = target->nodeList[stopNodes[i]];
            node->visited = 0;
            pathNodes--;
        }
        nSteps--;
    }
}
bool BTWalk(GDFSPath* gpath, DFSNode* qroot, int startStep, int walkSteps, ChemGraph* tgraph,
            BTPath* cpath, GNode* troot) {
    if (walkSteps <= 0) return true;
    bool walkFailed = true;
    bool status = true;
    int nTConn = troot->nConnections;
    int nFConn = 0;  // total free connections (not visited)
    int nOut = qroot->nOut;
    int* permut = 0;
    int FEdgeList[10];  // free edge list (not visited neighbor edges)
    int FNodeList[10];  // corresponding neighbor node on un-visited edges)
    int currentStep;
    DFSNode* nextDFSNode;
    DFSWalkStep* wStep;
    GNode* gNextNode;
    GEdge* gEdge;
    //
    // Get the total steps reach the current node troot
    //
    int xSteps = cpath->getSteps();

    for (int i = 0; i < nTConn; i++) {
        GEdge* edge = tgraph->edgeList[troot->edgeList[i]];
        if (edge->visited == 0) {
            FEdgeList[nFConn] = troot->edgeList[i];
            FNodeList[nFConn++] = troot->neighborList[i];
            //   std::cout << "troot neighborList = " << troot->neighborList[i] << "\n";
        }
    }
    if (nFConn < nOut) {
        //  Roll back to xSteps before return
        cpath->rollBackToStep(xSteps);
        return false;
    }
    // Recursive calls
    // Get nOut edges to nFConn edges permutations first.

    permut = permutation(nFConn, nOut);
    int np = 1;
    for (int i = 0; i < nOut; i++) np = np * (nFConn - i);

    for (int i = 0; i < np; i++) {
        int im = i * nOut;
        currentStep = startStep;
        int FastCheckFail = 0;
        int walkedSteps = 0;
        for (int j = 0; j < nOut; j++) {
            int gNodeID = FNodeList[permut[im + j]];
            int gEdgeID = FEdgeList[permut[im + j]];
            gNextNode = tgraph->nodeList[gNodeID];
            gEdge = tgraph->edgeList[gEdgeID];
            nextDFSNode = gpath->dfsNodes[qroot->outNodes[j]];
            wStep = gpath->dfsSteps[currentStep];
            int walkDepth = nextDFSNode->DFSDepth;
            //
            // Fast check first by Node type, edge type, connections
            //
            if (gNextNode->nodeColor != nextDFSNode->nodeColor ||
                gEdge->edgeColor != wStep->edgeColor ||
                gNextNode->nConnections < nextDFSNode->nConnections) {
                FastCheckFail = 1;
                //  std::cout << "Fast Check Failed A\n";
            }
            // Check ring closure edge
            // nextDFSNode->dfsNodeID < qroot->dfsNodeID => ring closure
            //
            // If ringFlag is true, then gNextNode must be visited
            // And its nodeID must be equal to nextDFSNode ID.
            //
            bool ringFlag = nextDFSNode->dfsNodeID < qroot->dfsNodeID;
            if ((ringFlag && gNextNode->visited == 0) || (!ringFlag && gNextNode->visited == 1))
                FastCheckFail = 1;
            if (FastCheckFail == 1) break;

            if (gNextNode->visited == 1 &&
                (nextDFSNode->dfsNodeID != cpath->gNodeID2PathNodeID[gNodeID])) {
                FastCheckFail = 1;
                //  std::cout << "Fast Check Failed B\n";
            }
            if (FastCheckFail == 1) break;
            currentStep = currentStep + 1;
            if (!ringFlag) currentStep += walkDepth;
        }
        // if(FastCheckFail == 1) std::cout << "Fast Check Failed\n";
        if (FastCheckFail == 1) continue;
        status = true;
        currentStep = startStep;
        for (int j = 0; j < nOut; j++) {
            int gNodeID = FNodeList[permut[im + j]];
            int gEdgeID = FEdgeList[permut[im + j]];
            gNextNode = tgraph->nodeList[gNodeID];
            gEdge = tgraph->edgeList[gEdgeID];
            nextDFSNode = gpath->dfsNodes[qroot->outNodes[j]];
            wStep = gpath->dfsSteps[currentStep];
            int walkDepth = nextDFSNode->DFSDepth;
            bool ringFlag = nextDFSNode->dfsNodeID < qroot->dfsNodeID;
            //
            // Add a BTWalk step to cpath
            // and mark the corresponding edge as visited
            //
            int startNode = troot->nodeID;
            int stopNode = gNodeID;
            int newNodeFlag = 1 - gNextNode->visited;  // 1=newly visited, 0=no
            cpath->addStep(startNode, stopNode, gEdgeID, newNodeFlag);
            walkedSteps++;
            currentStep = currentStep + 1;
            if (walkDepth > 0 && (!ringFlag)) {
                status =
                    BTWalk(gpath, nextDFSNode, currentStep, walkDepth, tgraph, cpath, gNextNode);
                if (status) {
                    currentStep = currentStep + walkDepth;
                }
            }
            if (!status) break;
        }
        if (status) {
            // std::cout<<startStep<<"  mapping succeed!\n";
            delete[] permut;
            return true;  // mapping succeed for troot.
        } else {
            // std::cout << "A rollBack to sSteps\n";
            cpath->rollBackToStep(xSteps);
        }
    }
    // std::cout << "B rollBack to sSteps\n";
    cpath->rollBackToStep(xSteps);
    delete[] permut;
    return false;
}

int* BTMapping(GDFSPath* qpath, ChemGraph* tgraph) {
    int pathSteps = qpath->getSteps();
    int* TNodeList = new int[pathSteps];
    BTPath* cpath = new BTPath(pathSteps, tgraph);
    DFSNode* qroot = qpath->dfsNodes[0];
    GNode* troot;
    int tgnodes = tgraph->nNodes;
    int mappedNodes = 0;
    bool status = false;
    int startStep = 1;
    int pathDepth = qroot->DFSDepth;

    // Try all starting nodes

    for (int i = 0; i < tgnodes; i++) {
        // std::cout << "Try node i= " << i << "\n";
        cpath->rollBackToStep(0);
        troot = tgraph->nodeList[i];
        if (troot->nodeColor != qroot->nodeColor | troot->nConnections < qroot->nConnections)
            continue;
        cpath->addFirstStep(i);
        troot->visited = 1;
        status = BTWalk(qpath, qroot, startStep, pathDepth - 1, tgraph, cpath, troot);
        if (status) break;
    }
    if (status) {
        for (int i = 0; i < pathSteps; i++) {
            if (cpath->walk2NewNodes[i] > 0) {
                TNodeList[mappedNodes++] = cpath->stopNodes[i];
                // std::cout << "Mapped Nodes" << TNodeList[mappedNodes-1] << "\n";
            }
        }
    } else {
        delete[] TNodeList;
        TNodeList = 0;
        // std::cout << "Mapping failed \n";
    }

    // Do BT mapping
    // If failed, free TNodeList, and set it to NULL
    delete cpath;
    return TNodeList;
}

//
// BTMapping For Pharmacophore mapping function
//

int* BTMappingForPh4(GDFSPath* qpath, ChemGraph* tgraph, int Idx) {
    int pathSteps = qpath->getSteps();
    auto TNodeList = std::make_unique<int[]>(pathSteps);
    BTPath* cpath = new BTPath(pathSteps, tgraph);
    DFSNode* qroot = qpath->dfsNodes[0];
    GNode* troot;
    int tgnodes = tgraph->nNodes;
    int mappedNodes = 0;
    bool status = false;
    int startStep = 1;
    int pathDepth = qroot->DFSDepth;
    cpath->rollBackToStep(0);
    troot = tgraph->nodeList[Idx];
    if (troot->nodeColor != qroot->nodeColor | troot->nConnections < qroot->nConnections) {
        TNodeList.reset();
        // std::cout << "Mapping failed\n";
        delete cpath;
        return TNodeList.release();
    }
    cpath->addFirstStep(Idx);
    troot->visited = 1;
    status = BTWalk(qpath, qroot, startStep, pathDepth - 1, tgraph, cpath, troot);
    if (status) {
        for (int i = 0; i < pathSteps; i++) {
            if (cpath->walk2NewNodes[i] > 0) {
                TNodeList[mappedNodes++] = cpath->stopNodes[i];
                // std::cout<<"Matched!   " << "Mapped Nodes" << TNodeList[mappedNodes-1] << "\n";
            }
        }
    } else {
        TNodeList.reset();
        // std::cout << "Mapping failed \n";
    }

    // Do BT mapping
    // If failed, free TNodeList, and set it to NULL
    delete cpath;
    return TNodeList.release();
}

//
// assume that only index of heavy atoms are considered
//

int* subSearch(MFCFrag* qfrag, MFCFrag* tfrag, int Idx) {
    if ((tfrag->atomList[Idx])->atomicNumber == 1) {
        // std::cout<<"Only heavy atoms are considered !\n";
        return 0;
    }
    findSSSR(qfrag);
    setRingAtomFlags(qfrag);
    // findSSSR(tfrag);
    // setRingAtomFlags(tfrag);
    // for(int i=0;i<tfrag->numAtoms;i++){
    //    std::cout<<i+1<<"\t"<<(tfrag->atomList[i])->aromaticFlag<<"\n";
    // }
    // for(int i=0;i<qfrag->numAtoms;i++){
    // std::cout<<i+1<<"\t"<<(qfrag->atomList[i])->aromaticFlag<<"\n";
    // }
    // ChemGraph* QGraph = new ChemGraph();
    // ChemGraph* TGraph = new ChemGraph();
    // GDFSPath* GPath = new GDFSPath();
    // ChemGraph* QGraph;
    MFCAtom* atom;
    MFCBond* bond;
    GNode* Node;
    GEdge* Edge;
    // setFragnH(Frag);
    ChemGraph* QGraph = Frag2Graph(qfrag);
    ChemGraph* TGraph = Frag2Graph(tfrag);

    int* newID = new int[tfrag->numAtoms];
    int heavyAtomCount = 0;
    int* oldID = new int[tfrag->numAtoms];
    for (int i = 0; i < tfrag->numAtoms; i++) {
        atom = tfrag->atomList[i];
        if (atom->atomicNumber == 1) {
            newID[i] = -1;
            continue;
        }
        newID[i] = heavyAtomCount;
        oldID[heavyAtomCount] = i;
        heavyAtomCount++;
    }

    GDFSPath* GPath = DFSWalkOnGraph(QGraph);

    // print out GDFSpath

    /*  DFSWalkStep* step;
      int nSteps = GPath->getSteps();

      std::cout<< "nsteps = " << GPath->getSteps() << "\n";

      std::cout<< "DFSWalkSteps\n";
      for(int i=0;i<GPath->dfsSteps.size();i++){
          step = GPath->dfsSteps[i];
          std::cout<<step->startNode<< "-->" <<step->stopNode<< " Step color "
                   <<step->edgeColor <<"\n";
      }

      int numNode = GPath->dfsNodes.size();

      std::cout << "dfsNodeID\tDFSDepth\tnOut\n";
      DFSNode* dfsnode;
      for(int i=0;i<numNode;i++){
         dfsnode = GPath->dfsNodes[i];
         std::cout<<dfsnode->dfsNodeID<<"\t"<<dfsnode->DFSDepth<<"\t"<<dfsnode->nOut<<"\n";
         for (int j=0; j < dfsnode->nOut; j++ ) {
         std::cout<< " j= " << j << " " << "outList " << dfsnode->outNodes[j] << "\n";
         }
      }*/
    //
    // Map QGraph to TGraph
    //
    int nNodes = QGraph->nNodes;
    std::unique_ptr<int[]> TNodeList{BTMappingForPh4(GPath, TGraph, newID[Idx])};
    bool isMatch = false;
    auto tMapList = std::make_unique<int[]>(nNodes);
    if (TNodeList) {
        for (int i = 0; i < nNodes; i++) {
            tMapList[i] = oldID[TNodeList[i]];
            // std::cout<<"Mapped atoms in target:"<<tMapList[i]+1<<"\n";
        }
        isMatch = true;
    }
    delete[] newID;
    delete[] oldID;
    delete QGraph;
    delete TGraph;
    delete GPath;
    if (isMatch)
        return tMapList.release();
    else
        return TNodeList.release();
}

}  // namespace MISS
