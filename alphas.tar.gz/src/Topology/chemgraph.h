#ifndef chemgraph_h
#define chemgraph_h
/******************************************************************************
 *                                                                             *
 *    Category:   Graph Representation of Chemistry Structures                 *
 *    Function:   Define classes for ChemGraphs                                *
 *    Authors:    RCDD                                                         *
 *    Date:       September 2012                                               *
 *                                                                             *
 ******************************************************************************/

#include <vector>

#include "Utils/mfcUtil.hpp"

// Graph Node Class
namespace MISS {

class GNode {
public:
    GNode();
    int nodeID;
    int nodeColor;
    int nConnections;
    int neighborList[10];
    int edgeList[10];
    int ringFlag;  // 0=not a ring node; 1=is a ring node
    int visited;   // 0=not visited yet; 1 = visited
};
// Graph Edge Class
class GEdge {
public:
    GEdge();
    int edgeID;
    int edgeColor;
    int node1;     // First node index
    int node2;     // Second node index
    int ringFlag;  // 0=not a ring edge; 1= is a ring edge
    int visited;   // 0=not visited yet;1=visited
};

// Graph Edge Class
class ChemGraph {
public:
    ~ChemGraph();
    int nNodes;
    int nEdges;
    std::vector<GNode*> nodeList;  // Node list
    std::vector<GEdge*> edgeList;  // Edge list
};

// DFS Step
class DFSWalkStep {
public:
    int startNode;  // The sequence ID of the starting node in the DFS walk step.
    int stopNode;   // The sequence ID of the arrival node in a DFS walk step;
    int edgeColor;
};

// DFS Node Property
class DFSNode {
public:
    int dfsNodeID;     // equals to the sequence of dfsNode
    int DFSDepth;      // The depth (i.e. the total number of steps)
                       // of DFS walk from this node.
    int nConnections;  // The total number of connections.
    int nOut;          // The number of out going branches.
    int outNodes[10];  // The list of out going neighbors. (DFSNodes)
    int nodeColor;
};

// Path of a query graph from a DFS walk.
class GDFSPath {
public:
    GDFSPath();
    ~GDFSPath();
    std::vector<DFSWalkStep*> dfsSteps;  // Collection of DFS walk steps
    std::vector<DFSNode*> dfsNodes;      // Collection of DFS nodes info of a
                                         // DFS walk. The collection in the same
                                         // order as they have been reached in
                                         // a DFS walk.
    int getSteps() { return nSteps; }
    int addStep(DFSWalkStep* step);

private:
    int nSteps;  // Total number of steps of a DFS walk on a query graph
};

// Candidate Path of BT mapping on a target graph
class BTPath {
public:
    BTPath(int maxsteps, ChemGraph* tgraph);
    int* startNodes;
    int* stopNodes;
    int* visitedEdges;
    int* walk2NewNodes;
    int* gNodeID2PathNodeID;
    int getSteps();  // get the number of steps of the current BTPath
    void addStep(int start, int stop, int edgeID, int newNode);
    void addFirstStep(int start);
    void rollBackSteps(int rSteps);  // Roll back the status by rSteps
    void rollBackToStep(int stepX);  // Roll back to the status of step X

private:
    int pathNodes;  // Total nodes on the path
    int nSteps;     // Total number of steps of BT mapping on a target graph
    int maxSteps;
    ChemGraph* target;  // target graph for BT mapping. Holding status of
                        // visiting.

    std::vector<int> real_internal_memory;
};

// Method
ChemGraph* Frag2Graph(MFCFrag* frag);
int DFSWalk(int startNode, ChemGraph* g, GDFSPath* p, int* gNodeID2DFSNodeID);  // star with a node
GDFSPath* DFSWalkOnGraph(ChemGraph* g);
int* BTMapping(GDFSPath* qpath, ChemGraph* tgraph);  // Return a list of mapped
                                                     // nodes in target graph
int* subSearch(MFCFrag* qfrag, MFCFrag* tfrag, int Idx);

bool BTWalk(GDFSPath* gpath, DFSNode* qroot, int startStep, int walkSteps, ChemGraph* tgraph,
            BTPath* cpath, GNode* troot);

int* BTMappingForPh4(GDFSPath* qpath, ChemGraph* tgraph, int Idx);

}  // namespace MISS
#endif /* chemgraph_h */
