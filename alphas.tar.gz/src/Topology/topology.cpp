/************************************************
 *	Category:                               *
 *	Function:  Find SSSRs;                  *
 *		   Mark ring and aromaticity;   *
 *		   (refer to cheminfo/ )        *
 *	Author:    Xiuming Li                   *
 *	Date:      2017-05-17                   *
 ************************************************/

#include <fstream>
#include <iostream>
#include <map>
#include <string>
#include <vector>

#include "topology.h"

#include "MolStructure/mfcAtom.h"
#include "MolStructure/mfcBond.h"
#include "MolStructure/mfcMolecule.h"
#include "MolStructure/mfcRing.h"

using namespace std;

namespace MISS {

int getStereoParity(MFCFrag* Frag, MFCAtom* Atom, int* mapx) { return 0; }

// store ring bond list
thread_local map<int, vector<int> > ringBondMap;
thread_local std::vector<int> ringBondList;
thread_local map<int, vector<int> >::iterator ringBondMap_it;
void printringBondMap();

int checkBondInRing(int bond_idx);
int isSuperRing(MFCRing* ring);
void unmarkFragBond(MFCFrag* Frag, int* bondMark_arr);
void printFragBondType(MFCFrag* Frag);

void clearringBondMap() {
    ringBondMap.clear();
    ringBondList.clear();
    //    map<int, vector<int> > ringBondMap_tmp;
    //    ringBondMap.swap(ringBondMap_tmp);
    //    std::vector<int> ringBondList_tmp;
    //    ringBondList.swap(ringBondList);
}

// Find smallest set of smallest rings of a molecule
void findSSSR(MFCFrag* Frag) {
    assert(Frag);

    ringBondMap.clear();

    int bondMark_arr[Frag->numBonds];
    Frag->ringCount = 0;

    volatile int maxringsize = 0;
    // find the possible maximal ring size
    for (auto&& atom : Frag->atomList) {
        if (atom->nBonds > 1) maxringsize++;
    }
    constexpr int MAXRINGSIZE = 40;
    if (maxringsize > MAXRINGSIZE) maxringsize = MAXRINGSIZE;

    int i = 3;  // the min size of ring is defined as 3
    while (i <= maxringsize) {
        MFCPath path(i);  // alloc length of path

        for (int j = 0; j < Frag->numAtoms; j++) {
            if (Frag->atomList[j]->nBonds > 1) {
                path.cursor = 0;
                path.iniPath(Frag, j, bondMark_arr);

                for (;;) {
                    auto ring = std::make_unique<MFCRing>();

                    if (getRing(Frag, &path, ring.get(), bondMark_arr) == 0) {
                        break;
                    }
                    if (getAtomlist(&path, ring.get()) != i) {
                        continue;
                    }
                    if (isSuperRing(ring.get()) == 0) {
                        ring->ringSize = i;
                        ring->RIdx = Frag->ringCount++;
                        Frag->ringList.push_back(ring.get());
                        ringBondMap.insert(make_pair(ring->RIdx, ringBondList));
                        ring.release();
                    }
                }
            }
        }
        i++;
    }
}

// get ring path
// int getRing(MFCFrag* Frag, MFCPath* path, MFCRing* ring)
int getRing(MFCFrag* Frag, MFCPath* path, MFCRing* ring, int* bondMark_arr) {
    int i;
    int atom_idx, adjatom_idx, bond_idx;
    atom_idx = path->nodeList[0]->atomIdx;

    while (1) {
        // if(getPath(Frag, path) == 1)
        if (getPath(Frag, path, bondMark_arr) == 1) {
            if (path->len != path->nodeList.size()) {
                std::cerr << "the number of pathnode is not equal to path length." << endl;
                exit(1);
            }
            // path->printPath();
            adjatom_idx = path->nodeList[path->len - 1]->atomIdx;
            if ((adjatom_idx < 0) || (atom_idx == adjatom_idx)) continue;
            bond_idx = Frag->isBonded(atom_idx, adjatom_idx);
            /**
            if(bond_idx >= 0 && ring->ringBondList.empty())
            {
              ring->ringBondList.push_back(bond_idx);
              for(i=1; i<path->len; i++)
              {
                //ring->ringBondList.push_back(path->nodeList[i]->bond->BIdx);
                ring->ringBondList.push_back(path->nodeList[i]->bondIdx);
              }
              return 1;
            }
            **/

            if (bond_idx >= 0) {
                ringBondList.clear();
                ringBondList.push_back(bond_idx);
                int tmp;
                for (i = 1; i < path->len; i++) {
                    tmp = path->nodeList[i]->bondIdx;
                    ringBondList.push_back(tmp);
                    // ringBondList.push_back(path->nodeList[i]->bond->BIdx);
                }
                return 1;
            }

        } else
            return 0;
    }
    return 0;
}

// path should be pre-initialized
// int getPath(MFCFrag* Frag, MFCPath* path)
int getPath(MFCFrag* Frag, MFCPath* path, int* bondMark_arr) {
    MFCPathNode* node;
    MFCAtom* atom;
    MFCAtom* adjatom;
    MFCBond* bond;
    int atom_idx, adjatom_idx, bond_idx;
    int adjbondcnt;
    int found;

    if (path->cursor == path->len - 1) {
        path->cursor--;
        MFCPathNode* tmp = path->nodeList.back();
        delete tmp;
        path->nodeList.pop_back();
    }
    // std::cout << "getPath():in" << endl;
    while (1) {
        if (path->cursor < 0) {
            // Frag->unmarkFragBond();
            unmarkFragBond(Frag, bondMark_arr);
            path->cursor = 0;
            return 0;
        }  // no more path to search

        found = 0;
        if (path->cursor == 0)
            // FragraunmarkFragBond();
            unmarkFragBond(Frag, bondMark_arr);

        node = path->nodeList[path->cursor];
        atom_idx = node->atomIdx;
        atom = Frag->atomList[atom_idx];
        adjbondcnt = atom->nBonds;

        int k;
        while (1) {
            k = node->cursor++;
            if (k < adjbondcnt) {
                bond_idx = atom->bondList[k];
                bond = Frag->bondList[bond_idx];
                // if(!bond->bondMark)
                if (!bondMark_arr[bond_idx]) {
                    adjatom_idx = bond->getadjatomidx(atom_idx);
                    adjatom = Frag->atomList[adjatom_idx];
                    if (adjatom->atomicNumber == 1) continue;  // if adjacent atom is 'H'
                    atom = adjatom;
                    // bond->bondMark = 1;
                    bondMark_arr[bond_idx] = 1;
                    adjbondcnt = atom->nBonds;
                    path->cursor++;
                    // path->addPathNode(adjatom_idx, bond);
                    path->addPathNode(adjatom_idx, bond_idx);
                    if (path->cursor == path->len - 1) return 1;
                    found = 1;
                    break;
                }
            } else
                break;
        }
        if (found == 0) {
            path->cursor--;
            MFCPathNode* tmp = path->nodeList.back();
            delete tmp;
            path->nodeList.pop_back();
            if (path->cursor < 0) {
                path->cursor = 0;
                return 0;
            }
        }
    }
}

int getAtomlist(MFCPath* path, MFCRing* ring) {
    int i;
    int atom_idx;
    for (i = 0; i < path->len; i++) {
        atom_idx = path->nodeList[i]->atomIdx;
        if (!ring->checkAtomInRing(atom_idx)) ring->ringAtomList.push_back(atom_idx);
    }
    return ring->ringAtomList.size();
}

void printringBondMap() {
    ringBondMap_it = ringBondMap.begin();

    while (ringBondMap_it != ringBondMap.end()) {
        std::cout << ringBondMap_it->first << endl;
        for (unsigned int i = 0; i != ringBondMap_it->second.size(); i++) {
            std::cout << ringBondMap_it->second[i] << " ";
        }
        std::cout << endl;
        ringBondMap_it++;
    }
}

// Mark ring atoms (assuming rings are found)
void setRingAtomFlags(MFCFrag* Frag) {
    int e;  // pi electron count;

    unsigned int i;
    int j, ringsize;
    int atom_idx, adjatom_idx, bond_idx;
    int atomZ;
    MFCAtom* atom;
    MFCBond* bond;

    for (i = 0; i < Frag->ringList.size(); i++) {
        e = 0;
        ringsize = Frag->ringList[i]->ringSize;
        for (j = 0; j < ringsize; j++) {
            atom_idx = Frag->ringList[i]->ringAtomList[j];
            atom = Frag->atomList[atom_idx];
            atom->ringAtomFlag = 1;
        }

        // mark aromatic atoms and bonds
        for (j = 0; j < ringsize; j++) {
            atom_idx = Frag->ringList[i]->ringAtomList[j];
            atom = Frag->atomList[atom_idx];
            atomZ = atom->atomicNumber;
            if (Frag->potentialAromatic(atom_idx, i) == 0) {
                e = 0;
                break;
            }
            if ((atomZ > 5 && atomZ < 9) || (atomZ == 16)) {
                if (atomZ == 6) {
                    e++;
                    if (atom->chargeC() == (-1)) e++;
                } else {
                    if ((atomZ == 7) && (Frag->isSP2Atom(atom)) >= 0)
                        e++;
                    else
                        e += 2;
                }
            }
        }
        if ((e > 5) && ((e - 2) % 4) == 0) {
            Frag->ringList[i]->aromaticity = 1;

            for (j = 0; j < ringsize; j++) {
                bond_idx = ringBondMap.find(i)->second[j];
                bond = Frag->bondList[bond_idx];
                bond->bondType = 4;
            }

            for (j = 0; j < ringsize; j++) {
                atom_idx = Frag->ringList[i]->ringAtomList[j];
                atom = Frag->atomList[atom_idx];
                if (j < (ringsize - 1))
                    adjatom_idx = Frag->ringList[i]->ringAtomList[j + 1];
                else
                    adjatom_idx = Frag->ringList[i]->ringAtomList[0];
                Frag->bondList[Frag->isBonded(atom_idx, adjatom_idx)]->aromaticFlag = 1;
                atom->aromaticFlag = 1;
            }
        }
        if (ringsize == 6) {
            int cnt = 0;  // benzene atoms count;
            for (j = 0; j < ringsize; j++) {
                if (atom->atomicNumber == 6 && atom->aromaticFlag == 1) cnt++;
            }
            // if is benzene
            if (cnt == 6) {
                for (j = 0; j < ringsize; j++) {
                    atom_idx = Frag->ringList[i]->ringAtomList[j];
                    atom = Frag->atomList[atom_idx];
                    atom->ringAtomFlag = 2;  // benzene Flag
                }
            }
        }
    }
}

// Mark hybridized atoms
//"setspStatus" in ./cheminfo/mol.cpp
void setHybridization(MFCFrag* Frag) {
    unsigned int i;
    int j;
    int adjbondcnt;
    int bond_idx;
    MFCAtom* atom;
    MFCBond* bond;

    for (i = 0; i < Frag->atomList.size(); i++) {
        atom = Frag->atomList[i];
        if (atom->atomicNumber == 1) {
            atom->hybride = MFC_NO_HYBRID;
            continue;
        }
        adjbondcnt = atom->nBonds;
        for (j = 0; j < adjbondcnt; j++) {
            bond_idx = atom->bondList[j];
            bond = Frag->bondList[bond_idx];
            if (bond->bondType == 3) {
                atom->hybride = MFC_SP_HYBRID;
                break;
            } else if (bond->bondType == 2 || bond->bondType == 4) {
                atom->hybride = MFC_SP2_HYBRID;
                break;
            } else if (bond->bondType == 1) {
                atom->hybride = MFC_SP3_HYBRID;
                // uncertain complement
                if (atom->atomicNumber == 8 && atom->bondList.size() == 1)
                    atom->hybride = MFC_SP2_HYBRID;
                if (atom->atomicNumber == 7) {
                    int yes = 0;
                    MFCBond* bond_tmp;
                    int adjatom_idx_tmp, bond_idx_tmp;
                    for (unsigned int tmp = 0; tmp != atom->bondList.size(); tmp++) {
                        bond_idx_tmp = atom->bondList[tmp];
                        bond_tmp = Frag->bondList[bond_idx_tmp];
                        adjatom_idx_tmp = bond_tmp->getadjatomidx(atom->AIdx);
                        if (Frag->atomList[adjatom_idx_tmp]->aromaticFlag == 1) {
                            atom->hybride = MFC_SP2_HYBRID;
                            yes = 1;
                            break;
                        }
                    }
                    if (yes == 1) break;
                }
            } else
                break;
        }
    }
}

int MFCAtom::chargeC() {
    if (atomicNumber != 6) return 99;
    if (nBonds == 4) return 1;
    return 99;
}

int MFCBond::getadjatomidx(int atom_idx) {
    if (atom1 == atom_idx) return atom2;
    if (atom2 == atom_idx) return atom1;
    return -1;
}

int MFCRing::checkAtomInRing(int atom_idx) {
    unsigned int i;
    if (ringAtomList.empty()) return 0;
    for (i = 0; i < ringAtomList.size(); i++) {
        if (ringAtomList[i] == atom_idx) return 1;
    }
    return 0;
}

int checkBondInRing(int bond_idx) {
    unsigned int i;
    if (ringBondMap_it->second.empty()) return 0;
    for (i = 0; i < ringBondMap_it->second.size(); i++) {
        if (ringBondMap_it->second[i] == bond_idx) return 1;
    }
    return 0;
}

/**
int MFCRing::checkBondInRing(int bond_idx)
{
  unsigned int i;
  if(ringBondList.empty())
    return 0;
  for(i=0;i<ringBondList.size();i++)
  {
    if(ringBondList[i] == bond_idx)
      return 1;
  }
  return 0;
}
**/

void MFCRing::printRing() {
    std::cout << "ringSize:" << ringSize << " "
              << "RIdx:" << RIdx << " "
              << "aromaticity:" << aromaticity << endl;
    unsigned int i;

    std::cout << "ringAtomList: ";
    if (!ringAtomList.empty()) {
        for (i = 0; i != ringAtomList.size(); i++) {
            std::cout << ringAtomList[i] << " ";
        }
    }
    std::cout << endl;
    /**
    std::cout << "ringBondList: ";
    if(!ringBondList.empty())
    {
      for(i=0; i!=ringBondList.size(); i++)
      {
        std::cout << ringBondList[i] << " ";
      }
    }
    std::cout << endl;
    **/
    return;
}

int MFCFrag::potentialAromatic(int atom_idx, int ring_idx) {
    int i;
    int adjbondcnt;
    int bond_idx, adjatom_idx;
    int atomZ;
    MFCAtom* atom;
    MFCBond* bond;

    atom = atomList[atom_idx];
    adjbondcnt = atom->nBonds;
    for (i = 0; i < adjbondcnt; i++) {
        bond_idx = atom->bondList[i];
        bond = bondList[bond_idx];
        adjatom_idx = bond->atom1;
        if (bond->atom1 == atom_idx) adjatom_idx = bond->atom2;
        if (bond->bondType == 2) {
            if (ringList[ring_idx]->checkAtomInRing(adjatom_idx) == 1) return 1;
            /**
            else
            {
              if(bond->ringBondFlag == 1)
                return 1;
            }
            **/
        } else if (bond->bondType == 4) {
            return 1;
        } else {
            atomZ = atomList[atom_idx]->atomicNumber;
            if ((atomZ == 7) || (atomZ == 8) || (atomZ == 16)) {
                if (atomList[adjatom_idx]->ringAtomFlag == 1) return 1;
            }
        }
    }
    return 0;
}

int MFCFrag::isSP2Atom(MFCAtom* atom) {
    int i;
    int bond_idx;
    MFCBond* bond;
    for (i = 0; i < atom->nBonds; i++) {
        bond_idx = atom->bondList[i];
        bond = bondList[bond_idx];
        if (bond->bondType == 2) return i;
    }
    return -1;
}

// return bond index
int MFCFrag::isBonded(int atom_idx, int adjatom_idx) {
    int i;
    int adjbondcnt, bond_idx;
    MFCAtom* atom;
    MFCBond* bond;

    atom = atomList[atom_idx];
    adjbondcnt = atom->nBonds;

    for (i = 0; i < adjbondcnt; i++) {
        bond_idx = atom->bondList[i];
        bond = bondList[bond_idx];
        if (adjatom_idx == bond->getadjatomidx(atom_idx)) return bond_idx;
    }
    return -1;
}

void unmarkFragBond(MFCFrag* Frag, int* bondMark_arr) {
    int i;
    for (i = 0; i < Frag->numBonds; i++) bondMark_arr[i] = 0;
}

/**
void MFCFrag::unmarkFragBond()
{
   int i;
   for(i=0; i<Frag->numBonds; i++)
      bondList[i]->bondMark = 0;
}

int MFCFrag::isSuperRing(MFCRing* ring)
{
  if(ringList.empty())
    return 0;
  unsigned int i, j;
  int foundsamebond;
  for(i=0; i<ring->ringBondList.size(); i++)
  {
    foundsamebond = 0;
    for(j=0; j<ringList.size(); j++)
    {
      if(ringList[j]->checkBondInRing(ring->ringBondList[i]) == 1)
      {
        foundsamebond = 1;
        break;
      }
    }
    if(foundsamebond == 0)
      return 0;
  }
  return -1;
}
**/

int isSuperRing(MFCRing* ring) {
    unsigned int i;
    int foundsamebond;

    for (i = 0; i < ringBondList.size(); i++) {
        foundsamebond = 0;
        ringBondMap_it = ringBondMap.begin();
        while (ringBondMap_it != ringBondMap.end()) {
            if (checkBondInRing(ringBondList[i]) == 1) {
                foundsamebond = 1;
                break;
            }
            ringBondMap_it++;
        }
        if (foundsamebond == 0) return 0;
    }
    return -1;
}

// why don't store bond idx instead of bond?
// int MFCPath::iniPath(MFCFrag* Frag, int start)
int MFCPath::iniPath(MFCFrag* Frag, int start, int* bondMark_arr) {
    MFCAtom* atom = Frag->atomList[start];
    MFCPathNode* node = new MFCPathNode();
    if (cursor == 0) {
        node->atomIdx = start;
        node->adjbondcnt = atom->nBonds;
        if (!nodeList.empty())
            // nodeList.clear();
            for (unsigned int i = 0; i != nodeList.size(); i++) delete nodeList[i];

        nodeList.push_back(node);
    } else {  // to be checked
        if (cursor < len)
            // nodeList[cursor]->bond->bondMark = 0;
            // Frag->bondList[nodeList[cursor]->bondIdx]->bondMark = 0;
            bondMark_arr[nodeList[cursor]->bondIdx] = 0;
        cursor--;
        MFCPathNode* tmp = nodeList.back();
        delete tmp;
        nodeList.pop_back();
    }
    return 1;
}

// void MFCPath::addPathNode(int atom_idx, MFCBond* bond)
void MFCPath::addPathNode(int atom_idx, int bond_idx) {
    MFCPathNode* node = new MFCPathNode();
    node->atomIdx = atom_idx;
    // node->bond = bond;
    node->bondIdx = bond_idx;
    node->cursor = 0;
    nodeList.push_back(node);
}

void MFCPath::printPath() {
    std::cout << "PathInfo:" << endl;
    std::cout << "\tlen:" << len << "\tcursor:" << cursor << "\tnodeList.size:" << nodeList.size()
              << endl;
    if (!nodeList.empty()) {
        for (unsigned int i = 0; i != nodeList.size(); i++) {
            nodeList[i]->printPathNode();
        }
    }
    return;
}

void MFCPathNode::printPathNode() {
    std::cout << "PathInfo::nodeListInfo:" << endl;
    std::cout << "\tatomIdx:" << atomIdx << " "
              << "\tadjbondcnt:" << adjbondcnt << " "
              << "\tcursor:" << cursor << endl;
    return;
}

MFCPath::~MFCPath() {
    /**
    for(std::vector<MFCPathNode*>::iterator it=nodeList.begin();
       it!=nodeList.end(); it++)
    {
      delete *it;
    }
    nodeList.clear();
    //std::vector<MFCPathNode*>(nodeList).swap(nodeList);
    //std::cout << nodeList.capacity() << endl;
    **/
    // std::cout << nodeList.size() << endl;
    // for(unsigned int i=0; i!=nodeList.size(); i++)
    // delete nodeList[i];
}

void printFragBondType(MFCFrag* Frag) {
    for (int i = 0; i < Frag->numBonds; i++) {
        std::cout << Frag->bondList[i]->bondType << " ";
    }
    std::cout << endl;
}

// lixm:output all information of Frag
void outputFragInfo(MFCFrag* Frag) {
    std::ofstream fout;
    fout.open("outputFragInfo.txt");

    fout << "NAME: " << Frag->fragname << endl;
    fout << "numAtoms: " << Frag->numAtoms << endl;
    fout << "numBonds: " << Frag->numBonds << endl;
    fout << "numRings: " << Frag->numRings << endl;
    // fout << "ringCount: "  << Frag->ringCount  << endl;
    fout << "stereoFlag: " << Frag->stereoFlag << endl;
    fout << "nRotEdges: " << Frag->nRotEdges << endl;
    fout << "fragname: " << Frag->fragname << endl;

    unsigned int i, j;
    fout << "ATOMINFO:\n";
    for (i = 0; i < Frag->atomList.size(); i++) {
        MFCAtom* atom = Frag->atomList[i];
        fout << "/*ATOM" << i << "**************/" << endl;
        fout << "atomicNumber:" << atom->atomicNumber << endl;
        fout << "nH: " << atom->nH << endl;
        fout << "AIdx: " << atom->AIdx << endl;
        fout << "hybride:" << atom->hybride << endl;
        fout << "nBonds:" << atom->nBonds << endl;
        fout << "ringAtomFlag: " << atom->ringAtomFlag << endl;
        fout << "aromaticFlag: " << atom->aromaticFlag << endl;
        fout << "mdlChargeFlag: " << atom->mdlChargeFlag << endl;
        fout << "charge: " << atom->charge << endl;
        fout << "FormalCharge:" << atom->FormalCharge << endl;
    }

    fout << "BONDINFO:\n";
    for (i = 0; i < Frag->bondList.size(); i++) {
        MFCBond* bond = Frag->bondList[i];
        fout << "/*BOND" << i << "**************/" << endl;
        fout << "atom1: " << bond->atom1 << endl;
        fout << "atom2: " << bond->atom2 << endl;
        fout << "BIdx: " << bond->BIdx << endl;
        fout << "ringBondFlag: " << bond->ringBondFlag << endl;
        fout << "aromaticFlag: " << bond->aromaticFlag << endl;
        fout << "bondType: " << bond->bondType << endl;
    }

    fout << "RINGINFO:\n";
    if (Frag->ringList.empty()) fout << "No Ring!" << endl;
    fout << "RINGamount: " << Frag->ringList.size() << endl;
    for (i = 0; i < Frag->ringList.size(); i++) {
        MFCRing* ring = Frag->ringList[i];
        fout << "/*RING" << i << "**************/" << endl;
        fout << "ringSize: " << ring->ringSize << endl;
        fout << "RIdx: " << ring->RIdx << endl;
        fout << "aromaticity: " << ring->aromaticity << endl;
        fout << "ringatomlist: ";
        for (j = 0; j < ring->ringAtomList.size(); j++) {
            fout << ring->ringAtomList[j] << " ";
        }
        fout << endl;
    }

    fout.clear();
    fout.close();
}

//
// add
//
//
int findOtherBondAtom(MFCBond* bond, int atom_idx) {
    if (bond == nullptr) return -1;
    if (bond->atom1 == atom_idx) return bond->atom2;
    if (bond->atom2 == atom_idx) return bond->atom1;
    return -1;
}

MFCBond* findBondByAtomPair(MFCAtom* atom, MFCAtom* adjatom) {
    std::cout << "yes" << endl;
    MFCBond* bond;
    MFCFrag* Frag;
    Frag = (MFCFrag*)(atom->ownerFrag);
    for (unsigned int i = 0; i != Frag->bondList.size(); i++) {
        bond = Frag->bondList[i];
        if (adjatom->AIdx == findOtherBondAtom(bond, atom->AIdx)) {
            /**
            if(Frag->fragname == "121")
            {
              std::cout << "BOND" << bond->BIdx  << ": " << bond->atom1  << "; " << bond->atom2 <<
            endl;
            }
            **/
            return bond;
        }
    }
}

// from ./cheminfo/atom.h
static int group[109 + 1] = {
    0,  1, 18, 1, 2, 13, 14, 15, 16, 17, 18, 1,  2,  13, 14, 15, 16, 17,
    18, 1, 2,  3, 4, 5,  6,  7,  8,  9,  10, 11, 12, 13, 14, 15, 16, 17,
    18, 1, 2,  3, 4, 5,  6,  7,  8,  9,  10, 11, 12, 13, 14, 15, 16, 17,
    18, 1, 2,  3, 3, 3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3,  // lanthanides
    4,  5, 6,  7, 8, 9,  10, 11, 12, 13, 14, 15, 16, 17, 18, 1,  2,  3,
    3,  3, 3,  3, 3, 3,  3,  3,  3,  3,  3,  3,  3,  3  // actinides
};

int getAtomGroup(int z) {
    int g;
    if (z < 1 || z > 109)
        g = 0;
    else
        g = group[z];

    if (g == 0) return (-1);
    if (g <= 8) return (g);
    if (g == 9 || g == 10) return (8);
    return (g - 10);
}

int isMainAtomGroup(int z) {
    int g;
    if (z < 1 || z > 109)
        g = 0;
    else
        g = group[z];

    if (g == 1 || g == 2 || g >= 13)
        return 1;
    else
        return 0;
}

int gAtomValence(MFCAtom* atom) {
    int sum = gAtomTotalBondOrder(atom);
    int z = atom->atomicNumber;
    int g = getAtomGroup(z);
    // if(((MFCFrag*)(atom->ownerFrag))->fragname == "121")
    // std::cout << g << " ";
    if (!isMainAtomGroup(z)) return (0);
    if (g == 1 || g == 2) return (g);
    if (g == 3) {
        if (z == 81) {  // Tl
            if (sum > 1) return (3);
            return (1);
        }
        return (3);
    }

    if (g == 4) {
        if (z == 50 || z == 82) {  // Sn, Bi
            if (sum > 2) return (4);
            return (2);
        }
        return (4);
    }
    if (g == 5) {
        if (sum > 3)
            return (5);
        else
            return (3);
    }
    if (g == 6) {
        if (z == 8) return (2);  // O
        if (sum > 4) return (6);
        if (sum > 2) return (4);
        return (2);
    }
    if (g == 7) {
        if (z == 9) return (1);  // F
        if (sum > 5) return (7);
        if (sum > 3) return (5);
        if (sum > 1) return (3);
        return (1);
    }
    if (g == 8) return (0);
    return (0);
}

int gAtomTotalBondOrder(MFCAtom* atom) {
    int total = 0;  // record all bondOrder
    int bond_idx;
    MFCBond* bond;
    MFCFrag* Frag;
    Frag = (MFCFrag*)(atom->ownerFrag);
    for (unsigned int i = 0; i != atom->bondList.size(); i++) {
        bond_idx = atom->bondList[i];
        bond = Frag->bondList[bond_idx];
        if (bond->bondType == 1) total++;
        if (bond->bondType == 2 || bond->bondType == 4) total += 2;
        if (bond->bondType == 3) total += 3;
    }
    return total;
}

}  // namespace MISS
