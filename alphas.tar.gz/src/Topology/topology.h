#ifndef topology_h
#define topology_h
/************************************************
 * *       Category:                               *
 * *       Function:  Find SSSRs;                  *
 * *                  Mark ring and aromaticity;   *
 * *                  (refer to cheminfo/ )        *
 * *       Author:    Xiuming Li                   *
 * *       Date:      2017-05-17                   *
 * ************************************************/

#include <vector>

#include "MolStructure/mfcAtom.h"
#include "MolStructure/mfcBond.h"
#include "MolStructure/mfcMolecule.h"
#include "MolStructure/mfcRing.h"

using namespace std;

namespace MISS {

class MFCPathNode {
public:
    MFCPathNode() : atomIdx(0), adjbondcnt(0), cursor(0), bondIdx(0){};

    int atomIdx;  // atom index in a node
    int adjbondcnt;
    int cursor;
    // MFCBond* bond;
    int bondIdx;

    void printPathNode();

};  // record each node in a path

class MFCPath {
public:
    MFCPath() : len(0), cursor(0){};
    explicit MFCPath(int size) : len(size), cursor(0){};
    ~MFCPath();

    int len;
    int cursor;
    std::vector<MFCPathNode*> nodeList;

    // int iniPath(MFCFrag* Frag, int start);
    int iniPath(MFCFrag* Frag, int start, int* bondMark_arr);
    // void addPathNode(int atom_idx, MFCBond* bond);
    void addPathNode(int atom_idx, int bond_idx);
    void printPath();

};  // record mapping(herein ring) path.

void outputFragInfo(MFCFrag* Frag);
void findSSSR(MFCFrag* Frag);
int getRing(MFCFrag* Frag, MFCPath* path, MFCRing* ring, int* bondMark_arr);
int getPath(MFCFrag* Frag, MFCPath* path, int* bondMark_arr);
int getAtomlist(MFCPath* path, MFCRing* ring);
void setRingAtomFlags(MFCFrag* Frag);
void setHybridization(MFCFrag* Frag);
void printFragBondType(MFCFrag* Frag);
int findOtherBondAtom(MFCBond* bond, int atom_idx);
MFCBond* findBondByAtomPair(MFCAtom* atom, MISS::MFCAtom* adjatom);
int gAtomValence(MFCAtom* atom);
int gAtomTotalBondOrder(MFCAtom* atom);
int isMainAtomGroup(int Z);
int getAtomGroup(int z);
void delringBondMap();
void clearringBondMap();

int getStereoParity(MFCFrag* Frag, MFCAtom* Atom, int* mapx);

}  // namespace MISS

#endif /*topology_h*/
