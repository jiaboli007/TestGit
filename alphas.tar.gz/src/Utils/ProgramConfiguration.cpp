
#include <iostream>

#include <boost/dll.hpp>

#include <pugixml.hpp>

#include "ProgramConfiguration.hpp"

bool verbose_message = false;

[[maybe_unused]] inline struct {
    template <typename... Args>
    void operator()(Args &&...args) {
        if (verbose_message) (std::cout << ... << std::forward<Args>(args));
    }
} LOG;

ProgramConfiguration::ProgramConfiguration() {
    const boost::filesystem::path name = ".alphas.xml";

    for (auto path = boost::filesystem::current_path();;) {
        if (try_load_path(path / name)) return;
        auto parent_path = path.parent_path();
        if (parent_path.parent_path() == parent_path) break;

        path = parent_path;
    }
    if (try_load_path(std::getenv("HOME") / name)) return;
    if (try_load_path(boost::dll::program_location().parent_path() / name)) return;

    LOG("Default configuration is used\n");
}

ProgramConfiguration::ProgramConfiguration(const boost::filesystem::path &config_file) {
    load_config(config_file);
}

bool ProgramConfiguration::try_load_path(const boost::filesystem::path &path) {
    LOG("try load ", path.native());

    if (boost::filesystem::exists(path) and boost::filesystem::is_regular_file(path)) {
        load_config(path);
        LOG(" ...OK\n");
        return true;
    }
    LOG(" ...Fail\n");
    return false;
}

void ProgramConfiguration::load_config(const boost::filesystem::path &config_file) {
    pugi::xml_document doc;

    if (auto result = doc.load_file(config_file.c_str()); result) {
        LOG("  load");

        const auto &root = doc.child("alphas");
        nthreads = root.child("nthreads").attribute("value").as_int(0);
        sd_path = root.child("sd_path").attribute("value").as_string(
            boost::filesystem::current_path().c_str());
        if (sd_path.is_relative()) sd_path = config_file.parent_path() / sd_path;
    }
}
