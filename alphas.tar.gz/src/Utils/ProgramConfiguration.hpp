//
// Created by xiamr on 10/2/20.
//

#ifndef ALPHACS_SRC_UTILS_PROGRAMCONFIGURATION_HPP
#define ALPHACS_SRC_UTILS_PROGRAMCONFIGURATION_HPP

#include <boost/filesystem.hpp>

class ProgramConfiguration {
public:
    ProgramConfiguration();

    ProgramConfiguration(const boost::filesystem::path &config_file);

    void load_config(const boost::filesystem::path &config_file);

    auto get_nthreads() const { return nthreads; }

    boost::filesystem::path get_sd_path() const { return sd_path; }

private:
    bool try_load_path(const boost::filesystem::path &path);

    int nthreads = 0;
    boost::filesystem::path sd_path;
};

#endif  // ALPHACS_SRC_UTILS_PROGRAMCONFIGURATION_HPP
