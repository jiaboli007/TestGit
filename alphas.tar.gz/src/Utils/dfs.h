#pragma once
#include <cassert>
#include <vector>

#include "MolStructure/mfcMolecule.h"

using namespace std;

namespace MISS {

bool null_condition(MFCFrag &, int, int) { return true; }

struct NullCondition {
    bool operator()(MFCFrag &, int, int) { return true; }
};

inline void null_operation(MFCFrag &, int) {}

struct NullOperation {
    void operator()(MFCFrag &, int) {}
    template <class Parameter>
    void operator()(MFCFrag &, int, Parameter &) {}
};

template <class Condition, class PrefixOperation, class SuffixOperation>
void dfs(MFCFrag &frag, int AId, Condition cdt, PrefixOperation &f, SuffixOperation &g) {
    vector<int> next;
    next.reserve(frag.atomList[AId]->atomList.size());
    int i;
    for (i = 0; i < frag.atomList[AId]->atomList.size(); i++)
        if (cdt(frag, AId, i)) next.push_back(frag.atomList[AId]->atomList[i]);
    f(frag, AId);
    for (i = 0; i < next.size(); i++) dfs(frag, next[i], cdt, f, g);
    g(frag, AId, f);
};

}  // namespace MISS
