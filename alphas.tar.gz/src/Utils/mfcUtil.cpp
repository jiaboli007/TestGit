/******************************************************************************
 *    Description: Implementation of Molecular Foundation Classes              *
 *                                                                             *
 *    Author:      James Li                                                    *
 *                                                                             *
 *    Date:        March 2011                                                  *
 *                                                                             *
 ******************************************************************************/

#include "config.hpp"

#include <algorithm>
#include <cassert>
#include <charconv>
#include <concepts>
#include <fstream>
#include <iomanip>
#include <map>
#include <sstream>
#include <vector>

#include <boost/algorithm/string.hpp>
#include <boost/filesystem.hpp>
#include <boost/math/constants/constants.hpp>
#include <boost/range/adaptors.hpp>
#include <boost/range/algorithm.hpp>
#include <boost/range/combine.hpp>

#include <math.h>
#include <time.h>
#include <xsimd/xsimd.hpp>

#include "mfcUtil.hpp"

#include "ForceField/mfcFF.h"
#include "GShape/gaussian.h"
#include "Misc/fragment2D.h"
#include "MolStructure/canonUtil.h"
#include "MolStructure/mfcMolecule.h"
#include "MolStructure/stereo.h"
#include "Singleton/params.h"
#include "ThirdParty/fast_double_parser.hpp"
#include "Topology/chemgraph.h"
#include "Topology/topology.h"
#include "Utils/ProgramConfiguration.hpp"
#include "Utils/pharmacophore_defs.hpp"

using namespace boost::adaptors;
constexpr double PI = 3.1415927;

namespace MISS {

MFCFrag* findLargestFragInMol(Molecule* mol);
std::vector<MFCFrag*> findWaterInMol(Molecule* mol);

inline int stoi(std::string_view view) {
    int value;
    char* p = const_cast<char*>(view.begin());
    while (std::isspace(*p)) ++p;
    std::from_chars(p, view.end(), value);
    return value;
}

int ijx(int a, int b) {
    if (a > b)
        return a * (a - 1) / 2 + b;
    else
        return b * (b - 1) / 2 + a;
}

void printMFCAtom(MFCAtom* Atom) {
    // MFCFrag* Frag = (MFCFrag*)Atom->ownerFrag;
    if (Atom == 0)
        // exit(0);
        throw("Exception 12");

    std::cout << " Atom" << Atom->AIdx + 1 << " " << ElementSymbol(Atom->atomicNumber);
    std::cout << ",Charge=" << Atom->charge << ",Bonds=" << Atom->nBonds;
    std::cout << ",Aromatic=" << Atom->aromaticFlag;
    std::cout << ",RingAtomFlag=" << Atom->ringAtomFlag;
    std::cout << ",Bond Atoms: ";
    for (int i = 0; i < Atom->nBonds; i++) {
        std::cout << Atom->atomList[i] + 1 << ",";
    }
    std::cout << "\n";
}

void printMFCBond(MFCBond* Bond) {
    if (Bond == 0) exit(0);
    std::cout << " Bond " << Bond->BIdx << ": ";
    std::cout << "Atom" << Bond->atom1 << "-Atom" << Bond->atom2 << "; ";
    std::cout << "Bond Type= " << Bond->bondType << "; ";
    std::cout << "RingBondFlag= " << Bond->ringBondFlag << "\n";
}

void printMFCRing(MFCRing* Ring) {
    if (Ring == 0) exit(0);
    std::cout << " Ring Size = " << Ring->ringSize << " Ring Idx = " << Ring->RIdx
              << " Aromaticity = " << Ring->aromaticity << " Ring atom list: ";
    for (int i = 0; i < Ring->ringSize; i++) {
        std::cout << Ring->ringAtomList[i] << " ";
    }
    std::cout << "\n";
}
void printMFCFrag(MFCFrag* Frag) {
    int nAtoms = Frag->numAtoms;
    int nBonds = Frag->numBonds;
    int Rings = Frag->ringList.size();
    MFCAtom* Atom;
    MFCBond* Bond;
    MFCRing* Ring;

    // Print atoms
    for (int i = 0; i < nAtoms; i++) {
        Atom = Frag->atomList[i];
        if (Atom != 0) printMFCAtom(Atom);
    }

    for (int i = 0; i < nBonds; i++) {
        Bond = Frag->bondList[i];
        if (Bond != 0) printMFCBond(Bond);
    }

    for (int i = 0; i < Rings; i++) {
        Ring = Frag->ringList[i];
        if (Ring != 0) printMFCRing(Ring);
    }
}

int ElemAtomicNumber(string_view symbol) {
    PeriodicTable* xTable = PeriodicTable::Instance();
    return xTable->AtomicNumber(symbol);
}

std::string ElementSymbol(int atomicNumber) {
    PeriodicTable* xTable = PeriodicTable::Instance();
    return xTable->AtomicSymbol(atomicNumber);
}

void parseV3000AtomLine(const std::string& ss, int& atomicNumber, double& x, double& y, double& z,
                        int& chg, int& cfg) {
    int number;
    double value;
    std::string tmpstr;
    std::string element;
    std::istringstream iss(ss);
    int nSkips = 3;
    for (int i = 0; i < nSkips; i++) iss >> tmpstr;
    iss >> element;
    if (element.length() == 1) {
        element = element + " ";
    }
    atomicNumber = ElemAtomicNumber(element);
    iss >> x;
    iss >> y;
    iss >> z;
    iss >> number;
    cfg = 0;
    chg = 0;
    while (iss >> tmpstr) {
        if (tmpstr.find("CFG=") != std::string::npos) {
            const string& ss1 = tmpstr.substr(tmpstr.find("CFG=") + 4, 1);
            cfg = stoi(ss1);
        }
        if (tmpstr.find("CHG=") != std::string::npos) {
            const string& ss1 = tmpstr.substr(tmpstr.find("CHG=") + 4, 1);
            chg = stoi(ss1);
        }
    }
}

void parseV3000BondLine(const std::string& ss, int& atom1, int& atom2, int& bondType,
                        int& bondDir) {
    int number;
    std::string tmpstr;
    std::istringstream iss(ss);
    int nSkips = 3;
    for (int i = 0; i < nSkips; i++) iss >> tmpstr;
    iss >> bondType;
    iss >> atom1;
    iss >> atom2;
    bondDir = 0;

    while (iss >> tmpstr) {
        if (tmpstr.find("CFG=") != std::string::npos) {
            const string& ss1 = tmpstr.substr(tmpstr.find("CFG=") + 4, 1);
            bondDir = stoi(ss1);
        }
    }
}

template <typename iFileLikeStream>
bool SDReaderT<iFileLikeStream>::endOfSD() {
    return fin.eof();
}

template <typename iFileLikeStream>
long SDReaderT<iFileLikeStream>::getfpos() {
    return fin.tellg();
}
template <typename iFileLikeStream>
void SDReaderT<iFileLikeStream>::resetfpos() {
    fin.clear();
    fin.seekg(0);
}
template <typename iFileLikeStream>
void SDReaderT<iFileLikeStream>::seekfpos(long fpos) {
    fin.seekg(fpos);
}

template <typename iFileLikeStream>
void SDReaderT<iFileLikeStream>::readSDProperties(MFCFrag* Frag) {
    //
    // TODO: Implement it
    // read data from fin
    //
    //
    // skip2MolEnd(fin);
    std::string tmpstr;
    //
    // Skip to the end of mol
    //
    MolProperties* molPro = new MolProperties();
    do {
        std::getline(fin, tmpstr);
        if (tmpstr.substr(0, 4) == std::string("$$$$")) break;
        molPro->PropertyDoc.push_back(tmpstr);
    } while (!fin.eof());
    Frag->setMolPro(molPro);
}

//
// Read one molecule from a SD file
// The molecule may contain multiple fragments.
// Both V2000 and V3000 format can be read.
// The program detects the format automatically
//
// Authors: Feng Lu & James Li
//
template <typename iFileLikeStream>
Molecule* SDReaderT<iFileLikeStream>::readMolecule() {
    bool threeD2chiral = true;
    bool threeD2cistrans = true;
    bool isFlat = true;

    MFCFrag* Frag = readSDF(isFlat);

    if (Frag == nullptr) return nullptr;

    //
    // Post process: add H to mol
    //
    Frag->add_hydrogens();
    //
    // Set chirality by stereo parity
    //
    Frag->set_chirality();
    //
    // Set parity by bond direction if the molecule is flat and there is a bond
    // direction flag (1,6)
    // For either bond direction (4), the chiral sign of the atom is set to 0.
    //
    Frag->set_parity(isFlat);

    Frag->set_stereo(threeD2chiral, threeD2cistrans, isFlat);

    // Read molecule properties and store property name - value in
    // property map
    // >  <Prop Name2>
    // PropLine1
    // PropLine2
    //
    // >  <Prop Name2>
    // .....

    // Store: Frag->fragProp["Prop Name1"] = PropLine1 PropLine2 .....
    //
    readSDProperties(Frag);  // include "M  END"

    return convertFragToMol(Frag);
}

template <typename T>
bool is_open(T& fin) {
    if constexpr (requires {
                      { fin.is_open() } -> std::convertible_to<bool>;
                  }) {
        return fin.is_open();
    }
    return true;
}

template <typename iFileLikeStream>
MFCFrag* SDReaderT<iFileLikeStream>::readSDF(bool& isFlat) {
    std::unique_ptr<MFCFrag> frag;
    constexpr double eps = 1.0E-10;
    int nAtoms, nBonds;

    try {
        if (!is_open(fin)) {
            cerr << "Input file is not open yet\n";
            exit(1);
        } else {
            //
            // Skip 3 lines
            //
            string tmpstr, fragname;
            if (fin.eof()) return nullptr;
            if (!std::getline(fin, fragname)) return nullptr;
            if (!std::getline(fin, tmpstr)) return nullptr;
            std::getline(fin, tmpstr);
            std::getline(fin, tmpstr);

            int cFlag;
            // Check SD version
            const bool isV3000 = boost::contains(tmpstr, "V3000");
            int nList;
            if (isV3000) {
                // std::cout << "This is V3000 format \n";
                std::getline(fin, tmpstr);
                std::getline(fin, tmpstr);
                tmpstr = tmpstr.substr(14);
                nAtoms = stoi(tmpstr.substr(0, tmpstr.find(' ')));
                tmpstr = tmpstr.substr(tmpstr.find(' ') + 1);
                nBonds = stoi(tmpstr.substr(0, tmpstr.find(' ')));
                nList = 0;  // Do not know how to do
                tmpstr = tmpstr.substr(tmpstr.find(' ') + 1);
                tmpstr = tmpstr.substr(tmpstr.find(' ') + 1);
                tmpstr = tmpstr.substr(tmpstr.find(' ') + 1);
                cFlag = stoi(tmpstr.substr(0, 1));
            } else {
                // std::cout << "This is V2000 format \n";

                nAtoms = stoi(tmpstr.substr(0, 3));
                nBonds = stoi(tmpstr.substr(3, 3));
                nList = stoi(tmpstr.substr(6, 3));
                cFlag = stoi(tmpstr.substr(12, 3));
            }
            frag =
                std::make_unique<MFCFrag>(nAtoms, nBonds, fragname.empty() ? "NONAME" : fragname);
            frag->stereoFlag = cFlag;
            frag->topology.cFlag = cFlag;
            // Skip one line for V3000
            if (isV3000) std::getline(fin, tmpstr);
            string tmp;
            double z0;
            for (int i = 0; i < nAtoms; i++) {
                std::getline(fin, tmpstr);
                int atomicNumber, massDiff, formalCharge, stereoParity, freeValence;
                double x, y, z;
                if (isV3000) {
                    // V3000 format
                    parseV3000AtomLine(tmpstr, atomicNumber, x, y, z, cFlag, stereoParity);
                    massDiff = 0;  // Do not know how to do
                    formalCharge = cFlag;
                    // TODO: check the V3000 document and find the correct way for
                    // calculation free valence
                    // freeValence = 0;
                    // if(cFlag==4) freeValence = 1; // Radical
                } else {
                    // V2000 format
                    //                    const char* v = tmpstr.data();
                    //                    fast_double_parser::parse_number_inplace(v, v + 10, &x);
                    //                    fast_double_parser::parse_number_inplace(v + 10, v + 20,
                    //                    &y); fast_double_parser::parse_number_inplace(v + 20, v +
                    //                    30, &z);

                    x = stod(tmpstr.substr(0, 10));
                    y = stod(tmpstr.substr(10, 10));
                    z = stod(tmpstr.substr(20, 10));

                    tmp = tmpstr.substr(33, 3);  // update on 2012/4/9
                    massDiff = tmp.empty() ? 0 : stoi(tmp);
                    tmp = tmpstr.substr(36, 3);
                    cFlag = tmp.empty() ? 0 : stoi(tmp);
                    tmp = tmpstr.substr(39, 3);
                    stereoParity = tmp.empty() ? 0 : stoi(tmp);
                    atomicNumber = ElemAtomicNumber(tmpstr.substr(31, 3));
                    formalCharge = 4 - cFlag;
                    if (cFlag == 0) formalCharge = 0;
                    freeValence = 0;
                    if (cFlag == 4) freeValence = 1;  // Radical
                }
                auto atom = new MFCAtom(i, atomicNumber);
                frag->topology.add_atom({.atom = {.cFlag = cFlag,
                                                  .stereoParity = stereoParity,
                                                  .atomicNumber = atomicNumber}});
                atom->x = x;
                atom->y = y;
                atom->z = z;
                if (i == 0) z0 = z;
                if (z != z0) isFlat = false;
                atom->genFlag = 0;
                atom->nBonds = 0;
                atom->ownerFrag = frag.get();
                atom->FormalCharge = formalCharge;
                atom->mdlChargeFlag = cFlag;
                atom->charge = formalCharge;
                atom->freeValence = freeValence;
                atom->massDiff = massDiff;
                atom->stereoParity = stereoParity;
                frag->atomList.push_back(atom);
            }
            //
            // Read Bond and direction
            //
            // MDL conventions
            // Double bond: bond direction = 0, use xyz
            //                               3, either cis or trans
            //
            if (isV3000) {
                std::getline(fin, tmpstr);
                std::getline(fin, tmpstr);
            }
            for (int i = 0; i < nBonds; i++) {
                std::getline(fin, tmpstr);
                //
                // Atom Index is "0" based!!
                //
                int bondType = 0;
                int bondDir = 0;
                int atom1, atom2, bondOrder;
                if (isV3000) {
                    // V3000
                    parseV3000BondLine(tmpstr, atom1, atom2, bondOrder, bondDir);
                    atom1--;
                    atom2--;
                } else {
                    // V2000
                    atom1 = stoi(tmpstr.substr(0, 3)) - 1;
                    atom2 = stoi(tmpstr.substr(3, 3)) - 1;
                    bondOrder = stoi(tmpstr.substr(6, 3));
                    bondDir = stoi(tmpstr.substr(9, 3));
                }
                frag->topology.add_bond({.atom1 = frag->topology.atoms_.at(atom1).get(),
                                         .atom2 = frag->topology.atoms_.at(atom2).get(),
                                         .bondOrder = bondOrder,
                                         .bondDir = bondDir});
                bondType = bondOrder;
                bondOrder = bondOrder * 100;
                auto bond = new MFCBond(atom1, atom2, bondOrder, i);

                frag->bondList.push_back(bond);
                auto Atom1 = frag->atomList[atom1];
                auto Atom2 = frag->atomList[atom2];
                Atom1->nBonds++;
                Atom2->nBonds++;

                bond->bondDirection = bondDir;
                if (atom1 > atom2 && bondDir == 1) {
                    bond->bondDirection = 6;
                } else if (atom1 > atom2 && bondDir == 6) {
                    bond->bondDirection = 1;
                }

                if (bondType == 2) bond->bondDirection = bondDir;
                // stereoParity = 0 (not a stereo center or not set)
                // 1/2 (R/S), 3 (unknown),
                // 4 (fixed, determine by 3D).
                // modify is stereoParity is not set yet
                //
                if (bondDir == 4)
                    Atom1->stereoParity = 3;
                else if (bondDir == 1 || bondDir == 6)
                    Atom1->stereoParity = 4;
            }

            // Setup atom bond list
            for (int i = 0; i < nBonds; i++) {
                auto Bond = frag->bondList[i];
                auto atom1 = Bond->atom1;
                auto atom2 = Bond->atom2;
                auto Atom1 = frag->atomList[atom1];
                auto Atom2 = frag->atomList[atom2];
                Atom1->atomList.push_back(atom2);
                Atom2->atomList.push_back(atom1);
                Atom1->bondList.push_back(i);
                Atom2->bondList.push_back(i);
                Atom1->genFlag++;
                Atom2->genFlag++;
            }
        }
    } catch (...) {
        // Found error in reading mfcFFFrag
        skip2MolEnd(fin);
        // throw("Error found in the reading mfcFFFrag \n");
        return nullptr;
    }
    if (nAtoms < 1) {
        // Handle special cases, where there molecule is empty, i.e. nAtoms=0
        return nullptr;
    }
    frag->numAtoms = nAtoms;
    frag->numBonds = nBonds;
    frag->topology.make();
    return frag.release();
}

template <>
MFCFrag* SDReaderT<MMapStream>::readSDF(bool& isFlat) {
    std::unique_ptr<MFCFrag> frag;
    constexpr double eps = 1.0E-10;
    int nAtoms, nBonds;

    try {
        if (!fin.is_open()) {
            cerr << "Input file is not open yet\n";
            exit(1);
        } else {
            //
            // Skip 3 lines
            //
            string_view tmpstr, fragname;
            if (fin.eof()) return nullptr;
            if (!std::getline(fin, fragname)) return nullptr;
            if (!std::getline(fin, tmpstr)) return nullptr;
            std::getline(fin, tmpstr);
            std::getline(fin, tmpstr);

            int cFlag;
            // Check SD version
            const bool isV3000 = boost::contains(tmpstr, "V3000");
            int nList;

            // std::cout << "This is V2000 format \n";

            nAtoms = stoi(tmpstr.substr(0, 3));
            nBonds = stoi(tmpstr.substr(3, 3));
            nList = stoi(tmpstr.substr(6, 3));
            cFlag = stoi(tmpstr.substr(12, 3));

            frag = std::make_unique<MFCFrag>(
                nAtoms, nBonds, fragname.empty() ? std::string("NONAME") : std::string(fragname));
            frag->stereoFlag = cFlag;
            frag->topology.cFlag = cFlag;
            // Skip one line for V3000
            if (isV3000) std::getline(fin, tmpstr);
            string_view tmp;
            double z0;
            for (int i = 0; i < nAtoms; i++) {
                std::getline(fin, tmpstr);
                int atomicNumber, massDiff, formalCharge, stereoParity, freeValence;
                double x, y, z;

                // V2000 format
                const char* v = tmpstr.data();
                fast_double_parser::parse_number_inplace(v, v + 10, &x);
                fast_double_parser::parse_number_inplace(v + 10, v + 20, &y);
                fast_double_parser::parse_number_inplace(v + 20, v + 30, &z);

                tmp = tmpstr.substr(33, 3);  // update on 2012/4/9
                massDiff = tmp.empty() ? 0 : stoi(tmp);
                tmp = tmpstr.substr(36, 3);
                cFlag = tmp.empty() ? 0 : stoi(tmp);
                tmp = tmpstr.substr(39, 3);
                stereoParity = tmp.empty() ? 0 : stoi(tmp);
                atomicNumber = ElemAtomicNumber(tmpstr.substr(31, 3));
                formalCharge = 4 - cFlag;
                if (cFlag == 0) formalCharge = 0;
                freeValence = 0;
                if (cFlag == 4) freeValence = 1;  // Radical
                frag->topology.add_atom({.atom = {.cFlag = cFlag,
                                                  .stereoParity = stereoParity,
                                                  .atomicNumber = atomicNumber}});

                auto atom = new MFCAtom(i, atomicNumber);
                atom->x = x;
                atom->y = y;
                atom->z = z;
                if (i == 0) z0 = z;
                if (z != z0) isFlat = false;
                atom->genFlag = 0;
                atom->nBonds = 0;
                atom->ownerFrag = frag.get();
                atom->FormalCharge = formalCharge;
                atom->mdlChargeFlag = cFlag;
                atom->charge = formalCharge;
                atom->freeValence = freeValence;
                atom->massDiff = massDiff;
                atom->stereoParity = stereoParity;
                frag->atomList.push_back(atom);
            }
            //
            // Read Bond and direction
            //
            // MDL conventions
            // Double bond: bond direction = 0, use xyz
            //                               3, either cis or trans
            //

            for (int i = 0; i < nBonds; i++) {
                std::getline(fin, tmpstr);
                //
                // Atom Index is "0" based!!
                //
                int bondType = 0;
                int bondDir = 0;
                int atom1, atom2, bondOrder;

                // V2000
                atom1 = stoi(tmpstr.substr(0, 3)) - 1;
                atom2 = stoi(tmpstr.substr(3, 3)) - 1;
                bondOrder = stoi(tmpstr.substr(6, 3));
                bondDir = stoi(tmpstr.substr(9, 3));

                frag->topology.add_bond({.atom1 = frag->topology.atoms_.at(atom1).get(),
                                         .atom2 = frag->topology.atoms_.at(atom2).get(),
                                         .bondOrder = bondOrder,
                                         .bondDir = bondDir});

                bondType = bondOrder;
                bondOrder = bondOrder * 100;
                auto bond = new MFCBond(atom1, atom2, bondOrder, i);

                frag->bondList.push_back(bond);
                auto Atom1 = frag->atomList[atom1];
                auto Atom2 = frag->atomList[atom2];
                Atom1->nBonds++;
                Atom2->nBonds++;

                bond->bondDirection = bondDir;
                if (atom1 > atom2 && bondDir == 1) {
                    bond->bondDirection = 6;
                } else if (atom1 > atom2 && bondDir == 6) {
                    bond->bondDirection = 1;
                }

                if (bondType == 2) bond->bondDirection = bondDir;
                // stereoParity = 0 (not a stereo center or not set)
                // 1/2 (R/S), 3 (unknown),
                // 4 (fixed, determine by 3D).
                // modify is stereoParity is not set yet
                //
                if (bondDir == 4)
                    Atom1->stereoParity = 3;
                else if (bondDir == 1 || bondDir == 6)
                    Atom1->stereoParity = 4;
            }

            // Setup atom bond list
            for (int i = 0; i < nBonds; i++) {
                auto Bond = frag->bondList[i];
                auto atom1 = Bond->atom1;
                auto atom2 = Bond->atom2;
                auto Atom1 = frag->atomList[atom1];
                auto Atom2 = frag->atomList[atom2];
                Atom1->atomList.push_back(atom2);
                Atom2->atomList.push_back(atom1);
                Atom1->bondList.push_back(i);
                Atom2->bondList.push_back(i);
                Atom1->genFlag++;
                Atom2->genFlag++;
            }
        }
    } catch (...) {
        // Found error in reading mfcFFFrag
        skip2MolEnd(fin);
        // throw("Error found in the reading mfcFFFrag \n");
        return nullptr;
    }
    if (nAtoms < 1) {
        // Handle special cases, where there molecule is empty, i.e. nAtoms=0
        return nullptr;
    }
    frag->numAtoms = nAtoms;
    frag->numBonds = nBonds;
    frag->topology.make();
    return frag.release();
}
//
// TODO: This is a temp solution for force field initialization
//       We will revisit this part at a later stage
// Author: James Li
//
template <typename iFileLikeStream>
MFCFFFrag* SDReaderT<iFileLikeStream>::readMFCFFFrag() {
    bool threeD2chiral = true;
    bool threeD2cistrans = true;
    bool isFlat = true;

    MFCFrag* Frag = readSDF(isFlat);
    //
    // Post process: add H to mol
    //
    Frag->add_hydrogens();

    //
    // Set chirality by stereo parity
    //
    Frag->set_chirality();
    //
    // Set parity by bond direction if the molecule is flat and there is a bond
    // direction flag (1,6)
    // For either bond direction (4), the chiral sign of the atom is set to 0.
    //
    Frag->set_parity(isFlat);
    Frag->set_stereo(threeD2chiral, threeD2cistrans, isFlat);

    // Assume one fragment
    setHybridization(Frag);
    setMFCAtomVDW(Frag);
    auto mfcFFFrag = new MFCFFFrag(Frag);
    mfcFFFrag->initFF(fin);
    // Read additional properties
    readSDProperties(Frag);
    return mfcFFFrag;
}

//
// Read the largest fragment in a molecule. In most cases, there is only
// one fragment, thus the fragment is the whole molecule.
//
template <typename iFileLikeStream>
MFCFrag* SDReaderT<iFileLikeStream>::readLargestMFCFrag() {
    std::unique_ptr<Molecule> molecule{readMolecule()};

    return molecule ? std::max_element(std::begin(*molecule), std::end(*molecule),
                                       [](const auto& lhs, const auto& rhs) {
                                           return lhs->numAtoms < rhs->numAtoms;
                                       })
                          ->release()
                    : nullptr;
}

template class SDReaderT<std::istream>;
template class SDReaderT<std::ifstream>;
template class SDReaderT<iStringFileStream>;
template class SDReaderT<MMapStream>;
//
// Find the largest frag in mol and delete all other frags in the molecule
//
std::vector<MFCFrag*> findWaterInMol(Molecule* mol) {
    std::vector<MFCFrag*> waters;
    for (auto& tmpFrag : *mol) {
        if (tmpFrag->numAtoms != 3) continue;
        int atomO = 0;
        int atomH = 0;
        for (int j = 0; j < 3; j++) {
            MFCAtom* atom = tmpFrag->atomList[j];
            if (8 == atom->atomicNumber) atomO++;
            if (1 == atom->atomicNumber) atomH++;
        }
        if (atomO == 1 && atomH == 2) waters.push_back(tmpFrag.release());
    }
    return waters;
}
//
// Find the largest frag in mol and delete all other frags in the molecule
// and destroy molecule object (except the largest frag)
//
MFCFrag* findLargestFragInMol(Molecule* mol) {
    auto it = std::max_element(
        std::begin(*mol), std::end(*mol),
        [](const auto& lhs, const auto& rhs) { return lhs->numAtoms > rhs->numAtoms; });
    assert(it != std::end(*mol));
    auto pointer = it->release();
    std::for_each(std::begin(*mol), std::end(*mol), [](auto& p) { p.reset(); });
    return pointer;
}
//
// Convert a raw MFCFrag into multi-frag molecule
//
Molecule* convertFragToMol(MFCFrag* inFrag) {
    std::string fragname = std::string("Frag1");
    Molecule* Mole = new Molecule();
    MFCAtom* Atom;
    MFCAtom* Atom1;
    MFCAtom* Atom2;
    MFCBond* Bond;
    MFCBond* Bond2;
    std::vector<std::vector<int>> FragAtomLists;

    int amap[inFrag->numAtoms];
    int bmap[inFrag->numBonds];
    int vFlg[inFrag->numAtoms];
    int atomList[inFrag->numAtoms];
    int atomList2[inFrag->numAtoms];
    TChirality* chiral = nullptr;
    CTFlag* ctFlag;

    for (int i = 0; i < inFrag->numAtoms; i++) {
        amap[i] = -1;
        vFlg[i] = 0;
    }
    for (int i = 0; i < inFrag->numBonds; i++) {
        bmap[i] = -1;
        Bond = inFrag->bondList[i];
        Bond->genFlag = 0;
    }

    for (int i = 0; i < inFrag->numAtoms; i++) {
        Atom = inFrag->atomList[i];
        amap[Atom->AIdx] = i;
        if (Atom->nBonds == 4) {
            // if(!Atom->chiralStruct)
            // std::cout << "Wrong!\n";
        }
    }

    int LAtoms = 1;
    int LAtomx = 0;
    int FragIdx = 1;
    int maxFragSize = 0;
    int fragSize = 0;
    int maxFragIdx;
    int LUVAtom = 1;
    atomList[0] = 0;

    do {
        fragSize = 0;
        std::vector<int> tmpvector;
        while (LAtoms > 0) {
            LAtomx = 0;
            for (int i = 0; i < LAtoms; i++) {
                Atom = inFrag->atomList[atomList[i]];
                // Collect frag atom indexes
                tmpvector.push_back(atomList[i]);
                vFlg[Atom->AIdx] = FragIdx;
                for (int j = 0; j < Atom->nBonds; j++) {
                    Atom1 = inFrag->atomList[Atom->atomList[j]];
                    if (vFlg[Atom1->AIdx] == 0) {
                        atomList2[LAtomx++] = amap[Atom1->AIdx];
                        vFlg[Atom1->AIdx] = FragIdx;
                        fragSize++;
                    }
                }
            }
            LAtoms = LAtomx;
            for (int i = 0; i < LAtomx; i++) {
                atomList[i] = atomList2[i];
            }

        }  // Loop over a new frag

        // Put frag atom list into a collection vector
        FragAtomLists.push_back(tmpvector);

        if (maxFragSize < fragSize) {
            maxFragSize = fragSize;
            maxFragIdx = FragIdx;
        }
        //
        // Scan for unvisited atom for a new frag
        //
        for (int i = LUVAtom; i < inFrag->numAtoms; i++) {
            if (vFlg[i] == 0) {
                LAtoms = 1;
                FragIdx++;
                atomList[0] = amap[i];
                LUVAtom = i + 1;
                break;
            }
        }

    } while (LAtoms > 0);

    int nFrags = FragIdx;

    if (1 == nFrags) {
        Mole->addFrag(inFrag);
        return Mole;
    }

    for (FragIdx = 1; FragIdx <= nFrags; FragIdx++) {
        MFCFrag* frag = new MFCFrag();

        frag->fragname = std::string(inFrag->fragname);
        // + std::string(FragIdx);
        int bCount = 0;
        int aCount = 0;
        std::vector<int> tmpvector = FragAtomLists[FragIdx - 1];
        int nFragAtoms = (int)tmpvector.size();

        for (int i = 0; i < nFragAtoms; i++) {
            Atom = inFrag->atomList[tmpvector[i]];
            if (vFlg[Atom->AIdx] != FragIdx) continue;
            Atom2 = new MFCAtom(*Atom);  // atomlist and bondlist already added from Atom to Atom2
                                         // in the construction method
            // std::cout << "Atom2-nBonds: " << Atom2->nBonds << "," <<Atom2->bondList.size()
            // <<"\n";
            Atom2->ownerFrag = frag;
            /*
            for (int j=0; j < Atom->nBonds; j++) {
                Atom2->atomList.push_back(Atom->atomList[j]);
                Atom2->bondList.push_back(Atom->bondList[j]);
            }*/

            //
            // stereoParity is already stored in chiralStruct
            //
            Atom2->stereoParity = 0;
            Atom2->AIdx = aCount;
            amap[Atom->AIdx] = aCount++;
            frag->atomList.push_back(Atom2);
            for (int j = 0; j < Atom->nBonds; j++) {
                Bond = inFrag->bondList[Atom->bondList[j]];
                if (Bond->genFlag == 0) {
                    bmap[Bond->BIdx] = bCount;
                    Bond2 = new MFCBond(*Bond);
                    Bond2->BIdx = bCount++;
                    Bond2->bondStereo = 0;     // Bond2->bondStereo = Bond->bondStereo;
                    Bond2->bondDirection = 0;  // Bond2->bondDirection = Bond->bondDirection;
                    if (Bond->bondDirection == 3) Bond2->bondDirection = 3;
                    frag->bondList.push_back(Bond2);
                    Bond->genFlag = 1;
                }
            }
        }
        frag->numAtoms = aCount;
        frag->numBonds = bCount;
        frag->numRings = bCount - aCount + 1;
        //
        // Now, fix indexes in Atom, Bond, atom bond atom list etc.
        //
        for (int i = 0; i < frag->numAtoms; i++) {
            Atom = frag->atomList[i];
            for (int j = 0; j < Atom->nBonds; j++) {
                Atom->atomList[j] = amap[Atom->atomList[j]];
                Atom->bondList[j] = bmap[Atom->bondList[j]];
            }
            chiral = Atom->chiralStruct;
            if (chiral != 0) {
                if (chiral->a > -1) chiral->a = amap[chiral->a];
                if (chiral->b > -1) chiral->b = amap[chiral->b];
                if (chiral->c > -1) chiral->c = amap[chiral->c];
                if (chiral->d > -1) chiral->d = amap[chiral->d];
            }
        }
        for (int i = 0; i < frag->numBonds; i++) {
            Bond = frag->bondList[i];
            Bond->atom1 = amap[Bond->atom1];
            Bond->atom2 = amap[Bond->atom2];
            if (Bond->atom1 > Bond->atom2) {
                int atom1 = Bond->atom1;
                Bond->atom1 = Bond->atom2;
                Bond->atom2 = atom1;
            }
            ctFlag = Bond->ctFlag;
            if (ctFlag != 0) {
                if (ctFlag->a > -1) ctFlag->a = amap[ctFlag->a];
                if (ctFlag->b > -1) ctFlag->b = amap[ctFlag->b];
                if (ctFlag->c > -1) ctFlag->c = amap[ctFlag->c];
                if (ctFlag->d > -1) ctFlag->d = amap[ctFlag->d];
            }
        }

        Mole->addFrag(frag);
    }  // Loop over Frags

    // save property to the largest Frag, add on 2018/06/02 by Yanx
    int maxFragIndex = 0;
    int maxAtoms = 0;
    for (int i = 0; i < nFrags; i++) {
        auto&& tmpFrag = Mole->getFrag(i);
        if (tmpFrag->numAtoms > maxAtoms) {
            maxFragIndex = i;
            maxAtoms = tmpFrag->numAtoms;
        }
    }
    MolProperties* molProOrig = inFrag->getMolPro();
    MolProperties* molPro = new MolProperties();
    for (int i = 0; i < molProOrig->PropertyDoc.size(); i++) {
        molPro->PropertyDoc.push_back(molProOrig->PropertyDoc[i]);
    }

    auto&& maxFrag = Mole->getFrag(maxFragIndex);

    maxFrag->setMolPro(molPro);

    delete inFrag;
    return Mole;
}

bool getVectorIntersection(std::vector<int> TempVector1, std::vector<int> TempVector2,
                           std::vector<int>& TempVector3) {
    boost::sort(TempVector1);
    boost::sort(TempVector2);
    set_intersection(TempVector1.begin(), TempVector1.end(), TempVector2.begin(), TempVector2.end(),
                     TempVector3.begin());
    return !TempVector3.empty();
}

void writeMFCConf2SD(MFCFrag* Frag, double* xyz, std::ostream& fout, int* mapx) {
    PeriodicTable* xTable = PeriodicTable::Instance();
    Fragmentation* fraction = (Fragmentation*)Frag->fraction;
    MFCAtom* Atom;
    MFCBond* Bond;
    int nAtoms = Frag->numAtoms, nBonds = Frag->numBonds;
    int AIdx, i, i3, aNum;
    int* map = new int[nAtoms];

    fout << Frag->fragname << "\n";
    fout << "MFCFrag2SD\n";
    fout << "\n";
    fout << std::setw(3) << Frag->numAtoms << std::setw(3) << Frag->numBonds;
    fout << std::setw(3) << 0 << std::setw(3) << 0;
    fout << std::setw(3) << Frag->stereoFlag << "  0  0  0  0  0  0 V2000\n";

    if (mapx != 0) {
        for (i = 0; i < nAtoms; i++) {
            map[mapx[i]] = i;
        }
    } else if (fraction == 0) {
        for (i = 0; i < nAtoms; i++) {
            map[i] = i;
        }
    } else {
        for (i = 0; i < nAtoms; i++) {
            AIdx = fraction->atomList[i];
            map[AIdx] = i;
        }
    }

    if (mapx == 0) {
        for (AIdx = 0; AIdx < nAtoms; AIdx++) {
            i = map[AIdx];
            Atom = Frag->atomList[AIdx];
            aNum = Atom->atomicNumber;
            i3 = i * 3;
            fout << std::setw(10) << std::setiosflags(std::ios::fixed) << std::setprecision(4)
                 << xyz[i3];
            fout << std::setw(10) << std::setiosflags(std::ios::fixed) << std::setprecision(4)
                 << xyz[i3 + 1];
            fout << std::setw(10) << std::setiosflags(std::ios::fixed) << std::setprecision(4)
                 << xyz[i3 + 2];
            fout << " " << std::setw(2) << xTable->AtomicSymbol(aNum);
            fout << std::setw(3) << Atom->massDiff << std::setw(3) << Atom->mdlChargeFlag;
            fout << std::setw(3) << Atom->stereoParity << "  0  0" << '\n';
        }
        for (i = 0; i < nBonds; i++) {
            Bond = Frag->bondList[i];
            fout << std::setw(3) << Bond->atom1 + 1 << std::setw(3) << Bond->atom2 + 1
                 << std::setw(3) << Bond->bondOrder / 100 << std::setw(3) << Bond->bondDirection
                 << "  0  0" << '\n';
        }
    } else {
        // To do list: reset stereo flag according to the new order in mapx
        // Set stereo parity flag. Modify it only if Atom is a chiral
        // center. (i.e. Atom->stereoParity != 0).
        for (i = 0; i < Frag->numAtoms; i++) {
            Atom = Frag->atomList[i];
            if (Atom->stereoParity != 0 && Atom->stereoParity != 3)
                Atom->stereoParity = getStereoParity(Frag, Atom, map);
        }

        for (AIdx = 0; AIdx < nAtoms; AIdx++) {
            i = mapx[AIdx];
            Atom = Frag->atomList[i];
            aNum = Atom->atomicNumber;
            i3 = i * 3;
            fout << std::setw(10) << std::setiosflags(std::ios::fixed) << std::setprecision(4)
                 << xyz[i3];
            fout << std::setw(10) << std::setiosflags(std::ios::fixed) << std::setprecision(4)
                 << xyz[i3 + 1];
            fout << std::setw(10) << std::setiosflags(std::ios::fixed) << std::setprecision(4)
                 << xyz[i3 + 2];
            fout << " " << std::setw(2) << xTable->AtomicSymbol(aNum);
            fout << std::setw(3) << Atom->massDiff << std::setw(3) << Atom->mdlChargeFlag;
            fout << std::setw(3) << Atom->stereoParity << "  0  0" << '\n';
            // fout <<  std::setw(3) << 0 <<"  0  0" << '\n';
        }
        for (i = 0; i < nBonds; i++) {
            Bond = Frag->bondList[i];
            fout << std::setw(3) << map[Bond->atom1] + 1 << std::setw(3) << map[Bond->atom2] + 1
                 << std::setw(3) << Bond->bondOrder / 100 << std::setw(3) << Bond->bondDirection
                 << "  0  0" << '\n';
        }
    }

    // properties
    MolProperties* molPro = Frag->getMolPro();
    int size = molPro->PropertyDoc.size();
    for (i = 0; i < size; i++) {
        fout << molPro->PropertyDoc[i] << "\n";
    }

    fout << "$$$$\n";
    delete[] map;
}

void writeMFCConf2SD_HA(MFCFrag* Frag, double* xyz, std::ostream& fout, int* mapx) {
    PeriodicTable* xTable = PeriodicTable::Instance();
    Fragmentation* fraction = (Fragmentation*)Frag->fraction;

    MFCAtom* Atom;
    MFCBond* Bond;
    int nAtoms = Frag->numAtoms;
    // std::cout << "nAtoms: " << nAtoms << "\n";
    int nBonds = Frag->numBonds;
    int AIdx, i, i3, aNum;
    int* map = new int[nAtoms];

    // new index for Heavy Atoms
    int* HAtomIdx = new int[nAtoms];

    int nHAtoms = 0;
    for (i = 0; i < nAtoms; i++) {
        Atom = Frag->atomList[i];
        if (1 == Atom->atomicNumber) continue;

        HAtomIdx[i] = nHAtoms;  // i is old index for heavy atom
        nHAtoms++;
    }

    // std::cout << "nHeavyAtoms: " << nHAtoms << "\n";

    int nRealBonds = 0;
    for (i = 0; i < nBonds; i++) {
        Bond = Frag->bondList[i];
        Atom = Frag->atomList[Bond->atom1];
        if (1 == Atom->atomicNumber) continue;
        Atom = Frag->atomList[Bond->atom2];
        if (1 == Atom->atomicNumber) continue;

        nRealBonds++;
    }

    fout << Frag->fragname << "\n";
    fout << "MFCFrag2SD\n";
    fout << "\n";
    fout << std::setw(3) << nHAtoms << std::setw(3) << nRealBonds;
    fout << std::setw(3) << 0 << std::setw(3) << 0;
    fout << std::setw(3) << Frag->stereoFlag << "  0  0  0  0  0  0 V2000\n";

    if (mapx != 0) {
        for (i = 0; i < nAtoms; i++) {
            map[mapx[i]] = i;
        }
    } else if (fraction == 0) {
        for (i = 0; i < nAtoms; i++) {
            map[i] = i;
        }
    } else {
        for (i = 0; i < nAtoms; i++) {
            AIdx = fraction->atomList[i];
            map[AIdx] = i;
        }
    }

    if (mapx == 0) {
        for (AIdx = 0; AIdx < nAtoms; AIdx++) {
            i = map[AIdx];
            Atom = Frag->atomList[AIdx];
            aNum = Atom->atomicNumber;
            if (1 == aNum) continue;

            i3 = i * 3;
            fout << std::setw(10) << std::setiosflags(std::ios::fixed) << std::setprecision(4)
                 << xyz[i3];
            fout << std::setw(10) << std::setiosflags(std::ios::fixed) << std::setprecision(4)
                 << xyz[i3 + 1];
            fout << std::setw(10) << std::setiosflags(std::ios::fixed) << std::setprecision(4)
                 << xyz[i3 + 2];
            fout << " " << std::setw(2) << xTable->AtomicSymbol(aNum);
            fout << std::setw(3) << Atom->massDiff << std::setw(3) << Atom->mdlChargeFlag;
            fout << std::setw(3) << Atom->stereoParity << "  0  0" << '\n';
        }
        for (i = 0; i < nBonds; i++) {
            Bond = Frag->bondList[i];
            Atom = Frag->atomList[Bond->atom1];
            if (1 == Atom->atomicNumber) continue;
            Atom = Frag->atomList[Bond->atom2];
            if (1 == Atom->atomicNumber) continue;

            fout << std::setw(3) << HAtomIdx[Bond->atom1] + 1 << std::setw(3)
                 << HAtomIdx[Bond->atom2] + 1 << std::setw(3) << Bond->bondOrder / 100
                 << std::setw(3) << Bond->bondDirection << "  0  0" << '\n';
        }

    } else {
        // To do list: reset stereo flag according to the new order in mapx
        // Set stereo parity flag. Modify it only if Atom is a chiral
        // center. (i.e. Atom->stereoParity != 0).
        for (i = 0; i < nAtoms; i++) {
            Atom = Frag->atomList[i];
            if (Atom->stereoParity != 0 && Atom->stereoParity != 3)
                Atom->stereoParity = getStereoParity(Frag, Atom, map);
        }

        for (AIdx = 0; AIdx < nAtoms; AIdx++) {
            i = mapx[AIdx];
            Atom = Frag->atomList[i];
            aNum = Atom->atomicNumber;
            if (1 == aNum) continue;

            i3 = i * 3;
            fout << std::setw(10) << std::setiosflags(std::ios::fixed) << std::setprecision(4)
                 << xyz[i3];
            fout << std::setw(10) << std::setiosflags(std::ios::fixed) << std::setprecision(4)
                 << xyz[i3 + 1];
            fout << std::setw(10) << std::setiosflags(std::ios::fixed) << std::setprecision(4)
                 << xyz[i3 + 2];
            fout << " " << std::setw(2) << xTable->AtomicSymbol(aNum);
            fout << std::setw(3) << Atom->massDiff << std::setw(3) << Atom->mdlChargeFlag;
            fout << std::setw(3) << Atom->stereoParity << "  0  0" << '\n';
            // fout <<  std::setw(3) << 0 <<"  0  0" << '\n';
        }
        for (i = 0; i < nBonds; i++) {
            Bond = Frag->bondList[i];
            Atom = Frag->atomList[Bond->atom1];
            if (1 == Atom->atomicNumber) continue;
            Atom = Frag->atomList[Bond->atom2];
            if (1 == Atom->atomicNumber) continue;

            fout << std::setw(3) << HAtomIdx[map[Bond->atom1]] + 1 << std::setw(3)
                 << HAtomIdx[map[Bond->atom2]] + 1 << std::setw(3) << Bond->bondOrder / 100
                 << std::setw(3) << Bond->bondDirection << "  0  0" << '\n';
        }
    }

    // properties
    MolProperties* molPro = Frag->getMolPro();
    if (molPro != 0) {
        int size = molPro->PropertyDoc.size();
        for (i = 0; i < size; i++) {
            fout << molPro->PropertyDoc[i] << "\n";
        }
    }

    fout << "$$$$\n";
    delete[] map;
    delete[] HAtomIdx;
}

void writeMFCFrag2SD(MFCFrag* Frag, std::ostream& fout, bool onlyHeavyAtoms) {
    Fragmentation* fraction = (Fragmentation*)Frag->fraction;
    if (fraction != 0) {
        FragConf* tmpConf = fraction->firstConf;
        int numConfs = 0;

        for (tmpConf = fraction->firstConf; tmpConf != 0; tmpConf = tmpConf->nextConf) {
            numConfs++;
            if (onlyHeavyAtoms)
                writeMFCConf2SD_HA(Frag, tmpConf->xyz, fout);
            else
                writeMFCConf2SD(Frag, tmpConf->xyz, fout, 0);
        }
    } else {
        double* xyz = new double[Frag->numAtoms * 3];
        for (int i = 0; i < Frag->numAtoms; i++) {
            int i3 = i * 3;
            MFCAtom* atom = Frag->atomList[i];
            xyz[i3] = atom->x;
            xyz[i3 + 1] = atom->y;
            xyz[i3 + 2] = atom->z;
        }
        if (onlyHeavyAtoms)
            writeMFCConf2SD_HA(Frag, xyz, fout, 0);
        else
            writeMFCConf2SD(Frag, xyz, fout, 0);
        delete[] xyz;
    }
}

//
// for scaffold hunter
// number of atoms is equal to the size of atomList, not the numAtoms
//
void writeMFCFrag2SD_SH(MFCFrag* Frag, std::ostream& fout) {
    Fragmentation* fraction = (Fragmentation*)Frag->fraction;
    if (fraction != 0) {
        FragConf* tmpConf = fraction->firstConf;
        int numConfs = 0;

        for (tmpConf = fraction->firstConf; tmpConf != 0; tmpConf = tmpConf->nextConf) {
            numConfs++;
            writeMFCConf2SD_SH(Frag, tmpConf->xyz, fout, 0);
        }
    } else {
        int nAtoms = Frag->atomList.size();
        double* xyz = new double[nAtoms * 3];
        for (int i = 0; i < nAtoms; i++) {
            int i3 = i * 3;
            MFCAtom* atom = Frag->atomList[i];
            if (0 == atom) continue;

            xyz[i3] = atom->x;
            xyz[i3 + 1] = atom->y;
            xyz[i3 + 2] = atom->z;
        }
        writeMFCConf2SD_SH(Frag, xyz, fout, 0);
        delete[] xyz;
    }
}

void writeMFCConf2SD_SH(MFCFrag* Frag, double* xyz, std::ostream& fout, int* mapx) {
    PeriodicTable* xTable = PeriodicTable::Instance();
    Fragmentation* fraction = (Fragmentation*)Frag->fraction;
    MFCAtom* Atom;
    MFCBond* Bond;
    int oldNAtoms = Frag->atomList.size();
    int oldNBonds = Frag->bondList.size();
    int AIdx, i, i3, aNum;
    int* map = new int[oldNAtoms];

    // new index for Heavy Atoms
    int* HAtomIdx = new int[oldNAtoms];

    int nHAtoms = 0;
    for (i = 0; i < oldNAtoms; i++) {
        Atom = Frag->atomList[i];
        if (0 == Atom || 1 == Atom->atomicNumber) continue;

        HAtomIdx[i] = nHAtoms;  // i is old index for heavy atom
        nHAtoms++;
    }

    int nRealBonds = 0;
    for (i = 0; i < oldNBonds; i++) {
        Bond = Frag->bondList[i];
        if (0 == Bond)  // deleted bonds
            continue;

        // X-H bonds
        Atom = Frag->atomList[Bond->atom1];
        if (1 == Atom->atomicNumber) continue;
        Atom = Frag->atomList[Bond->atom2];
        if (1 == Atom->atomicNumber) continue;

        nRealBonds++;
    }

    fout << Frag->fragname << "\n";
    fout << "MFCFrag2SD\n";
    fout << "\n";
    fout << std::setw(3) << Frag->numAtoms << std::setw(3) << Frag->numBonds;
    fout << std::setw(3) << 0 << std::setw(3) << 0;
    fout << std::setw(3) << Frag->stereoFlag << "  0  0  0  0  0  0 V2000\n";

    /*
          if(mapx != 0) {
             for (i=0; i < nAtoms; i++) {
                  map[mapx[i]] = i;
             }
          } else if(fraction == 0) {
             for (i=0; i < nAtoms; i++) {
                  map[i] = i;
             }
          } else {
             for (i=0; i < nAtoms; i++) {
                  AIdx = fraction->atomList[i];
                  map[AIdx] = i;
             }
          }
    */
    if (mapx == 0) {
        for (AIdx = 0; AIdx < oldNAtoms; AIdx++) {
            // i = map[AIdx];
            Atom = Frag->atomList[AIdx];
            if (0 == Atom) continue;
            aNum = Atom->atomicNumber;
            if (1 == aNum) continue;

            i3 = AIdx * 3;
            fout << std::setw(10) << std::setiosflags(std::ios::fixed) << std::setprecision(4)
                 << xyz[i3];
            fout << std::setw(10) << std::setiosflags(std::ios::fixed) << std::setprecision(4)
                 << xyz[i3 + 1];
            fout << std::setw(10) << std::setiosflags(std::ios::fixed) << std::setprecision(4)
                 << xyz[i3 + 2];
            fout << " " << std::setw(2) << xTable->AtomicSymbol(aNum);
            fout << std::setw(3) << Atom->massDiff  //<< std::setw(3)
                                                    //<< Atom->mdlChargeFlag;
                 << "  0";
            if (Atom->stereoParity < 0) Atom->stereoParity = 0;
            fout << std::setw(3) << Atom->stereoParity << "  0  0" << '\n';
        }
        for (i = 0; i < oldNBonds; i++) {
            Bond = Frag->bondList[i];
            if (0 == Bond) continue;
            Atom = Frag->atomList[Bond->atom1];
            if (0 == Atom || 1 == Atom->atomicNumber) continue;
            Atom = Frag->atomList[Bond->atom2];
            if (0 == Atom || 1 == Atom->atomicNumber) continue;

            fout << std::setw(3) << HAtomIdx[Bond->atom1] + 1 << std::setw(3)
                 << HAtomIdx[Bond->atom2] + 1
                 << std::setw(3)
                 //<< Bond->bondOrder/100 <<  std::setw(3)
                 << Bond->bondType << std::setw(3);

            if (Bond->bondDirection < 0) Bond->bondDirection = 0;
            fout << Bond->bondDirection << "  0  0" << '\n';
        }
    }
    /*else {
        // To do list: reset stereo flag according to the new order in mapx
        // Set stereo parity flag. Modify it only if Atom is a chiral
        // center. (i.e. Atom->stereoParity != 0).
        for (i=0; i < nAtoms; i++) {
            Atom = Frag->atomList[i];
            if(Atom->stereoParity !=0 && Atom->stereoParity != 3)
             Atom->stereoParity = getStereoParity(Frag, Atom, map);
        }

        for (AIdx=0; AIdx < nAtoms; AIdx++) {
            i = mapx[AIdx];
            Atom = Frag->atomList[i];
            aNum = Atom->atomicNumber;
            if(1 == aNum)
              continue;

            i3 = i*3;
            fout << std::setw(10)
                 <<  std::setiosflags(std::ios::fixed)
                 << std::setprecision(4) << xyz[i3];
            fout << std::setw(10)
                 <<  std::setiosflags(std::ios::fixed)
                 << std::setprecision(4) << xyz[i3+1];
            fout << std::setw(10)
                 << std::setiosflags(std::ios::fixed)
                 << std::setprecision(4) << xyz[i3+2];
            fout << " " << std::setw(2) << xTable->AtomicSymbol(aNum);
            fout <<  std::setw(3) << Atom->massDiff << std::setw(3)
                 << Atom->mdlChargeFlag;
            fout <<  std::setw(3) << Atom->stereoParity <<"  0  0" << '\n';
            //fout <<  std::setw(3) << 0 <<"  0  0" << '\n';
        }
        for (i=0; i < nBonds; i++) {
            Bond = Frag->bondList[i];
            Atom = Frag->atomList[ Bond->atom1 ];
            if(1 == Atom->atomicNumber)
              continue;
            Atom = Frag->atomList[ Bond->atom2 ];
            if(1 == Atom->atomicNumber)
              continue;

            fout << std::setw(3) << HAtomIdx[ map[Bond->atom1] ]+1 << std::setw(3)
                 << HAtomIdx[ map[Bond->atom2] ]+1
                 << std::setw(3) << Bond->bondOrder/100
                 << std::setw(3) << Bond->bondDirection << "  0  0" << '\n';
        }
    }
    */

    // properties
    MolProperties* molPro = Frag->getMolPro();
    int size = molPro->PropertyDoc.size();
    for (i = 0; i < size; i++) {
        fout << molPro->PropertyDoc[i] << "\n";
    }

    fout << "$$$$\n";
    delete[] map;
    delete[] HAtomIdx;
}

void writeMFCFrag2SDX(MFCFrag* Frag, std::ostream& fout) {
    int numConfs = 0;
    Fragmentation* fraction = (Fragmentation*)Frag->fraction;
    std::vector<FragConf*>::iterator iter = fraction->confList.begin();
    std::vector<FragConf*>::iterator iter_end = fraction->confList.end();

    for (; iter != iter_end; ++iter) {
        FragConf* tmpConf = *iter;
        numConfs++;
        writeMFCConf2SD(Frag, tmpConf->xyz, fout);
    }
}

MFCFrag* mergeMFCFrags(MFCFrag* FragA, MFCFrag* FragB, int link1, int link2) {
    // Merge FragA and FragB with link atoms link1 and link2 on FragA, B, respectively to construct
    // FragC.

    MFCFrag* FragC = new MFCFrag();
    link1--;  // PDB atom number to AIdx
    link2--;
    std::vector<MFCAtom*> vAtomsA = FragA->atomList;
    std::vector<MFCAtom*> vAtomsB = FragB->atomList;
    std::vector<MFCAtom*> vAtomsC;
    int nAtomsA = FragA->numAtoms;
    int nAtomsB = FragB->numAtoms;
    int nAtomsC = 0;
    MFCAtom* Atom;
    MFCAtom* link1Atom = vAtomsA[link1];
    MFCAtom* link2Atom = vAtomsB[link2];
    MFCBond* Bond;
    std::vector<MFCBond*> vBondsA = FragA->bondList;
    std::vector<MFCBond*> vBondsB = FragB->bondList;
    std::vector<MFCBond*> vBondsC;
    int nBondsA = FragA->numBonds;
    int nBondsB = FragB->numBonds;
    int nBondsC = 0;
    int newBondIdx = nBondsA + nBondsB - 2;
    int swaptemp = 0;
    int* mapA = new int[nAtomsA];
    int* mapB = new int[nAtomsB];
    int* bondmapA = new int[nBondsA];
    int* bondmapB = new int[nBondsB];

    // Detect if link1 and link2 have only one bond
    if ((link1Atom->nBonds != 1) or (link2Atom->nBonds != 1)) {
        std::cout << "Either link1 or link2 atom have more than one bonds!" << std::endl;
        return 0;
    }
    int link1BIdx = link1Atom->bondList[0];
    int link2BIdx = link2Atom->bondList[0];
    std::cout << "link1BIdx=" << link1BIdx << " link2BIdx=" << link2BIdx << std::endl;
    // Set up atom maps for FragA and FragB
    for (int i = 0; i < nAtomsA; i++) {
        if (i > link1) {
            mapA[i] = i - 1;
        } else {
            mapA[i] = i;
        }
    }
    for (int i = 0; i < nAtomsB; i++) {
        if (i > link2) {
            mapB[i] = i + nAtomsA - 2;
        } else {
            mapB[i] = i + nAtomsA - 1;
        }
    }
    // Bond maps for FragA and FragB
    for (int i = 0; i < nBondsA; i++) {
        if (i > link1BIdx) {
            bondmapA[i] = i - 1;
        } else {
            bondmapA[i] = i;
        }
    }
    for (int i = 0; i < nBondsB; i++) {
        if (i > link2BIdx) {
            bondmapB[i] = i + nBondsA - 2;
        } else {
            bondmapB[i] = i + nBondsA - 1;
        }
    }
    bondmapA[link1BIdx] = newBondIdx;
    bondmapB[link2BIdx] = newBondIdx;
    std::cout << "newBondIdx = " << newBondIdx << "\n";
    // Determine point1 and point2 for newBond
    int point1 = vAtomsA[link1]->atomList[0];
    point1 = mapA[point1];
    int point2 = vAtomsB[link2]->atomList[0];
    point2 = mapB[point2];
    // Fix link1 and link2 for maps
    mapA[link1] = point2;
    mapB[link2] = point1;
    std::cout << "point 1 and 2 = " << point1 << " " << point2 << "\n";
    // For Atoms
    for (int i = 0; i < nAtomsA; i++) {
        MFCAtom* tmpAtom = vAtomsA[i];
        if (i != link1) {
            Atom = new MFCAtom(*tmpAtom);
            Atom->AIdx = mapA[i];
            Atom->atomList.clear();
            for (int j = 0; j < tmpAtom->atomList.size(); j++) {
                Atom->atomList.push_back(mapA[tmpAtom->atomList[j]]);
            }
            Atom->bondList.clear();
            for (int k = 0; k < tmpAtom->bondList.size(); k++) {
                Atom->bondList.push_back(bondmapA[tmpAtom->bondList[k]]);
            }
            Atom->ownerFrag = FragC;
            vAtomsC.push_back(Atom);
        }
    }
    for (int i = 0; i < nAtomsB; i++) {
        MFCAtom* tmpAtom = vAtomsB[i];
        if (i != link2) {
            Atom = new MFCAtom(*tmpAtom);
            Atom->AIdx = mapB[i];
            Atom->atomList.clear();
            for (int j = 0; j < tmpAtom->atomList.size(); j++) {
                Atom->atomList.push_back(mapB[tmpAtom->atomList[j]]);
            }
            Atom->bondList.clear();
            for (int k = 0; k < tmpAtom->bondList.size(); k++) {
                Atom->bondList.push_back(bondmapB[tmpAtom->bondList[k]]);
            }
            Atom->ownerFrag = FragC;
            vAtomsC.push_back(Atom);
        }
    }
    // For Bonds
    int BondCounts = 0;
    for (int i = 0; i < nBondsA; i++) {
        MFCBond* tmpBond = vBondsA[i];
        Bond = new MFCBond(*tmpBond);
        if (tmpBond->BIdx != link1BIdx) {
            Bond->atom1 = mapA[Bond->atom1];
            Bond->atom2 = mapA[Bond->atom2];
            Bond->BIdx = BondCounts;
            BondCounts++;
            Bond->ownerFrag = FragC;
            vBondsC.push_back(Bond);
        }
    }
    for (int i = 0; i < nBondsB; i++) {
        MFCBond* tmpBond = vBondsB[i];
        Bond = new MFCBond(*tmpBond);
        if (tmpBond->BIdx != link2BIdx) {
            Bond->atom1 = mapB[Bond->atom1];
            Bond->atom2 = mapB[Bond->atom2];
            Bond->BIdx = BondCounts;
            BondCounts++;
            Bond->ownerFrag = FragC;
            vBondsC.push_back(Bond);
        }
    }
    MFCBond* newBond = new MFCBond(point1, point2, 100, newBondIdx);
    newBond->ownerFrag = FragC;
    vBondsC.push_back(newBond);

    // Set FragC members and print
    FragC->numAtoms = vAtomsC.size();
    FragC->numBonds = vBondsC.size();
    FragC->numRings = FragC->numBonds - FragC->numAtoms + 1;
    for (std::vector<MFCAtom*>::iterator it = vAtomsC.begin(); it < vAtomsC.end(); it++)
        FragC->atomList.push_back(*it);
    for (std::vector<MFCBond*>::iterator it = vBondsC.begin(); it < vBondsC.end(); it++)
        FragC->bondList.push_back(*it);
    for (std::vector<MFCRing*>::iterator it = FragA->ringList.begin(); it < FragA->ringList.end();
         it++)
        FragC->ringList.push_back(*it);
    for (std::vector<MFCRing*>::iterator it = FragB->ringList.begin(); it < FragB->ringList.end();
         it++)
        FragC->ringList.push_back(*it);
    FragC->ringCount = FragC->ringList.size();

    return FragC;
}

int getNSpheres(MFCFrag* frag, bool onlyHeavyAtoms) {
    int i, i3;
    int nAtoms = frag->numAtoms;
    MFCAtom* atom;
    if (onlyHeavyAtoms) {
        int nHAtoms = 0;
        for (i = 0; i < nAtoms; i++) {
            atom = frag->atomList[i];
            if (1 == atom->atomicNumber) continue;
            nHAtoms++;
        }
        return nHAtoms;
    }

    return nAtoms;
}

int getFragXYZ(MFCFrag* frag, double* xyz, bool onlyHeavyAtoms) {
    int nAtoms = frag->numAtoms;
    int i, i3;
    MFCAtom* atom;
    if (onlyHeavyAtoms) {
        int nHAtoms = 0;
        int nHAtoms3;
        for (i = 0; i < nAtoms; i++) {
            atom = frag->atomList[i];
            if (1 == atom->atomicNumber) continue;
            i3 = i * 3;
            nHAtoms3 = nHAtoms * 3;
            xyz[nHAtoms3] = atom->x;
            xyz[nHAtoms3 + 1] = atom->y;
            xyz[nHAtoms3 + 2] = atom->z;
            nHAtoms++;
        }
        return nHAtoms;
    }

    for (i = 0; i < nAtoms; i++) {
        atom = frag->atomList[i];
        i3 = i * 3;
        xyz[i3] = atom->x;
        xyz[i3 + 1] = atom->y;
        xyz[i3 + 2] = atom->z;
    }
    return nAtoms;
}

int getFragXYZVDWR(MFCFrag* frag, double* xyz, double* vdwR, bool onlyHeavyAtoms, bool equalR) {
    int i;
    int nSpheres = getFragXYZ(frag, xyz, onlyHeavyAtoms);
    if (equalR) {
        for (i = 0; i < nSpheres; i++) vdwR[i] = 1.8;

        return nSpheres;
    }

    int nAtoms = frag->numAtoms;
    MFCAtom* atom;
    if (onlyHeavyAtoms) {
        nSpheres = 0;
        for (i = 0; i < nAtoms; i++) {
            atom = frag->atomList[i];
            if (1 == atom->atomicNumber) continue;
            vdwR[nSpheres] = atom->vdwR / 100;
            nSpheres++;
        }
        return nSpheres;
    }

    for (i = 0; i < nAtoms; i++) {
        atom = frag->atomList[i];
        vdwR[i] = atom->vdwR / 100;
    }

    return nSpheres;
}

void setFragXYZ(MFCFrag* frag, double* xyz, bool onlyHeavyAtoms) {
    int nAtoms = frag->numAtoms;
    int i, i3;
    MFCAtom* atom;
    if (onlyHeavyAtoms) {
        int nHAtoms = 0;
        int nHAtoms3;
        for (i = 0; i < nAtoms; i++) {
            atom = frag->atomList[i];
            if (1 == atom->atomicNumber) continue;
            i3 = i * 3;
            nHAtoms3 = nHAtoms * 3;
            atom->x = xyz[nHAtoms3];
            atom->y = xyz[nHAtoms3 + 1];
            atom->z = xyz[nHAtoms3 + 2];
            nHAtoms++;
        }
        return;
    }

    for (i = 0; i < nAtoms; i++) {
        atom = frag->atomList[i];
        i3 = i * 3;
        atom->x = xyz[i3];
        atom->y = xyz[i3 + 1];
        atom->z = xyz[i3 + 2];
    }
}

void setFragnH(MFCFrag* frag) {
    for (auto Atom : frag->atomList) {
        int count = 0;
        if (Atom->atomicNumber != 1) {
            for (auto bond :
                 Atom->bondList | transformed([frag](auto i) { return frag->bondList[i]; })) {
                auto otherAtomIdx = findOtherBondAtom(bond, Atom->AIdx);
                if (frag->atomList[otherAtomIdx]->atomicNumber == 1) ++count;
            }
        }
        Atom->nH = count;
    }
}

//
// This function is used to calculate the accessible surface of an atom
// Assume that frag has add H already and each H has the 3D coordinate.
// vdwR_C = 180pm, vdwR_H = 120pm
// Accuracy Test:
// 1.set distance of two C atoms in testSASA.mol = 3.2,
// 2.set vdwR_C = 1.8(default), solventR = 1.4.
// 3.the standard SASA fraction = 0.75.
// 4.use m = 10,n = 36, SASA fraction = 0.7434, Relative Error = 0.875%
//
double calSASA(MFCFrag* Frag, int Idx, bool isArea) {
    double solventR = 1.4;
    MFCAtom* Atom;
    MFCAtom* neiboAtom;
    int nAtoms = Frag->numAtoms;
    int nInNodes = 0;
    Atom = Frag->atomList[Idx];
    double x = Atom->x;
    double y = Atom->y;
    double z = Atom->z;
    // std::cout<<"Atom "<<Idx+1<<" vdwR:"<<Atom->vdwR<<"xyz"<<x<<"\t"<<y<<"\t"<<z<<"\n";
    double vR = solventR + Atom->vdwR / 100.0;
    int m = 36;   // number part in each radius
    int n = 36;  // number nodes in the circle
    int nAllNodes = 2 * (m - 1) * n + n + 2;
    int mc = 2 * m + 1;
    for (int i = 0; i < mc; i++) {
        if (i == 0 || i == mc - 1) continue;
        double per = 1.0 * i / m;
        double r = vR * sqrt(1.0 - (1 - per) * (1 - per));
        double z1 = z - (m - i) * vR / m;
        for (int j = 0; j < n; j++) {
            double angle = 2 * PI * j / n;
            double x1 = x + r * sin(angle);
            double y1 = y + r * cos(angle);
            double distance = 0.0;
            for (int k = 0; k < nAtoms; k++) {
                if (k == Idx) continue;
                neiboAtom = Frag->atomList[k];
                if (neiboAtom->atomicNumber == 1) continue;
                double x2 = neiboAtom->x;
                double y2 = neiboAtom->y;
                double z2 = neiboAtom->z;
                double neibovR = solventR + neiboAtom->vdwR / 100.0;
                if (fabs(x1 - x2) >= neibovR) continue;
                if (fabs(y1 - y2) >= neibovR) continue;
                if (fabs(z1 - z2) >= neibovR) continue;
                distance = (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2) + (z1 - z2) * (z1 - z2);
                if (distance <= neibovR * neibovR) {
                    nInNodes++;
                    break;
                }
            }
        }
    }
    double access = 1.0 - 1.0 * nInNodes / nAllNodes;
    // double area = 4*PI*vR*vR;
    std::cout << "nInNodes, nAllNodes " << nInNodes << " " << nAllNodes << "\n";
    double SASA = access * 4 * PI * vR * vR;
    // std::cout<<"access = "<<access<<"SASA = "<<SASA<<"\n";
    if (isArea) return SASA;
    return access;
}

double calSASA_SIMD(MFCFrag* Frag, int Idx, bool isArea) {
    constexpr double solventR = 1.4;
    //    setMFCAtomVDW(Frag);
    //    setHybridization(Frag);
    MFCAtom* Atom;
    MFCAtom* neiboAtom;
    int nAtoms = Frag->numAtoms;
    int nInNodes = 0;
    Atom = Frag->atomList[Idx];
    double x = Atom->x;
    double y = Atom->y;
    double z = Atom->z;

    alignas(XSIMD_DEFAULT_ALIGNMENT) double x2s[Frag->atomList.size()];
    alignas(XSIMD_DEFAULT_ALIGNMENT) double y2s[Frag->atomList.size()];
    alignas(XSIMD_DEFAULT_ALIGNMENT) double z2s[Frag->atomList.size()];
    alignas(XSIMD_DEFAULT_ALIGNMENT) double neibovRs[Frag->atomList.size()];

    int count = 0;

    const double vR = solventR + Atom->vdwR / 100.0;

    for (int k = 0; k < nAtoms; k++) {
        // skip self and hydrogen
        if (k == Idx) continue;
        neiboAtom = Frag->atomList[k];
        if (neiboAtom->atomicNumber == 1) continue;

        x2s[count] = neiboAtom->x;
        y2s[count] = neiboAtom->y;
        z2s[count] = neiboAtom->z;

        neibovRs[count] = solventR + neiboAtom->vdwR / 100.0;
        count++;
    }

    const int total_array_size = count;
    const auto vectorize_size =
        total_array_size - total_array_size % xsimd::simd_type<double>::size;

    constexpr int m = 36;   // number part in each radius
    constexpr int n = 36;  // number nodes in the circle
    constexpr int nAllNodes = 2 * (m - 1) * n + n + 2;
    constexpr int mc = 2 * m + 1;

    constexpr auto f = 2 * PI / 20.0;
    alignas(XSIMD_DEFAULT_ALIGNMENT) constexpr double simd_angle_data[]{
        0 * f,  1 * f,  2 * f,  3 * f,  4 * f,  5 * f,  6 * f,  7 * f,
        8 * f,  9 * f,  10 * f, 11 * f, 12 * f, 13 * f, 14 * f, 15 * f,
        16 * f, 17 * f, 18 * f, 19 * f, 0,      0,      0,      0};  //

    alignas(XSIMD_DEFAULT_ALIGNMENT) double simd_sin_data[24], simd_cos_data[24];

    static_assert(24 % xsimd::simd_type<double>::size == 0);
    for (std::size_t k = 0; k < 24; k += xsimd::simd_type<double>::size) {
        auto simd_angle = xsimd::load_aligned(simd_angle_data + k);
        xsimd::simd_type<double> simd_sin, simd_cos;
        sincos(simd_angle, simd_sin, simd_cos);
        xsimd::store_aligned(simd_sin_data + k, simd_sin);
        xsimd::store_aligned(simd_cos_data + k, simd_cos);
    }

    alignas(XSIMD_DEFAULT_ALIGNMENT) double simd_x_data[24], simd_y_data[24];

    for (int i = 1; i < mc - 1; i++) {
        const double per = 1.0 * i / m;
        const double r = vR * sqrt((2 - per) * per);
        const double z1 = z - (m - i) * vR / m;

        for (std::size_t k = 0; k < 24; k += xsimd::simd_type<double>::size) {
            auto simd_sin = xsimd::load_aligned(simd_sin_data + k);
            auto simd_cos = xsimd::load_aligned(simd_cos_data + k);
            auto simd_x = x + r * simd_sin;
            auto simd_y = y + r * simd_cos;
            xsimd::store_aligned(simd_x_data + k, simd_x);
            xsimd::store_aligned(simd_y_data + k, simd_y);
        }

        for (int j = 0; j < n; j++) {
            const double x1 = simd_x_data[j];
            const double y1 = simd_y_data[j];

            for (std::size_t k = 0; k < vectorize_size; k += xsimd::simd_type<double>::size) {
                auto simd_x2 = xsimd::load_aligned(x2s + k);
                auto simd_y2 = xsimd::load_aligned(y2s + k);
                auto simd_z2 = xsimd::load_aligned(z2s + k);
                auto simd_neibovR = xsimd::load_aligned(neibovRs + k);

                if (all(abs(x1 - simd_x2) >= simd_neibovR or abs(y1 - simd_y2) >= simd_neibovR or
                        abs(z1 - simd_z2) >= simd_neibovR))
                    continue;

                auto dx = x1 - simd_x2;
                auto dy = y1 - simd_y2;
                auto dz = z1 - simd_z2;

                auto distance2 = dx * dx + dy * dy + dz * dz;

                if (any(distance2 < (simd_neibovR * simd_neibovR))) {
                    nInNodes++;
                    goto end;
                }
            }

            for (int k = vectorize_size; k < total_array_size; ++k) {
                auto x2 = x2s[k];
                auto y2 = y2s[k];
                auto z2 = z2s[k];
                auto neibovR = neibovRs[k];

                if (abs(x1 - x2) >= neibovR or abs(y1 - y2) >= neibovR or abs(z1 - z2) >= neibovR)
                    continue;

                const auto distance =
                    (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2) + (z1 - z2) * (z1 - z2);
                if (distance <= neibovR * neibovR) {
                    nInNodes++;
                    break;
                }
            }
        end:
            continue;
        }
    }
    double access = 1.0 - 1.0 * nInNodes / nAllNodes;
    std::cout << "nInNodes, nAllNodes SIMD " << nInNodes << " " << nAllNodes << "\n";
    // double area = 4*PI*vR*vR;
    double SASA = access * 4 * PI * vR * vR;
    // std::cout<<"access = "<<access<<"SASA = "<<SASA<<"\n";
    if (isArea) return SASA;
    return access;
}

//
// find the n bonds away atoms and save the index in vector, nbonds >= 1
//
void findAtomList(MFCFrag* frag, int Idx, int nbonds, std::vector<int>& vec) {
    vec.clear();
    MFCAtom* atom;
    int nAtoms = frag->numAtoms;
    int* visited = new int[nAtoms];
    for (int i = 0; i < nAtoms; i++) visited[i] = 0;
    visited[Idx] = 1;
    std::vector<int> tem;
    atom = frag->atomList[Idx];
    int nConnections = atom->nBonds;
    for (int i = 0; i < nConnections; i++) {
        vec.push_back(atom->atomList[i]);
        visited[atom->atomList[i]] = 1;
    }
    for (int i = 1; i < nbonds; i++) {
        if (vec.size() == 0) break;
        for (int k = 0; k < vec.size(); k++) {
            atom = frag->atomList[vec[k]];
            nConnections = atom->nBonds;
            for (int j = 0; j < nConnections; j++) {
                if (visited[atom->atomList[j]] == 0) {
                    tem.push_back(atom->atomList[j]);
                    visited[atom->atomList[j]] = 1;
                }
            }
        }
        swap(tem, vec);
        tem.clear();
    }
    delete[] visited;
}
//
// check if an atom has double bonds attached
//
bool hasDoubleBond(MFCFrag* frag, int Idx) {
    // assume frag was set aromatic already
    MFCAtom* atom;
    MFCBond* bond;
    bool doubleBond = false;
    atom = frag->atomList[Idx];
    if (atom->aromaticFlag == 1) return true;
    for (int i = 0; i < atom->nBonds; i++) {
        bond = frag->bondList[atom->bondList[i]];
        if (bond->bondType == 2) {
            doubleBond = true;
            break;
        }
    }
    return doubleBond;
}

//
// This function is used to detect the atom type for
// defining the topology-dependent termt in HYD mapping.
//
bool topologyHYD(int Atype, MFCFrag* frag, int Idx, int Flag) {
    MFCAtom* Atom;
    MFCAtom* Atom1;
    Atom = frag->atomList[Idx];
    std::vector<int> AtomList;
    int count = 0;
    switch (Atype) {
        case 1:  // N, O, or H
            if (Atom->atomicNumber == 7 || Atom->atomicNumber == 8 || Atom->atomicNumber == 1)
                return true;
            return false;
        case 2:  // S in SH
            if (Atom->atomicNumber == 16 && Atom->nH == 1 && Atom->nBonds == 2) return true;
            return false;
        case 3:  // ��2 bonds away from charged atom
            if (Flag == 1) return true;
            return false;
        case 4:  // ��2 bonds away from OH or NH, no delocalized electrons
            if (Flag == 1) return true;
            return false;
        case 5:  // ��1 bond away from SH, no delocalized electrons
            if (Atom->aromaticFlag == 1) return false;
            for (int i = 0; i < Atom->nBonds; i++) {
                Atom1 = frag->atomList[Atom->atomList[i]];
                if (Atom1->atomicNumber == 16 && Atom1->nH == 1) return true;
            }
            return false;
        case 6:  // ��2 bonds away from O with double bond
            if (Flag == 1) return true;
            return false;
        case 7:  //��1 bond away from S with valence > 2
            if (Atom->atomicNumber == 16 && Atom->freeValence > 2) return true;
            for (int i = 0; i < Atom->nBonds; i++) {
                Atom1 = frag->atomList[Atom->atomList[i]];
                if (Atom1->atomicNumber == 16 && Atom1->freeValence > 2) return true;
            }
            return false;
        case 8:  // S with double bond
            if (Atom->atomicNumber == 16 && hasDoubleBond(frag, Idx)) return true;
            return false;
        case 9:  // 3 bonds away from O with double bond
            findAtomList(frag, Idx, 3, AtomList);
            for (int i = 0; i < AtomList.size(); i++) {
                Atom = frag->atomList[AtomList[i]];
                if (Atom->atomicNumber == 8 && Atom->nBonds == 1) return true;
            }
            return false;
        case 10:  // 2 bonds away from S with valence >2
            findAtomList(frag, Idx, 2, AtomList);
            for (int i = 0; i < AtomList.size(); i++) {
                Atom = frag->atomList[AtomList[i]];
                if (Atom->atomicNumber == 16 && Atom->freeValence > 2) return true;
            }
            return false;
        case 11:  // 1 bond away from S with double bond
            for (int i = 0; i < Atom->nBonds; i++) {
                Atom1 = frag->atomList[Atom->atomList[i]];
                if (Atom1->atomicNumber == 16 && hasDoubleBond(frag, Idx)) return true;
            }
            return false;
        case 12:  // ��2 instances of any of previous 3 conditions
            if (topologyHYD(9, frag, Idx, Flag) && topologyHYD(10, frag, Idx, Flag))
                return true;
            else if (topologyHYD(9, frag, Idx, Flag) && topologyHYD(11, frag, Idx, Flag))
                return true;
            else if (topologyHYD(10, frag, Idx, Flag) && topologyHYD(11, frag, Idx, Flag))
                return true;
            else
                return false;
        case 13:  // 1 neighboring O or N, no delocalized electrons
            if (Atom->aromaticFlag == 1) return false;
            for (int i = 0; i < Atom->nBonds; i++) {
                Atom1 = frag->atomList[Atom->atomList[i]];
                if (Atom1->atomicNumber == 8 || Atom1->atomicNumber == 7) count++;
            }
            if (count == 1)
                return true;
            else
                return false;
        case 14:  // >1 neighboring O or N, no delocalized electrons
            if (Atom->atomicNumber == 7 && Atom->aromaticFlag == 1) return false;
            for (int i = 0; i < Atom->nBonds; i++) {
                Atom1 = frag->atomList[Atom->atomList[i]];
                if (Atom1->atomicNumber == 8 || Atom1->atomicNumber == 7) count++;
            }
            if (count > 1)
                return true;
            else
                return false;
        defaut:
            std::cout << "error in function topologyHYD()!\n";
            return (-1);
    }
}
//
// This function is used to calculate the the topology-dependent term t
//
void calTopoTerm(MFCFrag* Frag, double* topoterm) {
    // For case 3,4,6, flag atoms.
    int nAtoms = Frag->numAtoms;
    int* chargeFlag = new int[nAtoms];
    int* NOFlag = new int[nAtoms];
    int* OFlag = new int[nAtoms];
    for (int i = 0; i < nAtoms; i++) {
        chargeFlag[i] = 0;
        NOFlag[i] = 0;
        OFlag[i] = 0;
    }
    MFCAtom* Atom;
    std::vector<int> AtomList;
    // For case 3:atoms in charge center or <= 2 bonds away from charge center are flagged.
    for (int i = 0; i < nAtoms; i++) {
        Atom = Frag->atomList[i];
        if (Atom->FormalCharge != 0) {
            chargeFlag[i] = 1;
            findAtomList(Frag, i, 1, AtomList);
            int atoms = AtomList.size();
            for (int j = 0; j < atoms; j++) chargeFlag[AtomList[j]] = 1;
            ;
            AtomList.clear();
            findAtomList(Frag, i, 2, AtomList);
            atoms = AtomList.size();
            for (int j = 0; j < atoms; j++) chargeFlag[AtomList[j]] = 1;
            AtomList.clear();
        }
    }
    // For case 4:atoms ��2 bonds away from OH or NH, no delocalized electrons are flagged
    for (int i = 0; i < nAtoms; i++) {
        Atom = Frag->atomList[i];
        if ((Atom->atomicNumber == 8 || Atom->atomicNumber == 7) && (Atom->nH == 1)) {
            if (Atom->aromaticFlag == 1) continue;
            findAtomList(Frag, i, 1, AtomList);
            int atoms = AtomList.size();
            for (int j = 0; j < atoms; j++) NOFlag[AtomList[j]] = 1;
            AtomList.clear();
            findAtomList(Frag, i, 2, AtomList);
            atoms = AtomList.size();
            for (int j = 0; j < atoms; j++) NOFlag[AtomList[j]] = 1;
            AtomList.clear();
        }
    }
    // For case 6: atoms ��2 bonds away from O with double bond are flagged

    for (int i = 0; i < nAtoms; i++) {
        Atom = Frag->atomList[i];
        if (Atom->atomicNumber != 8 || Atom->nBonds != 1) continue;
        findAtomList(Frag, i, 1, AtomList);
        int atoms = AtomList.size();
        for (int j = 0; j < atoms; j++) OFlag[AtomList[j]] = 1;
        AtomList.clear();
        findAtomList(Frag, i, 2, AtomList);
        atoms = AtomList.size();
        for (int j = 0; j < atoms; j++) OFlag[AtomList[j]] = 1;
        AtomList.clear();
    }

    // check each atom type and get the topoloy-dependent term
    for (int i = 0; i < nAtoms; i++) {
        if (topologyHYD(1, Frag, i, 0))
            topoterm[i] = 0.0;
        else if (topologyHYD(2, Frag, i, 0))
            topoterm[i] = 0.0;
        else if (topologyHYD(3, Frag, i, chargeFlag[i]))
            topoterm[i] = 0.0;
        else if (topologyHYD(4, Frag, i, NOFlag[i]))
            topoterm[i] = 0.0;
        else if (topologyHYD(5, Frag, i, 0))
            topoterm[i] = 0.0;
        else if (topologyHYD(6, Frag, i, OFlag[i]))
            topoterm[i] = 0.0;
        else if (topologyHYD(7, Frag, i, 0))
            topoterm[i] = 0.0;
        else if (topologyHYD(8, Frag, i, 0))
            topoterm[i] = 0.0;
        else if (topologyHYD(9, Frag, i, 0))
            topoterm[i] = 0.6;
        else if (topologyHYD(10, Frag, i, 0))
            topoterm[i] = 0.6;
        else if (topologyHYD(11, Frag, i, 0))
            topoterm[i] = 0.6;
        else if (topologyHYD(12, Frag, i, 0))
            topoterm[i] = 0.0;
        else if (topologyHYD(13, Frag, i, 0))
            topoterm[i] = 0.25;
        else if (topologyHYD(14, Frag, i, 0))
            topoterm[i] = 0.0;
        else
            topoterm[i] = 1.0;
    }
    delete[] chargeFlag;
    delete[] NOFlag;
    delete[] OFlag;
}

//
// Excluded or Include some groups in HBA,HBD,POS and NEG.
//

void exclusiveLib(int fType, std::vector<MFCFrag*>& Lib) {
    if (!program_configuration) program_configuration = std::make_unique<ProgramConfiguration>();
    auto g = [](boost::filesystem::path p) -> std::string {
        return (program_configuration->get_sd_path() / p).generic_string();
    };

    auto get_sd = [=] {
        switch (fType) {
            case 1:
                return std::make_tuple(g(HBA_Exclude_FILE), HBA_Exclude_data_str);
            case 2:
                return std::make_tuple(g(HBD_Exclude_FILE), HBD_Exclude_data_str);
            case 4:
                return std::make_tuple(g(POS_Included_FILE), POS_Included_data_str);
            case 5:
                return std::make_tuple(g(NEG_Included_FILE), NEG_Included_data_str);
        }
    };

    auto [sdf_filename, data_str] = get_sd();
    boost::iostreams::mapped_file_source source;
    SDReaderT<MMapStream> sdReader;
    if (boost::filesystem::exists(sdf_filename)) {
        source.open(sdf_filename);
        sdReader.open(begin(source), end(source));
    } else {
        sdReader.open(begin(data_str), end(data_str));
    }
    while (!sdReader.endOfSD()) {
        auto qFrag = sdReader.readLargestMFCFrag();
        if (qFrag) Lib.push_back(qFrag);
    }
}

//
// This function used to generate the HBA and HBD spheres. Two spheres for each feature.
//
void getHBPharmaPoints(MFCFrag* Frag, int fType, int fIdx, std::vector<PharmaFeature*>& HB) {
    PharmaFeature* point = (PharmaFeature*)new PharmaFeature();
    if (fType == 1) point->fType = 1;
    if (fType == 2) point->fType = 2;
    point->atomList.push_back(fIdx);
    point->nSpheres = 2;
    double x1, y1, z1, r1 = 160;
    MFCAtom* atom;
    atom = Frag->atomList[fIdx];
    x1 = atom->x;
    y1 = atom->y;
    z1 = atom->z;
    point->x1 = x1;
    point->y1 = y1;
    point->z1 = z1;
    point->r1 = r1;
    // Find the centroid of atoms connected with HB heavy atom (x2,y2,z2)
    int nBonds = atom->nBonds;
    double mx = 0, my = 0, mz = 0;
    MFCAtom* atom1;
    for (int i = 0; i < nBonds; i++) {
        atom1 = Frag->atomList[atom->atomList[i]];
        if (atom1->atomicNumber == 1) continue;
        mx += atom1->x;
        my += atom1->y;
        mz += atom1->z;
    }
    int nH = atom->nH;
    int count = nBonds - nH;
    double x2, y2, z2;
    x2 = mx / count;
    y2 = my / count;
    z2 = mz / count;
    double x, y, z;  // normal vector
    x = x1 - x2;
    y = y1 - y2;
    z = z1 - z2;
    double x3, y3, z3;
    double dist = x * x + y * y + z * z;
    double k;
    if (dist < 0.001)
        k = 0;
    else
        k = 3.0 / sqrt(dist);

    x3 = k * x + x1;
    y3 = k * y + y1;
    z3 = k * z + z1;
    double r2 = 220;
    point->x2 = x3;
    point->y2 = y3;
    point->z2 = z3;
    point->r2 = r2;
    HB.push_back(point);
}

//
// This function used to generate the Aromatic points
//
void getAroPharmaPoints(MFCFrag* Frag, std::vector<int>& Idx, std::vector<PharmaFeature*>& ARO) {
    PharmaFeature* point1 = (PharmaFeature*)new PharmaFeature();
    PharmaFeature* point2 = (PharmaFeature*)new PharmaFeature();
    point1->fType = 3;
    point2->fType = 3;
    point1->r1 = 160;  // pm
    point1->r2 = 220;
    point2->r1 = 160;
    point2->r2 = 220;
    point1->nSpheres = 2;
    point2->nSpheres = 2;
    point1->atomList.insert(point1->atomList.end(), Idx.begin(), Idx.end());
    point2->atomList.insert(point2->atomList.end(), Idx.begin(), Idx.end());
    // Find the centroid of the ring (x2,y2,z2)
    double mx = 0, my = 0, mz = 0;
    MFCAtom* atom;
    int nAtoms = Idx.size();
    for (int i = 0; i < nAtoms; i++) {
        atom = Frag->atomList[Idx[i]];
        mx += atom->x;
        my += atom->y;
        mz += atom->z;
    }
    double x2, y2, z2;
    x2 = mx / nAtoms;
    y2 = my / nAtoms;
    z2 = mz / nAtoms;
    // Find 3 atoms in the plane and confirm two vectors (v1,v2)
    MFCAtom* atom1 = Frag->atomList[Idx[0]];
    MFCAtom* atom2 = Frag->atomList[Idx[1]];
    MFCAtom* atom3 = Frag->atomList[Idx[2]];
    double v1x = (atom2->x) - (atom1->x);
    double v1y = (atom2->y) - (atom1->y);
    double v1z = (atom2->z) - (atom1->z);
    double v2x = (atom3->x) - (atom2->x);
    double v2y = (atom3->y) - (atom2->y);
    double v2z = (atom3->z) - (atom2->z);
    // Find the normal(nx,ny,nz) of the two vectors by using cross product
    double nx, ny, nz;
    nx = v1y * v2z - v2y * v1z;
    ny = v1z * v2x - v2z * v1x;
    nz = v1x * v2y - v2x * v1y;
    // Find the aromatic point
    double x, y, z;
    double k = 3.0 / sqrt(nx * nx + ny * ny + nz * nz);
    x = k * nx + x2;
    y = k * ny + y2;
    z = k * nz + z2;
    point1->x1 = x2;
    point1->y1 = y2;
    point1->z1 = z2;
    point1->x2 = x;
    point1->y2 = y;
    point1->z2 = z;
    x = -k * nx + x2;
    y = -k * ny + y2;
    z = -k * nz + z2;
    point2->x1 = x2;
    point2->y1 = y2;
    point2->z1 = z2;
    point2->x2 = x;
    point2->y2 = y;
    point2->z2 = z;
    ARO.push_back(point1);
    ARO.push_back(point2);
    // delete point1;
    // delete point2;
}
//
// This function is used to get Pharmacophore Point for HYD
//
void getHYDPharmaPoints(MFCFrag* Frag, std::vector<int>& Idx, double* HYV, double HYSum,
                        std::vector<PharmaFeature*>& HYD) {
    PharmaFeature* point = (PharmaFeature*)new PharmaFeature();
    point->fType = 6;
    point->nSpheres = 1;
    point->r1 = 160;
    point->atomList.insert(point->atomList.end(), Idx.begin(), Idx.end());
    double x1, y1, z1;
    MFCAtom* atom;
    if (Idx.size() == 1) {
        atom = Frag->atomList[Idx[0]];
        x1 = atom->x;
        y1 = atom->y;
        z1 = atom->z;
        point->x1 = x1;
        point->y1 = y1;
        point->z1 = z1;
        HYD.push_back(point);
    } else {
        point->x1 = 0;
        point->y1 = 0;
        point->z1 = 0;
        int nAtoms = Idx.size();
        for (int i = 0; i < nAtoms; i++) {
            atom = Frag->atomList[Idx[i]];
            point->x1 += atom->x * HYV[Idx[i]] / HYSum;
            point->y1 += atom->y * HYV[Idx[i]] / HYSum;
            point->z1 += atom->z * HYV[Idx[i]] / HYSum;
        }
        HYD.push_back(point);
    }
}
//
// This function used for NEG,POS,HYD.
//
void getChargePharmaPoints(MFCFrag* Frag, int fType, std::vector<int>& Idx,
                           std::vector<PharmaFeature*>& Charge) {
    PharmaFeature* point = (PharmaFeature*)new PharmaFeature();
    if (fType == 4) point->fType = 4;
    if (fType == 5) point->fType = 5;
    if (fType == 6) point->fType = 6;
    point->nSpheres = 1;
    point->atomList.insert(point->atomList.end(), Idx.begin(), Idx.end());
    point->r1 = 160;
    int nAtoms = Idx.size();
    double mx = 0, my = 0, mz = 0;
    MFCAtom* atom;
    for (int i = 0; i < nAtoms; i++) {
        atom = Frag->atomList[Idx[i]];
        mx += atom->x;
        my += atom->y;
        mz += atom->z;
    }
    double x = mx / nAtoms;
    double y = my / nAtoms;
    double z = mz / nAtoms;
    point->x1 = x;
    point->y1 = y;
    point->z1 = z;
    Charge.push_back(point);
}
void mapHBA(MFCFrag* Frag, std::vector<PharmaFeature*>& HBA) {
    int nAtoms = Frag->numAtoms;
    std::vector<MFCFrag*> excludeGroups;
    exclusiveLib(1, excludeGroups);
    int Flag[nAtoms];
    for (int i = 0; i < nAtoms; i++) Flag[i] = 0;
    MFCFrag* qFrag;
    int nFrags = excludeGroups.size();
    // subSearch N-C=X(X=N,O,S) and N-S=O and flag the mapped N atom
    for (int i = 0; i < nFrags; i++) {
        qFrag = excludeGroups[i];
        for (int j = 0; j < nAtoms; j++) {
            if ((Frag->atomList[j])->atomicNumber == 1) continue;
            int* mapList = subSearch(qFrag, Frag, j);
            if (mapList) {
                Flag[mapList[0]] = 1;
                delete[] mapList;
            }
        }
    }
    MFCAtom* Atom;
    int Idx;
    for (int i = 0; i < nAtoms; i++) {
        Atom = Frag->atomList[i];
        Idx = Atom->AIdx;
        // For Nitrogen
        if (Atom->atomicNumber == 7 && Atom->FormalCharge <= 0) {
            // 1.exclude -N-C=X but not =N-C=X(X=N,O,S),also exclude -N-S=O
            if (Flag[i] == 1 && Atom->nBonds == 3) continue;
            // 2.exclude N in aromatic ring and has 3 bonds
            if (Atom->aromaticFlag == 1 && Atom->nBonds == 3) continue;
            // 3.exclude N has 3 bonds and connected with aromatic ring
            bool connectAromatic = false;
            if (Atom->nBonds == 3) {
                for (int k = 0; k < 3; k++) {
                    if (Frag->atomList[Atom->atomList[k]]->aromaticFlag == 1) {
                        connectAromatic = true;
                        break;
                    }
                }
            }
            if (connectAromatic) continue;
            // 4.exclude the Basic primary, secondary, and tertiary amines
            if (Atom->nBonds == 3) continue;
            // 5.exclude atoms which  solvent access surface area fraction < 2%
            if (calSASA(Frag, Idx, false) < 0.02) continue;
            getHBPharmaPoints(Frag, 1, i, HBA);
        }
        // For Oxygen
        else if (Atom->atomicNumber == 8 && Atom->FormalCharge <= 0) {
            if (calSASA(Frag, Idx, false) < 0.02) continue;
            getHBPharmaPoints(Frag, 1, i, HBA);
        }
        // For Sulfur,S in -SH is HBA as well
        else if (Atom->atomicNumber == 16 && Atom->FormalCharge <= 0 && Atom->hybride == 4) {
            if (calSASA(Frag, Idx, false) < 0.02) continue;
            getHBPharmaPoints(Frag, 1, i, HBA);
        }
    }
    for (int i = 0; i < nFrags; i++) delete excludeGroups[i];
}
void mapHBD(MFCFrag* Frag, std::vector<PharmaFeature*>& HBD) {
    int nAtoms = Frag->numAtoms;
    std::vector<MFCFrag*> excludeGroups;
    exclusiveLib(2, excludeGroups);
    int Flag[nAtoms];
    for (int i = 0; i < nAtoms; i++) Flag[i] = 0;
    MFCFrag* qFrag;
    int nFrags = excludeGroups.size();
    for (int i = 0; i < nFrags; i++) {
        qFrag = excludeGroups[i];
        for (int j = 0; j < nAtoms; j++) {
            if ((Frag->atomList[j])->atomicNumber == 1) continue;
            std::unique_ptr<int[]> mapList{subSearch(qFrag, Frag, j)};
            // exclude protonated pyridines and imidazoles but not exlude unprotonated
            if (mapList) {
                if (i == 2 || i == 3) {
                    if (Frag->atomList[mapList[0]]->FormalCharge == 1) Flag[mapList[0]] = 1;
                } else
                    Flag[mapList[0]] = 1;
            }
        }
    }
    MFCAtom* Atom;
    for (int i = 0; i < nAtoms; i++) {
        Atom = Frag->atomList[i];
        // For Nitrogen
        if ((Atom->atomicNumber == 7) && (Atom->nH > 0)) {
            // 1.exclude the protonated the N
            if (Atom->FormalCharge > 0) continue;
            // 2.exclude the -NH(trifluoromethyl sulfonamide),tetrazoles, pyridines,imidazoles
            if (Flag[i] == 1) continue;
            getHBPharmaPoints(Frag, 2, i, HBD);
        }
        // For Oxygen
        else if ((Atom->atomicNumber == 8) && (Atom->nH > 0)) {
            if (Atom->FormalCharge < 0) continue;
            // exclude -COOH
            if (Flag[i] == 1) continue;
            getHBPharmaPoints(Frag, 2, i, HBD);
        }
        // For Carbon, acetylenic hydrogens
        else if ((Atom->atomicNumber == 6) && (Atom->nBonds == 2) && (Atom->nH == 1)) {
            getHBPharmaPoints(Frag, 2, i, HBD);
        }
        // For Sulfur (-SH)
        else if ((Atom->atomicNumber == 16) && (Atom->nBonds == 2) && (Atom->nH == 1)) {
            getHBPharmaPoints(Frag, 2, i, HBD);
        }
    }
    for (int i = 0; i < nFrags; i++) delete excludeGroups[i];
}

void mapARO(MFCFrag* Frag, std::vector<PharmaFeature*>& ARO) {
    MFCRing* Ring;
    int ringCount = Frag->ringCount;
    // std::cout<<"ringcount = "<<ringCount<<"\n";
    for (int i = 0; i < ringCount; i++) {
        Ring = Frag->ringList[i];
        if (Ring->aromaticity != 1) continue;
        // std::cout<<"haha\n";
        getAroPharmaPoints(Frag, Ring->ringAtomList, ARO);
    }
}

void mapPOS(MFCFrag* Frag, std::vector<PharmaFeature*>& POS) {
    int nAtoms = Frag->numAtoms;
    int Flag[nAtoms];
    for (int i = 0; i < nAtoms; i++) Flag[i] = 0;
    std::vector<MFCFrag*> IncludeGroups;
    exclusiveLib(4, IncludeGroups);
    MFCFrag* qFrag;
    int nFrags = IncludeGroups.size();
    qFrag = IncludeGroups[0];  // guanidine
    for (int j = 0; j < nAtoms; j++) {
        if (Frag->atomList[j]->atomicNumber == 1) continue;
        int* mapList = subSearch(qFrag, Frag, j);
        if (mapList) {
            std::vector<int> gua;
            Flag[mapList[0]] = 1;
            Flag[mapList[2]] = 1;
            Flag[mapList[3]] = 1;
            gua.push_back(mapList[0]);
            gua.push_back(mapList[2]);
            gua.push_back(mapList[3]);
            getChargePharmaPoints(Frag, 4, gua, POS);
            gua.clear();
        }
    }
    qFrag = IncludeGroups[1];  // amidine
    for (int j = 0; j < nAtoms; j++) {
        int* mapList = subSearch(qFrag, Frag, j);
        if (mapList) {
            // Exclude the guanidine flagged before
            if (Flag[mapList[0]] == 1 || Flag[mapList[2]] == 1) continue;
            std::vector<int> amidine;
            Flag[mapList[0]] = 1;
            Flag[mapList[2]] = 1;
            // Basic secondary amidines:R-N-C=N
            if ((Frag->atomList[mapList[2]])->nH == 0) {
                amidine.push_back(mapList[0]);
            }
            // Basic primary amidines: R-NH-C=N
            else if ((Frag->atomList[mapList[2]])->nH > 0) {
                amidine.push_back(mapList[0]);
                amidine.push_back(mapList[2]);
            } else {
                std::cout << "error in POS detection!\n";
                exit(0);
            }
            getChargePharmaPoints(Frag, 4, amidine, POS);
        }
    }
    /*
    // exclude N atom in -N-C=O,
    qFrag = IncludeGroups[2];
    for(int j=0;j<nAtoms;j++){
       if(Frag->atomList[j]->atomicNumber ==1 ) continue;
       int* mapList = subSearch(qFrag,Frag,j);
       if(mapList) Flag[mapList[0]] = 1;
    }
    //exclude N atom in -NH-S(O2)-CF3,
    qFrag = IncludeGroups[3];
    for(int j=0;j<nAtoms;j++){
       if(Frag->atomList[j]->atomicNumber ==1 ) continue;
       int* mapList = subSearch(qFrag,Frag,j);
       if(mapList){
          if(Frag->atomList[mapList[0]]->nH == 1)
             Flag[mapList[0]] = 1;
       }
    }*/
    MFCAtom* Atom;
    for (int i = 0; i < nAtoms; i++) {
        Atom = Frag->atomList[i];
        // Positive charges not adjacent to a negative charge
        if (Flag[i] == 0 && Atom->FormalCharge > 0) {
            bool isNeg = false;
            int nBonds = Atom->nBonds;
            for (int k = 0; k < nBonds; k++) {
                if ((Frag->atomList[Atom->atomList[k]])->FormalCharge < 0) {
                    isNeg = true;
                    break;
                }
            }
            if (isNeg) continue;
            std::vector<int> posAtomList;
            posAtomList.push_back(Atom->AIdx);
            getChargePharmaPoints(Frag, 4, posAtomList, POS);
            posAtomList.clear();
        }
        // Basic primary, secondary, and tertiary amines
        else if (Flag[i] == 0 && Atom->atomicNumber == 7 && Atom->nBonds == 3) {
            // exclude the N in aromatic ring
            if (Atom->aromaticFlag == 1) continue;
            // Exclude the N attached with atoms which have double bonds or have aromatic
            bool isDouble = false;
            for (int k = 0; k < 3; k++) {
                int j = Frag->atomList[i]->atomList[k];
                if (hasDoubleBond(Frag, j)) {
                    isDouble = true;
                    break;
                }
            }
            if (isDouble == true) continue;
            std::vector<int> posAtomList;
            posAtomList.push_back(Atom->AIdx);
            getChargePharmaPoints(Frag, 4, posAtomList, POS);
            posAtomList.clear();
        }
    }
    for (int i = 0; i < nFrags; i++) delete IncludeGroups[i];
}

void mapNEG(MFCFrag* Frag, std::vector<PharmaFeature*>& NEG) {
    int nAtoms = Frag->numAtoms;
    int Flag[nAtoms];
    for (int i = 0; i < nAtoms; i++) Flag[i] = 0;
    std::vector<MFCFrag*> excludeGroups;
    exclusiveLib(5, excludeGroups);
    int nFrags = excludeGroups.size();
    MFCFrag* qFrag;
    MFCAtom* Atom;
    for (int i = 0; i < nFrags; i++) {
        qFrag = excludeGroups[i];
        if (i == 0) {  // For Trifluoromethyl sulfonamide hydrogens
            for (int j = 0; j < nAtoms; j++) {
                std::unique_ptr<int[]> mapList{subSearch(qFrag, Frag, j)};
                if (mapList) {
                    if (Frag->atomList[mapList[0]]->nH != 1) continue;
                    Flag[mapList[0]] = 1;
                    std::vector<int> negAtomList;
                    negAtomList.push_back(mapList[0]);
                    getChargePharmaPoints(Frag, 5, negAtomList, NEG);
                    negAtomList.clear();
                }
            }
        }
        // Sulfonic acids (centroid of the three oxygens)
        else if (i == 1) {
            for (int j = 0; j < nAtoms; j++) {
                std::unique_ptr<int[]> mapList{subSearch(qFrag, Frag, j)};
                if (mapList) {
                    if ((Frag->atomList[mapList[3]])->nH == 1) {
                        Flag[mapList[1]] = 1;
                        Flag[mapList[2]] = 1;
                        Flag[mapList[3]] = 1;
                        std::vector<int> negAtomList;
                        negAtomList.push_back(mapList[1]);
                        negAtomList.push_back(mapList[2]);
                        negAtomList.push_back(mapList[3]);
                        getChargePharmaPoints(Frag, 5, negAtomList, NEG);
                        negAtomList.clear();
                    }
                }
            }
        }
        // Phosphonic acids (centroid of the three oxygens)
        else if (i == 2) {
            for (int j = 0; j < nAtoms; j++) {
                std::unique_ptr<int[]> mapList{subSearch(qFrag, Frag, j)};
                if (mapList) {
                    std::vector<int> negAtomList;
                    if ((Frag->atomList[mapList[2]])->nH == 1) {
                        Flag[mapList[2]] = 1;
                        negAtomList.push_back(mapList[2]);
                    }
                    if ((Frag->atomList[mapList[3]])->nH == 1) {
                        Flag[mapList[3]] = 1;
                        negAtomList.push_back(mapList[3]);
                    }
                    if (negAtomList.size() > 0) {
                        negAtomList.push_back(mapList[1]);
                        getChargePharmaPoints(Frag, 5, negAtomList, NEG);
                        negAtomList.clear();
                    }
                }
            }
        }
        // Sulfinic, carboxylic, or phosphinic acids (centroid of the two oxygens)
        else if (i > 2 && i < 6) {
            for (int j = 0; j < nAtoms; j++) {
                std::unique_ptr<int[]> mapList{subSearch(qFrag, Frag, j)};
                if (mapList) {
                    if ((Frag->atomList[mapList[2]])->nH == 1) {
                        // Exclude the above situation
                        if (Flag[mapList[1]] == 1 || Flag[mapList[2]] == 1) continue;
                        Flag[mapList[1]] = 1;
                        Flag[mapList[2]] = 1;
                        std::vector<int> negAtomList;
                        negAtomList.push_back(mapList[1]);
                        negAtomList.push_back(mapList[2]);
                        getChargePharmaPoints(Frag, 5, negAtomList, NEG);
                        negAtomList.clear();
                    }
                }
            }
        }
        // For Tetrazoles,the H is required
        else if (i == 6) {
            for (int j = 0; j < nAtoms; j++) {
                std::unique_ptr<int[]> mapList{subSearch(qFrag, Frag, j)};
                if (mapList) {
                    if ((Frag->atomList[mapList[0]])->nH == 1) {
                        Flag[mapList[0]] = 1;
                        Flag[mapList[2]] = 1;
                        Flag[mapList[3]] = 1;
                        Flag[mapList[4]] = 1;
                        std::vector<int> negAtomList;
                        negAtomList.push_back(mapList[0]);
                        negAtomList.push_back(mapList[2]);
                        negAtomList.push_back(mapList[3]);
                        negAtomList.push_back(mapList[4]);
                        getChargePharmaPoints(Frag, 5, negAtomList, NEG);
                        negAtomList.clear();
                    }
                }
            }
        }
    }
    for (int i = 0; i < nAtoms; i++) {
        Atom = Frag->atomList[i];
        // Positive charges not adjacent to a negative charge
        if (Flag[i] == 0 && Atom->FormalCharge < 0) {
            bool isPos = false;
            for (int k = 0; k < Atom->nBonds; k++) {
                if ((Frag->atomList[Atom->atomList[k]])->FormalCharge < 0) {
                    isPos = true;
                    break;
                }
            }
            if (isPos) continue;
            std::vector<int> negAtomList;
            negAtomList.push_back(i);
            getChargePharmaPoints(Frag, 5, negAtomList, NEG);
            negAtomList.clear();
        }
    }
    for (int i = 0; i < nFrags; i++) delete excludeGroups[i];
}

void mapHYD(MFCFrag* Frag, std::vector<PharmaFeature*>& HYD) {
    // calculate the hydrophobicity of each atom

    int nAtoms = Frag->numAtoms;
    double* atomSASA = new double[nAtoms];
    double* atomTopoTerm = new double[nAtoms];
    double* HYValue = new double[nAtoms];
    calTopoTerm(Frag, atomTopoTerm);
    int* mark = new int[nAtoms];
    for (int i = 0; i < nAtoms; i++) {
        mark[i] = 0;
        // if atomTopoTerm = 0, no need to calculate the atomSASA;use default value 0;
        if (atomTopoTerm[i] == 0) {
            atomSASA[i] = 0;
            HYValue[i] = 0;
            continue;
        }
        //atomSASA[i] = calSASA_SIMD(Frag, i, true);
        atomSASA[i] = calSASA(Frag, i, true);
        HYValue[i] = atomSASA[i] * atomTopoTerm[i];
    }

    // Print the atom SASA and topoterm
    /*
       std::cout<<"Atom\tatomicNumber\ttopot\tatomSASA\tHYValue\n";
       MFCAtom* Atom;
       for(int i=0;i<nAtoms;i++){
          Atom = Frag->atomList[i];
          std::cout<<i+1<<"\t"<<Atom->atomicNumber<<"\t"<<atomTopoTerm[i]<<"\t"<<atomSASA[i]<<"\t"<<HYValue[i]<<"\n";
       }
    */

    // 1.Define groups for rings of size 7 or less

    MFCRing* Ring;
    int ringCount = Frag->ringCount;
    for (int i = 0; i < ringCount; i++) {
        Ring = Frag->ringList[i];
        int ringSize = Ring->ringAtomList.size();
        if (ringSize > 7) continue;
        double sumHY = 0;
        for (int j = 0; j < ringSize; j++) {
            mark[Ring->ringAtomList[j]] = 1;
            sumHY += HYValue[Ring->ringAtomList[j]];
        }
        if (sumHY > 9.87) getHYDPharmaPoints(Frag, Ring->ringAtomList, HYValue, sumHY, HYD);
    }

    // 2.Define groups for atoms with three or more bonds.
    //  Atom with three or more bonds and those of its neighbors that are not bonded to any other
    //  atom

    MFCAtom* Atom1;
    MFCAtom* Atom2;
    for (int i = 0; i < nAtoms; i++) {
        if (mark[i] == 1) continue;
        Atom1 = Frag->atomList[i];
        int nBonds = Atom1->nBonds;
        if (nBonds >= 3) {
            int count = 0;
            for (int j = 0; j < nBonds; j++) {
                Atom2 = Frag->atomList[Atom1->atomList[j]];
                // check if Atom2 is terminal atom
                if ((Atom2->nBonds - Atom2->nH == 1) || Atom2->atomicNumber == 1) {
                    count++;
                }
            }
            if (count < nBonds - 1) continue;
            double sumHY = HYValue[i];
            std::vector<int> hydAtom;
            hydAtom.push_back(i);
            mark[i] = 1;
            for (int j = 0; j < nBonds; j++) {
                int neiborID = Atom1->atomList[j];
                if (HYValue[neiborID] > 0 && mark[neiborID] == 0) {
                    sumHY += HYValue[neiborID];
                    hydAtom.push_back(neiborID);
                    mark[neiborID] = 1;
                }
            }
            if (hydAtom.size() == 2) {
                Atom2 = Frag->atomList[hydAtom[1]];
                int nnBonds = Atom2->nBonds;
                for (int j = 0; j < nnBonds; j++) {
                    int neiborID = Atom2->atomList[j];
                    if (HYValue[neiborID] > 0 && mark[neiborID] == 0) {
                        sumHY += HYValue[neiborID];
                        hydAtom.push_back(neiborID);
                        mark[neiborID] = 1;
                    }
                }
            }
            if (sumHY > 9.87) getHYDPharmaPoints(Frag, hydAtom, HYValue, sumHY, HYD);
        }
    }

    // 3. Define chain group

    for (int i = 0; i < nAtoms; i++) {
        if (mark[i] == 1 || HYValue[i] == 0) continue;
        Atom1 = Frag->atomList[i];
        int nBonds = Atom1->nBonds;
        double sumHY = HYValue[i];
        std::vector<int> hydAtom;
        hydAtom.push_back(i);
        mark[i] = 1;
        for (int j = 0; j < nBonds; j++) {
            int neiborID = Atom1->atomList[j];
            if (mark[neiborID] == 0 && HYValue[neiborID] > 0) {
                sumHY += HYValue[neiborID];
                hydAtom.push_back(neiborID);
                mark[neiborID] = 1;
            }
        }
        if (hydAtom.size() == 2) {
            Atom2 = Frag->atomList[hydAtom[1]];
            int nnBonds = Atom2->nBonds;
            for (int j = 0; j < nnBonds; j++) {
                int neiborID = Atom2->atomList[j];
                if (HYValue[neiborID] > 0 && mark[neiborID] == 0) {
                    sumHY += HYValue[neiborID];
                    hydAtom.push_back(neiborID);
                    mark[neiborID] = 1;
                }
            }
        }
        if (sumHY > 9.87) getHYDPharmaPoints(Frag, hydAtom, HYValue, sumHY, HYD);
    }
    delete[] atomSASA;
    delete[] atomTopoTerm;
    delete[] HYValue;
    delete[] mark;
}
//
// map all the features
//
void mapAllFeatures(MFCFrag* Frag, std::vector<PharmaFeature*>& ALL) {
    mapHBA(Frag, ALL);
    mapHBD(Frag, ALL);
    mapARO(Frag, ALL);
    mapPOS(Frag, ALL);
    mapNEG(Frag, ALL);
    mapHYD(Frag, ALL);
    std::cout << "Print All Features\n";
    printFeature(ALL);
}
//
// print the Feature
//
void printFeature(std::vector<PharmaFeature*>& pf) {
    int nFeatures = pf.size();
    std::cout << "Total Features = " << nFeatures << "\n";
    for (int i = 0; i < nFeatures; i++) {
        std::cout << "\n***fType = " << pf[i]->fType << "\tnSpheres = " << pf[i]->nSpheres << "\t";
        int nAtoms = (pf[i]->atomList).size();
        std::cout << "Feature Atoms: ";
        for (int j = 0; j < nAtoms; j++) {
            if (j == nAtoms - 1)
                std::cout << pf[i]->atomList[j] + 1 << "\n";
            else
                std::cout << pf[i]->atomList[j] + 1 << "\t";
        }
        std::cout.width(8);
        std::cout.precision(4);
        std::cout << pf[i]->x1 << "\t" << pf[i]->y1 << "\t" << pf[i]->z1 << "\t" << pf[i]->r1
                  << "\n";
        if (pf[i]->fType == 1 || pf[i]->fType == 2 || pf[i]->fType == 3) {
            std::cout.width(8);
            std::cout.precision(4);
            std::cout << pf[i]->x2 << "\t" << pf[i]->y2 << "\t" << pf[i]->z2 << "\t" << pf[i]->r2
                      << "\n";
        }
    }
}
//
// This function is used to generate the input file
// (hypoedit_input.txt)for generate pharmacophore file (chm)in DS
//
void genChmFile(std::vector<PharmaFeature*>& pf, char* name) {
    std::ofstream fout(name);
    fout << "-dict Dictionary.chm \\\n";
    int nFeatures = pf.size();
    for (int i = 0; i < nFeatures; i++) {
        if (pf[i]->fType == 1)
            fout << "-feat \"HB_ACCEPTOR\" \\\n";
        else if (pf[i]->fType == 2)
            fout << "-feat \"HB_DONOR\" \\\n";
        else if (pf[i]->fType == 3)
            fout << "-feat \"RING_AROMATIC\" \\\n";
        else if (pf[i]->fType == 4)
            fout << "-feat \"POS_CHARGE\" \\\n";
        else if (pf[i]->fType == 5)
            fout << "-feat \"NEG_CHARGE\" \\\n";
        else if (pf[i]->fType == 6)
            fout << "-feat \"HYDROPHOBIC\" \\\n";
        else {
            std::cout << "error in fType in genChmFile function!\n";
            return;
        }
    }
    for (int i = 0; i < nFeatures; i++) {
        if (pf[i]->nSpheres == 1)
            fout << "-blobn " << pf[i]->x1 * 100 << " " << pf[i]->y1 * 100 << " " << pf[i]->z1 * 100
                 << " " << pf[i]->r1 << " \\\n";
        if (pf[i]->nSpheres == 2) {
            fout << "-blobn " << pf[i]->x1 * 100 << " " << pf[i]->y1 * 100 << " " << pf[i]->z1 * 100
                 << " " << pf[i]->r1 << " \\\n";
            fout << "-blobn " << pf[i]->x2 * 100 << " " << pf[i]->y2 * 100 << " " << pf[i]->z2 * 100
                 << " " << pf[i]->r2 << " \\\n";
        }
    }
    fout << name << ".chm\n";
    fout.close();
}
//
// This function used to generate the chm file
//
void genChmFile1(std::vector<PharmaFeature*>& pf) {
    std::ofstream fout("out.chm");
    fout << "QUERY hypo\n{\n";
    // HBA
    std::ifstream fin("ChmTemplate.txt");
    if (!fin) std::cout << "error\n";
    std::string tem, str, hba, hbd, aro, pos, neg, hyd;
    while (getline(fin, tem)) {
        if (tem.find("$$$$hba_template_begain") != std::string::npos) {
            while (getline(fin, tem)) {
                if (tem.find("$$$$hba_template_end") == 0) break;
                hba.append(tem);
                hba.append("\n");
            }
        }
        if (tem.find("$$$$hbd_template_begain") != std::string::npos) {
            while (getline(fin, tem)) {
                if (tem.find("$$$$hbd_template_end") == 0) break;
                hbd.append(tem);
                hbd.append("\n");
            }
        }
    }

    int nFeatures = pf.size();
    int count1 = 0, count2 = 0, count3 = 0, count4 = 0, count5 = 0, count6 = 0;
    for (int i = 0; i < nFeatures; i++) {
        if (pf[i]->fType == 1) {
            std::string thba = hba;
            count1++;
            char a1[5], a2[5], x1[5], y1[5], z1[5], x2[5], y2[5], z2[5];
            sprintf(a1, "%d", count1);
            sprintf(a2, "%d", i + 1);
            sprintf(x1, "%lf", pf[i]->x1 * 100);
            sprintf(y1, "%lf", pf[i]->y1 * 100);
            sprintf(z1, "%lf", pf[i]->z1 * 100);
            sprintf(x2, "%lf", pf[i]->x2 * 100);
            sprintf(y2, "%lf", pf[i]->y2 * 100);
            sprintf(z2, "%lf", pf[i]->z2 * 100);
            while (thba.find("[") != std::string::npos) {
                if (thba.find("[ID]") != std::string::npos) thba.replace(thba.find("[ID]"), 4, a1);
                if (thba.find("[X1]") != std::string::npos) thba.replace(thba.find("[X1]"), 4, x1);
                if (thba.find("[Y1]") != std::string::npos) thba.replace(thba.find("[Y1]"), 4, y1);
                if (thba.find("[Z1]") != std::string::npos) thba.replace(thba.find("[Z1]"), 4, z1);
                if (thba.find("[X2]") != std::string::npos) thba.replace(thba.find("[X2]"), 4, x2);
                if (thba.find("[Y2]") != std::string::npos) thba.replace(thba.find("[Y2]"), 4, y2);
                if (thba.find("[Z2]") != std::string::npos) thba.replace(thba.find("[Z2]"), 4, z2);
            }
            std::cout << thba;
            fout << thba;
        } else if (pf[i]->fType == 2) {
            std::string thba = hbd;
            count2++;
            char a1[5], a2[5], x1[5], y1[5], z1[5], x2[5], y2[5], z2[5];
            sprintf(a1, "%d", count2);
            sprintf(a2, "%d", i + 1);
            sprintf(x1, "%lf", pf[i]->x1 * 100);
            sprintf(y1, "%lf", pf[i]->y1 * 100);
            sprintf(z1, "%lf", pf[i]->z1 * 100);
            sprintf(x2, "%lf", pf[i]->x2 * 100);
            sprintf(y2, "%lf", pf[i]->y2 * 100);
            sprintf(z2, "%lf", pf[i]->z2 * 100);
            while (thba.find("[") != std::string::npos) {
                if (thba.find("[CID]") != std::string::npos)
                    thba.replace(thba.find("[CID]"), 5, a2);
                if (thba.find("[ID]") != std::string::npos) thba.replace(thba.find("[ID]"), 4, a1);
                if (thba.find("[X1]") != std::string::npos) thba.replace(thba.find("[X1]"), 4, x1);
                if (thba.find("[Y1]") != std::string::npos) thba.replace(thba.find("[Y1]"), 4, y1);
                if (thba.find("[Z1]") != std::string::npos) thba.replace(thba.find("[Z1]"), 4, z1);
                if (thba.find("[X2]") != std::string::npos) thba.replace(thba.find("[X2]"), 4, x2);
                if (thba.find("[Y2]") != std::string::npos) thba.replace(thba.find("[Y2]"), 4, y2);
                if (thba.find("[Z2]") != std::string::npos) thba.replace(thba.find("[Z2]"), 4, z2);
            }
            std::cout << thba;
            fout << thba;
        }
    }
    // std::cout<<"HBA:\n"<<hba<<"\nHBD:\n"<<hbd;
}

std::string strhashing(std::string s) {
    char buff[25];
    unsigned long long h = 0;
    int n = s.length();
    for (int i = 0; i < n; i++) {
        h = long(31) * h + (long)s[i];
    }
    printf("Hex format=%16llx\n", h);
    sprintf(buff, "%16llx", h);
    std::cout << "string hass = " << buff << "\n";

    return std::string(buff);
}

void getAtomBondList(MFCFrag* Frag) {
    int nAtoms = Frag->numAtoms;
    int nBonds = Frag->numBonds;
    int atom0;
    int atom1;
    int AList[100];
    int nList = 0;
    MFCAtom* Atom;
    MFCBond* Bond;

    // Print atom's neighbors
    for (int i = 0; i < nAtoms; i++) {
        Atom = Frag->atomList[i];
        int nABonds = Atom->nBonds;
        atom0 = Atom->AIdx;
        printf("NAtoms = %d,%d,", nABonds + 1, atom0);
        for (int j = 0; j < nABonds; j++) {
            Bond = Frag->bondList[Atom->bondList[j]];
            atom1 = findOtherBondAtom(Bond, atom0);
            printf("%d,", atom1);
        }
        printf("\n");
    }

    // Print bond's neighbors
    for (int i = 0; i < nBonds; i++) {
        Bond = Frag->bondList[i];
        atom0 = Bond->atom1;
        Atom = Frag->atomList[atom0];
        AList[nList++] = atom0;
        int nABonds = Atom->nBonds;
        printf("NAtoms = %d,%d,", nABonds + 1, atom0);
        for (int j = 0; j < nABonds; j++) {
            Bond = Frag->bondList[Atom->bondList[j]];
            atom1 = findOtherBondAtom(Bond, atom0);
            AList[nList++] = atom1;
            printf("%d,", atom1);
        }
        atom0 = Bond->atom2;
        Atom = Frag->atomList[atom0];
        nABonds = Atom->nBonds;
        printf("NAtoms = %d,%d,", nABonds + 1, atom0);
        for (int j = 0; j < nABonds; j++) {
            Bond = Frag->bondList[Atom->bondList[j]];
            atom1 = findOtherBondAtom(Bond, atom0);
            // Check uniqueness of list
            bool inList = false;
            for (int k = 0; k < nList; k++) {
                if (atom1 == AList[k]) inList = true;
            }
            if (!inList) {
                AList[nList++] = atom1;
                printf("%d,", atom1);
            }
        }
        printf("BondAtoms = %d,%d,", i + 1, nList);
        for (int j = 0; j < nList; j++) {
            printf("%d,", AList[j]);
        }
        printf("\n");
    }
}
void genVB2000Inputs(MFCFrag* Frag) {
    int nAtoms = Frag->numAtoms;
    int nBonds = Frag->numBonds;
    int atom0;
    int atom1;
    int atom2;
    int AList[100];
    int nList = 0;
    int nE = 0;
    int nLMO = 0;
    MFCAtom* Atom;
    MFCBond* Bond;

    for (int i = 0; i < nAtoms; i++) {
        Atom = Frag->atomList[i];
        nE += Atom->atomicNumber;
    }

    nLMO = nE / 2;
    // Print VB2000 input
    printf("#! VB(%d)/6-31G TEST PRINTALL\n", nE);
    printf("\nAutomatically generated input\n");
    printf("\n0 1\n");

    for (int i = 0; i < nAtoms; i++) {
        Atom = Frag->atomList[i];
        printf("%d %10.5lf %10.5lf %10.5lf\n", Atom->atomicNumber, Atom->x, Atom->y, Atom->z);
    }
    printf("\n");
    printf(" $GRPDIM\n %d\n", nLMO);
    // Print atom's neighbors
    printf("Heavy atom neighbors\n");
    for (int i = 0; i < nAtoms; i++) {
        Atom = Frag->atomList[i];
        if (Atom->atomicNumber > 2) {
            int nABonds = Atom->nBonds;
            atom0 = Atom->AIdx;
            printf("NAtoms = %d,%d", nABonds + 1, atom0 + 1);
            for (int j = 0; j < nABonds; j++) {
                Bond = Frag->bondList[Atom->bondList[j]];
                atom1 = findOtherBondAtom(Bond, atom0);
                printf(",%d", atom1 + 1);
            }
            printf("\n");
        }
    }
    // Print bond's neighbors
    printf("Bond neighbors\n");
    for (int i = 0; i < nBonds; i++) {
        nList = 0;
        Bond = Frag->bondList[i];
        atom1 = Bond->atom1;
        atom2 = Bond->atom2;
        printf("Bond:%d-%d\n", Bond->atom1 + 1, Bond->atom2 + 1);
        Atom = Frag->atomList[atom1];
        AList[nList++] = atom1 + 1;
        int nABonds = Atom->nBonds;
        for (int j = 0; j < nABonds; j++) {
            Bond = Frag->bondList[Atom->bondList[j]];
            atom0 = findOtherBondAtom(Bond, atom1);
            AList[nList++] = atom0 + 1;
        }
        Atom = Frag->atomList[atom2];
        nABonds = Atom->nBonds;
        for (int j = 0; j < nABonds; j++) {
            Bond = Frag->bondList[Atom->bondList[j]];
            atom0 = findOtherBondAtom(Bond, atom2);
            // Check uniqueness of list
            bool inList = false;
            for (int k = 0; k < nList; k++) {
                if (atom0 + 1 == AList[k]) inList = true;
            }
            if (!inList) {
                AList[nList++] = atom0 + 1;
            }
        }
        printf("%d,%d", i + 1, nList);
        for (int j = 0; j < nList; j++) {
            printf(",%d", AList[j]);
        }
        printf("\n");
    }
}

//
// set ring flags for bonds
//
void setRingBondFlags(MFCFrag* frag) {
    // set ring flags for bonds
    int nBonds = frag->bondList.size();
    for (int i = 0; i < nBonds; i++) {
        setRingBondFlags(frag, i);
    }
}

void setRingBondFlags(MFCFrag* frag, int Bid) {
    int nRings =
        frag->ringList.size();  // for Scaffold Hunter, must use ringList.size() instead of numRings
    MFCRing* ring;
    int j, r;
    int ringSize;
    MFCAtom* atom1;
    MFCAtom* atom2;

    // set ring flags for bonds
    MFCBond* bond;
    bond = frag->bondList[Bid];
    if (0 == bond) return;

    bond->ringBondFlag = 0;
    bond->aromaticFlag = 0;
    atom1 = frag->atomList[bond->atom1];
    atom2 = frag->atomList[bond->atom2];
    if (atom1->ringAtomFlag >= 1 && atom2->ringAtomFlag >= 1)  //  ring atoms
    {
        int flag = 0;
        for (r = 0; r < nRings; r++) {
            flag = 0;
            ring = frag->ringList[r];
            if (0 == ring) continue;

            ringSize = ring->ringSize;
            for (j = 0; j < ringSize; j++) {
                if (bond->atom1 == ring->ringAtomList[j] || bond->atom2 == ring->ringAtomList[j])
                    flag++;
            }
            if (2 == flag) {  // in the same ring
                bond->ringBondFlag = 1;
                // aromatic flag for bond
                bond->aromaticFlag |= ring->aromaticity;
            }
        }
    }
    if (1 == bond->aromaticFlag) {
        bond->bondType = 4;
        bond->bondOrder = 400;
    }
}

}  // namespace MISS
