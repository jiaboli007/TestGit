#ifndef mfcUtil_h
#define mfcUtil_h
/******************************************************************************
 *                                                                             *
 *    Catagory:   Molecule Foundation Classes (MFC)                            *
 *    Function:   MFC Utilities                                                *
 *    Author:     James Li                                                     *
 *    Date:       March, 2011                                                  *
 *                                                                             *
 ******************************************************************************/
#include <fstream>
#include <functional>
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <string_view>
#include <vector>

#include <boost/algorithm/string.hpp>
#include <boost/iostreams/device/mapped_file.hpp>
#include <boost/iostreams/filtering_streambuf.hpp>

#include "MolStructure/mfcAtom.h"
#include "MolStructure/mfcBond.h"
#include "MolStructure/mfcMolecule.h"
#include "MolStructure/stereo.h"
#include "mathUtil.hpp"

namespace MISS {

template <typename T>
struct scope_exit {
    scope_exit(T&& t) : t_{std::move(t)} {}
    ~scope_exit() { t_(); }
    T t_;
};

// Forward declaration
class MFCFFFrag;

Molecule* convertFragToMol(MFCFrag* inFrag);

// SD file reader. This reader returns a molecule object (fragment) for each
// call.
template <typename iFileLikeStream>
class SDReaderT {
public:
    SDReaderT() = default;

    template <typename... Ts>
    void open(Ts&&... args) {
        fin.open(std::forward<Ts>(args)...);
    }

    template <typename... Ts>
    explicit SDReaderT(Ts&&... args) {
        fin.open(std::forward<Ts>(args)...);
    }

    template <typename T>
    requires std::is_same_v<iFileLikeStream, std::istream>
    explicit SDReaderT(T& in) : fin(&in) {}

    Molecule* readMolecule();
    MFCFrag* readLargestMFCFrag();
    // Notes: James Li, June 2011
    // This a temp function for force field development.
    // A MFCFrag with force field parameters initialized from the input
    // SD file's property field. We will revisit this part at a later time
    // for force field.
    MFCFFFrag* readMFCFFFrag();

    void readSDProperties(MFCFrag* Frag);

    bool endOfSD();
    long getfpos();
    void resetfpos();
    void seekfpos(long fpos);

    iFileLikeStream fin;
    MFCFrag* readSDF(bool& isFlat);
};

using SDReader = SDReaderT<std::ifstream>;

class iStringFileStream : public std::istringstream {
public:
    void open(const string& content, ios_base::openmode = ios_base::in) { str(content); }
    bool is_open() const { return true; }
    void close() const {}
};

}  // namespace MISS

class MMapStream {
public:
    void open(boost::iostreams::mapped_file_source::iterator b,
              boost::iostreams::mapped_file_source::iterator e) {
        this->begin = b;
        this->cursor = b;
        this->end = e;
    }
    bool is_open() { return true; }
    bool eof() { return cursor >= end; }
    auto tellg() { return cursor - begin; }

    auto get_cursor() { return cursor; }

    bool fail() { return failed; }

    operator bool() { return is_open() and !eof() and !fail(); }
    void clear() { failed = false; }
    void seekg(long offset) { cursor = begin + offset; }

    std::string_view getline() {
        if (eof() or !is_open()) {
            failed = true;
            return {};
        }
        auto it = find_if(cursor, end, boost::is_any_of("\n"));
        std::string_view view(cursor, it - cursor);

        cursor = it + 1;

        return view;
    }

    bool failed = false;

private:
    boost::iostreams::mapped_file_source::iterator begin, cursor, end;
};
namespace std {

inline MMapStream& getline(MMapStream& s, std::string& str) {
    if (s.eof()) {
        s.failed = true;
        return s;
    }
    str = s.getline();
    return s;
}

inline MMapStream& getline(MMapStream& s, std::string_view& str) {
    if (s.eof()) {
        s.failed = true;
        return s;
    }
    str = s.getline();
    return s;
}
}  // namespace std

namespace MISS {
template <typename iFileLikeStream>
void skip2MolEnd(iFileLikeStream& fin) {
    std::string tmpstr;
    //
    // Skip to the end of mol
    //
    do {
        std::getline(fin, tmpstr);
    } while (tmpstr.substr(0, 4) != std::string("$$$$") && !fin.eof());
}

int ijx(int a, int b);
// IO
MFCFrag* readSD2MFCFrag(const char* filename);
MFCFrag* mergeMFCFrags(MFCFrag* FragA, MFCFrag* FragB, int link1, int link2);
void printMFCFrag(MFCFrag* Frag);
void writeMFCFrag2SD(MFCFrag* Frag, std::ostream& fout, bool onlyHeavyAtoms = false);
void writeMFCFrag2SDX(MFCFrag* Frag, std::ostream& fout);
void writeMFCConf2SD(MFCFrag* Frag, double* xyz, std::ostream& fout, int* map = 0);
void writeMFCConf2SD_HA(MFCFrag* Frag, double* xyz, std::ostream& fout, int* map = 0);

//
// for scaffold hunter
// number of atoms is equal to the size of atomList, not the numAtoms
//
void writeMFCFrag2SD_SH(MFCFrag* Frag, std::ostream& fout);
void writeMFCConf2SD_SH(MFCFrag* Frag, double* xyz, std::ostream& fout, int* mapx);

std::string ElementSymbol(int atomicNumber);

int getNSpheres(MFCFrag* frag, bool onlyHeavyAtoms);
int getFragXYZ(MFCFrag* frag, double* xyz, bool onlyHeavyAtoms = false);
int getFragXYZVDWR(MFCFrag* frag, double* xyz, double* vdwR, bool onlyHeavyAtoms = false,
                   bool equalR = false);

void setFragXYZ(MFCFrag* frag, double* xyz, bool onlyHeavyAtoms = false);
void setFragnH(MFCFrag* frag);

double calSASA(MFCFrag* Frag, int Idx, bool isArea);
double calSASA_SIMD(MFCFrag* Frag, int Idx, bool isArea);

std::string strhashing(std::string s);
void getAtomBondList(MFCFrag* frag);
void genVB2000Inputs(MFCFrag* frag);
// For pharmacophore feature mapping
struct PharmaFeature {
    int fType;  // 1=HBA,2=HBD,3=ARO,4=POS,5=NEG,6=HYD
    // char fName[3];
    std::vector<int> atomList;
    int nSpheres;
    double x1, y1, z1, r1;
    double x2, y2, z2, r2;
};

void getChargePharmaPoints(MFCFrag* Frag, int fType, std::vector<int>& Idx,
                           std::vector<PharmaFeature*>& Charge);

bool hasDoubleBond(MFCFrag* frag, int Idx);

void mapHBA(MFCFrag* Frag, std::vector<PharmaFeature*>& HBA);
void mapHBD(MFCFrag* Frag, std::vector<PharmaFeature*>& HBD);
void mapARO(MFCFrag* Frag, std::vector<PharmaFeature*>& ARO);
void mapPOS(MFCFrag* Frag, std::vector<PharmaFeature*>& POS);
void mapNEG(MFCFrag* Frag, std::vector<PharmaFeature*>& NEG);
void mapHYD(MFCFrag* Frag, std::vector<PharmaFeature*>& HYD);
void mapAllFeatures(MFCFrag* Frag, std::vector<PharmaFeature*>& ALL);
void printFeature(std::vector<PharmaFeature*>& pf);
void genChmFile(std::vector<PharmaFeature*>& pf, char* name);
void genChmFile1(std::vector<PharmaFeature*>& pf);

void getHBPharmaPoints(MFCFrag* Frag, int fType, int fIdx, std::vector<PharmaFeature*>& HB);

// set ringFlag for all bonds in molecule
// should be called after calling setRingAtomFlags(MFCFrag* Frag);
void setRingBondFlags(MFCFrag* frag);
void setRingBondFlags(MFCFrag* frag, int Bid);
// function templates
template <class T>
void indice_after_compress(const T& objList, vector<int>& idc) {
    int i, j;
    typename T::const_iterator it;
    idc.clear();
    idc.reserve(objList.size());
    for (j = 0, it = objList.begin(); it != objList.end(); ++it) {
        if (*it)
            idc.push_back(j++);
        else
            idc.push_back(-1);
    }
}
}  // namespace MISS

#endif /* mfcUtil_h */
