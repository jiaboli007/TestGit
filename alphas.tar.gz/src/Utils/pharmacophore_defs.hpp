
#ifndef ALPHACS_PHARMACOPHORE_DEFS_HPP
#define ALPHACS_PHARMACOPHORE_DEFS_HPP

#include <string_view>

extern std::string_view HBA_Exclude_data_str;
extern std::string_view HBD_Exclude_data_str;
extern std::string_view NEG_Included_data_str;
extern std::string_view POS_Included_data_str;

#endif  // ALPHACS_PHARMACOPHORE_DEFS_HPP
