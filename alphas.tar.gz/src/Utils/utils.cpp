#include <boost/filesystem.hpp>
#include <boost/optional.hpp>
#include <boost/range/adaptor/indexed.hpp>
#include <boost/range/algorithm/copy.hpp>

#include "Utils/utils.hpp"

#include "ThirdParty/fast_double_parser.hpp"
#include "Topology/RingDecomposerLib_findSSSR.hpp"
#include "Utils/ProgramConfiguration.hpp"
#include "Utils/pharmacophore_defs.hpp"

namespace MISS::Optimize {

std::vector<std::tuple<std::size_t, std::unique_ptr<GDFSPath>>> read_exclusive_included_graph(
    const std::string& filename, std::string_view data_str) {
    std::vector<std::tuple<std::size_t, std::unique_ptr<GDFSPath>>> paths;
    boost::iostreams::mapped_file_source source;
    SDReaderT<MMapStream> sdReader;
    if (boost::filesystem::exists(filename)) {
        source.open(filename);
        sdReader.open(begin(source), end(source));
    } else {
        sdReader.open(begin(data_str), end(data_str));
    }
    while (!sdReader.endOfSD()) {
        std::unique_ptr<MFCFrag> qFrag{sdReader.readLargestMFCFrag()};
        if (!qFrag) continue;

        findSSSR(qFrag.get());
        setRingAtomFlags(qFrag.get());
        clearringBondMap();
        std::unique_ptr<ChemGraph> graph{Frag2Graph(qFrag.get())};
        std::unique_ptr<GDFSPath> GPath{DFSWalkOnGraph(graph.get())};

        paths.emplace_back(graph->nNodes, std::move(GPath));
    }
    return paths;
}

PharmacophoreGraph load_pharmacophore_graph() {
    if (!program_configuration) program_configuration = std::make_unique<ProgramConfiguration>();
    auto g = [](boost::filesystem::path p) {
        return (program_configuration->get_sd_path() / p).generic_string();
    };

    return {read_exclusive_included_graph(g(HBA_Exclude_FILE), HBA_Exclude_data_str),
            read_exclusive_included_graph(g(HBD_Exclude_FILE), HBD_Exclude_data_str),
            read_exclusive_included_graph(g(POS_Included_FILE), POS_Included_data_str),
            read_exclusive_included_graph(g(NEG_Included_FILE), NEG_Included_data_str)};
}

std::vector<int> BTMappingForPh4_Optimize(GDFSPath* qpath, ChemGraph* tgraph, int Idx) {
    int pathSteps = qpath->getSteps();
    std::vector<int> TNodeList(pathSteps);
    BTPath cpath(pathSteps, tgraph);
    DFSNode* qroot = qpath->dfsNodes[0];
    GNode* troot;
    int tgnodes = tgraph->nNodes;
    int mappedNodes = 0;
    bool status = false;
    int startStep = 1;
    int pathDepth = qroot->DFSDepth;
    cpath.rollBackToStep(0);
    troot = tgraph->nodeList[Idx];
    if (troot->nodeColor != qroot->nodeColor | troot->nConnections < qroot->nConnections) {
        TNodeList.clear();
        return TNodeList;
    }
    cpath.addFirstStep(Idx);
    troot->visited = 1;
    status = BTWalk(qpath, qroot, startStep, pathDepth - 1, tgraph, &cpath, troot);
    if (status) {
        for (int i = 0; i < pathSteps; i++) {
            if (cpath.walk2NewNodes[i] > 0) {
                TNodeList[mappedNodes++] = cpath.stopNodes[i];
            }
        }
    } else {
        TNodeList.clear();
    }
    return TNodeList;
}
std::vector<int> subSearch_Optimize(std::tuple<std::size_t, std::unique_ptr<GDFSPath>>& gpath,
                                    MFCFrag* tfrag, int Idx, ChemGraph* TGraph) {
    if ((tfrag->atomList[Idx])->atomicNumber == 1) {
        // std::cout<<"Only heavy atoms are considered !\n";
        return {};
    }

    int newID[tfrag->numAtoms];
    int heavyAtomCount = 0;
    int oldID[tfrag->numAtoms];
    for (int i = 0; i < tfrag->numAtoms; i++) {
        if (tfrag->atomList[i]->atomicNumber == 1) {
            newID[i] = -1;
            continue;
        }
        newID[i] = heavyAtomCount;
        oldID[heavyAtomCount] = i;
        heavyAtomCount++;
    }

    //
    // Map QGraph to TGraph
    //
    scope_exit reseter([TGraph] {
        for (auto node : TGraph->nodeList) node->visited = 0;
        for (auto edge : TGraph->edgeList) edge->visited = 0;
    });
    int nNodes = std::get<std::size_t>(gpath);
    auto TNodeList = BTMappingForPh4_Optimize(std::get<std::unique_ptr<GDFSPath>>(gpath).get(),
                                              TGraph, newID[Idx]);
    bool isMatch = false;
    std::vector<int> tMapList(nNodes);
    if (!TNodeList.empty()) {
        for (int i = 0; i < nNodes; i++) {
            tMapList[i] = oldID[TNodeList[i]];
        }
        isMatch = true;
    }
    if (isMatch)
        return tMapList;
    else
        return TNodeList;
}
void mapHBA_Optimize(
    MFCFrag* Frag, std::vector<PharmaFeature*>& HBA,
    std::vector<std::tuple<std::size_t, std::unique_ptr<GDFSPath>>>& exclude_group_graph,
    ChemGraph* TGraph) {
    int nAtoms = Frag->numAtoms;

    int Flag[nAtoms];
    for (int i = 0; i < nAtoms; i++) Flag[i] = 0;

    // subSearch N-C=X(X=N,O,S) and N-S=O and flag the mapped N atom
    for (std::size_t i = 0; i < exclude_group_graph.size(); i++) {
        auto& graph = exclude_group_graph[i];
        for (int j = 0; j < nAtoms; j++) {
            if ((Frag->atomList[j])->atomicNumber == 1) continue;
            std::vector<int> mapList = subSearch_Optimize(graph, Frag, j, TGraph);
            if (!mapList.empty()) {
                Flag[mapList[0]] = 1;
            }
        }
    }
    MFCAtom* Atom;
    int Idx;
    for (int i = 0; i < nAtoms; i++) {
        Atom = Frag->atomList[i];
        Idx = Atom->AIdx;
        // For Nitrogen
        if (Atom->atomicNumber == 7 && Atom->FormalCharge <= 0) {
            // 1.exclude -N-C=X but not =N-C=X(X=N,O,S),also exclude -N-S=O
            if (Flag[i] == 1 && Atom->nBonds == 3) continue;
            // 2.exclude N in aromatic ring and has 3 bonds
            if (Atom->aromaticFlag == 1 && Atom->nBonds == 3) continue;
            // 3.exclude N has 3 bonds and connected with aromatic ring
            bool connectAromatic = false;
            if (Atom->nBonds == 3) {
                for (int k = 0; k < 3; k++) {
                    if (Frag->atomList[Atom->atomList[k]]->aromaticFlag == 1) {
                        connectAromatic = true;
                        break;
                    }
                }
            }
            if (connectAromatic) continue;
            // 4.exclude the Basic primary, secondary, and tertiary amines
            if (Atom->nBonds == 3) continue;
            // 5.exclude atoms which  solvent access surface area fraction < 2%
            //if (calSASA_SIMD(Frag, Idx, false) < 0.02) continue;
            if (calSASA(Frag, Idx, false) < 0.02) continue;
            getHBPharmaPoints(Frag, 1, i, HBA);
        }
        // For Oxygen
        else if (Atom->atomicNumber == 8 && Atom->FormalCharge <= 0) {
            //if (calSASA_SIMD(Frag, Idx, false) < 0.02) continue;
            if (calSASA(Frag, Idx, false) < 0.02) continue;
            getHBPharmaPoints(Frag, 1, i, HBA);
        }
        // For Sulfur,S in -SH is HBA as well
        else if (Atom->atomicNumber == 16 && Atom->FormalCharge <= 0 && Atom->hybride == 4) {
            //if (calSASA_SIMD(Frag, Idx, false) < 0.02) continue;
            if (calSASA(Frag, Idx, false) < 0.02) continue;
            getHBPharmaPoints(Frag, 1, i, HBA);
        }
    }
}
void mapHBD_Optimize(
    MFCFrag* Frag, std::vector<PharmaFeature*>& HBD,
    std::vector<std::tuple<std::size_t, std::unique_ptr<GDFSPath>>>& exclude_group_graph,
    ChemGraph* TGraph) {
    int Flag[Frag->numAtoms];
    std::fill_n(Flag, Frag->numAtoms, 0);

    for (std::size_t i = 0; i < exclude_group_graph.size(); i++) {
        auto& graph = exclude_group_graph[i];
        for (int j = 0; j < Frag->numAtoms; j++) {
            if (Frag->atomList[j]->atomicNumber == 1) continue;
            std::vector<int> mapList = subSearch_Optimize(graph, Frag, j, TGraph);

            // exclude protonated pyridines and imidazoles but not exlude unprotonated
            if (!mapList.empty()) {
                if (i == 2 || i == 3) {
                    if (Frag->atomList[mapList[0]]->FormalCharge == 1) Flag[mapList[0]] = 1;
                } else
                    Flag[mapList[0]] = 1;
            }
        }
    }
    for (int i = 0; i < Frag->numAtoms; i++) {
        auto Atom = Frag->atomList[i];
        // For Nitrogen
        if ((Atom->atomicNumber == 7) && (Atom->nH > 0)) {
            // 1.exclude the protonated the N
            if (Atom->FormalCharge > 0) continue;
            // 2.exclude the -NH(trifluoromethyl sulfonamide),tetrazoles, pyridines,imidazoles
            if (Flag[i] == 1) continue;
            getHBPharmaPoints(Frag, 2, i, HBD);
        }
        // For Oxygen
        else if ((Atom->atomicNumber == 8) && (Atom->nH > 0)) {
            if (Atom->FormalCharge < 0) continue;
            // exclude -COOH
            if (Flag[i] == 1) continue;
            getHBPharmaPoints(Frag, 2, i, HBD);
        }
        // For Carbon, acetylenic hydrogens
        else if ((Atom->atomicNumber == 6) && (Atom->nBonds == 2) && (Atom->nH == 1)) {
            getHBPharmaPoints(Frag, 2, i, HBD);
        }
        // For Sulfur (-SH)
        else if ((Atom->atomicNumber == 16) && (Atom->nBonds == 2) && (Atom->nH == 1)) {
            getHBPharmaPoints(Frag, 2, i, HBD);
        }
    }
}
void mapPOS_Optimize(
    MFCFrag* Frag, std::vector<PharmaFeature*>& POS,
    std::vector<std::tuple<std::size_t, std::unique_ptr<GDFSPath>>>& included_group_graph,
    ChemGraph* TGraph) {
    int nAtoms = Frag->numAtoms;
    int Flag[nAtoms];
    for (int i = 0; i < nAtoms; i++) Flag[i] = 0;
    auto& graph0 = included_group_graph[0];  // guanidine
    for (int j = 0; j < nAtoms; j++) {
        if (Frag->atomList[j]->atomicNumber == 1) continue;
        auto mapList = subSearch_Optimize(graph0, Frag, j, TGraph);
        if (!mapList.empty()) {
            std::vector<int> gua;
            Flag[mapList[0]] = 1;
            Flag[mapList[2]] = 1;
            Flag[mapList[3]] = 1;
            gua.push_back(mapList[0]);
            gua.push_back(mapList[2]);
            gua.push_back(mapList[3]);
            getChargePharmaPoints(Frag, 4, gua, POS);
            gua.clear();
        }
    }
    auto& graph1 = included_group_graph[1];  // amidine
    for (int j = 0; j < nAtoms; j++) {
        auto mapList = subSearch_Optimize(graph1, Frag, j, TGraph);
        if (!mapList.empty()) {
            // Exclude the guanidine flagged before
            if (Flag[mapList[0]] == 1 || Flag[mapList[2]] == 1) continue;
            std::vector<int> amidine;
            Flag[mapList[0]] = 1;
            Flag[mapList[2]] = 1;
            // Basic secondary amidines:R-N-C=N
            if ((Frag->atomList[mapList[2]])->nH == 0) {
                amidine.push_back(mapList[0]);
            }
            // Basic primary amidines: R-NH-C=N
            else if ((Frag->atomList[mapList[2]])->nH > 0) {
                amidine.push_back(mapList[0]);
                amidine.push_back(mapList[2]);
            } else {
                std::cout << "error in POS detection!\n";
                exit(0);
            }
            getChargePharmaPoints(Frag, 4, amidine, POS);
        }
    }
    MFCAtom* Atom;
    for (int i = 0; i < nAtoms; i++) {
        Atom = Frag->atomList[i];
        // Positive charges not adjacent to a negative charge
        if (Flag[i] == 0 && Atom->FormalCharge > 0) {
            bool isNeg = false;
            int nBonds = Atom->nBonds;
            for (int k = 0; k < nBonds; k++) {
                if ((Frag->atomList[Atom->atomList[k]])->FormalCharge < 0) {
                    isNeg = true;
                    break;
                }
            }
            if (isNeg) continue;
            std::vector<int> posAtomList;
            posAtomList.push_back(Atom->AIdx);
            getChargePharmaPoints(Frag, 4, posAtomList, POS);
            posAtomList.clear();
        }
        // Basic primary, secondary, and tertiary amines
        else if (Flag[i] == 0 && Atom->atomicNumber == 7 && Atom->nBonds == 3) {
            // exclude the N in aromatic ring
            if (Atom->aromaticFlag == 1) continue;
            // Exclude the N attached with atoms which have double bonds or have aromatic
            bool isDouble = false;
            for (int k = 0; k < 3; k++) {
                int j = Frag->atomList[i]->atomList[k];
                if (hasDoubleBond(Frag, j)) {
                    isDouble = true;
                    break;
                }
            }
            if (isDouble == true) continue;
            std::vector<int> posAtomList;
            posAtomList.push_back(Atom->AIdx);
            getChargePharmaPoints(Frag, 4, posAtomList, POS);
            posAtomList.clear();
        }
    }
}
void mapNEG_Optimize(
    MFCFrag* Frag, std::vector<PharmaFeature*>& NEG,
    std::vector<std::tuple<std::size_t, std::unique_ptr<GDFSPath>>>& included_group_graph,
    ChemGraph* TGraph) {
    int nAtoms = Frag->numAtoms;
    int Flag[nAtoms];
    for (int i = 0; i < nAtoms; i++) Flag[i] = 0;
    MFCAtom* Atom;
    for (std::size_t i = 0; i < included_group_graph.size(); i++) {
        auto& graph = included_group_graph[i];
        if (i == 0) {  // For Trifluoromethyl sulfonamide hydrogens
            for (int j = 0; j < nAtoms; j++) {
                auto mapList{subSearch_Optimize(graph, Frag, j, TGraph)};
                if (!mapList.empty()) {
                    if (Frag->atomList[mapList[0]]->nH != 1) continue;
                    Flag[mapList[0]] = 1;
                    std::vector<int> negAtomList;
                    negAtomList.push_back(mapList[0]);
                    getChargePharmaPoints(Frag, 5, negAtomList, NEG);
                    negAtomList.clear();
                }
            }
        }
        // Sulfonic acids (centroid of the three oxygens)
        else if (i == 1) {
            for (int j = 0; j < nAtoms; j++) {
                auto mapList{subSearch_Optimize(graph, Frag, j, TGraph)};
                if (!mapList.empty()) {
                    if ((Frag->atomList[mapList[3]])->nH == 1) {
                        Flag[mapList[1]] = 1;
                        Flag[mapList[2]] = 1;
                        Flag[mapList[3]] = 1;
                        std::vector<int> negAtomList;
                        negAtomList.push_back(mapList[1]);
                        negAtomList.push_back(mapList[2]);
                        negAtomList.push_back(mapList[3]);
                        getChargePharmaPoints(Frag, 5, negAtomList, NEG);
                        negAtomList.clear();
                    }
                }
            }
        }
        // Phosphonic acids (centroid of the three oxygens)
        else if (i == 2) {
            for (int j = 0; j < nAtoms; j++) {
                auto mapList{subSearch_Optimize(graph, Frag, j, TGraph)};
                if (!mapList.empty()) {
                    std::vector<int> negAtomList;
                    if ((Frag->atomList[mapList[2]])->nH == 1) {
                        Flag[mapList[2]] = 1;
                        negAtomList.push_back(mapList[2]);
                    }
                    if ((Frag->atomList[mapList[3]])->nH == 1) {
                        Flag[mapList[3]] = 1;
                        negAtomList.push_back(mapList[3]);
                    }
                    if (negAtomList.size() > 0) {
                        negAtomList.push_back(mapList[1]);
                        getChargePharmaPoints(Frag, 5, negAtomList, NEG);
                        negAtomList.clear();
                    }
                }
            }
        }
        // Sulfinic, carboxylic, or phosphinic acids (centroid of the two oxygens)
        else if (i > 2 && i < 6) {
            for (int j = 0; j < nAtoms; j++) {
                auto mapList{subSearch_Optimize(graph, Frag, j, TGraph)};
                if (!mapList.empty()) {
                    if ((Frag->atomList[mapList[2]])->nH == 1) {
                        // Exclude the above situation
                        if (Flag[mapList[1]] == 1 || Flag[mapList[2]] == 1) continue;
                        Flag[mapList[1]] = 1;
                        Flag[mapList[2]] = 1;
                        std::vector<int> negAtomList;
                        negAtomList.push_back(mapList[1]);
                        negAtomList.push_back(mapList[2]);
                        getChargePharmaPoints(Frag, 5, negAtomList, NEG);
                        negAtomList.clear();
                    }
                }
            }
        }
        // For Tetrazoles,the H is required
        else if (i == 6) {
            for (int j = 0; j < nAtoms; j++) {
                auto mapList{subSearch_Optimize(graph, Frag, j, TGraph)};
                if (!mapList.empty()) {
                    if ((Frag->atomList[mapList[0]])->nH == 1) {
                        Flag[mapList[0]] = 1;
                        Flag[mapList[2]] = 1;
                        Flag[mapList[3]] = 1;
                        Flag[mapList[4]] = 1;
                        std::vector<int> negAtomList;
                        negAtomList.push_back(mapList[0]);
                        negAtomList.push_back(mapList[2]);
                        negAtomList.push_back(mapList[3]);
                        negAtomList.push_back(mapList[4]);
                        getChargePharmaPoints(Frag, 5, negAtomList, NEG);
                        negAtomList.clear();
                    }
                }
            }
        }
    }
    for (int i = 0; i < nAtoms; i++) {
        Atom = Frag->atomList[i];
        // Positive charges not adjacent to a negative charge
        if (Flag[i] == 0 && Atom->FormalCharge < 0) {
            bool isPos = false;
            for (int k = 0; k < Atom->nBonds; k++) {
                if ((Frag->atomList[Atom->atomList[k]])->FormalCharge < 0) {
                    isPos = true;
                    break;
                }
            }
            if (isPos) continue;
            std::vector<int> negAtomList;
            negAtomList.push_back(i);
            getChargePharmaPoints(Frag, 5, negAtomList, NEG);
            negAtomList.clear();
        }
    }
}

AS::Molecule::Conformation transform_to_conf(MFCFrag* frag, PharmacophoreGraph& pharmacophore,
                                             bool getW, bool initR) {
    AS::Molecule::Conformation conf;

    int nSpheres = getNSpheres(frag, onlyHeavyAtoms);
    setMFCAtomVDW(frag);

    RingDecomposerLib_findSSSR(frag);
    //
    // Find aromatic rings
    //
    setRingAtomFlags(frag);

    setHybridization(frag);
    clearringBondMap();
    //
    // Set ideal bond length according to atom and bond type
    //
    SetBondLength(frag);
    setFragnH(frag);

    double xyz[nSpheres * 3];
    double vdwR[nSpheres];
    getFragXYZVDWR(frag, xyz, vdwR, onlyHeavyAtoms, true);

    double wt[nSpheres];
    double alpha[nSpheres];
    double gVols[nSpheres * (nSpheres + 1) / 2];
    conf.vol = calMolSelfVolGS(nSpheres, xyz, vdwR, wt, gVols, alpha, getW, true);

    initTransAndRotation(nSpheres, xyz, alpha, wt, gVols, 0, true, initR);

    for (int i = 0; i < nSpheres; i++) {
        float x = xyz[i * 3 + 0];
        float y = xyz[i * 3 + 1];
        float z = xyz[i * 3 + 2];
        conf.coordinates.push_back({x, y, z});
        conf.wt.push_back(wt[i]);
    }

    //
    // get pharma features and calculate self volume of each feature
    //

    std::vector<PharmaFeature*> allFeatures;
    scope_exit deleter([&allFeatures] {
        for (auto feat : allFeatures) {
            delete feat;
        }
    });

    setFragXYZ(frag, xyz, onlyHeavyAtoms);

    std::unique_ptr<ChemGraph> TGraph{Frag2Graph(frag)};
    std::cout << "mapAllFeature_Opt 01\n";
    mapAllFeature_Optimize(frag, allFeatures, pharmacophore, TGraph);

    int numPerF[6];
    for (int i = 0; i < 6; i++) numPerF[i] = 0;

    for (auto feat : allFeatures) {
        numPerF[feat->fType - 1]++;
        conf.pharmaFeatures.push_back({static_cast<float>(feat->x1), static_cast<float>(feat->y1),
                                       static_cast<float>(feat->z1)});
    }

    for (int i = 0; i < 6; i++) {
        conf.pharma_feature_numbers[i] = numPerF[i];
    }

    // save coordinates of dirc spheres after saving that of feat
    // spheres
    for (auto feat : allFeatures) {
        if (4 > feat->fType) {
            conf.pharmaFeatures.push_back({static_cast<float>(feat->x2),
                                           static_cast<float>(feat->y2),
                                           static_cast<float>(feat->z2)});
        }
    }
    double selfVolTmp[10]{};  // selfVol[0] is empty
    calSelfVolFeature_ownPharma(allFeatures, selfVolTmp);

    std::copy(selfVolTmp + 1, std::end(selfVolTmp), conf.selfVol.begin());
    return conf;
}
constexpr auto equalR = true;
constexpr auto initR = true;

int trans_matrix[4][3]{{1, 1, 1}, {-1, -1, 1}, {-1, 1, -1}, {1, -1, -1}};

DBItem DBItem::process_db(unique_ptr<MFCFrag>&& frag, PharmacophoreGraph& pharmacophore) {
    DBItem db;
    setMFCAtomVDW(frag.get());
    RingDecomposerLib_findSSSR(frag);
    //
    // Find aromatic rings
    //
    setRingAtomFlags(frag.get());
    setHybridization(frag.get());
    //
    // Set ideal bond length according to atom and bond type
    //
    SetBondLength(frag.get());
    setFragnH(frag.get());

    db.heavy_atom_number = getNSpheres(frag.get(), onlyHeavyAtoms);
    db.xyz.resize(db.heavy_atom_number * 3);
    double vdwR[db.heavy_atom_number];
    getFragXYZVDWR(frag.get(), db.xyz.data(), vdwR, onlyHeavyAtoms, equalR);

    db.wt.resize(db.heavy_atom_number);
    db.alpha.resize(db.heavy_atom_number);
    double gVols[db.heavy_atom_number * (db.heavy_atom_number + 1) / 2];
    calMolSelfVolGS(db.heavy_atom_number, db.xyz.data(), vdwR, db.wt.data(), gVols, db.alpha.data(),
                    true, equalR);
    double Eout[3];
    initTransAndRotation(db.heavy_atom_number, db.xyz.data(), db.alpha.data(), db.wt.data(), gVols,
                         Eout, equalR, initR);
    //
    // features
    //
    std::vector<PharmaFeature*> allFeatures;
    setFragXYZ(frag.get(), db.xyz.data(), onlyHeavyAtoms);

    std::unique_ptr<ChemGraph> TGraph{Frag2Graph(frag.get())};
    std::cout << "mapAllFeature_Opt 02\n";
    mapAllFeature_Optimize(frag, allFeatures, pharmacophore, TGraph);

    for (auto feat : allFeatures) {
        db.feat_types.push_back(feat->fType);
        db.feat_xyz.push_back(feat->x1);
        db.feat_xyz.push_back(feat->y1);
        db.feat_xyz.push_back(feat->z1);

        if (4 > feat->fType) {
            db.dirc_types.push_back(feat->fType);
            db.dirc_xyz.push_back(feat->x2);
            db.dirc_xyz.push_back(feat->y2);
            db.dirc_xyz.push_back(feat->z2);
        }
    }
    for (auto feat : allFeatures) {
        delete feat;
    }
    db.frag = std::move(frag);
    return db;
}

void overlay(DBItem& db, QueryItem& query, ostream& os) {
    constexpr auto changeCords = true;
    double w1[10]{1.0,
                  1.0,   // HBA in ownPharma
                  1.0,   // HBD
                  0.5,   // ARO
                  2.0,   // POS
                  2.0,   // NEG
                  2.0,   // HYD
                  1.0,   // for direction of HBA in overlay
                  1.0,   // for direction of HBD
                  0.5};  // for direction of ARO

    double cxyz[db.heavy_atom_number * 3];
    double tmpxyz[db.heavy_atom_number * 3];
    double tmpfeatxyz[db.num_feats() * 3];
    double tmpdircxyz[db.num_dircs() * 3];

    auto maxVol = 0.0;

    for (int i = SO1; i < NUM_SO; ++i) {
        double cVol[10];
        boost::copy(db.xyz, tmpxyz);
        boost::copy(db.feat_xyz, tmpfeatxyz);
        boost::copy(db.dirc_xyz, tmpdircxyz);

        auto tmpVol = overlayFGSpheres_ourPharma(
            db.heavy_atom_number, tmpxyz, db.alpha.data(), db.wt.data(), query.heavy_atom_number,
            query.xyz[i].data(), query.alpha.data(), query.weight.data(), db.num_feats(),
            db.feat_types.data(), tmpfeatxyz, db.num_dircs(), db.dirc_types.data(), tmpdircxyz,
            query.num_feats(), query.feat_type.data(), query.feat_xyz[i].data(), query.num_dircs(),
            query.dirc_type.data(), query.dirc_xyz[i].data(), changeCords, equalR, w1, cVol);

        if (tmpVol > maxVol) {
            maxVol = tmpVol;
            for (auto j = 0; j < db.heavy_atom_number; j++) {
                // query template is the first start orientation, so the database
                // mols should change to the first start orientation
                for (auto k : boost::irange(3))
                    cxyz[j * 3 + k] = trans_matrix[i][k] * tmpxyz[j * 3 + k];
            }
        }
    }
    //
    // target molecule changes back to original,
    // and others molecules should also do this
    //
    // rotation

    double rTmp[3][3];
    for (auto i = 0; i < 3; i++) {
        for (auto j = 0; j < 3; j++) rTmp[i][j] = query.rotMatrix[i][j];
    }

    for (auto j = 0; j < db.heavy_atom_number; j++) {
        Rotation(&cxyz[j * 3], rTmp, &tmpxyz[j * 3]);
    }
    // translate
    for (auto j = 0; j < db.heavy_atom_number; j++) {
        auto j3 = j * 3;
        tmpxyz[j3] += query.transVector[0];
        tmpxyz[j3 + 1] += query.transVector[1];
        tmpxyz[j3 + 2] += query.transVector[2];
    }

    setFragXYZ(db.frag.get(), tmpxyz, onlyHeavyAtoms);
    writeMFCFrag2SD(db.frag.get(), os, onlyHeavyAtoms);
}

void QueryItem::generate_other_orientation(QueryItem& q, int numFeats, int numDircPoints) {
    for (int i = SO2; i < NUM_SO; ++i) {
        q.feat_xyz[i].resize(numFeats * 3);
        q.dirc_xyz[i].resize(numDircPoints * 3);
        for (auto k : boost::irange(3)) {
            for (auto j = 0; j < numFeats; j++) {
                q.feat_xyz[i][3 * j + k] = trans_matrix[i][k] * q.feat_xyz[SO1][3 * j + k];
            }
            for (auto j = 0; j < numDircPoints; j++) {
                q.dirc_xyz[i][3 * j + k] = trans_matrix[i][k] * q.dirc_xyz[SO1][3 * j + k];
            }
        }
    }
}

QueryItem QueryItem::process_query(unique_ptr<MFCFrag>&& frag, PharmacophoreGraph& pharmacophore) {
    QueryItem q;
    setMFCAtomVDW(frag.get());
    RingDecomposerLib_findSSSR(frag);
    //
    // Find aromatic rings
    //
    setRingAtomFlags(frag.get());
    setHybridization(frag.get());
    clearringBondMap();
    //
    // Set ideal bond length according to atom and bond type
    //
    SetBondLength(frag.get());
    setFragnH(frag.get());

    auto nSpheres = getNSpheres(frag.get(), onlyHeavyAtoms);
    q.xyz[SO1].resize(nSpheres * 3);
    double vdwR[nSpheres];
    getFragXYZVDWR(frag.get(), q.xyz[SO1].data(), vdwR, onlyHeavyAtoms, equalR);

    q.heavy_atom_number = nSpheres;

    // save old coordinates
    double xyzOld[nSpheres * 3];
    for (int i = 0; i < nSpheres; i++) {
        for (auto j : boost::irange(3)) xyzOld[3 * i + j] = q.xyz[SO1][3 * i + j];
    }

    q.weight.resize(nSpheres);
    q.alpha.resize(nSpheres);

    double gVols[nSpheres * (nSpheres + 1) / 2];
    auto molvol = calMolSelfVolGS(nSpheres, q.xyz[SO1].data(), vdwR, q.weight.data(), gVols,
                                  q.alpha.data(), true, equalR);

    // change back trans vector and rotation matrix
    double Eout[3];
    initTransAndRotation(nSpheres, q.xyz[SO1].data(), q.alpha.data(), q.weight.data(), gVols,
                         q.transVector.data(), Eout, equalR, initR);

    // calculate rotation matrix to rotate back
    for (auto i = 0; i < nSpheres; i++)
        for (auto j : boost::irange(3)) xyzOld[3 * i + j] -= q.transVector[j];

    double tmpXYZ[nSpheres * 3];
    boost::copy(q.xyz[SO1], tmpXYZ);

    double rTmp[3][3];
    superpose(xyzOld, tmpXYZ, nSpheres, rTmp);
    for (auto i : boost::irange(3))
        for (auto j : boost::irange(3)) q.rotMatrix[i][j] = rTmp[i][j];

    for (int i = SO2; i < NUM_SO; ++i) {
        q.xyz[i].resize(nSpheres * 3);
        for (auto j = 0; j < nSpheres; j++)
            for (auto k : boost::irange(3))
                q.xyz[i][3 * j + k] = trans_matrix[i][k] * q.xyz[SO1][3 * j + k];
    }
    //
    // get pharma features
    //

    std::vector<PharmaFeature*> allFeatures;
    setFragXYZ(frag.get(), q.xyz[SO1].data(), onlyHeavyAtoms);

    std::unique_ptr<ChemGraph> TGraph{Frag2Graph(frag.get())};
    std::cout << "mapAllFeature_Opt 03\n";
    mapAllFeature_Optimize(frag, allFeatures, pharmacophore, TGraph);

    for (auto feat : allFeatures) {
        q.feat_type.push_back(feat->fType);
        q.feat_xyz[SO1].push_back(feat->x1);
        q.feat_xyz[SO1].push_back(feat->y1);
        q.feat_xyz[SO1].push_back(feat->z1);
        if (4 > feat->fType) {
            q.dirc_type.push_back(feat->fType);
            q.dirc_xyz[SO1].push_back(feat->x2);
            q.dirc_xyz[SO1].push_back(feat->y2);
            q.dirc_xyz[SO1].push_back(feat->z2);
        }
    }

    generate_other_orientation(q, q.num_feats(), q.num_dircs());

    for (auto feat : allFeatures) {
        delete feat;
    }

    //
    // calculate self volume of each type of feature
    // For HBA,HBD,ARO, two volumes (one is for feature, the other is for dirction) are
    // considered selfVol[0] is the mol self volume, the others are feature self volumes
    //
    q.fragSelfVol[0] = molvol;
    for (auto i = 1; i < 10; i++) q.fragSelfVol[i] = 0;

    calSelfVolFeature_ownPharma(q.num_feats(), q.feat_type.data(), q.feat_xyz[SO1].data(),
                                q.num_dircs(), q.dirc_type.data(), q.dirc_xyz[SO1].data(),
                                q.fragSelfVol.data());

    q.frag = std::move(frag);
    return q;
}
std::vector<QueryItem> QueryItem::read_query(
    boost::iostreams::mapped_file_source::iterator source_begin,
    boost::iostreams::mapped_file_source::iterator source_end, PharmacophoreGraph& pharmacophore) {
    std::vector<QueryItem> queries;
    //
    // save query molecule after overlay
    //
    SDReaderT<MMapStream> sdReader(source_begin, source_end);
    do {
        auto b = sdReader.fin.get_cursor();
        std::unique_ptr<MFCFrag> frag{sdReader.readLargestMFCFrag()};
        if (frag != nullptr) {
            auto q = process_query(std::move(frag), pharmacophore);
            q.begin = b;
            q.end = sdReader.fin.get_cursor();
            queries.push_back(std::move(q));
        }
    } while (!sdReader.endOfSD());
    return queries;
}
std::vector<QueryItem> QueryItem::read_query(const string& qsd_filename,
                                             PharmacophoreGraph& pharmacophore) {
    boost::iostreams::mapped_file_source source(qsd_filename);
    return read_query(source.begin(), source.end(), pharmacophore);
}

double calc_similarity(QueryItem& lhs, QueryItem& rhs) {
	std::cout << "calc_similarity lhs rhs no weight\n";
    constexpr auto changeCords = true;
    double w1[10]{1.0,
                  1.0,   // HBA in ownPharma
                  1.0,   // HBD
                  0.5,   // ARO
                  2.0,   // POS
                  2.0,   // NEG
                  2.0,   // HYD
                  1.0,   // for direction of HBA in overlay
                  1.0,   // for direction of HBD
                  0.5};  // for direction of ARO

    double w2[10]{1.0, 1.0, 1.0, 0.5, 2.0, 2.0, 2.0,
                  1.0,   // for direction of HBA in scoring
                  1.0,   // for direction of HBD
                  0.5};  // for direction of ARO

    double tmpxyz[lhs.heavy_atom_number * 3];
    double tmpfeatxyz[lhs.num_feats() * 3 + 1];
    double tmpdircxyz[lhs.num_dircs() * 3 + 1];

    auto maxVol = 0.0;

    //
    // cross volume for shape and 6 kinds of features(2 volumes for HBA,HBD,ARO)
    //
    double cVol[10];
    double cVolTmp[10];

    for (int i = SO1; i < NUM_SO; ++i) {
        boost::copy(lhs.xyz[SO1], tmpxyz);
        boost::copy(lhs.feat_xyz[SO1], tmpfeatxyz);
        boost::copy(lhs.dirc_xyz[SO1], tmpdircxyz);

        auto tmpVol = overlayFGSpheres_ourPharma(
            lhs.heavy_atom_number, tmpxyz, lhs.alpha.data(), lhs.weight.data(),
            rhs.heavy_atom_number, rhs.xyz[i].data(), rhs.alpha.data(), rhs.weight.data(),
            lhs.num_feats(), lhs.feat_type.data(), tmpfeatxyz, lhs.num_dircs(),
            lhs.dirc_type.data(), tmpdircxyz, rhs.num_feats(), rhs.feat_type.data(),
            rhs.feat_xyz[i].data(), rhs.num_dircs(), rhs.dirc_type.data(), rhs.dirc_xyz[i].data(),
            changeCords, equalR, w1, cVolTmp);

        if (tmpVol > maxVol) {
            maxVol = tmpVol;
            boost::copy(cVolTmp, cVol);
        }
    }

    // shapeScore + featureScore
    double shapeScore = cVol[0] / (lhs.fragSelfVol[0] + rhs.fragSelfVol[0] - cVol[0]);
    if (shapeScore > 1.0) shapeScore = 1.0;

    double featCVol = 0.0;
    double featselfVol = 0.0;
    double featqselfVol = 0.0;
    for (int j = 1; j < 10; j++) {
        featCVol += cVol[j] * w2[j];
        featselfVol += lhs.fragSelfVol[j] * w2[j];
        featqselfVol += rhs.fragSelfVol[j] * w2[j];
    }
    double featScore = featCVol / (featselfVol + featqselfVol - featCVol);
    if (featScore > 1.0) featScore = 1.0;

    auto simi = sqrt((shapeScore * shapeScore + featScore * featScore) / 2.0);
    if (simi > 1.0) simi = 1.0;

    return simi;
}

void mapAllFeature_Optimize(MFCFrag* frag, vector<PharmaFeature*>& allFeatures,
                            PharmacophoreGraph& pharmacophore, unique_ptr<ChemGraph>& TGraph) {
    mapHBA_Optimize(frag, allFeatures, pharmacophore.HBA_exclusive, TGraph.get());
    mapHBD_Optimize(frag, allFeatures, pharmacophore.HBD_exclusive, TGraph.get());
    mapARO(frag, allFeatures);
    mapPOS_Optimize(frag, allFeatures, pharmacophore.POS_included, TGraph.get());
    mapNEG_Optimize(frag, allFeatures, pharmacophore.NEG_included, TGraph.get());
    mapHYD(frag, allFeatures);
    printFeature(allFeatures);
}

}  // namespace MISS::Optimize
