//
// Created by xiamr on 9/16/20.
//

#ifndef ALPHACS_UTILS_HPP
#define ALPHACS_UTILS_HPP

#include "config.hpp"

#include <algorithm>
#include <chrono>
#include <functional>
#include <iostream>
#include <vector>

#include <boost/filesystem.hpp>
#include <boost/range/adaptors.hpp>
#include <boost/range/algorithm/copy.hpp>

#include "ForceField/ffUtil.h"
#include "ForceField/mfcFF.h"
#include "GShape/gaussian.h"
#include "GShape/mfcGShape.hpp"
#include "IO/ASStructure.hpp"
#include "IO/SQLiteSchema.hpp"
#include "Misc/fragment2D.h"
#include "Misc/ssdUtil.h"
#include "MolStructure/canonUtil.h"
#include "MolStructure/mfcMolecule.h"
#include "MolStructure/stereo.h"
#include "Singleton/params.h"
#include "Topology/chemgraph.h"
#include "Topology/topology.h"
#include "Utils/mathUtil.hpp"
#include "Utils/mfcUtil.hpp"

constexpr bool onlyHeavyAtoms = true;

namespace MISS::Optimize {

std::vector<std::tuple<std::size_t, std::unique_ptr<GDFSPath>>> read_exclusive_included_graph(
    const std::string& filename, std::string_view data_str);

struct PharmacophoreGraph {
    std::vector<std::tuple<std::size_t, std::unique_ptr<GDFSPath>>> HBA_exclusive, HBD_exclusive,
        POS_included, NEG_included;
};

PharmacophoreGraph load_pharmacophore_graph();
//
// assume that only index of heavy atoms are considered
//

std::vector<int> BTMappingForPh4_Optimize(GDFSPath* qpath, ChemGraph* tgraph, int Idx);

std::vector<int> subSearch_Optimize(std::tuple<std::size_t, std::unique_ptr<GDFSPath>>& gpath,
                                    MFCFrag* tfrag, int Idx, ChemGraph* TGraph);

void mapHBA_Optimize(
    MFCFrag* Frag, std::vector<PharmaFeature*>& HBA,
    std::vector<std::tuple<std::size_t, std::unique_ptr<GDFSPath>>>& exclude_group_graph,
    ChemGraph* TGraph);

void mapHBD_Optimize(
    MFCFrag* Frag, std::vector<PharmaFeature*>& HBD,
    std::vector<std::tuple<std::size_t, std::unique_ptr<GDFSPath>>>& exclude_group_graph,
    ChemGraph* TGraph);

void mapPOS_Optimize(
    MFCFrag* Frag, std::vector<PharmaFeature*>& POS,
    std::vector<std::tuple<std::size_t, std::unique_ptr<GDFSPath>>>& included_group_graph,
    ChemGraph* TGraph);

void mapNEG_Optimize(
    MFCFrag* Frag, std::vector<PharmaFeature*>& NEG,
    std::vector<std::tuple<std::size_t, std::unique_ptr<GDFSPath>>>& included_group_graph,
    ChemGraph* TGraph);

void mapAllFeature_Optimize(MFCFrag* frag, std::vector<PharmaFeature*>& allFeatures,
                            PharmacophoreGraph& pharmacophore, std::unique_ptr<ChemGraph>& TGraph);

inline void mapAllFeature_Optimize(std::unique_ptr<MFCFrag>& frag,
                                   std::vector<PharmaFeature*>& allFeatures,
                                   PharmacophoreGraph& pharmacophore,
                                   std::unique_ptr<ChemGraph>& TGraph) {
    mapAllFeature_Optimize(frag.get(), allFeatures, pharmacophore, TGraph);
}

AS::Molecule::Conformation transform_to_conf(MFCFrag* frag, PharmacophoreGraph& pharmacophore,
                                             bool getW, bool initR);

enum { SO1, SO2, SO3, SO4 };
constexpr auto NUM_SO = 4;

class QueryItem;

class DBItem {
public:
    friend void overlay(DBItem& db, QueryItem& query, std::ostream& os);
    static DBItem process_db(std::unique_ptr<MFCFrag>&& frag, PharmacophoreGraph& pharmacophore);

private:
    std::unique_ptr<MFCFrag> frag;
    int heavy_atom_number;
    std::vector<double> xyz;

    std::vector<double> wt;
    std::vector<double> alpha;

    int num_feats() { return feat_types.size(); };
    std::vector<int> feat_types;
    std::vector<double> feat_xyz;

    int num_dircs() { return dirc_types.size(); };
    std::vector<int> dirc_types;
    std::vector<double> dirc_xyz;
};

template <bool changeCords = false>
auto calc_similarity(AS::Molecule::Conformation& db, QueryItem& rhs, double* w);

class QueryItem {
public:
    friend void overlay(DBItem& db, QueryItem& query, std::ostream& os);
    friend double calc_similarity(QueryItem& lhs, QueryItem& rhs);

    template <bool>
    friend auto calc_similarity(AS::Molecule::Conformation& db, QueryItem& rhs, double* w);

    static std::vector<QueryItem> read_query(const std::string& qsd_filename,
                                             PharmacophoreGraph& pharmacophore);

    static std::vector<QueryItem> read_query(
        boost::iostreams::mapped_file_source::iterator source_begin,
        boost::iostreams::mapped_file_source::iterator source_end,
        PharmacophoreGraph& pharmacophore);

    friend std::ostream& operator<<(std::ostream& os, const QueryItem& q) {
        std::copy(q.begin, q.end, std::ostream_iterator<char>(os));
        return os;
    }

    [[nodiscard]] const std::string& get_name() const { return frag->fragname; }

private:
    static QueryItem process_query(std::unique_ptr<MFCFrag>&& frag,
                                   PharmacophoreGraph& pharmacophore);
    static void generate_other_orientation(QueryItem& q, int numFeats, int numDircPoints);

    boost::iostreams::mapped_file_source::iterator begin, end;

    std::unique_ptr<MFCFrag> frag;
    std::array<std::vector<double>, NUM_SO> xyz;

    std::vector<double> weight;
    std::vector<double> alpha;
    int heavy_atom_number;

    // for changing target molecule back to its original coordinated
    std::array<double, 3> transVector{};
    std::array<std::array<double, 3>, 3> rotMatrix{};

    // for features
    int num_feats() { return feat_type.size(); };
    std::vector<int> feat_type;
    std::array<std::vector<double>, NUM_SO> feat_xyz;

    int num_dircs() { return dirc_type.size(); };
    std::vector<int> dirc_type;
    std::array<std::vector<double>, NUM_SO> dirc_xyz;

    std::array<double, 10> fragSelfVol{};
};

void overlay(DBItem& db, QueryItem& query, std::ostream& os);
double calc_similarity(QueryItem& lhs, QueryItem& rhs);

extern int trans_matrix[4][3];

template <bool changeCords = false>
auto calc_similarity(AS::Molecule::Conformation& db, QueryItem& rhs, double* w) {
	std::cout << "db_conf Query calc_similarity\n";
    double* w1 = w;

    double* w2 = w + 10;
    const auto heavy_atom_number = db.coordinates.size();
    std::vector<double> tmpxyz(heavy_atom_number * 3);
    double tmpfeatxyz[(db.get_num_feats() - db.get_num_dircs()) * 3 + 1];
    double tmpdircxyz[db.get_num_dircs() * 3 + 1];

    auto maxVol = 0.0;

    //
    // cross volume for shape and 6 kinds of features(2 volumes for HBA,HBD,ARO)
    //
    double cVol[10];
    double cVolTmp[10];
    double cxyz[heavy_atom_number * 3];

    for (int i = SO1; i < NUM_SO; ++i) {
        std::copy_n(db.coordinates.data()->data(), db.coordinates.size() * 3, tmpxyz.data());
        std::copy_n(db.pharmaFeatures.data()->data(), (db.get_num_feats() - db.get_num_dircs()) * 3,
                    tmpfeatxyz);
        std::copy_n(
            db.pharmaFeatures.data()->data() + (db.get_num_feats() - db.get_num_dircs()) * 3,
            db.get_num_dircs() * 3, tmpdircxyz);

        double wt[heavy_atom_number];
        double alpha[heavy_atom_number];
        double vdwR[heavy_atom_number];
        std::fill_n(vdwR, heavy_atom_number, 1.8);
        double gVols[heavy_atom_number * (heavy_atom_number + 1) / 2];
        calMolSelfVolGS(heavy_atom_number, tmpxyz.data(), vdwR, wt, gVols, alpha, true, true);

        std::vector<int> feat_type, dirc_type;

        for (const auto& [fType, feat_number] :
             db.pharma_feature_numbers | boost::adaptors::indexed(1)) {
            {
                auto t = feat_number;
                while (t--) feat_type.push_back(fType);
            }

            if (4 > fType) {
                auto t = feat_number;
                while (t--) dirc_type.push_back(fType);
            }
        }

        auto tmpVol = overlayFGSpheres_ourPharma(
            heavy_atom_number, tmpxyz.data(), alpha, wt, rhs.heavy_atom_number, rhs.xyz[i].data(),
            rhs.alpha.data(), rhs.weight.data(), db.get_num_feats() - db.get_num_dircs(),
            feat_type.data(), tmpfeatxyz, db.get_num_dircs(), dirc_type.data(), tmpdircxyz,
            rhs.num_feats(), rhs.feat_type.data(), rhs.feat_xyz[i].data(), rhs.num_dircs(),
            rhs.dirc_type.data(), rhs.dirc_xyz[i].data(), changeCords, true, w1, cVolTmp);

        if (tmpVol > maxVol) {
            maxVol = tmpVol;
            boost::copy(cVolTmp, cVol);
            if constexpr (changeCords) {
                for (auto j = 0; j < heavy_atom_number; j++) {
                    // query template is the first start orientation, so the database
                    // mols should change to the first start orientation
                    for (auto k : boost::irange(3))
                        cxyz[j * 3 + k] = trans_matrix[i][k] * tmpxyz[j * 3 + k];
                }
            }
        }
    }

    // shapeScore + featureScore
    double shapeScore = cVol[0] / (db.vol + rhs.fragSelfVol[0] - cVol[0]);
    if (shapeScore > 1.0) shapeScore = 1.0;

    double featCVol = 0.0;
    double featselfVol = 0.0;
    double featqselfVol = 0.0;
    for (int j = 1; j < 10; j++) {
        featCVol += cVol[j] * w2[j];
        featselfVol += db.selfVol[j - 1] * w2[j];
        featqselfVol += rhs.fragSelfVol[j] * w2[j];
    }
    double featScore = featCVol / (featselfVol + featqselfVol - featCVol);
    if (featScore > 1.0) featScore = 1.0;

    auto simi = sqrt((shapeScore * shapeScore + featScore * featScore) / 2.0);
    if (simi > 1.0) simi = 1.0;

    if constexpr (changeCords) {
        double rTmp[3][3];
        for (auto i = 0; i < 3; i++) {
            for (auto j = 0; j < 3; j++) rTmp[i][j] = rhs.rotMatrix[i][j];
        }

        for (auto j = 0; j < heavy_atom_number; j++) {
            Rotation(&cxyz[j * 3], rTmp, &tmpxyz[j * 3]);
        }
        // translate
        for (auto j = 0; j < heavy_atom_number; j++) {
            auto j3 = j * 3;
            tmpxyz[j3] += rhs.transVector[0];
            tmpxyz[j3 + 1] += rhs.transVector[1];
            tmpxyz[j3 + 2] += rhs.transVector[2];
        }

        return std::tuple{simi, tmpxyz};
    } else
        return simi;
}

}  // namespace MISS::Optimize

template <typename T>
void check(const T& filename) {
    if (not boost::filesystem::exists(filename)) {
        std::cerr << "FILE <" << filename << "> doesn't exists !" << std::endl;
        std::exit(EXIT_FAILURE);
    }
}

#endif  // ALPHACS_UTILS_HPP
