
#include "config.hpp"

#include <chrono>
#include <csignal>  // ::signal, ::raise
#include <cstring>
#include <ctime>
#include <iostream>
#include <sstream>

#include <boost/algorithm/string.hpp>
#include <boost/stacktrace.hpp>

#include "Utils/ProgramConfiguration.hpp"

std::unique_ptr<ProgramConfiguration> program_configuration;

static void alphas_signal_handler(int signum) {
    ::signal(signum, SIG_DFL);
    std::time_t now = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
    std::stringstream ss;
    ss << std::ctime(&now);
    std::cerr << "[signum = " << signum << ", " << strsignal(signum) << "] Stack Backtrace ("
              << boost::trim_copy(ss.str()) << "):\n"
              << boost::stacktrace::stacktrace() << std::flush;
    std::exit(EXIT_FAILURE);
}

void register_signals() {
    ::signal(SIGSEGV, &alphas_signal_handler);
    ::signal(SIGABRT, &alphas_signal_handler);
    ::signal(SIGILL, &alphas_signal_handler);
    ::signal(SIGFPE, &alphas_signal_handler);
}
