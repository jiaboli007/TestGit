//
// Created by xiamr on 9/16/20.
//

#ifndef ALPHACS_CONFIG_HPP
#define ALPHACS_CONFIG_HPP

#include <memory>

constexpr auto MAX_DB_ATOM_NUMBER = 64;
constexpr auto MAX_DB_FEATURE_NUMBER = 100;

constexpr auto MAX_QUERY_ATOM_NUMBER = 100;
constexpr auto MAX_QUERY_FEATURE_NUMBER = 100;

constexpr auto SDF_SPLIT_CHUNK_SIZE = 2'000'000L;

constexpr auto grpSize = 32;

constexpr auto HBA_Exclude_FILE = "HBA_Exclude.sdf";
constexpr auto HBD_Exclude_FILE = "HBD_Exclude.sdf";
constexpr auto POS_Included_FILE = "POS_Included.sdf";
constexpr auto NEG_Included_FILE = "NEG_Included.sdf";

constexpr auto AlphaS_Result_File_Application_ID = 0x6f42cd21;
constexpr auto AlphaS_Index_File_Application_ID = 0x089f2254;

class ProgramConfiguration;
extern std::unique_ptr<ProgramConfiguration> program_configuration;

void register_signals();

#endif  // ALPHACS_CONFIG_HPP
